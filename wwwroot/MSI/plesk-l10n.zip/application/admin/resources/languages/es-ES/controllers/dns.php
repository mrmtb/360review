<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'acl-records.title' => 'Plantilla de restricciones de transferencia',

    'add-acl-record.title' => 'Añadir dirección IP',
    'add-acl-record.success' => 'Las direcciones IP indicadas se han añadido correctamente.',

    'delete-acl-record.success' => 'Las direcciones IP seleccionadas se han eliminado correctamente.',

    'index.title' => 'Configuración DNS',

    'records.title' => 'Plantilla de registros de zona',

    'reset-settings.success' => 'La configuración predeterminada se ha restaurado correctamente.',

    'settings.title' => 'Configuración a nivel del servidor',
    'settings.success' => 'La configuración se ha actualizado correctamente.',

    'soa-record.title' => 'Plantilla de configuración de zona',

    'restore-default.title' => 'Restaurar la plantilla predeterminada de zona DNS',
    'restore-default.text' => 'Confirme que desea restaurar la configuración predeterminada de la plantilla de zona DNS.',

    'soa-sync.title' => 'Reemplazar la configuración SOA para todos los dominios existentes',
    'soa-sync.text' => '¿Desea actualizar los registros SOA de todos los dominios alojados aplicando los cambios efectuados a la plantilla SOA?',

    'sync.title' => 'Aplicar cambios de plantilla DNS',
    'sync.type-option' => 'Seleccione una de las siguientes opciones',
    'sync.safe' => 'Aplicar los cambios a las zonas sin modificar. Si una zona fue personalizada (se añadieron registros nuevos o se modificó algún registro existente), Plesk no aplicará los cambios de la plantilla a dichas zonas.',
    'sync.force' => 'Aplicar los cambios a todas las zonas. Plesk aplicará los cambios de la plantilla a todas las zonas DNS, incluyendo las personalizadas. Tenga en cuenta que los registros modificados por los usuarios siempre permanecerán intactos. Por ejemplo, si la plantilla contiene un registro nuevo que ya había sido añadido por un cliente, Plesk conservará el registro del cliente.',

    'external-dns.title' => 'DNS externo',
    'external-dns.hint' => 'Aquí puede configurar servidores DNS externos',
    'external-dns.success' => 'Guardada',
    'external-dns.configured' => 'Configurado',
    'external-dns.notConfigured' => 'No configurado',
    'external-dns.useExtension' => 'Usar esta extensión',

    'external-dns-edit.title' => 'DNS externo',
];