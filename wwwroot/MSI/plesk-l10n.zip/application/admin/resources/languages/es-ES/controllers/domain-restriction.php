<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Añadir un nombre de dominio',
    'add.domainAdded' => 'El nombre de dominio %%domain%% se añadió correctamente a la lista de nombres prohibidos.',

    'disable.listDisabled' => 'La comprobación de nombres de dominio prohibidos ha sido desactivada.',

    'edit.title' => '%%name%%',
    'edit.domainUpdated' => 'El nombre de dominio %%domain%% se ha actualizado correctamente.',

    'enable.listEnabled' => 'La comprobación de nombres de dominio prohibidos ha sido activada.',

    'list.title' => 'Nombres de dominio prohibidos',
    'list.hint' => 'Aquí puede administrar la lista de nombres de dominio prohibidos, que contiene los dominios más populares. Si activa la comprobación de nombres de dominio prohibidos haciendo clic en Activar, los usuarios no podrán crear dominios con los nombres presentes en esta lista. Esta restricción puede resultarle útil para impedir la intercepción de correos electrónicos. Si dicha comprobación está desactivada, los correos enviados por sus clientes a empresas legítimas puede que sean recibidos por los clientes que crearon dominios con los mismos nombres que dichas empresas.',
    'list.warningLisDisabled' => 'La comprobación de nombres de dominio prohibidos está desactivada.',

    'remove.domainRemoved' => 'Los nombres de dominio seleccionados han sido eliminados.',
    'remove.domainNotRemoved' => 'Algunos de los nombres de dominio seleccionados no han sido eliminados.',
    'remove.unableRemove' => 'Algunos de los nombres de dominio especificados no han sido eliminados.',
];