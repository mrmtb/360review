<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'oversell-policy.title' => 'Cambio de la directiva de sobreventa de recursos',
    'oversell-policy.pageHint' => 'Aquí puede modificar la directiva de sobreventa de recursos actual.',
    'oversell-policy.oversellPolicyChanged' => 'La directiva de sobreventa de recursos ha sido actualizada correctamente.',
    'oversell-policy.oversellPolicyNotChanged' => 'La directiva de sobreventa de recursos no puede ser actualizada.',

    'subscription-overview.title' => 'Descripción de la suscripción',
    'subscription-overview.pageHint' => 'Esta es la descripción general de su suscripción. Esta incluye la información acerca de la cantidad de recursos usados en contraposición con los proporcionados, así como la directiva de sobreventa de recursos y los privilegios y servicios proporcionados con la suscripción.',
    'subscription-overview.changeOversellPolicyLink' => '[cambiar]',
    'subscription-overview.oversellEnabledHint' => 'Su suscripción permite la sobreventa de recursos, lo que significa que usted puede vender más recursos que la cantidad asignada con su suscripción. En este caso, usted se regirá por el uso actual de recursos, en vez de por la asignación inicial de recursos.',
    'subscription-overview.oversellDisableHint' => 'Su suscripción prohíbe la sobreventa de recursos, lo que significa que usted solo puede vender tantos recursos como los asignados inicialmente con la suscripción, sin importar cuántos de ellos esté utilizando en este momento.',
    'subscription-overview.tabResources' => 'Recursos',
    'subscription-overview.tabPermissions' => 'Permisos',
    'subscription-overview.resourcesSummaryHint' => 'Aquí puede ver un resumen del uso de los recursos proporcionados con la suscripción.',
    'subscription-overview.showMoreResources' => 'Mostrar más recursos disponibles',
    'subscription-overview.hideMoreResources' => 'Mostrar menos recursos',
    'subscription-overview.permissionsSummaryHint' => 'Aquí puede ver una lista de los servicios y privilegios proporcionados con la suscripción.',
    'subscription-overview.hideMorePermissions' => 'Mostrar menos permisos',
    'subscription-overview.showMorePermissions' => 'Mostrar más permisos',
];