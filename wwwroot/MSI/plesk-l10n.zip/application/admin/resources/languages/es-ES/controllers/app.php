<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'clear-cache.apsCacheCleared' => 'Los archivos temporales han sido eliminados.',

    'configure.title' => '%%name%%',
    'configure.applicationNotFound' => "No se ha encontrado la app con ID '%%id%%'.",
    'configure.applicationHasNoSettings' => 'La app no tiene configuración.',
    'configure.settingsUpdated' => 'La configuración de la aplicación ha sido actualizada.',
    'configure.settingsUpdateFailed' => 'Error al actualizar la configuración de la aplicación: %%error%%',
    'configure.instancesNotReconfigured' => 'Algunas de las instancias de la app no se reconfiguraron.',

    'index.title' => 'Application Vault',

    'info.title' => '%%name%%',
    'info.hint' => 'La lista que aparece a continuación muestra la información acerca de los sitios web donde se ha instalado la aplicación. El valor Ninguno en la columna Sitio web significa que la aplicación es externa. Este tipo de aplicación no puede instalarse en el sitio web de un determinado cliente y únicamente proporciona un vínculo a un servicio externo.',

    'remote-app-info.title' => 'Detalles de la aplicación',

    'update-settings.title' => 'Configuración de actualización',
    'update-settings.settingsUpdated' => 'La configuración ha sido actualizada.',
    'update-settings.settingsUpdateFailed' => 'No se puede actualizar la configuración:%%error%%',

    'upload.title' => 'Añadir app',
    'upload.packageInstallationError' => 'No se ha podido añadir la aplicación: %%message%%.',
    'upload.appUploaded' => 'La app se ha cargado correctamente.',
    'upload.appDownloadStarted' => 'Descargando las aplicaciones seleccionadas.',

    'uploaded.title' => 'Mis aplicaciones',
    'uploaded.hint' => 'Aquí puede añadir o eliminar aplicaciones del Application Vault, así como administrar la disponibilidad de las aplicaciones para los clientes. La adición de aplicaciones permite ampliar la lista de aplicaciones disponibles y configurar parámetros a nivel del servidor para dichas aplicaciones. Tenga en cuenta que algunas aplicaciones no pueden instalarse sin esta configuración. A continuación se detallan todas las aplicaciones añadidas.',
    'uploaded.infoAppDeleted' => 'Las apps seleccionadas han sido eliminadas.',
    'uploaded.infoAppNotDeleted' => 'Algunas de las aplicaciones seleccionadas no han sido eliminadas.',
    'uploaded.applicationsNowAvailable' => 'Ahora sus clientes ya pueden instalar o configurar las aplicaciones seleccionadas.',
    'uploaded.applicationsNowNotAvailable' => 'Sus clientes ya no pueden instalar o configurar las aplicaciones seleccionadas.',
    'uploaded.cantChangePackageProperties' => 'Se ha producido un error cuando se intentaba cambiar la configuración de disponibilidad de la aplicación.',
    'uploaded.appDownloaded' => 'Las aplicaciones seleccionadas se han descargado correctamente.',
    'uploaded.appNotDownloaded' => 'No se descargaron algunas de las aplicaciones seleccionadas.',
    'uploaded.downloadInProgress' => 'Espere...',

    'usage.title' => 'Apps instaladas',
    'usage.hint' => 'La lista que aparece a continuación muestra todas las aplicaciones añadidas por usted o instaladas por sus clientes. Aquí puede administrar la configuración de las aplicaciones, buscar actualizaciones o eliminar archivos temporales añadidos durante las instalaciones de aplicaciones.',
    'usage.hintReseller' => 'La lista que aparece a continuación muestra la información acerca de todas las instalaciones de aplicaciones en sus sitios y en los sitios de sus clientes. Haga clic en el nombre de una aplicación para examinar la lista de sitios web que tienen instalada esta aplicación y para comprobar la existencia de actualizaciones para la aplicación.',
];