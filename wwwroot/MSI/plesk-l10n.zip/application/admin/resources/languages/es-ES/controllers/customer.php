<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-domain-alias.noDomains' => 'No se ha podido crear un alias. No hay dominios disponibles.',

    'add-domain.noDomains' => 'No se ha podido crear un dominio complementario. No hay dominios disponibles.',

    'add-subdomain.noDomains' => 'No se ha podido crear un subdominio. No hay dominios disponibles.',

    'change-owner.wrongOwnerId' => 'No se pudo encontrar el nuevo propietario de la cuenta de cliente.',

    'change.title' => 'Cambio del plan y de los complementos asociados con las suscripciones',

    'create.title' => 'Adición de un cliente nuevo',

    'domains.title' => 'Dominios',

    'list.title' => 'Clientes',
    'list.infoNewCustomerCreated' => 'El cliente %%name%% ha sido creado.',
    'list.infoCustomerActivated' => 'Los clientes seleccionados han sido activados.',
    'list.infoCustomerNotActivated' => 'Algunos de los clientes seleccionados no han sido activados.',
    'list.infoCustomerSuspended' => 'Los clientes seleccionados han sido suspendidos.',
    'list.infoCustomerNotSuspended' => 'Algunos de los clientes seleccionados no han sido suspendidos.',
    'list.infoCustomerDeleted' => 'Los clientes seleccionados han sido eliminados.',
    'list.infoCustomerNotDeleted' => 'Algunos de los clientes seleccionados no han sido eliminados.',
    'list.upgrageCustomersHint' => 'Ha actualizado a Plesk 11, que emplea un nuevo modelo de negocio y de clientes. Para completar el cambio al modelo nuevo, convierta las cuentas de cliente en cuentas de revendedor o de cliente. De no hacerlo, sus clientes no podrán crear sitios web aunque estos tuvieran este permiso anteriormente.',
    'list.upgrageCustomersLink' => 'Convierta cuenta de cliente.',
    'list.infoCustomerToResellerConverted' => 'Los clientes seleccionados se han convertido correctamente en revendedores.',
    'list.errorCustomerToResellerNotConverted' => 'Algunos de los clientes seleccionados no se han convertido en revendedores.',
    'list.infoOwnerChanged' => 'Los clientes seleccionados fueron transferidos a %%name%%.',
    'list.infoOwnerNotChanged' => 'Algunos de los clientes seleccionados no fueron transferidos a %%name%%.',

    'login-info.title' => 'Edición de la información de inicio de sesión de %%name%%',

    'overview.title' => '%%name%%',

    'personal-info.title' => 'Edición de la info de contacto de %%name%%',

    'subscriptions.title' => 'Suscripciones',
];