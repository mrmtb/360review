<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'eula.title' => 'Contrato de licencia del usuario final (EULA) de WebPros',
    'eula.popupTitle' => 'EULA',
    'eula.updatePopupTitle' => 'Actualización del EULA',
    'eula.popupDescription' => 'Lea la versión el EULA y acéptela para así poder seguir usando el producto.',
    'eula.updatePopupDescription' => 'El EULA de WebPros ha sido actualizado. Lee la versión el EULA y acéptela el EULA actualizado para así poder seguir usando el producto.',
    'eula.buttonAccept' => 'Aceptar',
    'eula.buttonDecline' => 'Rechazar',
];