<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-filter.title' => 'Añadir filtro de jail',
    'add-filter.filterAdded' => 'El filtro de jail ha sido añadido.',
    'add-filter.errorFilterNotAdded' => 'No se ha podido añadir el filtro jail: %%error%%.',

    'add-jail.title' => 'Añadir jail',
    'add-jail.jailAdded' => 'El jail ha sido añadido.',

    'add-trusted-ip.title' => 'Añadir una dirección IP de confianza',
    'add-trusted-ip.trustedListTitle' => 'Direcciones IP de confianza',
    'add-trusted-ip.ipAdded' => 'La dirección IP ha sido añadida a la lista de direcciones de confianza.',
    'add-trusted-ip.errorIpNotAdded' => 'No se ha podido añadir la dirección IP: %%error%%.',

    'edit-trusted-ip.title' => 'Editar la descripción para %%ip%%',
    'edit-trusted-ip.ipEdited' => 'La descripción de la dirección IP ha sido actualizada.',
    'edit-trusted-ip.ipAddressNotFound' => 'La dirección IP no ha sido encontrada en la lista de confianza.',
    'edit-trusted-ip.errorIpNotEdited' => 'No se ha podido editar la dirección IP: %%error%%.',

    'delete-banned-ips.infoBannedIpsDeleted' => 'Las direcciones IP seleccionadas han sido eliminadas de la lista de direcciones prohibidas.',
    'delete-banned-ips.infoBannedIpsNotDeleted' => 'No se pudieron eliminar algunas direcciones IP de la lista de direcciones prohibidas: %%error%%.',

    'delete-filters.infoFiltersDeleted' => 'Los filtros de jail seleccionados han sido eliminados.',
    'delete-filters.errorFiltersNotDeleted' => 'No se pudieron eliminar los filtros seleccionados: %%error%%.',
    'delete-filters.errorFiltersBuiltIn' => 'Los filtros integrados no pueden ser eliminados.',

    'delete-jail.infoJailDeleted' => 'El jail ha sido eliminado.',
    'delete-jail.errorJailNotDeleted' => 'No se pudo eliminar el jail: %%error%%.',
    'delete-jail.errorJailsBuiltIn' => 'Los jails integrados no pueden ser eliminados.',

    'delete-jails.infoJailsDeleted' => 'Los jails seleccionados han sido eliminados.',
    'delete-jails.errorJailsNotDeleted' => 'No se pudieron eliminar los jails seleccionados: %%error%%.',
    'delete-jails.errorJailsBuiltIn' => 'Los jails integrados no pueden ser eliminados.',

    'delete-trusted-ips.infoTrustedIpsDeleted' => 'Las direcciones IP seleccionadas han sido eliminadas de la lista de direcciones de confianza.',
    'delete-trusted-ips.infoTrustedIpsNotDeleted' => 'No se pudieron eliminar algunas direcciones IP de la lista de direcciones de confianza: %%error%%.',
    'delete-trusted-ips.warningTrustedIpsPresentOnInterfaces' => 'Algunas de las IPs de confianza eliminadas están presentes en interfaz(ces) de red: %%ips%%. Es posible que se prohíban de forma accidental, lo que ocasionaría problemas para acceder a los sitios o servicios.',

    'disable-jails.infoJailsDisabled' => 'Los jails seleccionados han sido desactivados.',
    'disable-jails.errorJailsNotDisabled' => 'No se pudieron desactivar los jails seleccionados: %%error%%.',

    'edit-filter.title' => 'Editar filtro de jail',
    'edit-filter.filterSaved' => 'El filtro de jail ha sido guardado.',
    'edit-filter.errorFilterNotSaved' => 'No se ha podido guardar el filtro jail: %%error%%.',
    'edit-filter.errorFilterNotEditable' => 'No se puede cambiar el filtro.',

    'edit-jail.title' => '%%name%%',
    'edit-jail.jailSaved' => 'La configuración del jail ha sido guardada.',
    'edit-jail.errorJailNotEditable' => 'No se puede cambiar el jail.',

    'enable-jails.infoJailsEnabled' => 'Los jails seleccionados han sido activados.',
    'enable-jails.errorJailsNotEnabled' => 'No se pudieron activar los jails seleccionados: %%error%%.',

    'filters-list.title' => 'Filtros de jail',

    'index.title' => 'Prohibición de direcciones IP',
    'index.banListTab' => 'Direcciones IP prohibidas',
    'index.trustedListTab' => 'Direcciones IP de confianza',
    'index.jailListTab' => 'Jails',
    'index.settingsTab' => 'Configuración',
    'index.logListTab' => 'Registros',
    'index.jailNotFound' => 'No se ha encontrado el jail %%name%%.',
    'index.filterNotFound' => 'No se ha podido encontrar el filtro %%name%%.',
    'index.logFileNotFound' => 'No se ha podido encontrar el archivo de registro.',
    'index.tooManyDomains' => 'Puede que Fail2Ban no funcione correctamente si existen demasiados dominios y Fail2Ban debe monitorizar demasiados archivos de registro.',
    'index.errorServiceFailed' => 'Error en el servicio de prohibición de direcciones IP (Fail2Ban). Como consecuencia, puede que este no funcione correctamente. %%link%%',
    'index.restartLink' => 'Intente reiniciarlo',

    'jail-list.failed' => 'No se pudo obtener la lista de jails: %%error%%.',

    'log-view.fileIsEmpty' => 'El archivo está vacío.',

    'move-to-trusted.infoTrustedIpsAdded' => 'Las direcciones IP seleccionadas han sido añadidas a la lista de direcciones de confianza.',
    'move-to-trusted.infoTrustedIpsNotAdded' => 'No se pudieron añadir algunas direcciones IP a la lista de direcciones de confianza: %%error%%.',

    'overview-jail.title' => '%%name%%',
    'overview-jail.pageHint' => 'Aquí puede ver la información detallada acerca del jail.',
    'overview-jail.buttonEditJail' => 'Cambiar configuración',
    'overview-jail.hintEditJail' => 'Cambie la configuración de este jail.',
    'overview-jail.buttonDisableJail' => 'Desactivar',
    'overview-jail.hintDisableJail' => 'Desactive este jail.',
    'overview-jail.buttonActivateJail' => 'Activar',
    'overview-jail.hintActivateJail' => 'Active este jail.',
    'overview-jail.buttonRemoveJail' => 'Eliminar',
    'overview-jail.hintRemoveJail' => 'Elimine este jail.',
    'overview-jail.fieldSatatus' => 'Estado',
    'overview-jail.fieldParameters' => 'Configuración',
    'overview-jail.enabled' => 'Activo',
    'overview-jail.disabled' => 'Inactivo',
    'overview-jail.banListHint' => 'Direcciones IP bloqueadas por este jail:',

    'restart.success' => 'El reinicio del servicio puede tardar unos minutos.',
    'restart.failed' => 'No se pudo reiniciar el servicio.',

    'settings.settingsSaved' => 'La configuración ha sido guardada.',
    'settings.errorSettingsNotSaved' => 'No se ha podido guardar la configuración: %%error%%.',
    'settings.errorServiceFailed' => 'Error del servicio de prohibición de direcciones IP (Fail2Ban): %%error%%',

    'toggle-jail.infoJailEnabled' => 'El jail ha sido activado.',
    'toggle-jail.infoJailDisabled' => 'El jail ha sido desactivado.',
    'toggle-jail.errorJailNotEnabled' => 'No se pudo activar el jail: %%error%%.',
    'toggle-jail.errorJailNotDisabled' => 'No se pudo desactivar el jail: %%error%%.',

    'add-banned-ip.title' => 'Prohibir dirección IP',
    'add-banned-ip.bannedListTitle' => 'Direcciones IP prohibidas',
    'add-banned-ip.ipAdded' => 'La dirección IP ha sido añadida a la lista de direcciones prohibidas.',
    'add-banned-ip.errorIpNotAdded' => 'No se ha podido prohibir la dirección IP: %%error%%.',
];