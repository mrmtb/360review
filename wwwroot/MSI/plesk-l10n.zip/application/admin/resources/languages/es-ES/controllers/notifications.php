<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Notificaciones',

    'email-settings.title' => 'Email',

    'panel-settings.title' => 'IU de Plesk',
    'panel-settings.notificationSettingsSaved' => 'La configuración de notificación se ha guardado correctamente.',

    'panel-notifications-toggle.successfullyEnabled' => 'La notificación \'%%title%%\' ha sido activada.',
    'panel-notifications-toggle.successfullyDisabled' => 'La notificación \'%%title%%\' ha sido desactivada.',

    'template-settings-list.hint' => 'Seleccione las notificaciones que desea ver activándolas y desactivándolas.',
    'template-settings-list.name' => 'Nombre',
    'template-settings-list.context' => 'Contexto',
    'template-settings-list.sendToAdmin' => 'Enviar al administrador',

    'template-settings-form.storagePeriod' => 'Periodo durante el que almacenar las notificaciones',
    'template-settings-form.days' => 'días',
];