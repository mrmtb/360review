<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'email.subjSuccess' => 'Plesk ser actualizó correctamente',
    'email.subjFailure' => 'Error al actualizar Plesk',
    'email.bodySuccess' => "¡Atención!\n\nPlesk se ha actualizado correctamente.\nSi desea ver la lista de cambios, visite %%link%%.\n\nEste mensaje ha sido enviado automáticamente por Plesk Installer.",
    'email.bodyFailure' => "¡Atención!\n\nSe ha producido un error al actualizar Plesk.\n\nPuede descargar los registros de Plesk Installer en el siguiente vínculo: %%link%%.\nPóngase en contacto con su proveedor de hosting para obtener soporte.\n\nEste mensaje ha sido enviado automáticamente por Plesk Installer.",
];