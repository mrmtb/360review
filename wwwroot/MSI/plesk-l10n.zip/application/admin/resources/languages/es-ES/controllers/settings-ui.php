<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'branding.title' => 'Personalización de Plesk',

    'disable-languages.disableLanguagesSuccess' => 'Los idiomas seleccionados ya no están disponibles para los usuarios.',

    'edit-controls.updateSuccess' => 'La configuración se ha actualizado correctamente.',

    'edit-interface-view.title' => 'Vistas de la interfaz',
    'edit-interface-view.updateSuccess' => 'La configuración se ha actualizado correctamente.',

    'enable-languages.enableLanguagesSuccess' => 'Los idiomas seleccionados están a disposición de los usuarios.',

    'language-make-default.languageMakeDefaultSuccess' => 'El idioma seleccionado se ha establecido como el idioma predeterminado de Plesk.',

    'list-languages.title' => 'Idiomas',
    'list-languages.mlsLimitExceeded' => "Su licencia actual de Plesk le permite usar %%allowedByLicense%% idiomas. En este momento sus usuarios disponen de %%availableToUsers%% idiomas, lo que excede el número de idiomas proporcionado con la licencia. Seleccione los %%allowedByLicense%% idiomas que desee usar y desactive los demás haciendo clic en sus iconos en la columna 'S'.",
];