<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoDomainActivated' => 'Los dominios y alias seleccionados han sido activados.',
    'activate.errorDomainNotActivated' => 'Algunos de los dominios o alias seleccionados no fueron activados.',
    'activate.domainStillSuspended' => 'No se pudo activar el dominio: %%reason%%',
    'activate.domainStatusOffByAdmin' => 'El dominio ha sido suspendido por el administrador.',
    'activate.domainStatusOffWithParent' => 'El propietario del dominio o su suscripción está suspendida.',
    'activate.domainStatusOffExpired' => 'La suscripción correspondiente ha expirado.',
    'activate.domainStatusOffBackupRestore' => 'El dominio está suspendido temporalmente para backup o restauración.',
    'activate.domainStatusOff' => 'El dominio está suspendido.',
    'activate.aliasStillSuspended' => 'No se pudo activar el alias: El dominio de destino está suspendido.',

    'add-domain-alias.noDomains' => 'No se ha podido crear un alias. No hay dominios disponibles.',

    'add-domain.noDomains' => 'No se ha podido crear un dominio complementario. No hay dominios disponibles.',

    'add-subdomain.noDomains' => 'No se ha podido crear un subdominio. No hay dominios disponibles.',

    'disable.infoDomainDisabled' => 'Los dominios seleccionados han sido deshabilitados.',
    'disable.errorDomainNotDisabled' => 'Algunos de los dominios seleccionados no se han deshabilitado.',

    'list.title' => 'Dominios',
    'list.customerLinkTitle' => 'cree una cuenta de cliente',
    'list.subscriptionLinkTitle' => 'cree su propia suscripción',

    'suspend.infoDomainSuspended' => 'Los dominios seleccionados han sido suspendidos.',
    'suspend.errorDomainNotSuspended' => 'Algunos de los dominios seleccionados no fueron suspendidos.',
];