<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

$messages = [
    'accessDenied' => 'Sitejet Builder no se incluye en tu suscripción. Para habilitar Sitejet Builder, ponte en contacto con tu servicio de hosting.',
];