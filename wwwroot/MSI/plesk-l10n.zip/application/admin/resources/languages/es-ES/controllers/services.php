<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'operation.startActionSuccess' => 'El servicio ha sido iniciado',
    'operation.stopActionSuccess' => 'El servicio ha sido detenido',
    'operation.restartActionSuccess' => 'El servicio ha sido reiniciado',
    'operation.changeStartupActionSuccess' => 'El tipo de inicio para el servicio se ha modificado correctamente.',

    'list.title' => 'Servicios',

    'operation.startServiceMessage' => 'Tenga en cuenta que el servicio necesita unos minutos para iniciarse.',
    'operation.stopServiceMessage' => 'Tenga en cuenta que el servicio necesita unos minutos para detenerse.',
    'operation.restartServiceMessage' => 'Tenga en cuenta que el servicio necesita unos minutos para reiniciarse.',
    'operation.unableFetchFormData' => 'No se pudieron recuperar los datos del formulario: %%error%%',
    'operation.startActionError' => 'No se pudo iniciar el servicio: %%error%%',
    'operation.stopActionError' => 'No se pudo detener el servicio: %%error%%',
    'operation.restartActionError' => 'No se pudo reiniciar el servicio: %%error%%',
    'operation.changeStartupActionError' => 'No pudo cambiarse el tipo de inicio para el servicio: %%error%%',
];