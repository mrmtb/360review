<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Creación de plan de revendedor',
    'create.hint' => 'Aquí puede crear un plan de revendedor correspondiente a su oferta.',

    'edit.title' => '%%name%%',
    'edit.hint' => 'Aquí puede cambiar el plan de revendedor correspondiente a su oferta. Tenga en cuenta que el cambio de plan actualiza automáticamente todas las suscripciones asociadas con el mismo, a excepción de las suscripciones personalizadas, cuya sincronización está bloqueada.',

    'list.title' => 'Planes de revendedor',
    'list.hint' => 'Aquí puede administrar sus planes de revendedor, lo que permite crear suscripciones de revendedor. A diferencia de sus clientes de servicios de hosting, los revendedores solo pueden suscribirse a un plan y no pueden disponer de complementos.',
    'list.tabTitle' => 'Planes de revendedor',
    'list.infoNewPlanCreated' => 'El plan de revendedor %%name%% fue creado.',
    'list.infoPlanUpdated' => 'El plan de revendedor %%name%% fue actualizado.',
    'list.infoPlanUpdatedSynced' => 'El plan de servicio %%name%% ha sido actualizado. Todas las suscripciones de revendedor asociadas se han actualizado correctamente, a excepción de las personalizadas suscripciones, cuya sincronización está bloqueada.',
    'list.infoPlanDeleted' => 'Los planes de revendedor seleccionados fueron eliminados.',
    'list.infoPlanNotDeleted' => 'Algunos de los planes de revendedor seleccionados no fueron eliminados.',
    'list.infoPlanDuplicated' => 'Los planes de servicio seleccionados se han clonado correctamente.',
    'list.infoPlanNotDuplicated' => 'Algunos de los planes de servicio seleccionados no han sido duplicados.',
];