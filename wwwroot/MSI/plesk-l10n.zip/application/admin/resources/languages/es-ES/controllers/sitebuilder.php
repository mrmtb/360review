<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'settings.title' => 'Configuración del modo Probar y comprar',
    'settings.sitebuilderSettingsUpdated' => 'La configuración ha sido actualizada.',
];