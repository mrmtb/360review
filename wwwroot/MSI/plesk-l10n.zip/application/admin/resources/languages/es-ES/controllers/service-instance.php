<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.formTitle' => 'Seleccione el servicio que desea añadir',
    'create.successfullyAdded' => 'El servicio \'%%serviceDisplayName%%\' se ha creado correctamente.',
    'create.successfullyUpdated' => 'El servicio \'%%serviceDisplayName%%\' se ha actualizado correctamente.',
    'create.selectServiceInstallationTitle' => 'Seleccionar un servicio',

    'edit.formTitle' => 'Administrar el servicio \'%%serviceDisplayName%%\'',
    'edit.title' => 'Servicios de %%subscriptionName%%',
    'edit.successfullyUpdated' => 'El servicio \'%%serviceDisplayName%%\' se ha actualizado correctamente.',

    'list.hint' => 'Aquí puede administrar los servicios de la suscripción',
    'list.title' => 'Servicios de %%subscriptionName%%',
    'list.breadcrumb' => 'Servicios',
    'list.infoServiceDeleted' => 'Los servicios seleccionados han sido eliminados.',
    'list.infoServiceNotDeleted' => 'Algunos de los servicios seleccionados no fueron eliminados.',
];