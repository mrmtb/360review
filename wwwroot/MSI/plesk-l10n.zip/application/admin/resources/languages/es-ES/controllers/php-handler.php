<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Configuración de PHP',
    'list.hint' => 'Seleccione los controladores PHP que desea que estén disponibles. Puede instalar otros controladores usando %%link%%.',
    'list.hintLink' => 'Plesk Installer',
    'list.brokenDomainsError' => 'Las siguientes versiones de PHP no están instaladas: %%phpVersions%%. Scripting PHP para %%domainCount%% dominio(s) no disponible. Instale las versiones de PHP que faltan o siga las indicaciones que se detallan en <a href=https://support.plesk.com/hc/en-us/articles/12377342328343>este artículo de la base de conocimiento</a> para reparar el scripting PHP.',
    'list.brokenHandlersError' => 'La(s) siguiente(s) version(es) de PHP no están instaladas: %%phpVersions%%. Instálelas o ejecute <code>plesk repair web -php-handlers</code> para seleccionar otra versión de PHP.',

    'modules.canNotManageModules' => 'El acceso a la administración de la configuración del controlador PHP está limitado porque no se ha especificado la ruta al archivo PHP CLI.',

    'php-ini.title' => 'Configuración para <b>%%name%%</b>',
    'php-ini.tabTitle' => 'php.ini',
    'php-ini.success' => 'La configuración ha sido actualizada.',

    'toggle.errorEnableBrokenHandler' => 'El controlador está dañado y no puede activarse.',
    'toggle.errorDisableBrokenHandler' => 'El controlador está dañado y no puede desactivarse.',
    'toggle.infoHandlerEnabled' => 'El controlador fue activado.',
    'toggle.infoHandlerDisabled' => 'El controlador fue desactivado.',
];