<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoAdminAliasActivated' => 'Las cuentas de administrador seleccionadas se han activado correctamente.',
    'activate.infoAdminAliasNotActivated' => 'Algunas de las cuentas de administrador seleccionadas no fueron activadas.',

    'create.title' => 'Adición de una cuenta de administrador',
    'create.infoNewAdminAliasCreated' => 'La cuenta de administrador adicional %%contact%% se ha creado correctamente.',

    'deactivate.infoAdminAliasDeactivated' => 'Las cuentas de administrador seleccionadas se han suspendido correctamente.',
    'deactivate.infoAdminAliasNotDeactivated' => 'Algunas de las cuentas de administrador seleccionadas no han sido suspendidas.',

    'delete.infoAdminAliasDeleted' => 'Las cuentas de administrador seleccionadas se han eliminado correctamente.',
    'delete.infoAdminAliasNotDeleted' => 'Algunas de las cuentas de administrador seleccionadas no han sido eliminadas.',

    'edit.title' => "%%contact%%",
    'edit.infoNewAdminAliasUpdated' => 'La cuenta de administrador se ha actualizado correctamente.',

    'list.title' => 'Cuentas de administrador adicionales',
    'list.hint' => 'Aquí puede crear cuentas de administrador adicionales para sus ingenieros de soporte para que así estos puedan llevar a cabo distintas tareas de administración.',
];