<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Registro de un servicio de webmail adicional',
    'create.infoNewWebmailRegistered' => 'El nuevo servicio de webmail ha sido registrado.',

    'edit.unknownWebmail' => 'Webmail desconocido',
    'edit.infoWebmailUpdated' => 'La configuración del servicio de webmail %%name%% ha sido actualizada.',

    'index.title' => 'Servicios de webmail',
    'index.hint' => 'Puede emplear cualquier servicio de webmail además de soluciones de webmail que instale mediante Plesk Installer. Registre la instalación de webmail deseada haciendo clic en el botón que aparece a continuación y esta aparecerá como opción disponible de webmail en las suscripciones y planes de hosting. Si necesita ocultar un servicio de webmail de forma temporal, desactívelo haciendo clic en el botón que aparece a continuación.',
    'index.webmailDeleted' => 'El registro de los servicios de webmail seleccionados ha sido eliminado.',
    'index.webmailNotDeleted' => 'El registro de algunos servicios de webmail no ha sido eliminado.',
    'index.webmailEnabled' => 'Los servicios de webmail seleccionados han sido habilitados y están disponibles.',
    'index.webmailNotEnabled' => 'Algunas de las opciones webmail seleccionadas no han sido habilitadas.',
    'index.webmailDisabled' => 'Las opciones de webmail seleccionadas han sido deshabilitadas y ya no están disponibles.',
    'index.webmailNotDisabled' => 'Algunas de las opciones webmail seleccionadas no han sido deshabilitadas.',
];