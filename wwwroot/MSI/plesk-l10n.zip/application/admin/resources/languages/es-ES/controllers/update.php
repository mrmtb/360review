<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Plesk Installer',
    'index.autoinstallerRedirectError' => 'No fue posible iniciar Plesk Installer. Se produjo el siguiente error: %%message%%',

    'product.title' => 'Plesk Installer',
    'product.autoinstallerRedirectError' => 'No fue posible iniciar Plesk Installer. Se produjo el siguiente error: %%message%%',

    'settings.title' => 'Configuración de actualización',
    'settings.settingsUpdated' => 'La configuración de actualización se ha actualizado.',
];