<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Estado del servidor',
    'index.pageHint' => 'Aquí puede ver informes detallados acerca del estado del servidor. Si desea ver de qué forma han ido cambiando los parámetros de estado del servidor, seleccione los parámetros deseados y Plesk le mostrará los gráficos correspondientes. Tenga en cuenta que puede cambiar el periodo para el que se presentan los gráficos desde las últimas 3 horas hasta una semana. Aquí también puede cambiar la configuración de control de estado del servidor, que define cuándo deben mostrarse alertas rojas y amarillas para cada uno de los parámetros y qué recursos del disco duro deben ser monitorizados. Para ello, descargue un archivo de configuración usando el botón que aparece abajo, edite el archivo y cargue su versión. Si el hardware del servidor ha sido modificado, debería propagar estos cambios a Health Monitor con el fin de obtener unas estadísticas correctas.',
    'index.waitMessage' => 'Cargando...',
    'index.buttonUpload' => 'Cargar archivo de configuración',
    'index.buttonDownload' => 'Descargar archivo de configuración',
    'index.buttonRestoreDefaults' => 'Revertir a la configuración predeterminada',
    'index.buttonReconfigure' => 'Detectar cambios de hardware',
    'index.buttonUploadHint' => 'Cargue su archivo de configuración de Health Monitor. La configuración nueva será aplicada de forma inmediata una vez se haya completado el proceso de carga.',
    'index.buttonDownloadHint' => 'Guarde la configuración actual de Health Monitor en su equipo.',
    'index.buttonRestoreDefaultsHint' => 'Restaure la configuración predeterminada del control de estado del servidor.',
    'index.buttonReconfigureHint' => 'Propagar cambios en la configuración de hardware a Health Monitor.',
    'index.confirmRestoreDefaultsTitle' => 'Restaurando la configuración predeterminada de Server Health Monitor',
    'index.confirmRestoreDefaultsDescription' => '¿Está seguro de que desea restaurar la configuración predeterminada?',
    'index.confirmReconfigureTitle' => 'Detectando cambios de hardware',
    'index.confirmReconfigureDescription' => 'Está a punto de actualizar la configuración de hardware en Health Monitor. Esto es relevante si el hardware del servidor ha cambiado y si desea reflejar estos cambios en las estadísticas de Health Monitor. ¿Desea continuar?',
    'index.settingsWereRestoredToDefault' => 'La configuración predeterminada ha sido restaurada.',
    'index.healthMonitorWasReconfigured' => 'La información de Health Monitor acerca de la configuración de hardware ha sido actualizada.',

    'parameters.loading' => 'Cargando...',
    'parameters.selectPeriod' => 'Seleccionar período',
    'parameters.periodFromNowTo3h' => '3 horas',
    'parameters.periodFromNowTo6h' => '6 horas',
    'parameters.periodFromNowTo12h' => '12 horas',
    'parameters.periodFromNowTo1d' => '1 día',
    'parameters.periodFromNowTo3d' => '3 días',
    'parameters.periodFromNowTo7d' => '1 semana',

    'thresholds-hint.waitMessage' => 'Cargando...',

    'upload-config-file.title' => 'Cargar archivo de configuración',
    'upload-config-file.configurationUploadedSuccessfully' => 'La configuración ha sido cargada y aplicada.',
];