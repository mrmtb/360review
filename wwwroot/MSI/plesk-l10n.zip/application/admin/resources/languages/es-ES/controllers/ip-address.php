<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Añadir dirección IP',
    'add.ipAddressAdded' => 'La dirección IP %%address%% ha sido añadida.',

    'delete.infoIpAddressesDeleted' => 'Las direcciones IP seleccionadas han sido eliminadas.',

    'edit.title' => 'La dirección IP %%address%% en la interfaz %%interface%%',
    'edit.ipAddressUpdated' => 'Se ha programado el cambio de la dirección IP %%address%%, que se efectuará en segundo plano',
    'edit.ipAddressInterfaceNotAvailableWarning' => 'El adaptador de red %%interface%% no existe. Mueva esta dirección IP a otro adaptador de red o elimínela de la lista.',

    'list.title' => 'Direcciones IP',
];