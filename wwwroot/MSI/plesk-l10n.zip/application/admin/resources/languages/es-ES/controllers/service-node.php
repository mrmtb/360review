<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.hint' => 'Descripción acerca de la adición de un nodo de servicio remoto.',
    'add.title' => 'Adición de un nodo de servicio remoto',
    'add.serviceNodeAdded' => 'Se ha añadido el nodo de servicio remoto %%name%%',

    'delete.infoServiceNodesDeleted' => 'Los nodos de servicio seleccionados se han desconectado correctamente.',
    'delete.infoServiceNodesNotDeleted' => 'No se pudieron desconectar algunos de los nodos de servicio seleccionados.',
    'delete.serviceNodeIsInUse' => 'El nodo de servicio está en uso.',

    'edit.hint' => 'Descripción acerca de la edición de un nodo de servicio remoto.',
    'edit.title' => 'Nodo de servicio remoto %%name%%',
    'edit.serviceNodeUpdated' => 'Las propiedades del nodo de servicio remoto %%name%% han sido actualizadas',

    'list.hint' => 'Aquí puede añadir nodos de servicio remotos',
    'list.title' => 'Nodos de servicio',
];