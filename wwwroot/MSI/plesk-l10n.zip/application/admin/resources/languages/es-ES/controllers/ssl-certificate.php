<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Añadir certificado SSL/TLS',
    'add.enterCertificateName' => 'Introduzca el nombre del certificado.',

    'delete.infoSslCertificatesDeleted' => 'Los certificados SSL/TLS han sido eliminados.',
    'delete.infoSslCertificatesNotDeleted' => 'No se pudieron eliminar los certificados SSL/TLS.',
    'delete.certificateUsedAsDefault' => 'Uno de los certificados que va a eliminar se utiliza como certificado predeterminado.',
    'delete.certificateAssignedOnIp' => 'Uno o más certificados están asignados a las direcciones IP/dominios.',
    'delete.certificateUsedByPanel' => 'Uno de los certificados que va a eliminar se utiliza para proteger Plesk.',
    'delete.certificateUsedByMailServer' => 'Uno de los certificados que va a eliminar se utiliza para proteger el servidor de correo.',

    'edit.title' => 'Edición de las propiedades del certificado SSL/TLS %%name%%',
    'edit.enterCertificateName' => 'Introduzca el nombre del certificado.',

    'list.title' => 'Certificados SSL/TLS',
    'list.certificateFound' => 'No se ha encontrado la clave privada (denominada %%name%%) para el certificado cargado. El certificado se ha añadido correctamente.',
    'list.certificatesList' => 'Lista de certificados presentes en el grupo de servidores',
    'list.certificatesListHint' => 'Lista de los certificados presentes en el grupo de servidores.',
    'list.currentCertificates' => 'Certificados que están usándose para proteger el servidor Plesk',
    'list.currentCertificatesHint' => 'Certificados que están usándose para proteger el servidor Plesk y el servidor de correo',
    'list.pleskCertificate' => 'Certificado para la protección de Plesk',
    'list.mailServerCertificate' => 'Certificado para la protección del correo',
    'list.serverPoolCertificateDescription' => '%%name%% del grupo de servidores.',
    'list.domainCertificateDescription' => '%%name%% de %%domain%%.',
    'list.change' => '[Cambiar]',
    'list.none' => 'Desconocido.',

    'secure-mail-server.title' => 'Protección del servidor de correo',
    'secure-mail-server.hint' => 'Seleccione el certificado que desea usar para proteger el servidor de correo.',
    'secure-mail-server.mailServerCertificateSet' => 'El certificado %%name%% se ha establecido correctamente para proteger el servidor de correo.',
    'secure-mail-server.mailServerNotInstalled' => 'El servicio de correo no está instalado.',

    'secure-panel.title' => 'Proteger Plesk',
    'secure-panel.hint' => 'Seleccione el certificado que desea usar para proteger Plesk.',
    'secure-panel.panelCertificateSet' => 'El certificado %%name%% se ha establecido correctamente para proteger Plesk.',
];