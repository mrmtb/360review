<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-password.title' => "Cambio de la contraseña del administrador",
    'change-password.passwordChanged' => 'La contraseña del administrador ha sido actualizada.',

    'index.personalInfoTitle' => "Edición del perfil del administrador",
    'index.successMessage' => "Su perfil ha sido actualizado.",
    'index.aliasInfoTitle' => 'Información de la cuenta de administrador adicional',
    'index.aliasInfoUpdated' => 'La información personal acerca de la cuenta de administrador adicional ha sido actualizada.',
];