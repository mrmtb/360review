<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'admin-customers-target-list.title' => 'Clientes del Admin en necesidad de transición',
    'admin-customers-target-list.hint-t1s1' => 'Esto es una lista de clientes formada por aquellos clientes a los que no se les permitió cambiar los límites del dominio y que tenían un dominio antes de la actualización.',
    'admin-customers-target-list.hint-t1s2' => 'Esto es una lista de clientes formada por aquellos clientes a los que se les permitió cambiar los límites del dominio y que tenían un dominio antes de la actualización.',
    'admin-customers-target-list.hint-t1s3' => 'Esto es una lista de clientes formada por aquellos clientes a los que no se les permitió crear dominios y cambiar los límites del dominio y que tenían varios dominios antes de la actualización.',
    'admin-customers-target-list.hint-t1s6' => 'Esto es una lista de clientes formada por aquellos clientes a los que se les permitió crear dominios y cambiar los límites del dominio y que tenían varios dominios antes de la actualización.',

    'admin-subscriptions-target-list.title' => 'Suscripciones del Admin que necesitan transición',
    'admin-subscriptions-target-list.hint' => 'Esto es una lista de suscripciones formada por los dominios que (a) pertenecían al admin y (b) tenían la cuenta de administrador de dominio activada antes de la actualización.',

    'bunch.title' => 'Finalización de cambio al nuevo modelo de negocio de Plesk',
    'bunch.noActionsDescription' => 'En el sistema no queda ningún cliente o suscripción que se adapten a los escenarios habituales, por lo que no hay nada que hacer en esta pestaña. Vaya a la siguiente pestaña para realizar la transición de los clientes restantes.',
    'bunch.description' => 'El modelo de distribución de recursos en Plesk 10 y en las versiones posteriores difiere del de las versiones anteriores: a partir de Plesk 10, los clientes no disponen de sus propios recursos tal y como sucedía en Plesk 8 y 9, sino que los obtienen con las suscripciones. En este momento existen varios clientes con recursos legacy, para los que debería hacerse la transición correctamente con el fin de adaptarse al nuevo modelo de Plesk. Basándose en los escenarios comunes de uso de Plesk, Plesk analizó estos clientes y generó la lista de las acciones de transición recomendadas que se muestra a continuación. Puede realizar dichas acciones o bien seleccionar un esquema de transición para cada cliente. Una vez realizada la transición de los clientes, estos desaparecerán de esta lista.',
    'bunch.help' => 'Más info acerca de la transición.',
    'bunch.applyed' => 'Se ha realizado la transición de las suscripciones y clientes seleccionados.',
    'bunch.failed' => 'No se puede realizar una transición de los clientes y suscripciones seleccionados.',

    'customers.title' => 'Finalización de cambio al nuevo modelo de negocio de Plesk − Transición selectiva para clientes',
    'customers.description' => 'Esta es una lista de todos los clientes que requieren transición. Además de las cuentas que coinciden on los escenarios habituales, esta incluye las cuentas con una configuración irregular, para la que no se recomienda ninguna acción. Debería seleccionar un esquema de transición aplicable en función de la configuración anterior del cliente, como por ejemplo límites, permisos, número actual de dominios, etc. Para descubrir los permisos y límites de un cliente anterior, haga clic en el nombre del cliente y en \'Mis Recursos\' en la lista de suscripciones del cliente.',
    'customers.help' => 'Más info acerca de la transición.',

    'manual-customer-solution.appliedInfo' => 'La transición se ha completado para los clientes seleccionados.',
    'manual-customer-solution.notAppliedInfo' => 'No se ha podido realizar la transición de todos o distintos de los clientes seleccionados.',

    'manual-subscription-solution.appliedInfo' => 'La transición se ha completado para las suscripciones seleccionadas.',
    'manual-subscription-solution.notAppliedInfo' => 'No se ha podido realizar la transición de todas o distintas de los suscripciones seleccionadas.',

    'notes.nonApplicableCustomers' => "%%count%% clientes no se adaptan a ninguno de los escenarios habituales, por lo que no existen acciones recomendadas para ellos. Para realizar la transición de las cuentas, %%link%%.",
    'notes.nonApplicableSubscriptions' => "%%count%% suscripciones no se adaptan a ninguno de los escenarios habituales, por lo que no existen acciones recomendadas para ellas. Para realizar la transición de las suscripciones, %%link%%.",
    'notes.manualCustomersUpgradeLink' => 'seleccione un esquema personalizado para estas',
    'notes.manualSubscriptionsUpgradeLink' => 'seleccione un esquema personalizado para estas',

    'reseller-customers-target-list.title' => 'Clientes del Revendedor que necesitan transición',
    'reseller-customers-target-list.hint-t2s1' => 'Esto es una lista de clientes formada por aquellos clientes a los que no se les permitió cambiar los límites del dominio y que tenían un dominio antes de la actualización.',
    'reseller-customers-target-list.hint-t2s2' => 'Esto es una lista de clientes formada por aquellos clientes a los que se les permitió cambiar los límites del dominio y que tenían un dominio antes de la actualización.',
    'reseller-customers-target-list.hint-t2s3' => 'Esto es una lista de clientes formada por aquellos clientes a los que no se les permitió crear dominios y cambiar los límites del dominio y que tenían varios dominios antes de la actualización.',
    'reseller-customers-target-list.hint-t2s6' => 'Esto es una lista de clientes formada por aquellos clientes a los que se les permitió crear dominios y cambiar los límites del dominio y que tenían varios dominios antes de la actualización.',

    'reseller-subscriptions-target-list.title' => 'Suscripciones del Revendedor que necesitan transición',
    'reseller-subscriptions-target-list.hint' => 'Esto es una lista de suscripciones formada por los dominios que (a) pertenecían a los revendedores y (b) tenían la cuenta de administrador de dominio activada antes de la actualización.',

    'subscriptions.title' => 'Finalización de cambio al nuevo modelo de negocio de Plesk − Transición selectiva para suscripciones',
    'subscriptions.description' => 'A continuación puede ver la lista de suscripciones que requieren transición. Esta lista contiene las mismas suscripciones que la página Acciones Recomendadas, pero aquí puede seleccionar el esquema de transición más adecuado para una suscripción determinada. Estas son las suscripciones creadas desde dominios que (a) pertenecían al administrador o a un revendedor y (b) tenían habilitada la cuenta de administrador del dominio.',
    'subscriptions.help' => 'Más info acerca de la transición.',

    'tabs.bunch' => 'Acciones recomendadas',
    'tabs.customers' => 'Transición personalizada de clientes',
    'tabs.subscriptions' => 'Transición personalizada de suscripciones',
];