<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-network.title' => 'Adición de una red',
    'add-network.added' => 'La red %%address%% ha sido añadida.',

    'delete-network.noNetworksSpecified' => 'Seleccione una o varias redes de la lista de restricciones de acceso IP.',
    'delete-network.networksDeleted' => 'Las redes seleccionadas han sido eliminadas.',
    'delete-network.networksNotDeleted' => 'No se pudieron eliminar algunas de las redes seleccionadas. Detalles: %%error%%.',

    'edit-network.title' => 'Edición de red',
    'edit-network.updated' => 'La dirección %%address%% ha sido actualizada.',

    'list.title' => 'Administración de restricción de acceso IP',
    'list.currentIpAddressDenied' => 'La directiva de restricción de acceso y la lista de redes están configuradas de tal forma que no podrá iniciar sesión con derechos de administrador con su dirección IP \'%%remoteAddress%%\'.',
    'list.allowHint' => 'Se permite el acceso a Plesk con privilegios de administrador, excluyendo las redes presentes en la lista.',
    'list.denyHint' => 'Se prohíbe el acceso a Plesk con privilegios de administrador desde todas las redes que no aparezcan en esta lista.',

    'settings.title' => 'Configuración de restricción de acceso IP',
    'settings.settingsSaved' => 'La directiva de restricción de acceso IP ha sido guardada.',
];