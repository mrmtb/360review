<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Actualizaciones del sistema',

    'list.title' => 'Todos los paquetes',
    'list.hint' => 'Los paquetes del sistema se actualizan mediante las herramientas del sistema (dpkg/apt o yum). Estos únicamente se actualizan desde los repositorios desde los que se instalaron. Si desea impedir la actualización de algún paquete, selecciónelo en la lista y haga clic en Bloquear.',

    'lock.success' => 'Los paquetes se bloquearon correctamente.',

    'settings.title' => 'Configuración',
    'settings.settingsUpdated' => 'La configuración se modificó correctamente.',

    'unlock.success' => 'Los paquetes se desbloquearon correctamente.',

    'updates-list.title' => 'Actualizaciones disponibles',
    'updates-list.hint' => 'Los paquetes del sistema se actualizan mediante las herramientas del sistema (dpkg/apt o yum). Estos únicamente se actualizan desde los repositorios desde los que se instalaron. Si desea impedir la actualización de algún paquete, selecciónelo en la lista y haga clic en Bloquear.',
];