<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-log.actionSuccess' => 'Los archivos de registro seleccionados han sido eliminados.',
    'delete-log.invalidFileName' => 'El nombre del archivo de registro no es válido.',
    'delete-log.actionError' => 'No se pudo eliminar el archivo de registro %%file%%: %%reason%%',

    'index.title' => 'Firewall para aplicaciones web',
    'index.generalTab' => 'General',
    'index.settingsTab' => 'Configuración',
    'index.settingsSaved' => 'La configuración del firewall para aplicaciones web ha sido guardada.',
    'index.updateFailed' => 'Error al actualizar el conjunto de reglas de ModSecurity: %%error%%',
    'index.updateFailedShort' => 'Error al actualizar el conjunto de reglas de ModSecurity. %%link%%',
    'index.updateFailedShortLink' => 'Detalles',

    'log-list.title' => 'Administración de archivos de registro',

    'view-log.fileNameIsUndefined' => 'No se ha definido el nombre del archivo de registro.',
];