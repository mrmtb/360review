<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'gallery.titleScreenshot' => 'Capturas de pantalla de %%packageName%%',
    'gallery.prevImage' => '< Anterior',
    'gallery.nextImage' => 'Siguiente >',
    'gallery.closeGallery' => 'Cerrar',
    'gallery.navigationOf' => 'de',
    'gallery.typeScreenshot' => 'capturas de pantalla',
    'gallery.title' => 'Capturas de pantalla',
];