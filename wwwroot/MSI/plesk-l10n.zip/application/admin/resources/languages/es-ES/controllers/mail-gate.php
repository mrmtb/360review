<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Configuración de servidor SMTP externo',
    'index.settingsUpdated' => 'La configuración ha sido actualizada.',
];