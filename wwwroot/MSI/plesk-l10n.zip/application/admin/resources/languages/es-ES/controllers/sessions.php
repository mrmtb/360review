<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Administración de sesiones',

    'remove.sessionsDeleted' => 'Las sesiones seleccionadas se han eliminado correctamente.',

    'settings.title' => 'Configuración de la sesión',
    'settings.settingsUpdated' => 'La configuración se modificó correctamente.',
];