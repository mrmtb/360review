<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'isEmpty' => 'Este campo obligatorio está vacío. Indique un valor para este campo.',
    'stringLengthTooShort' => "'%value%' tiene menos de %min% caracteres.",
    'stringLengthTooLong' => "'%value%' tiene más de %max% caracteres.",
    'regexNotMatch' => "'%value%' no coincide con el patrón '%pattern%'.",
    'notAlnum' => "'%value%' tiene caracteres que no son alfanuméricos. Compruebe que solo está usando caracteres alfanuméricos.",
    'stringEmpty' => "'%value%' está vacío.",
    'stringsNotEqual' => 'Las cadenas de texto no son iguales.',
    'passwordsNotEqual' => 'Las contraseñas indicadas no coinciden.',
    'passwordLengthTooShort' => "la contraseña tiene menos de %min% caracteres.",
    'passwordLengthTooLong' => "la contraseña tiene más de %max% caracteres.",
    'passwordRegexNotMatch' => "la contraseña no coincide con el patrón '%pattern%'.",
    'invalidUrl' => 'La dirección especificada no es válida. Indique una dirección válida como http://dominio.com.',
    'specialCharactersInIpAddress' => 'La dirección IP proporcionada no es válida.',
    'massEmailContactsNotSelected' => 'Seleccione al menos un contacto de la lista.',
    'ipAddressIsTooLong' => 'Una dirección IP no puede estar formada por más de %max% caracteres.',
    'ipAddressDescriptionTooLong' => 'La descripción no puede estar formada por más de %max% caracteres.',

    'fail2ban.invalidIpOrCidr' => 'La dirección IP debe ser una dirección IP válida o una máscara CIDR.',
];