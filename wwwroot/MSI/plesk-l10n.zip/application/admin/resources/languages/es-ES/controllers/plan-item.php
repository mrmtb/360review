<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Adición de un servicio',
    'create.hint' => 'Aquí puede añadir un vínculo a un servicio externo.',

    'edit.title' => 'Propiedades del servicio %%name%%',
    'edit.hint' => 'Aquí puede especificar las propiedades del servicio.',
    'edit.errorItemNotEditable' => 'Las propiedades de este servicio no pueden ser editadas.',

    'list.title' => 'Servicios adicionales',
    'list.tabTitle' => 'Servicios adicionales',
    'list.hint' => "A continuación puede ver una lista de los servicios adicionales que pueden aprovisionarse con los planes de hosting. Esta muestra los servicios definidos de forma manual y los servicios proporcionados por las aplicaciones instaladas como extensiones de Plesk. La adición manual de un servicio resulta útil cuando desea redireccionar a sus clientes a un servicio online externo: esto añade el botón correspondiente al panel del cliente. Por omisión, todos los servicios adicionales se detallan en la pestaña Servicios adicionales de las propiedades del plan de hosting. Esto le permite a usted y a sus revendedores incluir dichos servicios en los planes de hosting. Si no desea que sus revendedores utilicen un servicio determinado ni que lo proporcionen a sus clientes, use el enlace Hacer no disponible.",
    'list.planItemsNowAvailable' => 'Los servicios adicionales seleccionados están disponibles para los revendedores.',
    'list.planItemsNowNotAvailable' => 'Los servicios adicionales seleccionados ya no están disponibles para los revendedores.',
    'list.cantChangePlanItemsProperties' => 'Se ha producido un error cuando se intentaba cambiar la configuración de disponibilidad para el servicio.',
    'list.infoNewPlanItemCreated' => 'La opción %%name%% correspondiente al servicio ha sido añadida a las propiedades del plan.',
    'list.infoPlanItemUpdated' => 'La opción de plan %%name%% ha sido actualizada.',
    'list.planItemsDeleted' => 'Las opciones de plan seleccionadas han sido eliminadas.',
    'list.planItemsNotDeleted' => 'Algunas de las opciones de plan seleccionadas no han sido eliminadas.',
];