<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-customer-owner.title' => 'Transferencia de clientes a otro propietario',
    'change-customer-owner.description' => 'Las cuentas de cliente serán transferidas a otro propietario. Puede cambiar los planes de servicio para las suscripciones de los clientes. Si desea preservar los recursos disponibles para un cliente, deje seleccionado el plan personalizado.',
    'change-customer-owner.ownerHint' => 'Los clientes serán transferidos al propietario seleccionado:',
    'change-customer-owner.ipAddressHint' => 'Una dirección IP dedicada no puede ser preservada.',
    'change-customer-owner.loading' => 'Espere...',
    'change-customer-owner.ipAddressNotSelected' => 'Seleccione al menos una dirección IP para cada suscripción.',
    'change-customer-owner.ownerNotSelected' => 'Seleccione un propietario.',

    'customer.title' => 'Conversión de clientes en revendedores',
    'customer.description' => 'Las cuentas de cliente se convertirán en cuentas de revendedor. Puede seleccionar planes de revendedor para las cuentas convertidas. Si desea preservar los recursos que estaban disponibles para un cliente, seleccione el plan personalizado. El revendedor dispondrá de la suma de las asignaciones de recursos, permisos y aplicaciones de todas las suscripciones.',
    'customer.loading' => 'Convirtiendo...',

    'reseller.title' => 'Conversión de revendedores en clientes',
    'reseller.description' => 'Los revendedores se convertirán en clientes.',
    'reseller.descriptionExtended' => 'Seleccione planes de servicio nuevos para aquellos revendedores que disponen de sus propias suscripciones. Si desea preservar los recursos disponibles para un revendedor, seleccione el plan de servicio personalizado. Para transferir las suscripciones del revendedor a uno de los planes de servicio existentes, seleccione un plan de servicio existente.',
    'reseller.loading' => 'Convirtiendo...',
];