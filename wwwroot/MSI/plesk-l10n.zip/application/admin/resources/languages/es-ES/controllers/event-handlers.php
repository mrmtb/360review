<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Adición de un controlador de eventos',
    'add.added' => 'El controlador de eventos ha sido añadido.',

    'delete.noHandlersSpecified' => 'Seleccione los controladores de eventos que desea eliminar.',
    'delete.handlersDeleted' => 'Los controladores de eventos seleccionados han sido eliminados.',
    'delete.handlersNotDeleted' => 'Algunos de los controladores de eventos seleccionados no pudieron eliminarse. Detalles: %%error%%.',

    'edit.title' => 'Actualización de las propiedades del controlador de eventos',
    'edit.updated' => 'El controlador de eventos ha sido actualizado.',

    'list.title' => 'Administrador de eventos',
];