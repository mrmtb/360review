<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Configuración de correo a nivel de servidor',
    'index.preferencesTab' => 'Configuración',
    'index.spamFilteringTab' => 'Filtración de spam',
    'index.antivirusTab' => 'Antivirus',
    'index.blockedDomainsTab' => 'Lista negra',
    'index.whiteListTab' => 'Lista blanca',
    'index.queueTab' => 'Cola de correo',
    'index.statisticsTab' => 'Estadísticas',
    'index.smarthostTab' => 'Smarthost',

    'mail-lists.title' => 'Configuración del administrador de listas de correo',
    'mail-lists.configured' => 'El administrador de listas de correo Mailman ha sido configurado. En la pantalla Herramientas y configuración ya no se mostrará el botón Configurar servidor de listas de correo.', // PFU
    'mail-lists.noLocalhostInServerWhiteList' => 'Para usar listas de correo es necesario que localhost (127.0.0.0/8, ::1/128) esté presente en la lista blanca del servidor de correo. De todos modos, para poder hacer uso del control del correo saliente, localhost no debería estar en esta lista. Así, si activó el control del correo saliente, puede usar el redireccionamiento de correo en el buzón en vez de usar listas de correo.',
    'mail-lists.noLocalhostInServerWhiteListIpv4' => 'Para usar listas de correo es necesario que localhost esté presente en la lista blanca del servidor de correo. De todos modos, para poder hacer uso del control del correo saliente, localhost no debería estar en esta lista. Así, si activó el control del correo saliente, puede usar el redireccionamiento de correo en el buzón en vez de usar listas de correo. Tenga en cuenta que en este momento la lista blanca no incluye ninguna dirección IPv4 localhost (127.0.0.0/8), por lo que el control del correo saliente sí que funcionará para las direcciones IPv4.',
    'mail-lists.noLocalhostInServerWhiteListIpv6' => 'Para usar listas de correo es necesario que localhost esté presente en la lista blanca del servidor de correo. De todos modos, para poder hacer uso del control del correo saliente, localhost no debería estar en esta lista. Así, si activó el control del correo saliente, puede usar el redireccionamiento de correo en el buzón en vez de usar listas de correo. Tenga en cuenta que en este momento la lista blanca no incluye ninguna dirección IPv6 localhost (::1/128), por lo que el control del correo saliente sí que funcionará para las direcciones IPv6.',
    'mail-lists.mailingListSoftwareNotInstalled' => 'El software de listas de correo no está instalado.',
    'mail-lists.mailingListSoftwareAlreadyConfigured' => 'El software de listas de correo ya está configurado.',

    'customize-mailbox-quota-warning.title' => 'Personalización de la advertencia de cuota de buzón de correo',
    'customize-mailbox-quota-warning.successMessage' => 'Se ha modificado el mensaje de advertencia de la cuota de buzón.',

    'customize-mailbox-quota-warning-form.subject' => 'Asunto',
    'customize-mailbox-quota-warning-form.message' => 'Mensaje',
    'customize-mailbox-quota-warning-form.tooLongMessage' => "El mensaje es demasiado largo. La longitud máxima permitida es de %max% caracteres",
];