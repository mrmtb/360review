<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-sessions.noSessionsSpecified' => 'Seleccione una o más sesiones FTP de la lista.',
    'delete-sessions.sessionsDeleted' => 'Las sesiones seleccionadas han sido eliminadas.',
    'delete-sessions.sessionsNotDeleted' => 'Algunas de las sesiones seleccionadas no fueron eliminadas. Detalles: %%error%%.',

    'list.title' => 'Sesiones FTP',
];