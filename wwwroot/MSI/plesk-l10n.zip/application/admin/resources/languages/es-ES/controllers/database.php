<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'assign-to-subscription.databasesSuccessfullyAssignedToSubscription' => 'Las bases de datos se movieron a la suscripción \'%%subscriptionName%%\'.',
    'assign-to-subscription.databasesNotAssignedToSubscription' => 'Las bases de datos no pudieron moverse a la suscripción \'%%subscriptionName%%\'.',
    'assign-to-subscription.subscriptionNotFound' => 'No se encontró la suscripción \'%%name%%\'.',
    'assign-to-subscription.isNotMainDomain' => '\'%%name%%\' no es el dominio principal en la suscripción.',

    'settings.title' => 'Configuración de hosting de bases de datos',
    'settings.settingsSaved' => 'La configuración de hosting de bases de datos ha sido guardada.',

    'refresh.success' => 'La información de los servidores de bases de datos ha sido actualizada.',
];