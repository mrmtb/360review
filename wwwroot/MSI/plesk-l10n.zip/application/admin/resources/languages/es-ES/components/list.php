<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'recordsTotal' => '%%total%% elemento(s) en total',
    'pages' => 'Páginas',
    'firstPage' => 'Primera',
    'lastPage' => 'Última',
    'numberOfItemPerPage' => 'Entradas por página',
    'hideSearch' => 'Ocultar búsqueda',
    'showSearch' => 'Mostrar búsqueda',
    'buttonSearch' => 'Buscar',
    'buttonResetSearch' => 'Restablecer búsqueda',
    'noEntriesFound' => 'No se ha encontrado ningún elemento.',
    'itemsNotSelected' => 'En primer lugar, seleccione los elementos.',
    'messageBoxButtonYes' => 'Sí',
    'messageBoxButtonNo' => 'No',
    'messageBoxButtonOk' => 'ACEPTAR',
    'allItems' => 'Todas',
];