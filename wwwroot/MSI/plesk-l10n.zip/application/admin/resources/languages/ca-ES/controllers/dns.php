<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'acl-records.title' => 'Plantilla de restriccions de transferència',

    'add-acl-record.title' => 'Afegir adreça IP',
    'add-acl-record.success' => 'Les adreces IP indicades s\'han afegit correctament.',

    'delete-acl-record.success' => 'Les adreces IP seleccionades s\'han eliminat correctament.',

    'index.title' => 'Configuració de DNS',

    'records.title' => 'Plantilla de registres de zona',

    'reset-settings.success' => 'La configuració predeterminada s\'ha restaurat correctament.',

    'settings.title' => 'Configuració a nivell del servidor',
    'settings.success' => 'La configuració s\'ha actualitzat correctament.',

    'soa-record.title' => 'Plantilla de configuració de la zona',

    'restore-default.title' => 'Restauració de la plantilla de zona DNS predeterminada',
    'restore-default.text' => 'Confirmi que desitja restaurar la configuració predeterminada de la plantilla de zona DNS.',

    'soa-sync.title' => 'Substituir la configuració SOA per tots els dominis existents',
    'soa-sync.text' => 'Desitja actualitzar els registres SOA de tots els dominis allotjats aplicant els canvis efectuats a la plantilla SOA?',

    'sync.title' => 'Aplicar canvis de plantilla DNS',
    'sync.type-option' => 'Seleccioni una de les següents opcions',
    'sync.safe' => 'Aplicar els canvis a zones no alterades. Si s\'ha personalitzat una zona (s\'han afegit nous registres o s\'han modificat els registres existents), Plesk no aplicarà els canvis de la plantilla a aquest tipus de zones.',
    'sync.force' => 'Aplicar els canvis a totes les zones. Plesk aplicarà els canvis de la plantilla a totes les zones DNS, incloent les zones personalitzades. Tingui en compte que els registres modificats per l\'usuari sempre romanen intactes. Per exemple, si la plantilla conté un registre nou que ja havia estat afegit per un client, Plesk conservarà el registre del client.',

    'external-dns.title' => 'DNS extern',
    'external-dns.hint' => 'Aquí pot configurar servidors DNS externs',
    'external-dns.success' => 'Desada',
    'external-dns.configured' => 'Configurat',
    'external-dns.notConfigured' => 'No configurat',
    'external-dns.useExtension' => 'Emprar aquesta extensió',

    'external-dns-edit.title' => 'DNS extern',
];