<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoAdminAliasActivated' => 'Els comptes d\'administrador seleccionats s\'han activat correctament.',
    'activate.infoAdminAliasNotActivated' => 'No s\'han pogut activar alguns dels comptes d\'administrador seleccionats.',

    'create.title' => 'Addició d\'un compte d\'administrador',
    'create.infoNewAdminAliasCreated' => 'El compte d\'administrador addicional %%contact%% s\'ha creat correctament.',

    'deactivate.infoAdminAliasDeactivated' => 'Els comptes d\'administrador seleccionats s\'han suspès correctament.',
    'deactivate.infoAdminAliasNotDeactivated' => 'No s\'han pogut suspendre alguns dels comptes d\'administrador seleccionats.',

    'delete.infoAdminAliasDeleted' => 'Els comptes d\'administrador seleccionats s\'han eliminat correctament.',
    'delete.infoAdminAliasNotDeleted' => 'No s\'han pogut eliminar alguns dels comptes d\'administrador seleccionats.',

    'edit.title' => "%%contact%%",
    'edit.infoNewAdminAliasUpdated' => 'El compte d\'administrador s\'ha actualitzat correctament.',

    'list.title' => 'Comptes d\'administrador addicionals',
    'list.hint' => 'Aquí pot crear comptes d\'administrador addicional pels seus enginyers de suport tècnic per tal que així puguin realitzar tasques administratives.',
];