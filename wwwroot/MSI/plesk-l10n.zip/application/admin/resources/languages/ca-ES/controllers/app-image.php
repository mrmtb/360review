<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'gallery.titleScreenshot' => 'Captures de pantalla de %%packageName%%',
    'gallery.prevImage' => '< Anterior',
    'gallery.nextImage' => 'Següent>',
    'gallery.closeGallery' => 'Tancar',
    'gallery.navigationOf' => 'de',
    'gallery.typeScreenshot' => 'Captures de pantalla',
    'gallery.title' => 'Captures de pantalla',
];