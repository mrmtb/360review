<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'branding.title' => 'Personalització de Plesk',

    'disable-languages.disableLanguagesSuccess' => 'Els idiomes seleccionats ja no estan disponibles pels usuaris.',

    'edit-controls.updateSuccess' => 'La configuració s\'ha actualitzat correctament.',

    'edit-interface-view.title' => 'Modes de visualització de la interfície',
    'edit-interface-view.updateSuccess' => 'La configuració s\'ha actualitzat correctament.',

    'enable-languages.enableLanguagesSuccess' => 'Els idiomes seleccionats passaran a estar disponibles pels usuaris.',

    'language-make-default.languageMakeDefaultSuccess' => 'L\'idioma seleccionat s\'ha establert com idioma predeterminat de Plesk.',

    'list-languages.title' => 'Idiomes',
    'list-languages.mlsLimitExceeded' => "La seva llicència actual de Plesk li permet utilitzar %%allowedByLicense%% idiomes. En aquest moment els usuaris tenen a la seva disposició %%availableToUsers%% idiomes, el que excedeix el número proporcionat per la llicència. Seleccioni els %%allowedByLicense%% idiomes que desitja utilitzar i deshabiliti la resta d'idiomes fent clic a les seves icones a la columna 'S'.",
];