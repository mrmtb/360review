<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.hint' => 'Descripció sobre l\'addició de nodes de serveis remots.',
    'add.title' => 'Addició d\'un node de servei remot',
    'add.serviceNodeAdded' => 'El node de servei remot %%name%% ha estat afegit',

    'delete.infoServiceNodesDeleted' => 'Els nodes de servei seleccionats s\'han desconnectat correctament.',
    'delete.infoServiceNodesNotDeleted' => 'No ha estat possible desconnectar alguns dels nodes de servei seleccionats.',
    'delete.serviceNodeIsInUse' => 'El node de servei s\'està fent servir.',

    'edit.hint' => 'Descripció sobre l\'edició de nodes de serveis remots.',
    'edit.title' => 'Node de servei remot %%name%%',
    'edit.serviceNodeUpdated' => 'Les propietats del node de servei remot %%name%% han estat actualitzades',

    'list.hint' => 'Aquí pot afegir nodes de servei remots.',
    'list.title' => 'Nodes de servei',
];