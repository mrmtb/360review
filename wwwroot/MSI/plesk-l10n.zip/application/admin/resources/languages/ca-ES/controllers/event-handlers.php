<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Addició d\'un controlador d\'events',
    'add.added' => 'El controlador d\'events ha estat afegit.',

    'delete.noHandlersSpecified' => 'Seleccioni els controladors d\'events que desitja eliminar.',
    'delete.handlersDeleted' => 'Els controladors d\'events seleccionats han estat eliminats.',
    'delete.handlersNotDeleted' => 'Alguns dels controladors d\'events seleccionats no han estat eliminats. Detalls: %%error%%.',

    'edit.title' => 'Actualització de les propietats del controlador d\'events',
    'edit.updated' => 'El controlador d\'events ha estat actualitzat.',

    'list.title' => 'Administrador d\'events',
];