<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'assign-to-subscription.databasesSuccessfullyAssignedToSubscription' => 'Les bases de dades s\'han mogut a la subscripció \'%%subscriptionName%%\'.',
    'assign-to-subscription.databasesNotAssignedToSubscription' => 'No ha estat possible moure les bases de dades a la subscripció \'%%subscriptionName%%\'.',
    'assign-to-subscription.subscriptionNotFound' => 'No s\'ha trobat la subscripció \'%%name%%\'.',
    'assign-to-subscription.isNotMainDomain' => '\'%%name%%\' no és el domini principal a la subscripció.',

    'settings.title' => 'Configuració de hosting de bases de dades',
    'settings.settingsSaved' => 'La configuració de hosting de bases de dades ha estat desada.',

    'refresh.success' => 'La informació dels servidors de bases de dades ha estat actualitzada.',
];