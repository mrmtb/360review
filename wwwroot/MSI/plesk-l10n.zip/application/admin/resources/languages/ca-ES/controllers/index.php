<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'eula.title' => 'Contracte de llicència de l\'usuari final (EULA) de WebPros',
    'eula.popupTitle' => 'EULA',
    'eula.updatePopupTitle' => 'Actualització de l\'EULA',
    'eula.popupDescription' => 'Accepti i llegeixi l\'EULA per tal de poder seguir fent servir el producte.',
    'eula.updatePopupDescription' => 'L\'EULA de WebPros ha estat actualitzada. Accepti i llegeixi l\'EULA actualitzat per tal de poder seguir fent servir el producte.',
    'eula.buttonAccept' => 'Acceptar',
    'eula.buttonDecline' => 'Declinar',
];