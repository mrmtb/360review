<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-filter.title' => 'Addició d\'un filtre de jail',
    'add-filter.filterAdded' => 'El filtre de jail ha estat afegit.',
    'add-filter.errorFilterNotAdded' => 'No ha estat possible afegir un filtre de jail: %%error%%.',

    'add-jail.title' => 'Afegir jail',
    'add-jail.jailAdded' => 'El jail ha estat afegit.',

    'add-trusted-ip.title' => 'Afegir una adreça IP de confiança',
    'add-trusted-ip.trustedListTitle' => 'Adreces IP de confiança',
    'add-trusted-ip.ipAdded' => 'L\'adreça IP s\'ha afegit a la llista d\'adreces de confiança.',
    'add-trusted-ip.errorIpNotAdded' => 'No ha estat possible afegir l\'adreça IP: %%error%%.',

    'edit-trusted-ip.title' => 'Editar la descripció per %%ip%%',
    'edit-trusted-ip.ipEdited' => 'La descripció de l\'adreça IP ha estat actualitzada.',
    'edit-trusted-ip.ipAddressNotFound' => 'L\'adreça IP no s\'ha trobat a la llista de confiança.',
    'edit-trusted-ip.errorIpNotEdited' => 'No ha estat possible editar l\'adreça IP: %%error%%.',

    'delete-banned-ips.infoBannedIpsDeleted' => 'Les adreces IP seleccionades han estat eliminades de la llista d\'adreces prohibides.',
    'delete-banned-ips.infoBannedIpsNotDeleted' => 'No ha estat possible eliminar algunes adreces IP de la llista d\'adreces prohibides: %%error%%.',

    'delete-filters.infoFiltersDeleted' => 'Els filtres de jail seleccionats han estat eliminats.',
    'delete-filters.errorFiltersNotDeleted' => 'No ha estat possible eliminar els filtres seleccionats: %%error%%.',
    'delete-filters.errorFiltersBuiltIn' => 'Els filtres integrats no es poden eliminar.',

    'delete-jail.infoJailDeleted' => 'El jail ha estat eliminat.',
    'delete-jail.errorJailNotDeleted' => 'No ha estat possible eliminar el jail: %%error%%.',
    'delete-jail.errorJailsBuiltIn' => 'Els jails integrats no es poden eliminar.',

    'delete-jails.infoJailsDeleted' => 'Els jails seleccionats han estat eliminats.',
    'delete-jails.errorJailsNotDeleted' => 'No ha estat possible eliminar els jails seleccionats: %%error%%.',
    'delete-jails.errorJailsBuiltIn' => 'Els jails integrats no es poden eliminar.',

    'delete-trusted-ips.infoTrustedIpsDeleted' => 'Les adreces IP seleccionades han estat eliminades de la llista d\'adreces de confiança.',
    'delete-trusted-ips.infoTrustedIpsNotDeleted' => 'No ha estat possible eliminar algunes adreces IP de la llista d\'adreces de confiança: %%error%%.',
    'delete-trusted-ips.warningTrustedIpsPresentOnInterfaces' => 'Algunes de les IPs de confiança eliminades estan presents a les interfícies de xarxa: %%ips%%. De forma accidental, aquestes poden ser prohibides i com a conseqüència poden experimentar-se problemes a l\'hora d\'accedir als llocs o serveis.',

    'disable-jails.infoJailsDisabled' => 'Els jails seleccionats han estat desactivats.',
    'disable-jails.errorJailsNotDisabled' => 'No ha estat possible desactivar els jails seleccionats: %%error%%.',

    'edit-filter.title' => 'Edició d\'un filtre de jail',
    'edit-filter.filterSaved' => 'El filtre de jail ha estat desat.',
    'edit-filter.errorFilterNotSaved' => 'No ha estat possible desar el filtre de jail: %%error%%.',
    'edit-filter.errorFilterNotEditable' => 'No es pot canviar el filtre.',

    'edit-jail.title' => '%%name%%',
    'edit-jail.jailSaved' => 'La configuració del jail ha estat desada.',
    'edit-jail.errorJailNotEditable' => 'No es pot canviar el jail.',

    'enable-jails.infoJailsEnabled' => 'Els jails seleccionats han estat activats.',
    'enable-jails.errorJailsNotEnabled' => 'No ha estat possible activar els jails seleccionats: %%error%%.',

    'filters-list.title' => 'Filtres de jail',

    'index.title' => 'Prohibició d\'adreces IP',
    'index.banListTab' => 'Adreces IP prohibides',
    'index.trustedListTab' => 'Adreces IP de confiança',
    'index.jailListTab' => 'Jails',
    'index.settingsTab' => 'Configuració',
    'index.logListTab' => 'Registres',
    'index.jailNotFound' => 'No s\'ha trobat el jail %%name%%.',
    'index.filterNotFound' => 'No s\'ha trobar el filtre %%name%%.',
    'index.logFileNotFound' => 'No s\'ha trobat l\'arxiu de registre.',
    'index.tooManyDomains' => 'Fail2Ban pot no funcionar correctament si hi ha masses dominis i Fail2Ban ha de monitoritzar masses arxius de registre.',
    'index.errorServiceFailed' => 'El servei de prohibició d\'adreces IP (Fail2Ban) ha fallat i pot no funcionar correctament. %%link%%',
    'index.restartLink' => 'Provi a reiniciar',

    'jail-list.failed' => 'No ha estat possible obtenir la llista de jails: %%error%%.',

    'log-view.fileIsEmpty' => 'L\'arxiu està buit.',

    'move-to-trusted.infoTrustedIpsAdded' => 'Les adreces IP seleccionades s\'han afegit a la llista d\'adreces de confiança.',
    'move-to-trusted.infoTrustedIpsNotAdded' => 'No ha estat possible afegir algunes adreces IP a la llista d\'adreces de confiança: %%error%%.',

    'overview-jail.title' => '%%name%%',
    'overview-jail.pageHint' => 'Aquí pot veure la informació detallada sobre el jail.',
    'overview-jail.buttonEditJail' => 'Canviar la configuració',
    'overview-jail.hintEditJail' => 'Canviï la configuració d\'aquest jail.',
    'overview-jail.buttonDisableJail' => 'Desactivar',
    'overview-jail.hintDisableJail' => 'Desactivi aquest jail.',
    'overview-jail.buttonActivateJail' => 'Activar',
    'overview-jail.hintActivateJail' => 'Activi aquest jail.',
    'overview-jail.buttonRemoveJail' => 'Eliminar',
    'overview-jail.hintRemoveJail' => 'Elimini aquest jail.',
    'overview-jail.fieldSatatus' => 'Estat',
    'overview-jail.fieldParameters' => 'Configuració',
    'overview-jail.enabled' => 'Actiu',
    'overview-jail.disabled' => 'Inactiu',
    'overview-jail.banListHint' => 'Adreces IP bloquejades per aquest jail:',

    'restart.success' => 'El reinici del servei pot tardar uns minuts.',
    'restart.failed' => 'No s\'ha pogut reiniciar el servei.',

    'settings.settingsSaved' => 'La configuració ha estat desada.',
    'settings.errorSettingsNotSaved' => 'No ha estat possible desar la configuració: %%error%%.',
    'settings.errorServiceFailed' => 'Error del servei de prohibició d\'adreces IP (Fail2Ban): %%error%%',

    'toggle-jail.infoJailEnabled' => 'El jail ha estat activat.',
    'toggle-jail.infoJailDisabled' => 'El jail ha estat desactivat.',
    'toggle-jail.errorJailNotEnabled' => 'No ha estat possible activar el jail: %%error%%.',
    'toggle-jail.errorJailNotDisabled' => 'No ha estat possible desactivar el jail: %%error%%.',

    'add-banned-ip.title' => 'Prohibir adreça IP',
    'add-banned-ip.bannedListTitle' => 'Adreces IP prohibides',
    'add-banned-ip.ipAdded' => 'L\'adreça IP ha estat afegida a la llista d\'adreces prohibides.',
    'add-banned-ip.errorIpNotAdded' => 'No ha estat possible prohibir l\'adreça IP: %%error%%.',
];