<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Notificacions',

    'email-settings.title' => 'Email',

    'panel-settings.title' => 'IU de Plesk',
    'panel-settings.notificationSettingsSaved' => 'La configuració de notificació s\'ha desat correctament.',

    'panel-notifications-toggle.successfullyEnabled' => 'La notificació \'%%title%%\' ha estat activada.',
    'panel-notifications-toggle.successfullyDisabled' => 'La notificació \'%%title%%\' ha estat desactivada.',

    'template-settings-list.hint' => 'Triï les notificacions que desitja veure activant-les o desactivant-les.',
    'template-settings-list.name' => 'Títol',
    'template-settings-list.context' => 'Context',
    'template-settings-list.sendToAdmin' => 'Enviar a l\'administrador',

    'template-settings-form.storagePeriod' => 'Emmagatzemar notificacions durant',
    'template-settings-form.days' => 'dies',
];