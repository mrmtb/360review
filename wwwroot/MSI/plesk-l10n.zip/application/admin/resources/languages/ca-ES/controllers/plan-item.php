<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Addició d\'un servei',
    'create.hint' => 'Aquí pot afegir un enllaç a un servei extern.',

    'edit.title' => 'Propietats del servei %%name%%',
    'edit.hint' => 'Aquí pot especificar les propietats del servei.',
    'edit.errorItemNotEditable' => 'No és possible editar les propietats d\'aquest servei.',

    'list.title' => 'Serveis addicionals',
    'list.tabTitle' => 'Serveis addicionals',
    'list.hint' => "Aquí pot veure la llista de serveis addicionals que pot aprovisionar amb els plans de hosting. Aquesta mostra els serveis definits manualment i els serveis proporcionats per les aplicacions instal·lades com a extensions de Plesk. L'addició manual d'un servei resulta útil si desitja redireccionar els seus clients a un servei online extern, ja que afegeix un botó al panell del client. Per defecte, tots els serveis addicionals es mostren a les propietats del pla de hosting, concretament a la pestanya Serveis addicionals. Això li permet a vostè i als seus revenedors incloure aquests serveis als plans de hosting. Si no desitja que els seus revenedors puguin fer ús d'un servei ni que el puguin proporcionar als seus clients, faci clic a l'enllaç Fer no disponible.",
    'list.planItemsNowAvailable' => 'Els serveis addicionals seleccionats estan disponibles pels revenedors.',
    'list.planItemsNowNotAvailable' => 'Els serveis addicionals seleccionats ja no estan disponibles pels revenedors.',
    'list.cantChangePlanItemsProperties' => 'S\'ha produït un error quan s\'intentava canviar la configuració de disponibilitat del servei.',
    'list.infoNewPlanItemCreated' => 'L\'opció %%name%% corresponent al servei ha estat afegida a les propietats del pla.',
    'list.infoPlanItemUpdated' => 'L\'opció del pla %%name%% ha estat actualitzada.',
    'list.planItemsDeleted' => 'Les opcions del pla seleccionades han estat eliminades.',
    'list.planItemsNotDeleted' => 'No s\'han pogut eliminar algunes de les opcions del pla seleccionades.',
];