<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Actualitzacions del sistema',

    'list.title' => 'Tots els paquets',
    'list.hint' => 'Els paquets del sistema s\'actualitzen mitjançant les eines del sistema (dpkg/apt o yum). Aquests només s\'actualitzen des dels repositoris des d\'on es van instal·lar. Per tal d\'impedir l\'actualització d\'un paquet, seleccioni\'l a la llista i faci clic a Bloquejar.',

    'lock.success' => 'Els paquets s\'han bloquejat correctament.',

    'settings.title' => 'Configuració',
    'settings.settingsUpdated' => 'La configuració s\'ha modificat correctament.',

    'unlock.success' => 'Els paquets s\'han desbloquejat correctament.',

    'updates-list.title' => 'Actualitzacions disponibles',
    'updates-list.hint' => 'Els paquets del sistema s\'actualitzen mitjançant les eines del sistema (dpkg/apt o yum). Aquests només s\'actualitzen des dels repositoris des d\'on es van instal·lar. Per tal d\'impedir l\'actualització d\'un paquet, seleccioni\'l a la llista i faci clic a Bloquejar.',
];