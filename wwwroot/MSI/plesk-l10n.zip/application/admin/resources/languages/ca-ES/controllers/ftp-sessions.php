<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-sessions.noSessionsSpecified' => 'Seleccioni una o més sessions FTP de la llista.',
    'delete-sessions.sessionsDeleted' => 'Les sessions seleccionades han estat eliminades.',
    'delete-sessions.sessionsNotDeleted' => 'Algunes de les sessions seleccionades no han estat eliminades. Detalls: %%error%%.',

    'list.title' => 'Sessions FTP',
];