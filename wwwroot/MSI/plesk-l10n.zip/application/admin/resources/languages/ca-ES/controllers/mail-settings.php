<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Configuració de correu a nivell del servidor',
    'index.preferencesTab' => 'Configuració',
    'index.spamFilteringTab' => 'Filtració d\'spam',
    'index.antivirusTab' => 'Antivirus',
    'index.blockedDomainsTab' => 'Llista negra',
    'index.whiteListTab' => 'Llista blanca',
    'index.queueTab' => 'Cua de correu',
    'index.statisticsTab' => 'Estadístiques',
    'index.smarthostTab' => 'Smarthost',

    'mail-lists.title' => 'Configuració de l\'administrador de llistes de correu',
    'mail-lists.configured' => 'L\'administrador de la llista de correu Mailman ha estat configurat. A la pantalla Eines i configuració ja no es mostrarà el botó Configurar servidor de llistes de correu.', // PFU
    'mail-lists.noLocalhostInServerWhiteList' => 'Per poder utilitzar llistes de correu, és necessari que localhost (127.0.0.0/8, ::1/128) estigui present a la llista blanca del servidor de correu. De totes maneres, per fer ús del control dels correus sortint localhost no hauria d\'estar present a la llista blanca. Per a resoldre aquesta situació, si ha activat el control dels correus sortint, a la bústia pot fer servir el redireccionament de correu enlloc de fer servir llistes de correu.',
    'mail-lists.noLocalhostInServerWhiteListIpv4' => 'Per poder utilitzar llistes de correu, és necessari que localhost estigui present a la llista blanca del servidor de correu. De totes maneres, per fer ús del control dels correus sortint localhost no hauria d\'estar present a la llista blanca. Per a resoldre aquesta situació, si ha activat el control dels correus sortint, a la bústia pot fer servir el redireccionament de correu enlloc de fer servir llistes de correu. Tingui en compte que en aquest moment la llista blanca no inclou cap adreça localhost IPv4 (127.0.0.0/8), motiu pel qual el control del correus sortints funcionarà per a adreces IPv4.',
    'mail-lists.noLocalhostInServerWhiteListIpv6' => 'Per poder utilitzar llistes de correu, és necessari que localhost estigui present a la llista blanca del servidor de correu. De totes maneres, per fer ús del control dels correus sortint localhost no hauria d\'estar present a la llista blanca. Per a resoldre aquesta situació, si ha activat el control dels correus sortint, a la bústia pot fer servir el redireccionament de correu enlloc de fer servir llistes de correu. Tingui en compte que en aquest moment la llista blanca no inclou cap adreça localhost IPv6 (::1/128), motiu pel qual el control del correus sortints funcionarà per a adreces IPv6.',
    'mail-lists.mailingListSoftwareNotInstalled' => 'El software de llista de correu no està instal·lat.',
    'mail-lists.mailingListSoftwareAlreadyConfigured' => 'El software de llista de correu ja està configurat.',

    'customize-mailbox-quota-warning.title' => 'Personalització de l\'advertiment de quota de la bústia de correu',
    'customize-mailbox-quota-warning.successMessage' => 'El missatge de l\'advertiment de quota de la bústia de correu ha estat modificat.',

    'customize-mailbox-quota-warning-form.subject' => 'Assumpte',
    'customize-mailbox-quota-warning-form.message' => 'Missatge',
    'customize-mailbox-quota-warning-form.tooLongMessage' => "El missatge és massa llarg. La longitud màxima permesa és de %max% caràcters",
];