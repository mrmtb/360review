<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-domain-alias.noDomains' => 'No ha estat possible crear un àlies. No hi ha cap domini disponible.',

    'add-domain.noDomains' => 'No ha estat possible crear un domini complementari. No hi ha cap domini disponible.',

    'add-subdomain.noDomains' => 'No ha estat possible crear un subdomini. No hi ha cap domini disponible.',

    'change-owner.wrongOwnerId' => 'No ha estat possible trobar el nou propietari del compte de client.',

    'change.title' => 'Canvi del pla i dels complements associats amb les subscripcions',

    'create.title' => 'Addició d\'un nou client',

    'domains.title' => 'Dominis',

    'list.title' => 'Clients',
    'list.infoNewCustomerCreated' => 'El client %%name%% ha estat creat.',
    'list.infoCustomerActivated' => 'Els clients seleccionats han estat activats.',
    'list.infoCustomerNotActivated' => 'No s\'han pogut activar alguns dels clients seleccionats.',
    'list.infoCustomerSuspended' => 'Els clients seleccionats han estat suspesos.',
    'list.infoCustomerNotSuspended' => 'No s\'han pogut suspendre alguns dels clients seleccionats.',
    'list.infoCustomerDeleted' => 'Els clients seleccionats han estat eliminats.',
    'list.infoCustomerNotDeleted' => 'No s\'han pogut eliminar alguns dels clients seleccionats.',
    'list.upgrageCustomersHint' => 'A actualitzat a Plesk 11, que utilitza un nou model de negoci i de clients. Per tal de completar el canvi a aquest nou model, converteixi els comptes de client a comptes de client o revenedor. Si no ho fa, els seus clients no podran crear llocs web encara que ja disposessin del permís corresponent.',
    'list.upgrageCustomersLink' => 'Converteixi comptes de client.',
    'list.infoCustomerToResellerConverted' => 'Els clients seleccionats s\'han convertit correctament en revenedors.',
    'list.errorCustomerToResellerNotConverted' => 'Alguns dels clients seleccionats no s\'han pogut convertir en revenedors.',
    'list.infoOwnerChanged' => 'Els clients seleccionats s\'han transferit a %%name%%.',
    'list.infoOwnerNotChanged' => 'Alguns dels clients seleccionats no s\'han transferit a %%name%%.',

    'login-info.title' => 'Edició de la informació d\'inici de sessió de %%name%%',

    'overview.title' => '%%name%%',

    'personal-info.title' => 'Edició de la informació de contacte de %%name%%',

    'subscriptions.title' => 'Subscripcions',
];