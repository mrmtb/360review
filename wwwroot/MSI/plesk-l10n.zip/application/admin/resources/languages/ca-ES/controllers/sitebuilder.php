<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'settings.title' => 'Configuració del mode Provar i comprar',
    'settings.sitebuilderSettingsUpdated' => 'La configuració ha estat actualitzada.',
];