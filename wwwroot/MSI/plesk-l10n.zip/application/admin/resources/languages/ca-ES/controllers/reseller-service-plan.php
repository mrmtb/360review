<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Creació d\'un pla de revenedor',
    'create.hint' => 'Aquí pot crear un pla de revenedor corresponent a la seva oferta.',

    'edit.title' => '%%name%%',
    'edit.hint' => 'Aquí pot modificar el pla de revenedor corresponent a la seva oferta. Tingui en compte que el fet de modificar el pla farà que s\'actualitzin totes les subscripcions associades amb aquest de forma automàtica, a excepció de les subscripcions personalitzades, que no es sincronitzen.',

    'list.title' => 'Plans de revenedor',
    'list.hint' => 'Aquí pot gestionar els seus plans de revenedor i crear subscripcions de revenedor. A diferència dels clients estàndard del servei de hosting, un revenedor pot estar subscrit a un únic pla i no pot tenir complements.',
    'list.tabTitle' => 'Plans de revenedor',
    'list.infoNewPlanCreated' => 'El pla de revenedor %%name%% ha estat creat.',
    'list.infoPlanUpdated' => 'El pla de revenedor %%name%% ha estat actualitzat.',
    'list.infoPlanUpdatedSynced' => 'El pla de serveis %%name%% ha estat actualitzat. Totes les subscripcions de revenedor associades s\'han sincronitza correctament, a excepció de les subscripcions personalitzades, que no es poden sincronitzar.',
    'list.infoPlanDeleted' => 'Els plans de revenedor seleccionats han estat eliminats.',
    'list.infoPlanNotDeleted' => 'Alguns dels plans de revenedor seleccionats no han estat eliminats.',
    'list.infoPlanDuplicated' => 'Els plans de serveis seleccionats s\'han duplicat correctament.',
    'list.infoPlanNotDuplicated' => 'Alguns dels plans de serveis seleccionats no han estat duplicats.',
];