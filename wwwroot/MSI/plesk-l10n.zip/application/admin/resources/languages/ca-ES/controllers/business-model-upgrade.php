<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'admin-customers-target-list.title' => 'Clients de l\'admin que necessiten transició',
    'admin-customers-target-list.hint-t1s1' => 'Aquesta llista mostra els clients a qui no es permetia modificar els límits del domini i que tenien un domini abans de l\'actualització.',
    'admin-customers-target-list.hint-t1s2' => 'Aquesta llista mostra els clients a qui es permetia modificar els límits del domini i que tenien un domini abans de l\'actualització.',
    'admin-customers-target-list.hint-t1s3' => 'Aquesta llista mostra els clients a qui no es permetia crear dominis ni modificar els límits del domini i que tenien més d\'un domini abans de l\'actualització.',
    'admin-customers-target-list.hint-t1s6' => 'Aquesta llista mostra els clients a qui es permetia crear dominis ni modificar els límits del domini i que tenien més d\'un domini abans de l\'actualització.',

    'admin-subscriptions-target-list.title' => 'Subscripcions de l\'admin que necessiten transició',
    'admin-subscriptions-target-list.hint' => 'Aquí pot veure una llista de subscripcions formada pels dominis que (a) pertanyien a l\'admin i (b) tenien activat un compte d\'administrador de domini abans de l\'actualització.',

    'bunch.title' => 'Finalització del canvi al nou model de negoci de Plesk',
    'bunch.noActionsDescription' => 'No hi ha cap client ni cap subscripció que s\'ajusti als escenaris comuns restants al sistema, motiu pel que no hi ha cap operació pendent de fer en aquesta pestanya. Vagi a la propera pestanya i efectuï la transició pels clients restants.',
    'bunch.description' => 'El model de distribució de recursos a Plesk 10 i a les versions posteriors no és el mateix que el de les versions anteriors. A partir de Plesk 10, els clients no disposen dels seus propis recursos tal i com passava a Plesk 8 i Plesk 9, sinó que els obtenen amb les subscripcions. En aquest moment hi ha varis clients que disposen de recursos legacy, pels que s\'hauria d\'efectuar la transició correctament per tal que s\'adaptin al nou model de Plesk. Basant-se en els escenaris d\'ús més habituals de Plesk, Plesk ha analitzat aquests clients i ha generat la llista d\'accions de transició recomanades que pot veure a continuació. Pot realitzar aquestes accions ara mateix o bé seleccionar un esquema de transició per client. Un cop efectuada la transició dels clients, aquests desapareixeran d\'aquesta llista.',
    'bunch.help' => 'Més informació sobre la transició.',
    'bunch.applyed' => 'S\'ha efectuat la transició dels clients i subscripcions seleccionats.',
    'bunch.failed' => 'No ha estat possible efectuar la transició dels clients i subscripcions seleccionats.',

    'customers.title' => 'Finalització del canvi al nou model de negoci de Plesk − Transició selectiva de clients',
    'customers.description' => 'Aquí pot veure la llista completa de clients que requereixen transició. Juntament amb els comptes que s\'ajustin als escenaris comuns, aquesta inclou aquells comptes que presentin paràmetres irregulars, pels que no es recomana cap acció. Seleccioni un esquema de transició aplicable en el seu cas en funció de la configuració anterior del client, com per exemple límits, permisos, número actual de dominis, etc. Per a conèixer els permisos i límits d\'un client anterior, faci clic al nom del client i a continuació a \'Els meus recursos\' a la llista de subscripcions del client.',
    'customers.help' => 'Més informació sobre la transició.',

    'manual-customer-solution.appliedInfo' => 'S\'ha efectuat la transició dels clients seleccionats.',
    'manual-customer-solution.notAppliedInfo' => 'No s\'ha efectuat la transició de tots o varis clients seleccionats.',

    'manual-subscription-solution.appliedInfo' => 'S\'ha efectuat la transició de les subscripcions seleccionades.',
    'manual-subscription-solution.notAppliedInfo' => 'No s\'ha efectuat la transició de totes o vàries subscripcions seleccionades.',

    'notes.nonApplicableCustomers' => "%%count%% clients no s'ajusten a cap dels escenaris comuns, motiu pel qual no es recomana cap acció. Per a realitzar la transició dels comptes, %%link%%.",
    'notes.nonApplicableSubscriptions' => "%%count%% subscripcions no s'ajusten a cap dels escenaris comuns, motiu pel qual no es recomana cap acció. Per a realitzar la transició de les subscripcions, %%link%%.",
    'notes.manualCustomersUpgradeLink' => 'seleccioni un esquema personalitzat per aquests',
    'notes.manualSubscriptionsUpgradeLink' => 'seleccioni un esquema personalitzat per aquests',

    'reseller-customers-target-list.title' => 'Clients dels revenedors que necessiten transició',
    'reseller-customers-target-list.hint-t2s1' => 'Aquesta llista mostra els clients a qui no es permetia modificar els límits del domini i que tenien un domini abans de l\'actualització.',
    'reseller-customers-target-list.hint-t2s2' => 'Aquesta llista mostra els clients a qui es permetia modificar els límits del domini i que tenien un domini abans de l\'actualització.',
    'reseller-customers-target-list.hint-t2s3' => 'Aquesta llista mostra els clients a qui no es permetia crear dominis ni modificar els límits del domini i que tenien més d\'un domini abans de l\'actualització.',
    'reseller-customers-target-list.hint-t2s6' => 'Aquesta llista mostra els clients a qui es permetia crear dominis ni modificar els límits del domini i que tenien més d\'un domini abans de l\'actualització.',

    'reseller-subscriptions-target-list.title' => 'Subscripcions dels revenedors que necessiten transició',
    'reseller-subscriptions-target-list.hint' => 'Aquí pot veure una llista de subscripcions formada pels dominis que (a) pertanyien a revenedors i (b) tenien activat un compte d\'administrador de domini abans de l\'actualització.',

    'subscriptions.title' => 'Finalització del canvi al nou model de negoci de Plesk − Transició selectiva de subscripcions',
    'subscriptions.description' => 'Aquí pot veure una llista de subscripcions que necessiten transició. Aquesta inclou les mateixes subscripcions que les mostrades a la pàgina Accions recomanades, si bé aquí pot seleccionar l\'esquema de transició més adequat per a una determinada subscripció. Aquestes subscripcions s\'han creat des de dominis que (a) pertanyien a l\'admin o a un revenedor i (b) tenien activat un compte d\'administrador de domini.',
    'subscriptions.help' => 'Més informació sobre la transició.',

    'tabs.bunch' => 'Accions recomanades',
    'tabs.customers' => 'Transició selectiva de clients',
    'tabs.subscriptions' => 'Transició selectiva de subscripcions',
];