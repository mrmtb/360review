<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'operation.startActionSuccess' => 'El servei ha estat iniciat',
    'operation.stopActionSuccess' => 'El servei ha estat aturat',
    'operation.restartActionSuccess' => 'El servei ha estat reiniciat',
    'operation.changeStartupActionSuccess' => 'El tipus d\'inici pel servei s\'ha modificat correctament',

    'list.title' => 'Serveis',

    'operation.startServiceMessage' => 'Esperi uns minuts fins que s\'iniciï el servei.',
    'operation.stopServiceMessage' => 'Esperi uns minuts fins que s\'aturi el servei.',
    'operation.restartServiceMessage' => 'Esperi uns minuts fins que es reiniciï el servei.',
    'operation.unableFetchFormData' => 'No ha estat possible recuperar les dades del formulari: %%error%%',
    'operation.startActionError' => 'No ha estat possible iniciar el servei: %%error%%',
    'operation.stopActionError' => 'No ha estat possible aturar el servei: %%error%%',
    'operation.restartActionError' => 'No ha estat possible reiniciar el servei: %%error%%',
    'operation.changeStartupActionError' => 'No s\'ha pogut canviar el tipus d\'inici pel servei: %%error%%',
];