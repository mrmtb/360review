<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'clear-cache.apsCacheCleared' => 'Els arxius temporals han estat eliminats.',

    'configure.title' => '%%name%%',
    'configure.applicationNotFound' => "No s'ha trobat cap aplicació amb ID '%%id%%'.",
    'configure.applicationHasNoSettings' => 'L\'aplicació no presenta cap configuració.',
    'configure.settingsUpdated' => 'La configuració de l\'aplicació ha estat actualitzada.',
    'configure.settingsUpdateFailed' => 'No ha estat possible actualitzar la configuració de l\'aplicació: %%error%%',
    'configure.instancesNotReconfigured' => 'No s\'han pogut reconfigurar algunes de les instàncies de l\'aplicació.',

    'index.title' => 'Application vault',

    'info.title' => '%%name%%',
    'info.hint' => 'La llista que es mostra a continuació detalla la informació sobre els llocs web on s\'ha instal·lat l\'aplicació. El valor Cap a la columna Lloc web indica que l\'aplicació és externa. Aquest tipus d\'aplicació no es pot instal·lar en alguns llocs web del client, ja que només proporciona un enllaç a un servei extern.',

    'remote-app-info.title' => 'Detalls de l\'aplicació',

    'update-settings.title' => 'Configuració d\'actualització',
    'update-settings.settingsUpdated' => 'La configuració ha estat actualitzada.',
    'update-settings.settingsUpdateFailed' => 'No ha estat possible actualitzar la configuració: %%error%%',

    'upload.title' => 'Afegir aplicació',
    'upload.packageInstallationError' => 'No ha estat possible afegir l\'aplicació: %%message%%.',
    'upload.appUploaded' => 'L\'aplicació s\'ha carregat correctament.',
    'upload.appDownloadStarted' => 'Descarregant les aplicacions seleccionades.',

    'uploaded.title' => 'Les meves aplicacions',
    'uploaded.hint' => 'Aquí pot afegir o eliminar aplicacions de l\'Application Vault, així com gestionar la seva disponibilitat pels clients. Hi ha dos motius per l\'addició d\'aplicacions: Ampliar la llista d\'aplicacions disponibles o configurar els paràmetres de les aplicacions a nivell del servidor. Algunes aplicacions no es poden instal·lar sense aquest tipus de configuració. A continuació es detallen totes les aplicacions afegides.',
    'uploaded.infoAppDeleted' => 'Les aplicacions seleccionades han estat eliminades.',
    'uploaded.infoAppNotDeleted' => 'No s\'han pogut eliminar algunes de les aplicacions seleccionades.',
    'uploaded.applicationsNowAvailable' => 'Ara els seus clients poden instal·lar o configurar les aplicacions seleccionades.',
    'uploaded.applicationsNowNotAvailable' => 'Les aplicacions seleccionades ja no poden ser instal·lades o configurades pels seus clients.',
    'uploaded.cantChangePackageProperties' => 'S\'ha produït un error quan s\'intentava canviar la configuració de disponibilitat de l\'aplicació.',
    'uploaded.appDownloaded' => 'Les aplicacions seleccionades s\'han descarregat correctament.',
    'uploaded.appNotDownloaded' => 'No s\'han pogut descarregar algunes de les aplicacions seleccionades.',
    'uploaded.downloadInProgress' => 'Esperi...',

    'usage.title' => 'Aplicacions instal·lades',
    'usage.hint' => 'A continuació pot veure la llista de totes les aplicacions afegides per vostè o instal·lades pels seus clients. Aquí pot gestionar-ne la seva configuració, comprovar l\'existència d\'actualitzacions o eliminar arxius temporals afegits durant la instal·lació de les aplicacions.',
    'usage.hintReseller' => 'A continuació pot veure la llista amb la informació sobre totes les aplicacions instal·lades als seus llocs i als llocs dels seus clients. Faci clic al nom d\'una aplicació per veure la llista dels llocs web on ha estat instal·lada i per comprovar l\'existència d\'actualitzacions per l\'aplicació.',
];