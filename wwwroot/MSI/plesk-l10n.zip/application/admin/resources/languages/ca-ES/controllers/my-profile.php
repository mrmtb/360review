<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-password.title' => "Canvi de la contrasenya de l'administrador",
    'change-password.passwordChanged' => 'La contrasenya de l\'administrador ha estat modificada.',

    'index.personalInfoTitle' => "Edició del perfil de l'administrador",
    'index.successMessage' => "El seu perfil ha estat actualitzat.",
    'index.aliasInfoTitle' => 'Informació del compte d\'administrador addicional',
    'index.aliasInfoUpdated' => 'La informació personal del compte d\'administrador addicional ha estat actualitzada.',
];