<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoDomainActivated' => 'Els àlies i dominis seleccionats han estat activats.',
    'activate.errorDomainNotActivated' => 'No s\'han pogut activar alguns dels dominis o àlies seleccionats.',
    'activate.domainStillSuspended' => 'No ha estat possible activar el domini: %%reason%%',
    'activate.domainStatusOffByAdmin' => 'El domini ha estat suspès per l\'administrador.',
    'activate.domainStatusOffWithParent' => 'El propietari del domini o la seva subscripció està suspès.',
    'activate.domainStatusOffExpired' => 'La subscripció corresponent ha caducat.',
    'activate.domainStatusOffBackupRestore' => 'El domini s\'ha suspès temporalment perquè s\'està efectuant un backup o una restauració.',
    'activate.domainStatusOff' => 'El domini està suspès.',
    'activate.aliasStillSuspended' => 'No ha estat possible activar l\'àlies. El domini de destí està suspès.',

    'add-domain-alias.noDomains' => 'No ha estat possible crear un àlies. No hi ha cap domini disponible.',

    'add-domain.noDomains' => 'No ha estat possible crear un domini complementari. No hi ha cap domini disponible.',

    'add-subdomain.noDomains' => 'No ha estat possible crear un subdomini. No hi ha cap domini disponible.',

    'disable.infoDomainDisabled' => 'Els dominis seleccionats han estat desactivats.',
    'disable.errorDomainNotDisabled' => 'Alguns dels dominis seleccionats no han estat desactivats.',

    'list.title' => 'Dominis',
    'list.customerLinkTitle' => 'creï un compte de client',
    'list.subscriptionLinkTitle' => 'creï la seva pròpia subscripció',

    'suspend.infoDomainSuspended' => 'Els dominis seleccionats han estat suspesos.',
    'suspend.errorDomainNotSuspended' => 'Alguns dels dominis seleccionats no han estat suspesos.',
];