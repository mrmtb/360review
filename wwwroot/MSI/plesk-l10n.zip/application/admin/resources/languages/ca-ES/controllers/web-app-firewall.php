<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-log.actionSuccess' => 'Els arxius de registre seleccionats han estat eliminats.',
    'delete-log.invalidFileName' => 'El nom de l\'arxiu de registre no és vàlid.',
    'delete-log.actionError' => 'No ha estat possible eliminar l\'arxiu de registre %%file%%: %%reason%%',

    'index.title' => 'Firewall per a aplicacions web',
    'index.generalTab' => 'General',
    'index.settingsTab' => 'Configuració',
    'index.settingsSaved' => 'La configuració del firewall per a aplicacions web ha estat desada.',
    'index.updateFailed' => 'No ha estat possible actualitzar el conjunts de regles ModSecurity: %%error%%',
    'index.updateFailedShort' => 'No ha estat possible actualitzar el conjunts de regles ModSecurity. %%link%%',
    'index.updateFailedShortLink' => 'Detalls',

    'log-list.title' => 'Gestió d\'arxius de registre',

    'view-log.fileNameIsUndefined' => 'No s\'ha definit el nom de l\'arxiu de registre.',
];