<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Plesk Installer',
    'index.autoinstallerRedirectError' => 'No ha estat possible iniciar Plesk Installer. S\'ha produït el següent error: %%message%%',

    'product.title' => 'Plesk Installer',
    'product.autoinstallerRedirectError' => 'No ha estat possible iniciar Plesk Installer. S\'ha produït el següent error: %%message%%',

    'settings.title' => 'Configuració d\'actualització',
    'settings.settingsUpdated' => 'La configuració d\'actualització s\'ha modificat.',
];