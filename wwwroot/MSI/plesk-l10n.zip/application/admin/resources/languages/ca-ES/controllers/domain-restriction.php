<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Addició d\'un nom de domini',
    'add.domainAdded' => 'El nom de domini %%domain%% s\'ha afegit correctament a la llista de noms prohibits.',

    'disable.listDisabled' => 'La comprovació de noms de dominis prohibits ha estat desactivada.',

    'edit.title' => '%%name%%',
    'edit.domainUpdated' => 'El nom de domini %%domain%% s\'ha actualitzat correctament.',

    'enable.listEnabled' => 'La comprovació de noms de dominis prohibits ha estat activada.',

    'list.title' => 'Noms de domini prohibits',
    'list.hint' => 'Aquí pot gestionar la llista de noms de domini prohibits, que inclou els dominis més populars. Si activa la comprovació de noms de domini prohibits fent clic a Activar, els usuaris no podran crear dominis amb els noms d\'aquesta llista. Aquesta restricció resulta especialment útil per a evitar l\'intercepció dels correus. Si la comprovació està desactivada, els correus que enviïn els seus clients a empreses legítimes pot ser que siguin rebuts per clients que van crear dominis amb els mateixos noms que aquestes empreses.',
    'list.warningLisDisabled' => 'La comprovació de noms de dominis prohibits està desactivada.',

    'remove.domainRemoved' => 'Els noms de domini seleccionats han estat eliminats.',
    'remove.domainNotRemoved' => 'No s\'han pogut eliminar alguns dels noms de domini seleccionats.',
    'remove.unableRemove' => 'No s\'han pogut eliminar alguns dels noms de domini especificats.',
];