<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Gestió de sessions',

    'remove.sessionsDeleted' => 'Les sessions seleccionades s\'han eliminat correctament.',

    'settings.title' => 'Configuració de la sessió',
    'settings.settingsUpdated' => 'La configuració s\'ha modificat correctament.',
];