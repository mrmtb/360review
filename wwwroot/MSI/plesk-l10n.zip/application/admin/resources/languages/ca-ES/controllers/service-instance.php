<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.formTitle' => 'Seleccioni el servei que desitja afegir',
    'create.successfullyAdded' => 'El servei \'%%serviceDisplayName%%\' s\'ha creat correctament.',
    'create.successfullyUpdated' => 'El servei \'%%serviceDisplayName%%\' s\'ha actualitzat correctament.',
    'create.selectServiceInstallationTitle' => 'Seleccionar un servei',

    'edit.formTitle' => 'Gestió del servei \'%%serviceDisplayName%%\'',
    'edit.title' => 'Serveis de %%subscriptionName%%',
    'edit.successfullyUpdated' => 'El servei \'%%serviceDisplayName%%\' s\'ha actualitzat correctament.',

    'list.hint' => 'Aquí pot gestionar els serveis a la subscripció.',
    'list.title' => 'Serveis de %%subscriptionName%%',
    'list.breadcrumb' => 'Serveis',
    'list.infoServiceDeleted' => 'Els serveis seleccionats han estat eliminats.',
    'list.infoServiceNotDeleted' => 'Alguns dels serveis seleccionats no han estat eliminats.',
];