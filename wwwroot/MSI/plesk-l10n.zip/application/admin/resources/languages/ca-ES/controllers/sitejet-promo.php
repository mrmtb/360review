<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

$messages = [
    'accessDenied' => 'Sitejet Builder no s\'inclou a la teva subscripció. Per a habilitar Sitejet Builder, posa\'t en contacte amb el teu servei de hosting.',
];