<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Estat del servidor',
    'index.pageHint' => 'Aquí pot veure els informes detallats sobre l\'estat del servidor. Si desitja veure com han anat canviant els paràmetres de l\'estat del servidor, seleccioni els paràmetres desitjats i Plesk li mostrarà els gràfics corresponents. Tingui en compte que pot canviar el període pel que es presenten els informes − des de les darreres 3 hores fins a una setmana. Aquí també pot canviar la configuració de seguiment d\'estat que defineix quan s\'haurien de mostrar alarmes vermelles i grogues per cadascun dels paràmetres i quins recursos del disc duro caldria monitoritzar. Per fer-ho, descarregui un arxiu de configuració fent clic al botó que pot veure a continuació, editi l\'arxiu i carregui la seva versió. Si el hardware del servidor ha canviat, hauria de propagar aquests canvis al seguiment d\'estat per així obtenir unes estadístiques que siguin correctes.',
    'index.waitMessage' => 'Carregant...',
    'index.buttonUpload' => 'Carregar arxiu de configuració',
    'index.buttonDownload' => 'Descarregar arxiu de configuració',
    'index.buttonRestoreDefaults' => 'Revertir a la configuració predeterminada',
    'index.buttonReconfigure' => 'Detectar canvis de hardware',
    'index.buttonUploadHint' => 'Carregui el seu arxiu de configuració de seguiment d\'estat. La nova configuració s\'aplicarà just quan finalitzi el procés de càrrega.',
    'index.buttonDownloadHint' => 'Desi la configuració actual del seguiment d\'estat.',
    'index.buttonRestoreDefaultsHint' => 'Restauri la configuració predeterminada del seguiment d\'estat del servidor.',
    'index.buttonReconfigureHint' => 'Propagui els canvis efectuats a la configuració de hardware al seguiment d\'estat.',
    'index.confirmRestoreDefaultsTitle' => 'Restaurant la configuració predeterminada del seguiment d\'estat del servidor',
    'index.confirmRestoreDefaultsDescription' => 'Està segur que desitja restaurar la configuració predeterminada?',
    'index.confirmReconfigureTitle' => 'Detectant canvis de hardware',
    'index.confirmReconfigureDescription' => 'Està a punt d\'actualitzar la configuració de hardware a seguiment d\'estat. Això és especialment important si el hardware del servidor s\'ha modificat i desitja reflexar aquests canvis a les estadístiques de seguiment d\'estat. Desitja continuar?',
    'index.settingsWereRestoredToDefault' => 'La configuració predeterminada ha estat restaurada.',
    'index.healthMonitorWasReconfigured' => 'La informació de seguiment d\'estat sobre la configuració de hardware ha estat actualitzada.',

    'parameters.loading' => 'Carregant...',
    'parameters.selectPeriod' => 'Seleccionar període',
    'parameters.periodFromNowTo3h' => '3 hores',
    'parameters.periodFromNowTo6h' => '6 hores',
    'parameters.periodFromNowTo12h' => '12 hores',
    'parameters.periodFromNowTo1d' => '1 dia',
    'parameters.periodFromNowTo3d' => '3 dies',
    'parameters.periodFromNowTo7d' => '1 setmana',

    'thresholds-hint.waitMessage' => 'Carregant...',

    'upload-config-file.title' => 'Càrrega d\'un arxiu de configuració',
    'upload-config-file.configurationUploadedSuccessfully' => 'La configuració ha estat carregada i aplicada.',
];