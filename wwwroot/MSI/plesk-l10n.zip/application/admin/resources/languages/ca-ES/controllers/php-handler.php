<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Configuració de PHP',
    'list.hint' => 'Seleccioni els controladors de PHP que desitja que estiguin disponibles. Pot instal·lar controladors addicionals mitjançant %%link%%.',
    'list.hintLink' => 'Plesk Installer',
    'list.brokenDomainsError' => 'Les versions de PHP detallades a continuació no estan instal·lades: %%phpVersions%%. Scripting de PHP per %%domainCount%% domini(s) no disponible. Instal·li les versions que faltin o dugui a terme els passos detallats a <a href=https://support.plesk.com/hc/en-us/articles/12377342328343>l\'article de la base de coneixement</a> per reparar el scripting de PHP.',
    'list.brokenHandlersError' => 'Les següents versions de PHP no estan instal·lades: %%phpVersions%%. Instal·li-les o executi <code>plesk repair web -php-handlers</code> per seleccionar una altra versió de PHP.',

    'modules.canNotManageModules' => 'L\'accés a la gestió de la configuració del controlador de PHP està limitada perquè no s\'ha especificat la ruta a l\'arxiu PHP CLI.',

    'php-ini.title' => 'Configuració per <b>%%name%%</b>',
    'php-ini.tabTitle' => 'php.ini',
    'php-ini.success' => 'La configuració ha estat actualitzada.',

    'toggle.errorEnableBrokenHandler' => 'El controlador està malmès i no es pot activar.',
    'toggle.errorDisableBrokenHandler' => 'El controlador està malmès i no es pot desactivar.',
    'toggle.infoHandlerEnabled' => 'El controlador ha estat activat.',
    'toggle.infoHandlerDisabled' => 'El controlador ha estat desactivat.',
];