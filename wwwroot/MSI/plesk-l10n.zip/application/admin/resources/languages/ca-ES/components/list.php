<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'recordsTotal' => '%%total%% elements en total',
    'pages' => 'Pàgines',
    'firstPage' => 'Primera',
    'lastPage' => 'Última',
    'numberOfItemPerPage' => 'Entrades per pàgina',
    'hideSearch' => 'Amagar la cerca',
    'showSearch' => 'Mostrar la cerca',
    'buttonSearch' => 'Buscar',
    'buttonResetSearch' => 'Restablir cerca',
    'noEntriesFound' => 'No s\'ha trobat cap element.',
    'itemsNotSelected' => 'Seleccioni primer els elements.',
    'messageBoxButtonYes' => 'Sí',
    'messageBoxButtonNo' => 'No',
    'messageBoxButtonOk' => 'ACCEPTAR',
    'allItems' => 'Totes',
];