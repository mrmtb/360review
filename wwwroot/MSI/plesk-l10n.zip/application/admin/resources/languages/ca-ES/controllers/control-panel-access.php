<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-network.title' => 'Addició d\'una xarxa',
    'add-network.added' => 'La xarxa %%address%% ha estat afegida.',

    'delete-network.noNetworksSpecified' => 'Seleccioni una o vàries xarxes de la llista de restricció d\'accés IP.',
    'delete-network.networksDeleted' => 'Les xarxes seleccionades han estat eliminades.',
    'delete-network.networksNotDeleted' => 'Algunes de les xarxes seleccionades no han estat eliminades. Detalls: %%error%%.',

    'edit-network.title' => 'Edició de xarxa',
    'edit-network.updated' => 'La xarxa %%address%% ha estat actualitzada.',

    'list.title' => 'Gestió de la restricció d\'accés IP',
    'list.currentIpAddressDenied' => 'En aquests moments, la directiva de restricció d\'accés i la llista de xarxes està configurada de tal manera que vostè no podrà iniciar sessió amb permisos d\'administrador des de l\'adreça IP \'%%remoteAddress%%\'.',
    'list.allowHint' => 'Es permet l\'accés a Plesk amb les credencials de l\'administrador, excloent les xarxes presents a la llista.',
    'list.denyHint' => 'Es denega l\'accés a Plesk amb les credencials de l\'administrador des de totes les xarxes que no estan presents en aquesta llista.',

    'settings.title' => 'Configuració de la restricció d\'accés IP',
    'settings.settingsSaved' => 'La directiva de restricció d\'accés IP ha estat desada.',
];