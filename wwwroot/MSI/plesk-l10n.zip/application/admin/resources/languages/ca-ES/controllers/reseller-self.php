<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'oversell-policy.title' => 'Modificació de la directiva de sobreventa',
    'oversell-policy.pageHint' => 'Aquí pot modificar la seva directiva de sobreventa actual.',
    'oversell-policy.oversellPolicyChanged' => 'La directiva de sobreventa s\'ha actualitzat correctament.',
    'oversell-policy.oversellPolicyNotChanged' => 'La directiva de sobreventa no es pot actualitzar.',

    'subscription-overview.title' => 'Informació general sobre la subscripció',
    'subscription-overview.pageHint' => 'Aquí pot veure la informació general sobre la seva subscripció, incloent la informació sobre la quantitat de recursos utilitzats en contraposició amb els recursos proporcionats, la directiva de sobreventa, així com els privilegis i els serveis proporcionats amb la subscripció.',
    'subscription-overview.changeOversellPolicyLink' => '[canviar]',
    'subscription-overview.oversellEnabledHint' => 'La seva subscripció permet la sobreventa de recursos, el que significa que pot vendre més recursos dels inicialment assignats a la seva subscripció. En aquest cas es regeix per l\'ús actual de recursos, enlloc de regir-se per l\'assignació inicial de recursos.',
    'subscription-overview.oversellDisableHint' => 'La seva subscripció no permet sobrevendre els recursos, el que significa que només pot vendre els recursos inicialment assignats amb la subscripció, sense tenir en compte la quantitat de recursos utilitzada.',
    'subscription-overview.tabResources' => 'Recursos',
    'subscription-overview.tabPermissions' => 'Permisos',
    'subscription-overview.resourcesSummaryHint' => 'Aquí pot veure un resum de l\'ús dels recursos proporcionats amb la subscripció.',
    'subscription-overview.showMoreResources' => 'Mostrar més recursos disponibles',
    'subscription-overview.hideMoreResources' => 'Mostrar menys recursos',
    'subscription-overview.permissionsSummaryHint' => 'Aquí pot veure la llista de serveis i privilegis proporcionats amb la subscripció.',
    'subscription-overview.hideMorePermissions' => 'Mostrar menys permisos',
    'subscription-overview.showMorePermissions' => 'Mostrar més permisos',
];