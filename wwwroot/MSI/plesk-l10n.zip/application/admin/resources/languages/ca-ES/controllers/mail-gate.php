<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Configuració de servidor SMTP extern',
    'index.settingsUpdated' => 'La configuració ha estat actualitzada.',
];