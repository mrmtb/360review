<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-customer-owner.title' => 'Transferència de clients a un altre propietari',
    'change-customer-owner.description' => 'Aquests comptes de client es mouran a un altre propietari. Pot modificar els plans de servei per les subscripcions dels clients. Si desitja preservar els recursos disponibles per un client, deixi seleccionat el pla personalitzat.',
    'change-customer-owner.ownerHint' => 'Els clients es mouran al propietari seleccionat:',
    'change-customer-owner.ipAddressHint' => 'No es pot preservar una adreça IP dedicada.',
    'change-customer-owner.loading' => 'Esperi...',
    'change-customer-owner.ipAddressNotSelected' => 'Seleccioni almenys una adreça IP per cadascuna de les subscripcions.',
    'change-customer-owner.ownerNotSelected' => 'Seleccioni un propietari.',

    'customer.title' => 'Conversió de clients en revenedors',
    'customer.description' => 'Els comptes de client es convertiran en comptes de revenedor. Pot escollir plans de revenedor pels comptes convertits. Si desitja preservar els recursos que estaven disponibles per un client, seleccioni el pla personalitzat. D\'aquesta manera, el revenedor disposarà de la suma de les assignacions de recursos, permisos i aplicacions de totes les subscripcions.',
    'customer.loading' => 'Conversió en curs...',

    'reseller.title' => 'Conversió de revenedors en clients',
    'reseller.description' => 'Els revenedors es convertiran en clients.',
    'reseller.descriptionExtended' => 'Triï plans de servei per aquells revenedors que disposen de les seves pròpies subscripcions. Si desitja preservar els recursos disponibles per un revenedor, seleccioni el pla de servei personalitzat. Per tal de moure les subscripcions del revenedor a un dels plans de servei existents, seleccioni un pla existent.',
    'reseller.loading' => 'Conversió en curs...',
];