<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'isEmpty' => 'Aquest camp obligatori està buit. Indiqui un valor per aquest camp.',
    'stringLengthTooShort' => "'%value%' té menys de %min% caràcters.",
    'stringLengthTooLong' => "'%value%' té més de %max% caràcters.",
    'regexNotMatch' => "'%value%' no coincideix amb el patró '%pattern%'.",
    'notAlnum' => "'%value%' inclou caràcters que no són alfanumèrics. Comprovi que només utilitza caràcters alfanumèrics.",
    'stringEmpty' => "'%value%' està buit.",
    'stringsNotEqual' => 'Les cadenes de text no són iguals.',
    'passwordsNotEqual' => 'Les contrasenyes introduïdes no coincideixen.',
    'passwordLengthTooShort' => "la contrasenya té menys de %min% caràcters.",
    'passwordLengthTooLong' => "la contrasenya té més de %max% caràcters.",
    'passwordRegexNotMatch' => "la contrasenya no coincideix amb el patró '%pattern%'.",
    'invalidUrl' => 'L\'adreça especificada no és vàlida. Indiqui una adreça vàlida com http://domain.com.',
    'specialCharactersInIpAddress' => 'L\'adreça IP proporcionada no és vàlida.',
    'massEmailContactsNotSelected' => 'Seleccioni almenys un contacte de la llista.',
    'ipAddressIsTooLong' => 'Una adreça IP no pot estar formada per més de %max% caràcters.',
    'ipAddressDescriptionTooLong' => 'La descripció no pot estar formada per més de %max% caràcters.',

    'fail2ban.invalidIpOrCidr' => 'L\'adreça IP ha de ser una adreça IP vàlida o una màscara CIDR.',
];