<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Addició d\'un certificat SSL/TLS',
    'add.enterCertificateName' => 'Indiqui el nom del certificat.',

    'delete.infoSslCertificatesDeleted' => 'Els certificats SSL/TLS han estat eliminats.',
    'delete.infoSslCertificatesNotDeleted' => 'No ha estat possible eliminar els certificats SSL/TLS.',
    'delete.certificateUsedAsDefault' => 'Un dels certificats que està a punt d\'eliminar s\'utilitza com a certificat predeterminat.',
    'delete.certificateAssignedOnIp' => 'Les adreces IP/dominis tenen assignats un o varis certificats.',
    'delete.certificateUsedByPanel' => 'Un dels certificats que està a punt d\'eliminar s\'utilitza per a protegir Plesk.',
    'delete.certificateUsedByMailServer' => 'Un dels certificats que està a punt d\'eliminar s\'utilitza per a protegir el servidor de correu.',

    'edit.title' => 'Canvi de les propietats del certificat SSL/TLS %%name%%',
    'edit.enterCertificateName' => 'Indiqui el nom del certificat.',

    'list.title' => 'Certificats SSL/TLS',
    'list.certificateFound' => 'S\'ha trobat la clau privada anomenada %%name%% pel certificat carregar. El certificat s\'ha afegit correctament.',
    'list.certificatesList' => 'Llista de certificats al grup de servidors',
    'list.certificatesListHint' => 'Aquesta és la llista de certificats presents al grup de servidors.',
    'list.currentCertificates' => 'Certificats utilitzats en aquest moment per a protegir el servidor Plesk',
    'list.currentCertificatesHint' => 'Certificats utilitzats en aquest moment per a protegir el servidor Plesk i el servidor de correu',
    'list.pleskCertificate' => 'Certificat per a protegir Plesk',
    'list.mailServerCertificate' => 'Certificat per a protegir el correu',
    'list.serverPoolCertificateDescription' => '%%name%% del grup de servidors.',
    'list.domainCertificateDescription' => '%%name%% de %%domain%%.',
    'list.change' => '[Canviar]',
    'list.none' => 'Desconegut.',

    'secure-mail-server.title' => 'Protecció del servidor de correu',
    'secure-mail-server.hint' => 'Seleccioni el certificat que desitja utilitzar per a protegir el servidor de correu.',
    'secure-mail-server.mailServerCertificateSet' => 'El certificat %%name%% s\'ha establert correctament per a protegir el servidor de correu.',
    'secure-mail-server.mailServerNotInstalled' => 'El servei de correu no està instal·lat.',

    'secure-panel.title' => 'Protegir Plesk',
    'secure-panel.hint' => 'Seleccioni el certificat que desitja utilitzar per a protegir Plesk.',
    'secure-panel.panelCertificateSet' => 'El certificat %%name%% s\'ha establert correctament per a protegir Plesk.',
];