<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Afegir adreça IP',
    'add.ipAddressAdded' => 'L\'adreça IP %%address%% ha estat afegida.',

    'delete.infoIpAddressesDeleted' => 'Les adreces IP seleccionades han estat eliminades.',

    'edit.title' => 'L\'adreça IP %%address%% a la interfície %%interface%%',
    'edit.ipAddressUpdated' => 'S\'ha programat el canvi de l\'adreça IP %%address%%, que es durà a terme en segon pla',
    'edit.ipAddressInterfaceNotAvailableWarning' => 'L\'adaptador de xarxa %%interface%% no existeix. Transfereixi aquesta adreça IP a un altre adaptador de xarxa o elimini\'l de la llista.',

    'list.title' => 'Adreces IP',
];