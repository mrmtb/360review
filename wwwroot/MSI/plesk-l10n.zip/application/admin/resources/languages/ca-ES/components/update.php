<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'email.subjSuccess' => 'Plesk s\'ha actualitzat correctament',
    'email.subjFailure' => 'Error d\'actualització de Plesk',
    'email.bodySuccess' => "Atenció!\n\nPlesk s'ha actualitzat correctament.\nSi desitja consultar la llista de canvis aplicats, visiti %%link%%.\n\nAquest missatge ha estat enviat automàticament per Plesk Installer.",
    'email.bodyFailure' => "Atenció!\n\nS'ha produït un error a l'actualitzar Plesk.\n\nPot descarregar els registres de Plesk Installer al següent enllaç: %%link%%.\nContacti amb el seu proveïdor de hosting per tal d'obtenir suport.\n\nAquest missatge ha estat enviat automàticament per Plesk Installer.",
];