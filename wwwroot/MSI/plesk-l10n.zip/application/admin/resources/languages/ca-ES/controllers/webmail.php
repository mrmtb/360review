<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Registre de webmail addicional',
    'create.infoNewWebmailRegistered' => 'El nou servei de webmail ha estat registrat.',

    'edit.unknownWebmail' => 'Webmail desconegut',
    'edit.infoWebmailUpdated' => 'La configuració del servei de webmail %%name%% ha estat actualitzada.',

    'index.title' => 'Serveis de webmail',
    'index.hint' => 'A més a més de les solucions de webmail que instal·li amb Plesk Installer, pot fer servir qualsevol servei de webmail. Registri la instal·lació de webmail desitjada al panell mitjançant el botó que pot veure a continuació i aquesta apareixerà com a opció de webmail disponible a les subscripcions i plans de hosting. Si desitja amagar un servei de webmail temporalment, desactivi\'l fent clic al botó que es mostra a sota.',
    'index.webmailDeleted' => 'El registre dels serveis de webmail seleccionats ha estat eliminat.',
    'index.webmailNotDeleted' => 'El registre d\'alguns serveis de webmail no ha estat eliminat.',
    'index.webmailEnabled' => 'Els serveis de webmail seleccionats han estat activats i ara estan disponibles.',
    'index.webmailNotEnabled' => 'Algunes de les opcions de webmail seleccionades no han estat activades.',
    'index.webmailDisabled' => 'Les opcions de webmail seleccionades han estat desactivades i ja no estan disponibles.',
    'index.webmailNotDisabled' => 'Algunes de les opcions de webmail seleccionades no han estat desactivades.',
];