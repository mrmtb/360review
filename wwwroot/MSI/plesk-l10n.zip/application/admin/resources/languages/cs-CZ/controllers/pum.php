<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Aktualizace systému',

    'list.title' => 'Všechny balíčky',
    'list.hint' => 'Systémové balíčky se aktualizují prostřednictvím systémových nástrojů (dpkg/apt nebo yum). Balíčky se aktualizují pouze z úložišť, odkud byly nainstalovány. Chcete-li zamezit aktualizaci balíčku, vyberte ho ze seznamu a klikněte na Uzamknout.',

    'lock.success' => 'Balíčky byly úspěšně uzamčeny.',

    'settings.title' => 'Nastavení',
    'settings.settingsUpdated' => 'Nastavení bylo úspěšně změněno.',

    'unlock.success' => 'Balíčky byly úspěšně odemčeny.',

    'updates-list.title' => 'Dostupné aktualizace',
    'updates-list.hint' => 'Systémové balíčky se aktualizují prostřednictvím systémových nástrojů (dpkg/apt nebo yum). Balíčky se aktualizují pouze z úložišť, odkud byly nainstalovány. Chcete-li zamezit aktualizaci balíčku, vyberte ho ze seznamu a klikněte na Uzamknout.',
];