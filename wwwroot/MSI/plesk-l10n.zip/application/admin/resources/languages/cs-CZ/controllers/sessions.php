<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Správa relací',

    'remove.sessionsDeleted' => 'Vybrané relace byly úspěšně odebrány.',

    'settings.title' => 'Nastavení relace',
    'settings.settingsUpdated' => 'Nastavení bylo úspěšně změněno.',
];