<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'settings.title' => 'Nastavení zkušebního režimu (Try and Buy)',
    'settings.sitebuilderSettingsUpdated' => 'Nastavení bylo aktualizováno.',
];