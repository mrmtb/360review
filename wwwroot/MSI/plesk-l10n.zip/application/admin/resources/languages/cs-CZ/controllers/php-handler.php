<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Nastavení PHP',
    'list.hint' => 'Vyberte obslužné rutiny PHP, které chcete zpřístupnit: Další obslužné rutiny můžete nainstalovat prostřednictvím %%link%%.',
    'list.hintLink' => 'Instalační program Plesk',
    'list.brokenDomainsError' => 'Následující verze PHP nejsou nainstalovány: %%phpVersions%%. Skriptování PHP není k dispozici pro tento počet domén: %%domainCount%%. Nainstalujte chybějící verze PHP, nebo se řiďte pokyny z <a href=https://support.plesk.com/hc/en-us/articles/12377342328343>článku znalostní báze</a> a skriptování PHP tím opravte.',
    'list.brokenHandlersError' => 'Nejsou nainstalovány následující verze PHP: %%phpVersions%%. Nainstalujte je, nebo spusťte příkaz <code>plesk repair web -php-handlers</code> a vyberte jinou verzi PHP.',

    'modules.canNotManageModules' => 'Přístup ke správě nastavení PHP je omezen, protože cesta k souboru PHP CLI není zadána.',

    'php-ini.title' => 'Nastavení pro <b>%%name%%</b>',
    'php-ini.tabTitle' => 'php.ini',
    'php-ini.success' => 'Nastavení bylo aktualizováno.',

    'toggle.errorEnableBrokenHandler' => 'Obslužná rutina je poškozená a nelze ji povolit.',
    'toggle.errorDisableBrokenHandler' => 'Obslužná rutina je poškozená a nelze ji zakázat.',
    'toggle.infoHandlerEnabled' => 'Obslužná rutina byla povolena.',
    'toggle.infoHandlerDisabled' => 'Obslužná rutina byla zakázána.',
];