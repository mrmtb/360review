<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoDomainActivated' => 'Vybrané domény a aliasy byly aktivováni.',
    'activate.errorDomainNotActivated' => 'Některé z vybraných domén či aliasů nebyly aktivovány.',
    'activate.domainStillSuspended' => 'Nelze aktivovat doménu: %%reason%%',
    'activate.domainStatusOffByAdmin' => 'Doména je pozastavena správcem.',
    'activate.domainStatusOffWithParent' => 'Vlastník domény nebo jeho předplatné je pozastaveno.',
    'activate.domainStatusOffExpired' => 'Odpovídající předplatné vypršelo.',
    'activate.domainStatusOffBackupRestore' => 'Doména je dočasně pozastavena pro zálohování či obnovení.',
    'activate.domainStatusOff' => 'Doména je pozastavena.',
    'activate.aliasStillSuspended' => 'Nelze aktivovat alias: cílová doména je pozastavena.',

    'add-domain-alias.noDomains' => 'Nelze vytvořit alias: Nejsou k dispozici žádné domény.',

    'add-domain.noDomains' => 'Nelze vytvořit doménu doplňku: Nejsou k dispozici žádné domény.',

    'add-subdomain.noDomains' => 'Nelze vytvořit subdoménu: Nejsou k dispozici žádné domény.',

    'disable.infoDomainDisabled' => 'Vybrané domény byly zakázány.',
    'disable.errorDomainNotDisabled' => 'Některé z vybraných domén nebyly zakázány.',

    'list.title' => 'Domény',
    'list.customerLinkTitle' => 'vytvořit účet zákazníka',
    'list.subscriptionLinkTitle' => 'vytvořit vlastní předplatné',

    'suspend.infoDomainSuspended' => 'Vybrané domény byly pozastaveny.',
    'suspend.errorDomainNotSuspended' => 'Některé z vybraných domén nebyly pozastaveny.',
];