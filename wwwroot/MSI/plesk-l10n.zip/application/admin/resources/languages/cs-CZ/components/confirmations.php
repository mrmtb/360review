<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-customer-owner.title' => 'Přesun zákazníků na jiného vlastníka',
    'change-customer-owner.description' => 'Zákaznické účty budou přesunuty na jiného vlastníka. Plány služeb pro zákazníky lze změnit. Chcete-li zachovat prostředky dostupné pro prodejce, ponechte vybranou možnost Vlastní plány služeb.',
    'change-customer-owner.ownerHint' => 'Zákazníci budou přesunuti k vybranému vlastníkovi:',
    'change-customer-owner.ipAddressHint' => 'Vyhrazenou IP adresu nelze zachovat.',
    'change-customer-owner.loading' => 'Počkejte prosím…',
    'change-customer-owner.ipAddressNotSelected' => 'Vyberte alespoň jednu IP adresu pro každou předplacenou službu.',
    'change-customer-owner.ownerNotSelected' => 'Vyberte vlastníka.',

    'customer.title' => 'Probíhá převod zákazníků na prodejce',
    'customer.description' => 'Zákaznické účty budou převedeny na účty prodejce. Pro převedené účty můžete vybrat plány prodejce. Chcete-li zachovat prostředky dostupné zákazníkovi, vyberte Vlastní plán: Prodejce bude mít součet naplnění prostředků, oprávnění a aplikací všech předplacených služeb.',
    'customer.loading' => 'Převádění…',

    'reseller.title' => 'Probíhá převod prodejců na zákazníky',
    'reseller.description' => 'Prodejci budou převedeni na zákazníky.',
    'reseller.descriptionExtended' => 'Vyberte nové plány služeb pro prodejce, kteří mají vlastní předplacené služby. Chcete-li zachovat prostředky dostupné pro prodejce, vyberte Vlastní plány služeb. Chcete-li přesunout předplacené služby prodejce do jednoho z existujících plánů služeb, vyberte existující plán služeb.',
    'reseller.loading' => 'Převádění…',
];