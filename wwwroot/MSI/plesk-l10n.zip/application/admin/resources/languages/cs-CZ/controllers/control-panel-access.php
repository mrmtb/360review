<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-network.title' => 'Přidat síť',
    'add-network.added' => 'Byla přidána síťová adresa %%address%%.',

    'delete-network.noNetworksSpecified' => 'Vyberte jednu nebo více sítí ze seznamu omezení přístupu IP.',
    'delete-network.networksDeleted' => 'Vybrané sítě byly odstraněny.',
    'delete-network.networksNotDeleted' => 'Některé z vybraných sítí nebyly odstraněny. Podrobnosti: %%error%%.',

    'edit-network.title' => 'Úprava sítě',
    'edit-network.updated' => 'Byla aktualizována síťová adresa %%address%%.',

    'list.title' => 'Správa omezení IP přístupu',
    'list.currentIpAddressDenied' => 'Zásady omezení přístupu a seznam sítí jsou momentálně nakonfigurovány tak, že se ze své IP adresy \'%%remoteAddress%%\' nebudete moci přihlásit s oprávněním správce.',
    'list.allowHint' => 'Přístup do prostředí Plesk s oprávněním správce je povolen, kromě sítí v seznamu.',
    'list.denyHint' => 'Přístup do prostředí Plesk s oprávněním správce je zamítnut ze všech sítí, které zde nejsou uvedeny.',

    'settings.title' => 'Nastavení omezení IP přístupu',
    'settings.settingsSaved' => 'Zásady omezení IP přístupu byly uloženy.',
];