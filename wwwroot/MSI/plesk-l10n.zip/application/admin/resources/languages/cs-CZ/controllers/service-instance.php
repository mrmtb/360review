<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.formTitle' => 'Vybrat službu, kterou chcete přidat',
    'create.successfullyAdded' => 'Služba \\&amp;apos;%%serviceDisplayName%%\\&amp;apos; byla úspěšně vytvořena.',
    'create.successfullyUpdated' => 'Služba \\&amp;apos;%%serviceDisplayName%%\\&amp;apos; byla úspěšně aktualizována.',
    'create.selectServiceInstallationTitle' => 'Vybrat službu',

    'edit.formTitle' => 'Spravovat službu \\&amp;apos;%%serviceDisplayName%%\\&amp;apos;',
    'edit.title' => 'Služby %%subscriptionName%%',
    'edit.successfullyUpdated' => 'Služba \\&amp;apos;%%serviceDisplayName%%\\&amp;apos; byla úspěšně aktualizována.',

    'list.hint' => 'Zde můžete spravovat služby v předplatném',
    'list.title' => 'Služby %%subscriptionName%%',
    'list.breadcrumb' => 'Služby',
    'list.infoServiceDeleted' => 'Vybrané služby byly odebrány.',
    'list.infoServiceNotDeleted' => 'Některé z vybraných služeb nebyly odebrány.',
];