<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Nastavení pošty pro celý server',
    'index.preferencesTab' => 'Nastavení',
    'index.spamFilteringTab' => 'Filtrování nevyžádané pošty',
    'index.antivirusTab' => 'Antivirus',
    'index.blockedDomainsTab' => 'Černá listina',
    'index.whiteListTab' => 'Bílá listina',
    'index.queueTab' => 'Fronta e-mailů',
    'index.statisticsTab' => 'Statistiky',
    'index.smarthostTab' => 'Smarthost',

    'mail-lists.title' => 'Konfigurace správce seznamů adresátů',
    'mail-lists.configured' => 'Správce seznamu adresátů aplikace Mailman byl nakonfigurován. Tlačítko Nastavit server seznamu adresátů již nebude zobrazen na stránce Nástroje a nastavení.', // PFU
    'mail-lists.noLocalhostInServerWhiteList' => 'Chcete-li použít seznamy adresátů, musíte na bílou listinu e-mailového serveru zařadit položku localhost (127.0.0.0/8, ::1/128). Pokud ale chcete použít zabezpečení odchozí pošty, položku localhost nesmíte zařadit na bílou listinu. Kompromis: pokud jste aktivovali zabezpečení odchozí pošty, můžete místo seznamů adresátů použít předávání e-mailů na poštovní schránku.',
    'mail-lists.noLocalhostInServerWhiteListIpv4' => 'Chcete-li použít seznamy adresátů, musíte na bílou listinu e-mailového serveru zařadit položku localhost. Pokud ale chcete použít zabezpečení odchozí pošty, položku localhost nesmíte zařadit na bílou listinu. Kompromis: pokud jste aktivovali zabezpečení odchozí pošty, můžete místo seznamů adresátů použít předávání e-mailů na poštovní schránku. Pamatujte si, že na bílé listině nyní nejsou žádné IPv4 adresy localhost (127.0.0.0/8), takže zabezpečení odchozí pošty bude pracovat pro adresy IPv4.',
    'mail-lists.noLocalhostInServerWhiteListIpv6' => 'Chcete-li použít seznamy adresátů, musíte na bílou listinu e-mailového serveru zařadit položku localhost. Pokud ale chcete použít zabezpečení odchozí pošty, položku localhost nesmíte zařadit na bílou listinu. Kompromis: pokud jste aktivovali zabezpečení odchozí pošty, můžete místo seznamů adresátů použít předávání e-mailů na poštovní schránku. Pamatujte si, že na bílé listině nyní nejsou žádné IPv6 adresy localhost (::1/128), takže zabezpečení odchozí pošty bude pracovat pro adresy IPv6.',
    'mail-lists.mailingListSoftwareNotInstalled' => 'Software pro seznam adresátů není nainstalován.',
    'mail-lists.mailingListSoftwareAlreadyConfigured' => 'Software pro seznam adresátů je již nakonfigurován.',

    'customize-mailbox-quota-warning.title' => 'Vlastní nastavení upozornění na kvótu poštovní schránky',
    'customize-mailbox-quota-warning.successMessage' => 'Varovné upozornění na kvótu poštovní schránky bylo změněno.',

    'customize-mailbox-quota-warning-form.subject' => 'Předmět',
    'customize-mailbox-quota-warning-form.message' => 'Zpráva',
    'customize-mailbox-quota-warning-form.tooLongMessage' => "Zpráva je příliš dlouhá. Maximální délka je %max% znaků",
];