<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'branding.title' => 'Branding prostředí Plesk',

    'disable-languages.disableLanguagesSuccess' => 'Vybrané jazyky už nejsou dále uživatelům k dispozici.',

    'edit-controls.updateSuccess' => 'Nastavení byla úspěšně aktualizována.',

    'edit-interface-view.title' => 'Náhledy rozhraní',
    'edit-interface-view.updateSuccess' => 'Nastavení byla úspěšně aktualizována.',

    'enable-languages.enableLanguagesSuccess' => 'Vybrané jazyky jsou dostupné uživatelům.',

    'language-make-default.languageMakeDefaultSuccess' => 'Vybraný jazyk byl nastaven pro prostředí Plesk jako výchozí.',

    'list-languages.title' => 'Jazyky',
    'list-languages.mlsLimitExceeded' => "Vaše aktuální licence Plesk dovoluje použít %%allowedByLicense%% jazyky(ů). Momentálně máte nastaveny(o) %%availableToUsers%% jazyky(ů) k dispozici uživatelům, kteří překračují počet poskytovaný s licencí. Vyberte %%allowedByLicense%% jazyky, které chcete použít, a zbytek uživatelům znepřístupněte kliknutím na jejich ikony ve sloupci do 'S'.",
];