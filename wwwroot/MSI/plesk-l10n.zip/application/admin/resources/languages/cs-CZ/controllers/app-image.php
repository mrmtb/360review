<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'gallery.titleScreenshot' => 'Snímky obrazovky %%packageName%%',
    'gallery.prevImage' => '< Předchozí',
    'gallery.nextImage' => 'Další>',
    'gallery.closeGallery' => 'Zavřít',
    'gallery.navigationOf' => 'z',
    'gallery.typeScreenshot' => 'snímky obrazovky',
    'gallery.title' => 'Snímky obrazovky',
];