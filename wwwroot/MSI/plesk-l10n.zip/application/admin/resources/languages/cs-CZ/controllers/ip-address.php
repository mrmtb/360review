<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Přidat IP adresu',
    'add.ipAddressAdded' => 'Byla přidána IP adresa %%address%%.',

    'delete.infoIpAddressesDeleted' => 'Vybrané IP adresy byly odebrány.',

    'edit.title' => 'IP adresa %%address%% na rozhraní %%interface%%',
    'edit.ipAddressUpdated' => 'Změna nastavení IP adresy %%address%% byla naplánována a proběhne na pozadí',
    'edit.ipAddressInterfaceNotAvailableWarning' => 'Síťový adaptér %%interface%% neexistuje. Přesunout tuto IP adresu na jiný síťový adaptér nebo ji odebrat ze seznamu.',

    'list.title' => 'IP adresy',
];