<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'oversell-policy.title' => 'Změna pravidel nabídky',
    'oversell-policy.pageHint' => 'Zde můžete změnit aktuální zásady překročení nabídky.',
    'oversell-policy.oversellPolicyChanged' => 'Zásada nabídky byla úspěšně aktualizována.',
    'oversell-policy.oversellPolicyNotChanged' => 'Zásadu nabídky nelze aktualizovat.',

    'subscription-overview.title' => 'Přehled předplatného',
    'subscription-overview.pageHint' => 'Toto je přehled vašich předplacených služeb, zahrnuje informace o množství použitých a poskytnutých prostředků, zásadách nabídky, oprávněních a službách poskytovaných s předplatným.',
    'subscription-overview.changeOversellPolicyLink' => '[změnit]',
    'subscription-overview.oversellEnabledHint' => 'Vaše předplatné umožňuje překročení nabídky prostředků což znamená, že můžete prodat více prostředků, než je množství, které vám bylo přiděleno předplatným. V tomto případě se místo výchozího přidělení prostředků řídíte skutečným využitím prostředků.',
    'subscription-overview.oversellDisableHint' => 'Pokud vaše předplatné zakazuje překročení nabídky, což znamená, že můžete prodat pouze tolik prostředků, kolik jich bylo zpočátku přiděleno předplatným, bez ohledu na to, kolik z nich se skutečně využívá.',
    'subscription-overview.tabResources' => 'Prostředky',
    'subscription-overview.tabPermissions' => 'Oprávnění',
    'subscription-overview.resourcesSummaryHint' => 'Toto je souhrn využití prostředků poskytovaných s předplatným.',
    'subscription-overview.showMoreResources' => 'Zobrazit více dostupných prostředků',
    'subscription-overview.hideMoreResources' => 'Zobrazit méně prostředků',
    'subscription-overview.permissionsSummaryHint' => 'Toto je seznam služeb a oprávnění poskytovaných s předplatným.',
    'subscription-overview.hideMorePermissions' => 'Zobrazit méně oprávnění',
    'subscription-overview.showMorePermissions' => 'Zobrazit více oprávnění',
];