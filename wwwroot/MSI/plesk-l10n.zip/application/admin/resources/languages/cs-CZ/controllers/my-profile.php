<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-password.title' => "Změnit heslo správce",
    'change-password.passwordChanged' => 'Heslo správce se změnilo.',

    'index.personalInfoTitle' => "Úpravy profilu správce",
    'index.successMessage' => "Váš profil byl aktualizován.",
    'index.aliasInfoTitle' => 'Informace o dalším účtu správce',
    'index.aliasInfoUpdated' => 'Osobní údaje dalšího účtu správce byly aktualizovány.',
];