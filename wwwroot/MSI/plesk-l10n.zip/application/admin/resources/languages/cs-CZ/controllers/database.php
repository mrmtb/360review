<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'assign-to-subscription.databasesSuccessfullyAssignedToSubscription' => 'Databáze byly přesunuty na předplatné \\&amp;apos;%%subscriptionName%%\\&amp;apos;.',
    'assign-to-subscription.databasesNotAssignedToSubscription' => 'Databáze nelze přesunout na předplatné \\&amp;apos;%%subscriptionName%%\\&amp;apos;.',
    'assign-to-subscription.subscriptionNotFound' => 'Předplatné \\&amp;apos;%%name%%\\&amp;apos; nebylo nalezeno.',
    'assign-to-subscription.isNotMainDomain' => '\\&amp;apos;%%name%%\\&amp;apos; není hlavní doménou v předplatném.',

    'settings.title' => 'Nastavení hostování databáze',
    'settings.settingsSaved' => 'Nastavení hostování databáze bylo uloženo.',

    'refresh.success' => 'Informace databázových serverů byly obnoveny.',
];