<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Registrovat další webové rozhraní pošty',
    'create.infoNewWebmailRegistered' => 'Byla zaregistrována nová služba webového rozhraní pošty.',

    'edit.unknownWebmail' => 'Neznámé webové rozhraní pošty',
    'edit.infoWebmailUpdated' => 'Nastavení webového rozhraní pošty %%name%% bylo aktualizováno.',

    'index.title' => 'Služby webového rozhraní pošty',
    'index.hint' => 'K webovému rozhraní pošty, které jste nainstalovali pomocí instalačního programu Plesk (Updater - nástroj pro aktualizaci), můžete přidat libovolnou službu webového rozhraní pošty. Požadovanou instalaci webového rozhraní pošty zaregistrujte na panelu tlačítkem dole. Objeví se jako dostupná možnost webového rozhraní pošty v plánech hostování a předplatném. Jestliže potřebujete službu webového rozhraní dočasně skrýt, vypněte ji tlačítkem dole.',
    'index.webmailDeleted' => 'Registrace vybrané služby webového rozhraní pošty byla odebrána.',
    'index.webmailNotDeleted' => 'Registrace některých služeb webového rozhraní pošty nebyla odebrána.',
    'index.webmailEnabled' => 'Vybrané služby webového rozhraní pošty byli povoleny a nyní jsou k dispozici.',
    'index.webmailNotEnabled' => 'Některé z vybraných možností webového rozhraní pošty nebyly povoleny.',
    'index.webmailDisabled' => 'Vybrané možnosti webového rozhraní pošty byly zakázány a jsou nedostupné.',
    'index.webmailNotDisabled' => 'Některé z vybraných možností webového rozhraní pošty nebyly zakázány.',
];