<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Nastavení externího SMTP serveru',
    'index.settingsUpdated' => 'Nastavení bylo aktualizováno.',
];