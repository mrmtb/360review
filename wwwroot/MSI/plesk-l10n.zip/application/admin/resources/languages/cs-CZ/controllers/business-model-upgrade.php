<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'admin-customers-target-list.title' => 'Zákazníci správce, kteří potřebují převod',
    'admin-customers-target-list.hint-t1s1' => 'Toto je seznam zákazníků vytvořených z klientů, kterým bylo zakázáno měnit limity domény a mít jednu doménu před aktualizací na vyšší verzi.',
    'admin-customers-target-list.hint-t1s2' => 'Toto je seznam zákazníků vytvořených z klientů, kterým bylo povoleno měnit limity domény a mít jednu doménu před aktualizací na vyšší verzi.',
    'admin-customers-target-list.hint-t1s3' => 'Toto je seznam zákazníků vytvořených z klientů, kterým bylo zakázáno vytvářet domény a měnit limity domény a mít několik domén před aktualizací na vyšší verzi.',
    'admin-customers-target-list.hint-t1s6' => 'Toto je seznam zákazníků vytvořených z klientů, kterým bylo povoleno vytvářet domény a měnit limity domény a mít několik domén před aktualizací na vyšší verzi.',

    'admin-subscriptions-target-list.title' => 'Předplacená služba správce, která potřebuje převod',
    'admin-subscriptions-target-list.hint' => 'Toto je seznam předplacených služeb vytvořených z domén: (a) které patří správci a (b) před aktualizací na vyšší verzi mají zapnutý Účet správce domény.',

    'bunch.title' => 'Dokončit přechod na nový obchodní model Plesk.',
    'bunch.noActionsDescription' => 'V systému nezůstali žádní zákazníci a předplacené služby splňující běžné scénáře, takže na této záložce není co dělat. Přejděte na další záložku a přechod zbývajících zákazníků.',
    'bunch.description' => 'Model distribuce prostředků v prostředí Plesk 10 a vyšším se liší od předchozích verzí: počínaje verzí Plesk 10 nemají zákazníci vlastní prostředky, jako tomu bylo ve verzi Plesk 8 a 9, ale získávají je s předplacenými službami. Právě teď existuje několik zákazníků se staršími verzemi prostředků, které by měly být správně převedeny, aby zapadly do nového modelu prostředí Plesk. Na základě běžných scénářů využití prostředí Plesk tyto zákazníky analyzoval a vytvořil seznam doporučených přechodových akcí, které uvidíte níže. Můžete s nimi pokračovat nebo vybrat schéma přechodu podle zákazníka. Jakmile bude zákazník převeden, ztratí se ze seznamu.',
    'bunch.help' => 'Další informace o přechodu.',
    'bunch.applyed' => 'Vybraní zákazníci a předplacené služby byly převedeny.',
    'bunch.failed' => 'Nelze převézt vybrané zákazníky a předplacené služby.',

    'customers.title' => 'Dokončit přechod na nový obchodní model Plesk: Výběrový přechod pro zákazníky',
    'customers.description' => 'Toto je úplný seznam zákazníků, kteří potřebují převod. Společně s účty, které vyhoví běžným scénářům, obsahuje nepravidelná nastavení, pro které nejsou žádné doporučené akce. Sami si musíte vybrat použitelné schéma přechodu, založené na konkrétním nastavení předchozího klienta, např. limity, oprávnění, skutečný počet domén atd. Chcete-li zjistit limity a oprávnění předchozího klienta, klikněte na název zákazníka a poté na položku \'My Resources\' v seznamu předplacených služeb zákazníka.',
    'customers.help' => 'Další informace o přechodu.',

    'manual-customer-solution.appliedInfo' => 'Vybraní zákazníci byli převedeni.',
    'manual-customer-solution.notAppliedInfo' => 'Všichni nebo někteří vybraní zákazníci nebyli převedeni.',

    'manual-subscription-solution.appliedInfo' => 'Vybrané předplacené služby byly převedeny.',
    'manual-subscription-solution.notAppliedInfo' => 'Všechny nebo některé vybrané předplacené služby nebyly převedeny.',

    'notes.nonApplicableCustomers' => "%%count%% zákazníků nevyhoví žádnému z běžných scénářů, takže pro ně nejsou žádné doporučené akce. Chcete-li převést účty, %%link%%.",
    'notes.nonApplicableSubscriptions' => "%%count%% přeplacených služeb nevyhoví žádnému z běžných scénářů, takže pro ně nejsou žádné doporučené akce. Chcete-li převést předplatné, %%link%%.",
    'notes.manualCustomersUpgradeLink' => 'vyberte pro ně vlastní schéma',
    'notes.manualSubscriptionsUpgradeLink' => 'vyberte pro ně vlastní schéma',

    'reseller-customers-target-list.title' => 'Zákazníci prodejců, kteří potřebují převod',
    'reseller-customers-target-list.hint-t2s1' => 'Toto je seznam zákazníků vytvořených z klientů, kterým bylo zakázáno měnit limity domény a mít jednu doménu před aktualizací na vyšší verzi.',
    'reseller-customers-target-list.hint-t2s2' => 'Toto je seznam zákazníků vytvořených z klientů, kterým bylo povoleno měnit limity domény a mít jednu doménu před aktualizací na vyšší verzi.',
    'reseller-customers-target-list.hint-t2s3' => 'Toto je seznam zákazníků vytvořených z klientů, kterým bylo zakázáno vytvářet domény a měnit limity domény a mít několik domén před aktualizací na vyšší verzi.',
    'reseller-customers-target-list.hint-t2s6' => 'Toto je seznam zákazníků vytvořených z klientů, kterým bylo povoleno vytvářet domény a měnit limity domény a mít několik domén před aktualizací na vyšší verzi.',

    'reseller-subscriptions-target-list.title' => 'Předplacená služba prodejců, která potřebuje převod',
    'reseller-subscriptions-target-list.hint' => 'Toto je seznam předplacených služeb vytvořených z domén, které (a) patří prodejcům a (b) před aktualizací na vyšší verzi mají zapnutý Účet správce domény.',

    'subscriptions.title' => 'Dokončit přechod na nový obchodní model Plesk: Výběrový přechod pro předplacené služby',
    'subscriptions.description' => 'Toto je seznam předplacených služeb, které potřebují převod, obsahuje stejné předplacené služby jako stránka Doporučené akce, ale zde můžete vybrat schéma převodu, které nejvíce vyhovuje konkrétnímu předplatnému. Toto jsou předplacené služby vytvořené z domén, které (a) patří správci nebo prodejci a (b) mají zapnutý Účet správce domény.',
    'subscriptions.help' => 'Další informace o přechodu.',

    'tabs.bunch' => 'Doporučené akce',
    'tabs.customers' => 'Výběrový přechod zákazníků',
    'tabs.subscriptions' => 'Výběrový přechod předplacených služeb',
];