<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'isEmpty' => 'Toto povinné pole je prázdné. Musíte zadat hodnotu pro toto pole.',
    'stringLengthTooShort' => "'%value%' je nižší než délka %min% znaků.",
    'stringLengthTooLong' => "'%value%' je vyšší než délka %max% znaků.",
    'regexNotMatch' => "'%value%' se neshoduje se šablonou '%pattern%'.",
    'notAlnum' => "'%value%' obsahuje jiné než alfanumerické znaky. Ujistěte se, že používáte pouze alfanumerické znaky.",
    'stringEmpty' => "'%value%' je prázdná.",
    'stringsNotEqual' => 'Řetězce nejsou stejné.',
    'passwordsNotEqual' => 'Zadaná hesla se neshodují.',
    'passwordLengthTooShort' => "heslo je kratší než %min% znaků.",
    'passwordLengthTooLong' => "heslo je delší než %max% znaků.",
    'passwordRegexNotMatch' => "heslo se neshoduje se šablonou '%pattern%'.",
    'invalidUrl' => 'Zadaná adresa není platná. Musíte zadat platnou adresu, např. http://domain.com.',
    'specialCharactersInIpAddress' => 'Uvedená IP adresa je neplatná.',
    'massEmailContactsNotSelected' => 'Vyberte alespoň jednu položku ze seznamu kontaktů.',
    'ipAddressIsTooLong' => 'IP adresa nesmí být delší než %max% znaků.',
    'ipAddressDescriptionTooLong' => 'Popis nesmí mít více než %max% znaků.',

    'fail2ban.invalidIpOrCidr' => 'IP adresa musí být platná IP adresa nebo maska CIDR.',
];