<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'clear-cache.apsCacheCleared' => 'Dočasné soubory byly odebrány.',

    'configure.title' => '%%name%%',
    'configure.applicationNotFound' => "Aplikace s ID '%%id%%' nebyla nalezena.",
    'configure.applicationHasNoSettings' => 'Aplikace nemá žádné nastavení.',
    'configure.settingsUpdated' => 'Nastavení aplikace bylo aktualizováno.',
    'configure.settingsUpdateFailed' => 'Aktualizace nastavení aplikace se nezdařila: %%error%%',
    'configure.instancesNotReconfigured' => 'Některé instance aplikace nebyly překonfigurovány.',

    'index.title' => 'Aplikační trezor',

    'info.title' => '%%name%%',
    'info.hint' => 'Níže uvedený seznam obsahující informace o webech, na nichž je nainstalována aplikace. Hodnota Žádný ve sloupci Web znamená, že aplikace je externí. Takovou aplikaci nelze nainstalovat na určité weby zákazníků; obsahuje pouze odkaz na externí službu.',

    'remote-app-info.title' => 'Podrobnosti o aplikaci',

    'update-settings.title' => 'Aktualizovat nastavení',
    'update-settings.settingsUpdated' => 'Nastavení bylo aktualizováno.',
    'update-settings.settingsUpdateFailed' => 'Nelze aktualizovat nastavení: %%error%%',

    'upload.title' => 'Přidat aplikaci',
    'upload.packageInstallationError' => 'Aplikaci nebylo možno přidat: %%message%%.',
    'upload.appUploaded' => 'Aplikace byla úspěšně nahrána.',
    'upload.appDownloadStarted' => 'Stahování vybraných aplikací.',

    'uploaded.title' => 'Moje aplikace',
    'uploaded.hint' => 'Zde můžete přidat nebo odebrat aplikace z aplikačního trezoru a spravovat dostupnost aplikací zákazníkům. Existuji dva důvody, proč přidat aplikaci: rozšířit seznam dostupných aplikací nebo konfigurovat nastavení pro celý server. Některé aplikace nelze instalovat bez takové konfigurace. Všechny přidané aplikace jsou v níže uvedeném seznamu.',
    'uploaded.infoAppDeleted' => 'Vybrané aplikace byly odstraněny.',
    'uploaded.infoAppNotDeleted' => 'Některé z vybraných aplikací nebyly odstraněny.',
    'uploaded.applicationsNowAvailable' => 'Vybrané aplikace jsou nyní dostupné pro instalaci zákazníkům nebo pro konfiguraci.',
    'uploaded.applicationsNowNotAvailable' => 'Vybrané aplikace již nejsou dále dostupné pro instalaci zákazníkům nebo pro konfiguraci.',
    'uploaded.cantChangePackageProperties' => 'Při pokusu o změnu nastavení dostupnosti aplikace došlo k chybě.',
    'uploaded.appDownloaded' => 'Vybrané aplikace byly úspěšně staženy.',
    'uploaded.appNotDownloaded' => 'Některé z vybraných aplikací nebyly staženy.',
    'uploaded.downloadInProgress' => 'Počkejte prosím…',

    'usage.title' => 'Nainstalované aplikace',
    'usage.hint' => 'Níže uvedený seznam obsahuje všechny aplikace, které jste přidali sami nebo je nainstalovali vaši zákazníci. Zde můžete spravovat nastavení aplikace, kontrolovat aktualizace nebo odebrat dočasné soubory, které byly přidány během instalace aplikace.',
    'usage.hintReseller' => 'Níže uvedený seznam obsahuje informace o všech instalacích aplikací na vašich webech a na webech vašich zákazníků. Kliknutím na název aplikace vyvolejte seznam webů, na nichž je aplikace nainstalována, a zkontrolujte aktualizace aplikace.',
];