<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Stav serveru',
    'index.pageHint' => 'Zde můžete vidět podrobné hlášení o stavu serveru. Chcete-li vidět, jak se parametry stavu serveru měnily, vyberte parametry a Plesk vám zobrazí příslušné diagramy. Pamatujte si, že období, za které jsou výkazy prezentovány, lze změnit - od posledních 3 hodin až po týden. Zde můžete také změnit konfiguraci monitorování stavu, která stanovuje, jaké červené a žluté alarmy se musí objevit pro každý parametr, a který z prostředků pevného disku se musí monitorovat. Postupujte takto: stáhněte konfigurační soubor pomocí tlačítka níže, upravte soubor a nahrajte svou verzi. Pokud se změnil hardware serveru, měli byste tyto změny rozšířit do modulu Monitorování stavu, aby získal správnou statistiku.',
    'index.waitMessage' => 'Načítání...',
    'index.buttonUpload' => 'Nahrát konfigurační soubor',
    'index.buttonDownload' => 'Stáhnout konfigurační soubor',
    'index.buttonRestoreDefaults' => 'Zpět na výchozí konfiguraci',
    'index.buttonReconfigure' => 'Detekovat změny hardwaru',
    'index.buttonUploadHint' => 'Nahrát konfigurační soubor monitorování stavu. Konfigurace bude použita ihned po nahrání.',
    'index.buttonDownloadHint' => 'Uložit aktuální konfiguraci monitorování stavu do počítače.',
    'index.buttonRestoreDefaultsHint' => 'Obnovit výchozí nastavení monitorování stavu serveru.',
    'index.buttonReconfigureHint' => 'Rozšířit změny v hardwarové konfiguraci v modulu Monitorování stavu.',
    'index.confirmRestoreDefaultsTitle' => 'Obnovení výchozí nastavení monitorování stavu serveru',
    'index.confirmRestoreDefaultsDescription' => 'Určitě chcete výchozí nastavení obnovit?',
    'index.confirmReconfigureTitle' => 'Probíhá detekce změn hardwaru',
    'index.confirmReconfigureDescription' => 'Chystáte se aktualizovat hardwarovou konfiguraci v modulu Monitorování stavu. Toto platí, pokud se změnil hardware serveru a chcete, aby se tyto změny projevili ve statistice modulu Monitorování stavu. Pokračovat?',
    'index.settingsWereRestoredToDefault' => 'Výchozí nastavení bylo obnoveno.',
    'index.healthMonitorWasReconfigured' => 'Informace modulu Monitorování stavu o konfiguraci hardwaru bylo aktualizováno.',

    'parameters.loading' => 'Načítání...',
    'parameters.selectPeriod' => 'Zvolit období',
    'parameters.periodFromNowTo3h' => '3 hodin',
    'parameters.periodFromNowTo6h' => '6 hodin',
    'parameters.periodFromNowTo12h' => '12 hodin',
    'parameters.periodFromNowTo1d' => '1 den',
    'parameters.periodFromNowTo3d' => '3 dny',
    'parameters.periodFromNowTo7d' => '1 týden',

    'thresholds-hint.waitMessage' => 'Načítání...',

    'upload-config-file.title' => 'Nahrát konfigurační soubor',
    'upload-config-file.configurationUploadedSuccessfully' => 'Konfigurace byla nahrána použita.',
];