<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'acl-records.title' => 'Šablona omezení přenosu',

    'add-acl-record.title' => 'Přidat IP adresu',
    'add-acl-record.success' => 'Zadané adresy IP byly úspěšně přidány.',

    'delete-acl-record.success' => 'Vybrané adresy IP byly úspěšně odebrány.',

    'index.title' => 'Nastavení DNS',

    'records.title' => 'Šablona záznamů zón',

    'reset-settings.success' => 'Výchozí nastavení bylo úspěšně obnoveno.',

    'settings.title' => 'Nastavení pro celý server',
    'settings.success' => 'Nastavení bylo úspěšně aktualizováno.',

    'soa-record.title' => 'Šablona nastavení zóny',

    'restore-default.title' => 'Obnovit výchozí šablonu zóny DNS',
    'restore-default.text' => 'Potvrďte, že chcete obnovit výchozí konfiguraci šablony zóny DNS.',

    'soa-sync.title' => 'Přepsat nastavení SOA pro všechny existující domény',
    'soa-sync.text' => 'Chcete aktualizovat záznamy SOA všech hostovaných domén použitím změn provedených na šabloně SOA?',

    'sync.title' => 'Použít změny šablony DNS',
    'sync.type-option' => 'Zvolte jednu z následujících možností.',
    'sync.safe' => 'Použít změny na nezměněné zóny. Pokud byla zóna upravena (byly přidány nové záznamy nebo byly upraveny záznamy stávající), Plesk nepoužije na tyto zóny změny ze šablony.',
    'sync.force' => 'Použít změny na všechny zóny. Plesk použije změny ze šablony na všechny zóny DNS včetně těch, které byly upraveny Pamatujte si, že záznamy upravené uživatelem zůstávají vždy beze změny. Pokud například šablona obsahuje nový záznam, který byl již přidán zákazníkem, Plesk zachová záznam zákazníka.',

    'external-dns.title' => 'Externí DNS',
    'external-dns.hint' => 'Zde můžete nakonfigurovat externí DNS servery',
    'external-dns.success' => 'Uloženo',
    'external-dns.configured' => 'Konfigurováno',
    'external-dns.notConfigured' => 'Nenakonfigurováno',
    'external-dns.useExtension' => 'Použít toto rozšíření',

    'external-dns-edit.title' => 'Externí DNS',
];