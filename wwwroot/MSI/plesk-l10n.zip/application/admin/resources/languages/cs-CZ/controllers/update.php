<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Instalační program Plesk',
    'index.autoinstallerRedirectError' => 'Nelze spustit instalační program Plesk. Došlo k následující chybě: %%message%%',

    'product.title' => 'Instalační program Plesk',
    'product.autoinstallerRedirectError' => 'Nelze spustit instalační program Plesk. Došlo k následující chybě: %%message%%',

    'settings.title' => 'Aktualizovat nastavení',
    'settings.settingsUpdated' => 'Nastavení aktualizace bylo změněno.',
];