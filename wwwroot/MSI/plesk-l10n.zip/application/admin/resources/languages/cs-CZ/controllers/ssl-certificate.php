<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Přidat  certifikát SSL/TLS',
    'add.enterCertificateName' => 'Zadejte název certifikátu.',

    'delete.infoSslCertificatesDeleted' => 'Certifikáty SSL/TLS byly odebrány.',
    'delete.infoSslCertificatesNotDeleted' => 'Certifikát SSL/TLS nelze odebrat.',
    'delete.certificateUsedAsDefault' => 'Jeden z certifikátů, které se chystáte odstranit, se používá jako výchozí certifikát.',
    'delete.certificateAssignedOnIp' => 'IP adresám/doménám byl přiřazen jeden certifikát nebo několik certifikátů.',
    'delete.certificateUsedByPanel' => 'Jeden z certifikátů, které se chystáte odstranit, se používá k zabezpečení prostředí Plesk.',
    'delete.certificateUsedByMailServer' => 'Jeden z certifikátů, které se chystáte odstranit, se používá k zabezpečení e-mailového serveru.',

    'edit.title' => 'Změnit vlastnosti certifikátu SSL/TLS %%name%%',
    'edit.enterCertificateName' => 'Zadejte název certifikátu.',

    'list.title' => 'Certifikáty SSL/TLS',
    'list.certificateFound' => 'Byl nalezen privátní klíč (s názvem %%name%%) pro nahraný certifikát. Certifikát byl úspěšně přidán.',
    'list.certificatesList' => 'Seznam certifikátů ve fondu serverů',
    'list.certificatesListHint' => 'Ve fondu serverů je seznam certifikátů.',
    'list.currentCertificates' => 'Certifikáty aktuálně využité k zabezpečení serveru Plesk',
    'list.currentCertificatesHint' => 'Certifikáty aktuálně využité k zabezpečení serveru Plesk a e-mailového serveru',
    'list.pleskCertificate' => 'Certifikát k zabezpečení prostředí Plesk',
    'list.mailServerCertificate' => 'Certifikát k zabezpečení pošty',
    'list.serverPoolCertificateDescription' => '%%name%% z fondu serverů.',
    'list.domainCertificateDescription' => '%%name%% z %%domain%%.',
    'list.change' => '[Změnit]',
    'list.none' => 'Neznámý.',

    'secure-mail-server.title' => 'Zabezpečený e-mailový server',
    'secure-mail-server.hint' => 'Vybrat certifikát k zabezpečení e-mailového serveru.',
    'secure-mail-server.mailServerCertificateSet' => 'Certifikát %%name%% byl úspěšně nastaven na zabezpečení e-mailového serveru.',
    'secure-mail-server.mailServerNotInstalled' => 'Poštovní služba není nainstalována.',

    'secure-panel.title' => 'Zabezpečit Plesk',
    'secure-panel.hint' => 'Vybrat certifikát k zabezpečení prostředí Plesk.',
    'secure-panel.panelCertificateSet' => 'Certifikát %%name%% byl úspěšně nastaven na zabezpečení prostředí Plesk.',
];