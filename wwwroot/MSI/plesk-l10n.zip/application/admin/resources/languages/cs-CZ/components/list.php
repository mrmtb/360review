<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'recordsTotal' => '%%total%% položek celkem',
    'pages' => 'Stránky',
    'firstPage' => 'První',
    'lastPage' => 'Poslední',
    'numberOfItemPerPage' => 'Položek na stránku',
    'hideSearch' => 'Skrýt hledání',
    'showSearch' => 'Zobrazit hledání',
    'buttonSearch' => 'Hledat',
    'buttonResetSearch' => 'Resetovat hledání',
    'noEntriesFound' => 'Nebyly nalezeny žádné položky.',
    'itemsNotSelected' => 'Nejprve vybrat položky.',
    'messageBoxButtonYes' => 'Ano',
    'messageBoxButtonNo' => 'Ne',
    'messageBoxButtonOk' => 'OK',
    'allItems' => 'Vše',
];