<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Přidat službu',
    'create.hint' => 'Toto je místo, kde přidáte odkaz externí službě.',

    'edit.title' => 'Vlastnosti služby %%name%%',
    'edit.hint' => 'Zde můžete zadat vlastnosti služby.',
    'edit.errorItemNotEditable' => 'Vlastnosti této služby nelze upravit.',

    'list.title' => 'Další služby',
    'list.tabTitle' => 'Další služby',
    'list.hint' => "Toto je seznam dalších služeb, které můžete zajistit prostřednictvím plánů hostování. Zobrazí ručně definované služby a služby poskytované aplikacemi instalovanými jako rozšíření prostředí Plesk. Ruční přidání služby je vhodné, pokud chcete své zákazníky nasměrovat na externí službu online: na Panel zákazníka se přidá odpovídající tlačítko. Standardně jsou všechny další služby uvedeny ve vlastnostech plánu hostování nebo na záložce Další služby. Toto vás a vaše prodejce včetně těchto služeb ponechá v plánech hostování. Pokud nechcete, aby vaši prodejci používali službu a poskytovali ji svým zákazníkům, použijte odkaz Vytvořit nedostupnost.",
    'list.planItemsNowAvailable' => 'Vybrané další služby jsou k dispozici prodejcům.',
    'list.planItemsNowNotAvailable' => 'Vybrané další služby už nejsou prodejcům k dispozici.',
    'list.cantChangePlanItemsProperties' => 'Během pokusu o změnu dostupnosti nastavení pro službu došlo k chybě.',
    'list.infoNewPlanItemCreated' => 'Možnost %%name%% odpovídá službě, která byla přidána do vlastností plánu.',
    'list.infoPlanItemUpdated' => 'Možnost plánu %%name%% byla aktualizována.',
    'list.planItemsDeleted' => 'Vybrané možnosti plánu byly odstraněny.',
    'list.planItemsNotDeleted' => 'Některé z vybraných možností plánu nebyly odstraněny.',
];