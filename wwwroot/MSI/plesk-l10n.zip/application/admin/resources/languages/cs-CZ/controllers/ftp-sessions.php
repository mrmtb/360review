<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-sessions.noSessionsSpecified' => 'Ze seznamu vyberte jednu nebo více relací FTP.',
    'delete-sessions.sessionsDeleted' => 'Vybrané relace byly odstraněny.',
    'delete-sessions.sessionsNotDeleted' => 'Některé z vybraných relací nebyly odstraněny. Podrobnosti: %%error%%.',

    'list.title' => 'Relace FTP',
];