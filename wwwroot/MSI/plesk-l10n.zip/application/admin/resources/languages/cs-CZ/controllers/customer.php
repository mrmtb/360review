<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-domain-alias.noDomains' => 'Nelze vytvořit alias: Nejsou k dispozici žádné domény.',

    'add-domain.noDomains' => 'Nelze vytvořit doménu doplňku: Nejsou k dispozici žádné domény.',

    'add-subdomain.noDomains' => 'Nelze vytvořit subdoménu: Nejsou k dispozici žádné domény.',

    'change-owner.wrongOwnerId' => 'Nelze najít nového vlastníka účtu zákazníka.',

    'change.title' => 'Změna plánu a doplňků přiřazených k předplatnému',

    'create.title' => 'Přidání nového zákazníka',

    'domains.title' => 'Domény',

    'list.title' => 'Zákazníci',
    'list.infoNewCustomerCreated' => 'Bylo vytvořeno %%name%% zákazníka.',
    'list.infoCustomerActivated' => 'Vybraní zákazníci byli aktivováni.',
    'list.infoCustomerNotActivated' => 'Někteří z vybraných zákazníků nebyli aktivováni.',
    'list.infoCustomerSuspended' => 'Vybraní zákazníci byli pozastaveni.',
    'list.infoCustomerNotSuspended' => 'Někteří z vybraných zákazníků nebyli pozastaveni.',
    'list.infoCustomerDeleted' => 'Vybraní zákazníci byli odstraněni.',
    'list.infoCustomerNotDeleted' => 'Někteří z vybraných zákazníků nebyli odstraněni.',
    'list.upgrageCustomersHint' => 'Provedli jste aktualizaci na verzi Plesk 11, která využívá nový zákaznický a obchodní model. Chcete-li dokončit přepnutí na nový model, převeďte klientské účty na účty zákazníka nebo prodejce. Pokud to neuděláte, vaši zákazníci nebudou moci vytvořit weby, i když jim bylo dříve uděleno oprávnění.',
    'list.upgrageCustomersLink' => 'Převést klientské účty.',
    'list.infoCustomerToResellerConverted' => 'Vybraní zákazníci byli úspěšně převedeni na prodejce.',
    'list.errorCustomerToResellerNotConverted' => 'Někteří z vybraných zákazníků nebyli převedeni na prodejce.',
    'list.infoOwnerChanged' => 'Vybraní zákazníci byli přesunuti na %%name%%.',
    'list.infoOwnerNotChanged' => 'Někteří z vybraných zákazníků nebyli přesunuti na %%name%%.',

    'login-info.title' => 'Úprava přihlašovacích údajů %%name%%',

    'overview.title' => '%%name%%',

    'personal-info.title' => 'Úprava kontaktních údajů pro %%name%%',

    'subscriptions.title' => 'Předplacené služby',
];