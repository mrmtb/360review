<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-filter.title' => 'Přidat filtr typu jail',
    'add-filter.filterAdded' => 'Byl přidán filtr typu jail.',
    'add-filter.errorFilterNotAdded' => 'Nelze přidat filtr typu jail: %%error%%.',

    'add-jail.title' => 'Přidat filtr typu jail',
    'add-jail.jailAdded' => 'Byl přidán filtr typu jail.',

    'add-trusted-ip.title' => 'Přidat důvěryhodnou IP adresu',
    'add-trusted-ip.trustedListTitle' => 'Důvěryhodné IP adresy',
    'add-trusted-ip.ipAdded' => 'IP adresa byla přidána do seznamu důvěryhodných adres.',
    'add-trusted-ip.errorIpNotAdded' => 'Nelze přidat IP adresu: %%error%%.',

    'edit-trusted-ip.title' => 'Upravit popis pro %%ip%%',
    'edit-trusted-ip.ipEdited' => 'Popis IP adresy byl aktualizován.',
    'edit-trusted-ip.ipAddressNotFound' => 'IP adresa nebyla nalezena v seznamu důvěryhodných adres.',
    'edit-trusted-ip.errorIpNotEdited' => 'Nelze upravit IP adresu: %%error%%.',

    'delete-banned-ips.infoBannedIpsDeleted' => 'Vybrané IP adresy byly odebrány ze seznamu zablokovaných adres.',
    'delete-banned-ips.infoBannedIpsNotDeleted' => 'Nelze odebrat některé IP adresy ze seznamu zablokovaných adres: %%error%%.',

    'delete-filters.infoFiltersDeleted' => 'Vybrané filtry typu jail byly odebrány.',
    'delete-filters.errorFiltersNotDeleted' => 'Nelze odebrat vybrané filtry: %%error%%.',
    'delete-filters.errorFiltersBuiltIn' => 'Vestavěné filtry nelze odebrat.',

    'delete-jail.infoJailDeleted' => 'Filtr typu jail byl odebrán.',
    'delete-jail.errorJailNotDeleted' => 'Nelze odebrat filtr typu jail: %%error%%.',
    'delete-jail.errorJailsBuiltIn' => 'Vestavěné filtry typu jail nelze odebrat.',

    'delete-jails.infoJailsDeleted' => 'Vybrané filtry typu jail byly odebrány.',
    'delete-jails.errorJailsNotDeleted' => 'Nelze odebrat vybrané filtry typu jail: %%error%%.',
    'delete-jails.errorJailsBuiltIn' => 'Vestavěné filtry typu jail nelze odebrat.',

    'delete-trusted-ips.infoTrustedIpsDeleted' => 'Vybrané IP adresy byly odebrány ze seznamu důvěryhodných adres.',
    'delete-trusted-ips.infoTrustedIpsNotDeleted' => 'Některé IP adresy nelze odebrat ze seznamu důvěryhodných adres: %%error%%.',
    'delete-trusted-ips.warningTrustedIpsPresentOnInterfaces' => 'Některé z odstraněných důvěryhodných IP adres jsou přítomny v síťovém rozhraní: %%ips%%. Mohou být nechtěně zablokovány a proto se vyskytnou problémy s vyvoláním webů nebo přístupu ke službám.',

    'disable-jails.infoJailsDisabled' => 'Vybrané filtry typu jail byly vypnuty.',
    'disable-jails.errorJailsNotDisabled' => 'Nelze vypnout vybrané filtry typu jail: %%error%%.',

    'edit-filter.title' => 'Upravit filtr typu jail',
    'edit-filter.filterSaved' => 'Byl uložen filtr typu jail.',
    'edit-filter.errorFilterNotSaved' => 'Nelze uložit filtr typu jail: %%error%%.',
    'edit-filter.errorFilterNotEditable' => 'Filtr není možné změnit.',

    'edit-jail.title' => '%%name%%',
    'edit-jail.jailSaved' => 'Nastavení filtru typu jail bylo uloženo.',
    'edit-jail.errorJailNotEditable' => 'Filtr typu jail není možné změnit.',

    'enable-jails.infoJailsEnabled' => 'Vybrané filtry typu jail byly zapnuty.',
    'enable-jails.errorJailsNotEnabled' => 'Nelze zapnout vybrané filtry typu jail: %%error%%.',

    'filters-list.title' => 'Filtry typu jail',

    'index.title' => 'Blokování IP adresy',
    'index.banListTab' => 'Zablokované IP adresy',
    'index.trustedListTab' => 'Důvěryhodné IP adresy',
    'index.jailListTab' => 'Filtry typu jail',
    'index.settingsTab' => 'Nastavení',
    'index.logListTab' => 'Protokoly',
    'index.jailNotFound' => 'Filtr typu jail %%name%% nebyl nalezen.',
    'index.filterNotFound' => 'Filtr %%name%% nebyl nalezen.',
    'index.logFileNotFound' => 'Soubor protokolu nebyl nalezen.',
    'index.tooManyDomains' => 'Součást Fail2Ban nemusí pracovat správně, pokud existuje mnoho domén a Fail2Ban musí monitorovat příliš mnoho souborů protokolu.',
    'index.errorServiceFailed' => 'Služba Blokování IP adresy (Fail2Ban) selhala a nemusí pracovat správně. %%link%%',
    'index.restartLink' => 'Zkuste restartovat',

    'jail-list.failed' => 'Nelze získat seznam filtrů typu jail: %%error%%.',

    'log-view.fileIsEmpty' => 'Soubor je prázdný.',

    'move-to-trusted.infoTrustedIpsAdded' => 'Vybrané IP adresy byly přidány do seznamu důvěryhodných adres.',
    'move-to-trusted.infoTrustedIpsNotAdded' => 'Některé IP adresy nelze přidat na seznam důvěryhodných adres: %%error%%.',

    'overview-jail.title' => '%%name%%',
    'overview-jail.pageHint' => 'Zde můžete zobrazit podrobné informace o filtru typu jail.',
    'overview-jail.buttonEditJail' => 'Změnit nastavení',
    'overview-jail.hintEditJail' => 'Změnit nastavení tohoto filtru typu jail.',
    'overview-jail.buttonDisableJail' => 'Vypnout',
    'overview-jail.hintDisableJail' => 'Vypnout tento filtr typu jail.',
    'overview-jail.buttonActivateJail' => 'Zapnout',
    'overview-jail.hintActivateJail' => 'Zapnout tento filtr typu jail.',
    'overview-jail.buttonRemoveJail' => 'Odebrat',
    'overview-jail.hintRemoveJail' => 'Odebrat tento filtr typu jail.',
    'overview-jail.fieldSatatus' => 'Stav',
    'overview-jail.fieldParameters' => 'Nastavení',
    'overview-jail.enabled' => 'Aktivní',
    'overview-jail.disabled' => 'Neaktivní',
    'overview-jail.banListHint' => 'IP adresy zablokované tímto filtrem typu jail:',

    'restart.success' => 'Restartování služby může trvat několik minut.',
    'restart.failed' => 'Službu nelze restartovat.',

    'settings.settingsSaved' => 'Nastavení bylo uloženo.',
    'settings.errorSettingsNotSaved' => 'Nelze uložit nastavení: %%error%%.',
    'settings.errorServiceFailed' => 'Služba Blokování IP adresy (Fail2Ban) selhala: %%error%%',

    'toggle-jail.infoJailEnabled' => 'Filtr typu jail byl zapnut.',
    'toggle-jail.infoJailDisabled' => 'Filtr typu jail byl vypnut.',
    'toggle-jail.errorJailNotEnabled' => 'Nelze zapnout filtr typu jail: %%error%%.',
    'toggle-jail.errorJailNotDisabled' => 'Nelze vypnout filtr typu jail: %%error%%.',

    'add-banned-ip.title' => 'Zablokovat IP adresu',
    'add-banned-ip.bannedListTitle' => 'Zablokované IP adresy',
    'add-banned-ip.ipAdded' => 'IP adresa byla přidána do seznamu zablokovaných adres.',
    'add-banned-ip.errorIpNotAdded' => 'Nelze zablokovat IP adresu: %%error%%.',
];