<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Vytvoření plánu prodejce',
    'create.hint' => 'Toto je místo, kde lze vytvořit plán prodejce odpovídající vaší nabídce.',

    'edit.title' => '%%name%%',
    'edit.hint' => 'Toto je místo, kde lze změnit plán prodejce odpovídající vaší nabídce. Nezapomeňte, že při změně plánu dojde k automatické aktualizaci všech k ní přidružených předplacených služeb kromě těch individuálně přizpůsobených, které jsou pro synchronizací uzamčeny.',

    'list.title' => 'Plány prodejce',
    'list.hint' => 'Zde budete spravovat plány vašeho prodejce, které umožní vytvoření předplacených služeb prodejce. Na rozdíl od vašich pravidelných zákazníků hostitelských služeb může být prodejce přihlášen k odběru pouze do jednoho plánu a nemůže mít doplňky.',
    'list.tabTitle' => 'Plány prodejce',
    'list.infoNewPlanCreated' => 'Byl vytvořen plán prodejce %%name%%.',
    'list.infoPlanUpdated' => 'Byl aktualizován plán prodejce %%name%%.',
    'list.infoPlanUpdatedSynced' => 'Byl aktualizován plán služeb %%name%%. Všechny přidružené přeplacené služby prodejce byly úspěšně synchronizovány, kromě těch individuálně přizpůsobených, které jsou pro synchronizaci uzamčeny.',
    'list.infoPlanDeleted' => 'Vybrané plány prodejců byly odebrány.',
    'list.infoPlanNotDeleted' => 'Některé z vybraných plánů prodejce nebyly odebrány.',
    'list.infoPlanDuplicated' => 'Vybrané plány služeb byly úspěšně zduplikovány.',
    'list.infoPlanNotDuplicated' => 'Některé z vybraných plánů služeb nebyly zduplikovány.',
];