<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Oznámení',

    'email-settings.title' => 'E-mail',

    'panel-settings.title' => 'Uživatelské rozhraní Plesk',
    'panel-settings.notificationSettingsSaved' => 'Nastavení oznámení bylo úspěšně uloženo.',

    'panel-notifications-toggle.successfullyEnabled' => 'Oznámení \'%%title%%\' bylo povoleno.',
    'panel-notifications-toggle.successfullyDisabled' => 'Oznámení \'%%title%%\' bylo zakázáno.',

    'template-settings-list.hint' => 'Zapnutím či vypnutím vyberte oznámení, která chcete vidět.',
    'template-settings-list.name' => 'Titul',
    'template-settings-list.context' => 'Kontext',
    'template-settings-list.sendToAdmin' => 'Odeslat správci',

    'template-settings-form.storagePeriod' => 'Uložit oznámení pro',
    'template-settings-form.days' => 'dny',
];