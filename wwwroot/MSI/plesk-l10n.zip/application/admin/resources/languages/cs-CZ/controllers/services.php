<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'operation.startActionSuccess' => 'Služba byla spuštěna',
    'operation.stopActionSuccess' => 'Služba byla zastavena',
    'operation.restartActionSuccess' => 'Služba byla restartována',
    'operation.changeStartupActionSuccess' => 'Typ spouštění pro službu byl úspěšně změněn',

    'list.title' => 'Služby',

    'operation.startServiceMessage' => 'Ponechte určitou dobu, aby se služba mohla spustit.',
    'operation.stopServiceMessage' => 'Ponechte určitou dobu, aby se služba mohla zastavit.',
    'operation.restartServiceMessage' => 'Ponechte určitou dobu, aby se služba mohla restartovat.',
    'operation.unableFetchFormData' => 'Nelze načíst data formuláře: %%error%%',
    'operation.startActionError' => 'Službu nelze spustit: %%error%%',
    'operation.stopActionError' => 'Službu nelze zastavit: %%error%%',
    'operation.restartActionError' => 'Službu nelze restartovat: %%error%%',
    'operation.changeStartupActionError' => 'Nelze změnit typ spuštění pro službu: %%error%%',
];