<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.hint' => 'Popis přidávání uzlu služby.',
    'add.title' => 'Přidat vzdálený uzel služby',
    'add.serviceNodeAdded' => 'Byl přidán vzdálený uzel služby %%name%%',

    'delete.infoServiceNodesDeleted' => 'Vybrané uzly služeb byly úspěšně odpojeny.',
    'delete.infoServiceNodesNotDeleted' => 'Nelze odpojit některé z vybraných uzlů služby.',
    'delete.serviceNodeIsInUse' => 'Uzel služby se právě používá.',

    'edit.hint' => 'Popis úprav uzlu služby.',
    'edit.title' => 'Vzdálený uzel služby %%name%%',
    'edit.serviceNodeUpdated' => 'Vlastnosti vzdáleného uzlu služby %%name%% byly aktualizovány',

    'list.hint' => 'Zde můžete přidat vzdálené uzly služeb',
    'list.title' => 'Uzly služby',
];