<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'eula.title' => 'Licenční smlouva s koncovým uživatelem (EULA) WebPros',
    'eula.popupTitle' => 'EULA',
    'eula.updatePopupTitle' => 'Aktualizace smlouvy EULA',
    'eula.popupDescription' => 'Chcete-li pokračovat v používání produktu, musíte si smlouvu EULA přečíst a přijmout ji.',
    'eula.updatePopupDescription' => 'Proběhla aktualizace smlouvy WebPros EULA. Pokud chcete produkt dál používat, musíte si aktualizovanou smlouvu EULA přečíst a přijmout ji.',
    'eula.buttonAccept' => 'Přijmout',
    'eula.buttonDecline' => 'Zamítnout',
];