<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'email.subjSuccess' => 'Prostředí Plesk bylo úspěšně aktualizováno',
    'email.subjFailure' => 'Aktualizace Plesk se nezdařila',
    'email.bodySuccess' => "Pozor, prostředí Plesk bylo úspěšně aktualizováno. Chcete-li zobrazit seznam změn, navštivte odkaz %%link%%. Tato zpráva byla odeslána automaticky z instalačního programu Plesk.",
    'email.bodyFailure' => "Pozor, aktualizace prostředí Plesk se nezdařila. Protokoly instalačního programu Plesk lze stáhnout na tomto odkazu: %%link%%. O podporu požádejte svého poskytovatele hostingu. Tato zpráva byla odeslána automaticky z instalačního programu Plesk.",
];