<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Přidání obslužné rutiny události',
    'add.added' => 'Byla přidána obslužná rutina události.',

    'delete.noHandlersSpecified' => 'Vyberte obslužné rutiny událostí, které se mají odstranit.',
    'delete.handlersDeleted' => 'Vybrané obslužné rutiny událostí byly odebrány.',
    'delete.handlersNotDeleted' => 'Některé z vybraných obslužných rutin událostí nebyly odebrány. Podrobnosti: %%error%%.',

    'edit.title' => 'Aktualizace vlastností obslužných rutin událostí',
    'edit.updated' => 'Obslužná rutina události byla aktualizována.',

    'list.title' => 'Správce událostí',
];