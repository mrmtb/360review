<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-log.actionSuccess' => 'Vybrané soubory protokolu byly odebrány.',
    'delete-log.invalidFileName' => 'Název souboru protokolu je neplatný.',
    'delete-log.actionError' => 'Nelze odebrat soubor protokolu %%file%%: %%reason%%',

    'index.title' => 'Webová aplikační brána firewall',
    'index.generalTab' => 'Obecné',
    'index.settingsTab' => 'Nastavení',
    'index.settingsSaved' => 'Nastavení webové aplikační brány firewall bylo uloženo.',
    'index.updateFailed' => 'Aktualizace sady pravidel ModSecurity se nezdařila: %%error%%',
    'index.updateFailedShort' => 'Aktualizace sady pravidel ModSecurity se nezdařila. %%link%%',
    'index.updateFailedShortLink' => 'Podrobnosti',

    'log-list.title' => 'Správa souborů protokolu',

    'view-log.fileNameIsUndefined' => 'Název souboru protokolu není definován.',
];