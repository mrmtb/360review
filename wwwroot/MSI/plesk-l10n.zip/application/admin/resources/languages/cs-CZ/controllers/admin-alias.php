<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoAdminAliasActivated' => 'Vybrané účty správce byly úspěšně aktivovány.',
    'activate.infoAdminAliasNotActivated' => 'Některé z vybraných účtů správce nebyly aktivovány.',

    'create.title' => 'Přidání účtu správce',
    'create.infoNewAdminAliasCreated' => 'Další účet správce %%contact%% byl úspěšně vytvořen.',

    'deactivate.infoAdminAliasDeactivated' => 'Vybrané účty správce byly úspěšně pozastaveny.',
    'deactivate.infoAdminAliasNotDeactivated' => 'Některé z vybraných účtů správce nebyly pozastaveny.',

    'delete.infoAdminAliasDeleted' => 'Vybrané účty správce byly úspěšně odebrány.',
    'delete.infoAdminAliasNotDeleted' => 'Některé z vybraných účtů správce nebyly odebrány.',

    'edit.title' => "%%contact%%",
    'edit.infoNewAdminAliasUpdated' => 'Účet správce byl úspěšně aktualizován.',

    'list.title' => 'Další účty správce',
    'list.hint' => 'Zde můžete vytvořit další účty správce pro vaše techniky z oddělení podpory a umožnit jim provádění nejrůznějších administrativních úloh.',
];