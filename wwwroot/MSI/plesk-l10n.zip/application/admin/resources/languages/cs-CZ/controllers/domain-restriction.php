<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Přidat název domény',
    'add.domainAdded' => 'Do seznamu zakázaných názvů byl úspěšně přidán název domény %%domain%%.',

    'disable.listDisabled' => 'Kontrola zakázaných názvů domén byla vypnuta.',

    'edit.title' => '%%name%%',
    'edit.domainUpdated' => 'Název domény %%domain%% byl úspěšně aktualizován.',

    'enable.listEnabled' => 'Kontrola zakázaných názvů domén byla zapnuta.',

    'list.title' => 'Zakázané názvy domén',
    'list.hint' => 'Odtud můžete spravovat seznam zakázaných názvů domén, který obsahuje nejpopulárnější domény. Pokud zapnete kontrolu na zakázaná jména domén (kliknutím na Povolit), uživatelé nebudou moci vytvářet domény s názvy z tohoto seznamu. Takové omezení je užitečné, například k ochraně před zachycením pošty. Pokud je kontrola vypnuta, e-mailové zprávy odeslané vašimi zákazníky oficiálním společnostem mohou přijímat zákazníci, kteří si nastavili domény se stejnými názvy, jako v majetku těchto společností.',
    'list.warningLisDisabled' => 'Kontrola zakázaných názvů domén je vypnuta.',

    'remove.domainRemoved' => 'Vybrané názvy domén byly odebrány.',
    'remove.domainNotRemoved' => 'Některé z vybraných názvů domén nebyly odebrány.',
    'remove.unableRemove' => 'Některé ze zadaných názvů domén nebyly odebrány.',
];