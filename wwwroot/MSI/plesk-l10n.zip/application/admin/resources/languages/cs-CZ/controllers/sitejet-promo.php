<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

$messages = [
    'accessDenied' => 'Sitejet Builder není součástí vašeho předplatného. Pokud ho chcete povolit, kontaktujte svého poskytovatele hostingu.',
];