<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.formTitle' => 'Vælg service til tilføjelse',
    'create.successfullyAdded' => 'Servicen \'%%serviceDisplayName%%\' blev oprettet.',
    'create.successfullyUpdated' => 'Servicen\'%%serviceDisplayName%%\' blev opdateret.',
    'create.selectServiceInstallationTitle' => 'Vælg service',

    'edit.formTitle' => 'Administrér \'%%serviceDisplayName%%\' service',
    'edit.title' => 'Services for %%subscriptionName%%',
    'edit.successfullyUpdated' => 'Servicen\'%%serviceDisplayName%%\' blev opdateret.',

    'list.hint' => 'Her kan du administrere services på et abonnement',
    'list.title' => 'Services for %%subscriptionName%%',
    'list.breadcrumb' => 'Tjenester',
    'list.infoServiceDeleted' => 'Valgte services blev fjernet.',
    'list.infoServiceNotDeleted' => 'Nogle af de valgte services blev ikke fjernet.',
];