<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-log.actionSuccess' => 'De valgte logfiler blev fjernet.',
    'delete-log.invalidFileName' => 'Logfilnavnet er ugyldigt.',
    'delete-log.actionError' => 'Kan ikke fjerne logfilen %%file%%: %%reason%%',

    'index.title' => 'Webprogram firewall',
    'index.generalTab' => 'Generelt',
    'index.settingsTab' => 'Indstillinger',
    'index.settingsSaved' => 'Webprogrammets firewall-indstillinger blev gemt.',
    'index.updateFailed' => 'Kunne ikke opdatere ModSecurity regelsæt: %%error%%',
    'index.updateFailedShort' => 'Kunne ikke opdatere ModSecurity regelsæt. %%link%%',
    'index.updateFailedShortLink' => 'Detaljer',

    'log-list.title' => 'Logfil-administration',

    'view-log.fileNameIsUndefined' => 'Logfilnavnet er ikke defineret.',
];