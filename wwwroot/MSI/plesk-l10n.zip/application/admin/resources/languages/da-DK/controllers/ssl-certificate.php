<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Tilføj SSL/TLS-certifikat',
    'add.enterCertificateName' => 'Indtast certifikatets navn.',

    'delete.infoSslCertificatesDeleted' => 'SSL/TLS-certifikater blev fjernet.',
    'delete.infoSslCertificatesNotDeleted' => 'Kan ikke fjerne SSL-TLS certifikater.',
    'delete.certificateUsedAsDefault' => 'Et af de certifikater, du er ved at slette, bruges som standardcertifikat.',
    'delete.certificateAssignedOnIp' => 'et eller flere certifikater er knyttet til IP-adresser/domæner.',
    'delete.certificateUsedByPanel' => 'Et af de certifikater, du er ved at slette, bruges til sikring af Plesk.',
    'delete.certificateUsedByMailServer' => 'Et af de certifikater, du er ved at slette, bruges til sikring af mailserveren.',

    'edit.title' => 'Rediger egenskaberne for SS/TLSL-certifikat %%name%%',
    'edit.enterCertificateName' => 'Indtast certifikatets navn.',

    'list.title' => 'SSL/TLS-certifikater',
    'list.certificateFound' => 'Den private nøgle (med navnet %%name%%) for det uploadede certifikat blev ikke fundet. Certifikatet blev tilføjet.',
    'list.certificatesList' => 'Liste over certifikater i serverpulje',
    'list.certificatesListHint' => 'Der er listen over certifikater i serverpuljen.',
    'list.currentCertificates' => 'Certifikater, der aktuelt anvendes til sikring af Plesk-serveren',
    'list.currentCertificatesHint' => 'Certifikater, der aktuelt anvendes til sikring af Plesk-og mailserveren',
    'list.pleskCertificate' => 'Certifikat til sikring af Plesk',
    'list.mailServerCertificate' => 'Certifikat til sikring af e-mail',
    'list.serverPoolCertificateDescription' => '%%name%% fra serverpulje.',
    'list.domainCertificateDescription' => '%%name%% fra %%domain%%.',
    'list.change' => '[Rediger]',
    'list.none' => 'Ukendt.',

    'secure-mail-server.title' => 'Sikker e-mail server',
    'secure-mail-server.hint' => 'Vælg et certifikat til sikring af mailserveren.',
    'secure-mail-server.mailServerCertificateSet' => 'Certifikatet %%name%% blev indstillet korrekt til sikring af mailserveren.',
    'secure-mail-server.mailServerNotInstalled' => 'Mailtjenesten er ikke installeret.',

    'secure-panel.title' => 'Gør Plesk sikker',
    'secure-panel.hint' => 'Vælg et certifikat til sikring af Plesk.',
    'secure-panel.panelCertificateSet' => 'Certifikatet %%name%% blev indstillet korrekt til sikring af Plesk.',
];