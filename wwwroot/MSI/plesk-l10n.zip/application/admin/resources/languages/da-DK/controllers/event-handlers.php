<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Tilføjer hændelseshandler',
    'add.added' => 'Hændelseshandler blev tilføjet.',

    'delete.noHandlersSpecified' => 'Vælg de hændelses-handlere der skal fjernes.',
    'delete.handlersDeleted' => 'De valgte hændelseshandlere blev fjernet.',
    'delete.handlersNotDeleted' => 'Nogle af de valgte hændelseshandlere blev ikke fjernet. Detaljer: %%error%%.',

    'edit.title' => 'Opdaterer hændelseshandler-egenskaber',
    'edit.updated' => 'Hændelseshandleren blev opdateret.',

    'list.title' => 'Hændelsesadministrator',
];