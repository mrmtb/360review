<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

$messages = [
    'accessDenied' => 'Sitejet Builder er ikke inkluderet i dit abonnement. For at aktivere Sitejet Builder skal du kontakte din hostingudbyder.',
];