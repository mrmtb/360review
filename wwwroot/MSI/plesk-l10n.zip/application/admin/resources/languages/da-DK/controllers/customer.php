<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-domain-alias.noDomains' => 'Der kan ikke oprettes et alias: Der er ingen tilgængelige domæner.',

    'add-domain.noDomains' => 'Der kan ikke oprettes et addon-domæne: Der er ingen tilgængelige domæner.',

    'add-subdomain.noDomains' => 'Der kan ikke oprettes et subdomæne: Der er ingen tilgængelige domæner.',

    'change-owner.wrongOwnerId' => 'Kan ikke finde den nye ejer af kundekontoen.',

    'change.title' => 'Ændring af plan og tilføjelser der er knyttet sammen med abonnementer',

    'create.title' => 'Tilføje en ny kunde',

    'domains.title' => 'Domæner',

    'list.title' => 'Kunder',
    'list.infoNewCustomerCreated' => 'Kunden %%name%% blev oprettet.',
    'list.infoCustomerActivated' => 'De markerede kunder blev aktiveret.',
    'list.infoCustomerNotActivated' => 'Nogle af de markerede kunder blev ikke aktiveret.',
    'list.infoCustomerSuspended' => 'Markerede kunder blev suspenderet.',
    'list.infoCustomerNotSuspended' => 'Nogle af de markerede kunder blev ikke suspenderet.',
    'list.infoCustomerDeleted' => 'De markerede kunder blev slettet.',
    'list.infoCustomerNotDeleted' => 'Nogle af de markerede kunder blev ikke slettet.',
    'list.upgrageCustomersHint' => 'Du har opgraderet til Plesk 11, som anvender en ny kunde- og forretningsmodel. For at afsluttet skiftet til den nye model skal du konvertere klientkonti til kunde- eller forhandlerkonti. Hvis du ikke gør dette, vil dine kunder ikke kunne oprette websteder - heller ikke selvom de havde en sådan tilladelse før.',
    'list.upgrageCustomersLink' => 'Konvertér klientkonti.',
    'list.infoCustomerToResellerConverted' => 'De valgte kunder blev konverteret til forhandlere.',
    'list.errorCustomerToResellerNotConverted' => 'Nogle af de valgte kunder blev ikke konverteret til forhandlere.',
    'list.infoOwnerChanged' => 'De valgte kunder blev flyttet til %%name%%.',
    'list.infoOwnerNotChanged' => 'Nogle af de valgte kunder blev ikke flyttet til %%name%%.',

    'login-info.title' => 'Redigering af Login-Info for %%name%%',

    'overview.title' => '%%name%%',

    'personal-info.title' => 'Redigering af kontakt-Info for %%name%%',

    'subscriptions.title' => 'Abonnementer',
];