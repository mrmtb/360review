<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-filter.title' => 'Tilføj Jail-filter',
    'add-filter.filterAdded' => 'Jail-filter blev tilføjet.',
    'add-filter.errorFilterNotAdded' => 'Kan ikke tilføje jail-filter: %%error%%.',

    'add-jail.title' => 'Tilføj Jail',
    'add-jail.jailAdded' => 'Jail blev tilføjet.',

    'add-trusted-ip.title' => 'Tilføj en IP-adresse der er tillid til',
    'add-trusted-ip.trustedListTitle' => 'IP-adresser der er tillid til',
    'add-trusted-ip.ipAdded' => 'IP-adressen blev føjet til listen over adresser der er tillid til.',
    'add-trusted-ip.errorIpNotAdded' => 'Kan ikke tilføje IP-adressen: %%error%%.',

    'edit-trusted-ip.title' => 'Rediger beskrivelse af %%ip%%',
    'edit-trusted-ip.ipEdited' => 'Beskrivelse af IP-adressen blev opdateret.',
    'edit-trusted-ip.ipAddressNotFound' => 'IP-adressen blev ikke fundet på listen over IP-adresser med tillid til.',
    'edit-trusted-ip.errorIpNotEdited' => 'Kunne ikke redigere IP-adressen: %%error%%.',

    'delete-banned-ips.infoBannedIpsDeleted' => 'De valgte IP-adresser blev fjernet fra listen over bandlyste adresser.',
    'delete-banned-ips.infoBannedIpsNotDeleted' => 'Kunne ikke fjerne visse IP-adresser fra listen over bandlyste adresser: %%error%%.',

    'delete-filters.infoFiltersDeleted' => 'De valgte jail-filtre blev fjernet.',
    'delete-filters.errorFiltersNotDeleted' => 'Kan ikke fjerne de valgte filtre: %%error%%.',
    'delete-filters.errorFiltersBuiltIn' => 'De indbyggede filtre kan ikke fjernes.',

    'delete-jail.infoJailDeleted' => 'Jail blev fjernet.',
    'delete-jail.errorJailNotDeleted' => 'Kan ikke fjerne jail: %%error%%.',
    'delete-jail.errorJailsBuiltIn' => 'De indbyggede jails kan ikke fjernes.',

    'delete-jails.infoJailsDeleted' => 'De valgte jails blev fjernet.',
    'delete-jails.errorJailsNotDeleted' => 'Kan ikke fjerne de valgte jails: %%error%%.',
    'delete-jails.errorJailsBuiltIn' => 'De indbyggede jails kan ikke fjernes.',

    'delete-trusted-ips.infoTrustedIpsDeleted' => 'De valgte IP-adresser blev fjernet fra listen over adresser der er tillid til.',
    'delete-trusted-ips.infoTrustedIpsNotDeleted' => 'Kan ikke fjerne visse IP-adresser fra listen over adresser der er tillid til: %%error%%.',
    'delete-trusted-ips.warningTrustedIpsPresentOnInterfaces' => 'Nogle af de betroede IP\'er er tilstede på netværksgrænsefladen/flade3rne: %%ips%%. De kan forbydes ved en fejl, og på den måde medføre websteds- eller serviceadgangsproblemer.',

    'disable-jails.infoJailsDisabled' => 'De valgte jails blev deaktiveret.',
    'disable-jails.errorJailsNotDisabled' => 'Kan ikke deaktivere de valgte jails: %%error%%.',

    'edit-filter.title' => 'Redigér Jail-filter',
    'edit-filter.filterSaved' => 'Jail-filter blev gemt.',
    'edit-filter.errorFilterNotSaved' => 'Kan ikke gemme jail-filter: %%error%%.',
    'edit-filter.errorFilterNotEditable' => 'Filteret kan ikke ændres.',

    'edit-jail.title' => '%%name%%',
    'edit-jail.jailSaved' => 'Jail-indstillingerne blev gemt.',
    'edit-jail.errorJailNotEditable' => 'Det er ikke muligt at ændre jail.',

    'enable-jails.infoJailsEnabled' => 'De valgte jails blev aktiveret.',
    'enable-jails.errorJailsNotEnabled' => 'Kan ikke aktivere de valgte jails: %%error%%.',

    'filters-list.title' => 'Jail-filtre',

    'index.title' => 'IP-adressebandlysning',
    'index.banListTab' => 'Bandlyste IP-adresser',
    'index.trustedListTab' => 'IP-adresser der er tillid til',
    'index.jailListTab' => 'Jails',
    'index.settingsTab' => 'Indstillinger',
    'index.logListTab' => 'Hændelser',
    'index.jailNotFound' => 'Jail %%name%% blev ikke fundet.',
    'index.filterNotFound' => 'Filteret %%name%% blev ikke fundet.',
    'index.logFileNotFound' => 'Logfilen blev ikke fundet.',
    'index.tooManyDomains' => 'Fail2Ban fungerer muligvis ikke godt hvis der er mange domæner og Fail2Ban dermed skal overvåge for mange logfiler.',
    'index.errorServiceFailed' => 'IP-adressebandlysning (Fail2Ban) service mislykkedes og fungerer muligvis ikke korrekt. %%link%%',
    'index.restartLink' => 'Prøv at genstarte',

    'jail-list.failed' => 'Kan ikke hente listen over jails: %%error%%.',

    'log-view.fileIsEmpty' => 'Filen er tom.',

    'move-to-trusted.infoTrustedIpsAdded' => 'De valgte IP-adresser blev føjet til listen over adresser der er tillid til.',
    'move-to-trusted.infoTrustedIpsNotAdded' => 'Kan ikke tilføje visse IP-adresser fra listen over adresser der er tillid til: %%error%%.',

    'overview-jail.title' => '%%name%%',
    'overview-jail.pageHint' => 'Her kan du se detaljerede oplysninger om denne jail.',
    'overview-jail.buttonEditJail' => 'Rediger indstillinger',
    'overview-jail.hintEditJail' => 'Redigér indstillingerne for denne jail.',
    'overview-jail.buttonDisableJail' => 'Slå fra',
    'overview-jail.hintDisableJail' => 'Deaktivér denne jail.',
    'overview-jail.buttonActivateJail' => 'Slå til',
    'overview-jail.hintActivateJail' => 'Aktivér denne jail.',
    'overview-jail.buttonRemoveJail' => 'Fjern',
    'overview-jail.hintRemoveJail' => 'Fjern denne jail.',
    'overview-jail.fieldSatatus' => 'Status',
    'overview-jail.fieldParameters' => 'Indstillinger',
    'overview-jail.enabled' => 'Aktiv',
    'overview-jail.disabled' => 'Inaktiv',
    'overview-jail.banListHint' => 'IP-adresser blokeret af denne jail:',

    'restart.success' => 'Genstart af servicen kan tage nogle minutter.',
    'restart.failed' => 'Kunne ikke genstarte servicen.',

    'settings.settingsSaved' => 'Indstillingerne blev gemt.',
    'settings.errorSettingsNotSaved' => 'Kan ikke gemme indstillingerne: %%error%%.',
    'settings.errorServiceFailed' => 'IP-adresse bandlysning (Fail2Ban) service mislykkedes: %%error%%',

    'toggle-jail.infoJailEnabled' => 'Jail\'en blev aktiveret.',
    'toggle-jail.infoJailDisabled' => 'Jail\'en blev deaktiveret.',
    'toggle-jail.errorJailNotEnabled' => 'Kan ikke aktivere denne jail: %%error%%.',
    'toggle-jail.errorJailNotDisabled' => 'Kan ikke deaktivere denne jail: %%error%%.',

    'add-banned-ip.title' => 'Bandlys IP-adresse',
    'add-banned-ip.bannedListTitle' => 'Bandlyste IP-adresser',
    'add-banned-ip.ipAdded' => 'IP-adressen blev føjet til listen over bandlyste IP-adresser.',
    'add-banned-ip.errorIpNotAdded' => 'IP-adressen kunne ikke bandlyses: %%error%%.',
];