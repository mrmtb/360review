<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'assign-to-subscription.databasesSuccessfullyAssignedToSubscription' => 'Databaserne blev flyttet til abonnementet \'%%subscriptionName%%\'.',
    'assign-to-subscription.databasesNotAssignedToSubscription' => 'Kan ikke flytte databaserne til abonnementet \'%%subscriptionName%%\'.',
    'assign-to-subscription.subscriptionNotFound' => 'Abonnementet \'%%name%%\' blev ikke fundet.',
    'assign-to-subscription.isNotMainDomain' => '\'%%name%%\' er ikke hoveddomænet i abonnementet.',

    'settings.title' => 'Database-hosting indstillinger',
    'settings.settingsSaved' => 'Database-hosting indstillingerne blev gemt.',

    'refresh.success' => 'Databaseservers information blev genindlæst.',
];