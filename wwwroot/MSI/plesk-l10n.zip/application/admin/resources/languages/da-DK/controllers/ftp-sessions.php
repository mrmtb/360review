<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-sessions.noSessionsSpecified' => 'Vælg en eller flere FTP-sessioner på listen.',
    'delete-sessions.sessionsDeleted' => 'De valgte sessioner blev slettet.',
    'delete-sessions.sessionsNotDeleted' => 'Nogle af de valgte sessioner blev ikke slettet. Detaljer: %%error%%.',

    'list.title' => 'FTP--sessioner',
];