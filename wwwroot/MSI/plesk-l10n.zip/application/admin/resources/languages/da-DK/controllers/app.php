<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'clear-cache.apsCacheCleared' => 'Midlertidige filer blev fjernet.',

    'configure.title' => '%%name%%',
    'configure.applicationNotFound' => "Program med ID'et '%%id%%' blev ikke fundet.",
    'configure.applicationHasNoSettings' => 'Programmet har ingen indstillinger.',
    'configure.settingsUpdated' => 'Programindstillingerne blev opdateret.',
    'configure.settingsUpdateFailed' => 'Kunne ikke opdatere programindstillingerne: %%error%%',
    'configure.instancesNotReconfigured' => 'Nogle af programforekomsterne blev ikke importeret.',

    'index.title' => 'Applikations-vault',

    'info.title' => '%%name%%',
    'info.hint' => 'Listen herunder indeholder informationen om websteder hvorpå programmet er installeret. Værdien Ingen i kolonnen Websted betyder, at programmet er eksternt. Et sådant program kan ikke installeres på en bestemt kundes websted - det er kun et link til en ekstern service.',

    'remote-app-info.title' => 'Oplysninger om programmet',

    'update-settings.title' => 'Opdatereringsindstillinger',
    'update-settings.settingsUpdated' => 'Indstillingerne blev opdateret.',
    'update-settings.settingsUpdateFailed' => 'Indstillingerne kunne ikke opdateres: %%error%%',

    'upload.title' => 'Tilføj app',
    'upload.packageInstallationError' => 'Programmet kunne ikke tilføjes: %%message%%.',
    'upload.appUploaded' => 'Programmet blev uploadet korrekt.',
    'upload.appDownloadStarted' => 'Downloader de valgte programmer',

    'uploaded.title' => 'Mine apps',
    'uploaded.hint' => 'Her kan du tilføje eller fjerne programmer fra Programgruppen samt administrere programtilgængeligheden for dine kunder. Der er to grunde til at tilføje programmer: At udvide listen over programmer til rådighed, eller at konfigurere server-brede programindstillinger. Nogle programmer kan ikke installeres uden en sådan konfiguration. Alle de tilføjede programmer er vist herunder.',
    'uploaded.infoAppDeleted' => 'De valgte programmer blev slettet.',
    'uploaded.infoAppNotDeleted' => 'De valgte programmer blev ikke slettet.',
    'uploaded.applicationsNowAvailable' => 'De valgte programmer er nu til rådighed for installation af dine kunder eller for konfiguration.',
    'uploaded.applicationsNowNotAvailable' => 'De valgte programmer er nu til rådighed for installation af dine kunder eller for konfiguration.',
    'uploaded.cantChangePackageProperties' => 'Der opstod en fejl under forsøget på at ændre programmets rådighedsindstillinger.',
    'uploaded.appDownloaded' => 'De valgte programmer blev downloadet korrekt.',
    'uploaded.appNotDownloaded' => 'De valgte programmer blev ikke downloadet.',
    'uploaded.downloadInProgress' => 'Vent venligst...',

    'usage.title' => 'Installerede programmer',
    'usage.hint' => 'Nedenstående liste indeholder alle programmer, du enten selv har tilføjet eller som er installeret af dine kunder. Her kan du administrere programindstillinger, kontrollere om der er opdateringer eller fjerne midlertidige filer, der blev tilføjet under programinstallationerne.',
    'usage.hintReseller' => 'Nedenstående liste viser information om alle programinstallationerne på dit websted og på dine kunders websteder. Klik på et programnavn for at se en liste over websteder, som programmet er installeret på, og for at kontrollere om der er opdateringer til programmet.',
];