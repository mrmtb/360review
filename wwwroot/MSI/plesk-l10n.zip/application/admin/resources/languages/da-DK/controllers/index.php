<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'eula.title' => 'WebPros slutbrugerlicensaftale',
    'eula.popupTitle' => 'EULA (slutbrugerlicensaftale)',
    'eula.updatePopupTitle' => 'EULA-opdatering',
    'eula.popupDescription' => 'Du skal læse og acceptere EULA\'en for at fortsætte brugen af produktet.',
    'eula.updatePopupDescription' => 'WebPros EULA er blevet opdateret. Du skal læse og acceptere den opdaterede EULA for at fortsætte brugen af produktet.',
    'eula.buttonAccept' => 'Acceptere',
    'eula.buttonDecline' => 'Afvis',
];