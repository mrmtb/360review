<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'admin-customers-target-list.title' => 'Administrators kunder med behov for omdannelse',
    'admin-customers-target-list.hint-t1s1' => 'Dette er en liste over kunder der er oprettet fra klienter, som det var forbudt at ændre domænegrænserne og som havde et domæne inden opgraderingen.',
    'admin-customers-target-list.hint-t1s2' => 'Dette er en liste over kunder der er oprettet fra klienter, som havde tilladels til at ændre domænegrænserne og som havde et domæne inden opgraderingen.',
    'admin-customers-target-list.hint-t1s3' => 'Dette er en liste over kunder der er oprettet fra klienter, som det var forbudt at oprette domæner og ændre domænegrænserne og som havde flere domæner inden opgraderingen.',
    'admin-customers-target-list.hint-t1s6' => 'Dette er en liste over kunder der er oprettet fra klienter, som det var forbudt at oprette domæner og ændre domænegrænserne og som havde flere domæner inden opgraderingen.',

    'admin-subscriptions-target-list.title' => 'Administrators abonnementer med behov for omdannelse',
    'admin-subscriptions-target-list.hint' => 'Dette er en liste med abonnenter, der er oprettet fra de domæner der (a) hørte til admin og (b) havde en aktiv Domæneadministrator-konto inden opgraderingen.',

    'bunch.title' => 'Komplet skift til den nye Plesk-forretningsmodel',
    'bunch.noActionsDescription' => 'Der er ingen kunder eller abonnementer der passer til de almindelige scenarier tilbage i systemet, så der er ikke mere for dig at gøre under denne fane. Gå videre til næste fane og omdan de resterende kunder.',
    'bunch.description' => 'Modellen for ressourcedistribution i Plesk 10 og senere er forskellig i forhold til tidligere versioner: Plesk 10 kunder ikke har egne ressourcer, som det var tilfældet i Plesk 8 og 9, men får disse ved hjælp af abonnementer. Lige nu er der flere kunder med egne ressourcer, der skal omdannes for at passe til den nye Plesk-model. Baseret på de almindelige scenarier for Plesk-anvendelse, har Plesk analyseret disse kunder og genereret en liste over anbefalede omdannelseshandlinger. Du kan se listen herunder. Du kan enten fortsætte med disse eller vælge et omdannelsesskema pr. kunde. Når en kunde er omdannet, forsvinder vedkommende fra denne liste.',
    'bunch.help' => 'Få mere at vide om omdannelse.',
    'bunch.applyed' => 'Valgte kunder og abonnementer blev omdannet.',
    'bunch.failed' => 'Kunne ikke omdanne de valgte kunder og abonnementer.',

    'customers.title' => 'Komplet skift til den nye Plesk-forretningsmodel: Selektiv kundeomdannelse',
    'customers.description' => 'Dette er en fuldstændig liste over kunder med behov for omdannelse. Sammen med de konti, der passer ind i de almindelige scenarier, inkluder5er dette konti med uregelmæssige indstillinger, for hvilke der ikke er nogen anbefalede handlinger. Du bør selv vælge er passende omdannelsesskema, baseret på de enkelte tidligere klientindstillinger, f.eks. vedr. begrænsninger, tilladelser, nuværende antal domæner, osv. For at se en tidligere klients begrænsninger og tilladelse, skal du klikke på kundens navn og derefter på \'Mine ressourcer\' på listen over kundeabonnementer.',
    'customers.help' => 'Få mere at vide om omdannelse.',

    'manual-customer-solution.appliedInfo' => 'De valgte kunder blev omdannet.',
    'manual-customer-solution.notAppliedInfo' => 'Alle eller flere valgte kunder blev ikke omdannet.',

    'manual-subscription-solution.appliedInfo' => 'De valgte abonnementer blev omdannet.',
    'manual-subscription-solution.notAppliedInfo' => 'Alle eller flere valgte abonnementer blev ikke omdannet.',

    'notes.nonApplicableCustomers' => "%%count%% kunder passer ikke ind i de almindelige scenarier, så der er ingen anbefalede handlinger for disse. For at omdanne kontiene %%link%%.",
    'notes.nonApplicableSubscriptions' => "%%count%% abonnementer passer ikke ind i de almindelige scenarier, så der er ingen anbefalede handlinger for disse. For at omdanne abonnementerne %%link%%.",
    'notes.manualCustomersUpgradeLink' => 'vælg et brugerdefineret skema til dem',
    'notes.manualSubscriptionsUpgradeLink' => 'vælg et brugerdefineret skema til dem',

    'reseller-customers-target-list.title' => 'Forhandleres kunder med behov for omdannelse',
    'reseller-customers-target-list.hint-t2s1' => 'Dette er en liste over kunder der er oprettet fra klienter, som det var forbudt at ændre domænegrænserne og som havde et domæne inden opgraderingen.',
    'reseller-customers-target-list.hint-t2s2' => 'Dette er en liste over kunder der er oprettet fra klienter, som havde tilladels til at ændre domænegrænserne og som havde et domæne inden opgraderingen.',
    'reseller-customers-target-list.hint-t2s3' => 'Dette er en liste over kunder der er oprettet fra klienter, som det var forbudt at oprette domæner og ændre domænegrænserne og som havde flere domæner inden opgraderingen.',
    'reseller-customers-target-list.hint-t2s6' => 'Dette er en liste over kunder der er oprettet fra klienter, som det var forbudt at oprette domæner og ændre domænegrænserne og som havde flere domæner inden opgraderingen.',

    'reseller-subscriptions-target-list.title' => 'Forhandleres abonnementer med behov for omdannelse',
    'reseller-subscriptions-target-list.hint' => 'Dette er en liste med abonnenter, der er oprettet fra de domæner der (a) hørte til forhandlere og (b) havde en aktiv Domæneadministrator-konto inden opgraderingen.',

    'subscriptions.title' => 'Komplet skift til den nye Plesk-forretningsmodel: Selektiv abonnementsomdannelse',
    'subscriptions.description' => 'Dette er en liste over abonnementer med behov for omdannelse. Den indeholder de samme abonnementer som på siden Anbefalede handlinger, men her kan du vælge det omdannelsesskema, der er bedst egnet til et bestemt abonnement. Disse er de abonnementer, der er oprettet fra domæner der (a) hørte til en admin eller en forhandler og (b) havde en aktiv Domæneadministrator konto.',
    'subscriptions.help' => 'Få mere at vide om omdannelse.',

    'tabs.bunch' => 'Anbefalede handlinger',
    'tabs.customers' => 'Selektiv omdannelse af kunder',
    'tabs.subscriptions' => 'Selektiv omdannelse af abonnementer',
];