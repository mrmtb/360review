<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'email.subjSuccess' => 'Plesk blev korrekt opdateret',
    'email.subjFailure' => 'Plesk-opdatering mislykkedes',
    'email.bodySuccess' => "Bemærk:\n\nPlesk blev korrekt opdateret.\nDu kan se listen over ændringer på %%link%%.\n\nDenne meddelelse blev automatisk sendt af Plesk Installer.",
    'email.bodyFailure' => "Bemærk:\n\nOpdateringen af Plesk mislykkedes.\n\nDu kan downloade Plesk Installer-logge på følgende link: %%link%%.\nKontakt din hostingudbyder for supportassistance.\n\nDenne meddelelse blev automatisk sendt af Plesk Installer.",
];