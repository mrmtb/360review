<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'oversell-policy.title' => 'Ændring af oversalgspolitik',
    'oversell-policy.pageHint' => 'Her kan du ændre den nuværende oversalgspolitik.',
    'oversell-policy.oversellPolicyChanged' => 'Oversalgspolitikken blev korrekt opdateret.',
    'oversell-policy.oversellPolicyNotChanged' => 'Oversalgspolitikken kan ikke opdateres.',

    'subscription-overview.title' => 'Abonnementsoversigt',
    'subscription-overview.pageHint' => 'Dette er oversigten over dit abonnement. Den inkluderer information om mængden af anvendt vs. udbudte ressourcer, oversalgspolitik, privilegier og services der er indeholdt i abonnementet.',
    'subscription-overview.changeOversellPolicyLink' => '[rediger]',
    'subscription-overview.oversellEnabledHint' => 'Dit abonnement tillader oversalg af ressourcer, hvilket indebærer at du kan sælge flere ressourcer end den mængde, der oprindeligt blev reserveret i dit abonnement. I dette tilfælde styres du af det faktiske ressourceforbrug i stedet for af den oprindelige ressourcereservering',
    'subscription-overview.oversellDisableHint' => 'Dit abonnement forhindrer oversalg af ressourcer, hvilket indebærer, at du kun kan sælge det antal ressourcer, der oprindeligt blev reserveret i abonnementet, uanset hvor mange af dem der rent faktisk bruges.',
    'subscription-overview.tabResources' => 'Resurser',
    'subscription-overview.tabPermissions' => 'Rettigheder',
    'subscription-overview.resourcesSummaryHint' => 'Dette er en oversigt over forbruget af ressources der leveres med abonnementet.',
    'subscription-overview.showMoreResources' => 'Vis flere tilgængelige ressourcer',
    'subscription-overview.hideMoreResources' => 'Vis færre tilgængelige ressourcer',
    'subscription-overview.permissionsSummaryHint' => 'Dette er en liste over services og privilegier der er indeholdt i abonnementet.',
    'subscription-overview.hideMorePermissions' => 'Vis færre tilladelser',
    'subscription-overview.showMorePermissions' => 'Vis flere tilladelser',
];