<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Servertilstand',
    'index.pageHint' => 'Her kan du se detaljerede rapporter om serverens tilstand. Hvis du vil se, hvordan serverens sundhedsparametre er blevet ændret, skal du vælge parametrene, hvorefter Plesk viser de relevante diagrammer. Bemærk, at du kan ændre for hvilken periode rapporterne vises - fra de seneste 3 timer til 1 uge. Her kan du også ændre Tilstandsovervågningens konfiguration, der definerer hvornår røde og gule alarmer skal vises for hvert parameter, og hvilke harddisk-ressourcer der skal overvåges. For at gøre dette skal du downloade en konfigurationsfil vha. knappen herunder, redigere filen og uploade din version. Hvis serverhardwaren blev ændret, skal du videresende disse ændringer til Tilstandsovervågning for at få korrekte statistikker.',
    'index.waitMessage' => 'Indlæser…',
    'index.buttonUpload' => 'Upload konfigurationsfil',
    'index.buttonDownload' => 'Download konfigurationsfil',
    'index.buttonRestoreDefaults' => 'Vend tilbage til standardindstillingerne',
    'index.buttonReconfigure' => 'Detektér hardwareændringer',
    'index.buttonUploadHint' => 'Upload din Tilstandsovervågning-konfigurationsfil. Den nye konfiguration vil blive anvendt når upload er færdig.',
    'index.buttonDownloadHint' => 'Gem den nuværende Tilstandsovervågning-konfiguration på din computer.',
    'index.buttonRestoreDefaultsHint' => 'Gendan Tilstandsovervågningens standardindstillinger.',
    'index.buttonReconfigureHint' => 'Videresend ændringerne i hardwarekonfigurationen til Tilstandsovervågning.',
    'index.confirmRestoreDefaultsTitle' => 'Gendanner Tilstandsovervågningens standardindstillinger.',
    'index.confirmRestoreDefaultsDescription' => 'Er du sikker på, at du vil gendanne standardindstillingerne?',
    'index.confirmReconfigureTitle' => 'Detektering af hardwareændringer',
    'index.confirmReconfigureDescription' => 'Du er ved at opdatere hardwarekonfigurationen i Tilstandsovervågning. Dette er relevant hvis serverhardwaren er blevet ændret, og du ønsker at afspejle disse ændringer i Tilstandsovervågning-statistikker. Fortsætte?',
    'index.settingsWereRestoredToDefault' => 'Standardindstillingerne blev gendannet.',
    'index.healthMonitorWasReconfigured' => 'Tilstandsovervågning-information om hardwarekonfigurationen blev opdateret.',

    'parameters.loading' => 'Indlæser…',
    'parameters.selectPeriod' => 'Vælg periode.',
    'parameters.periodFromNowTo3h' => '3 timer',
    'parameters.periodFromNowTo6h' => '6 timer',
    'parameters.periodFromNowTo12h' => '12 timer',
    'parameters.periodFromNowTo1d' => '1 Dag',
    'parameters.periodFromNowTo3d' => '3 dage',
    'parameters.periodFromNowTo7d' => '1 uge',

    'thresholds-hint.waitMessage' => 'Indlæser…',

    'upload-config-file.title' => 'Upload konfigurationsfil',
    'upload-config-file.configurationUploadedSuccessfully' => 'Konfigurationen blev uploadet og anvendt.',
];