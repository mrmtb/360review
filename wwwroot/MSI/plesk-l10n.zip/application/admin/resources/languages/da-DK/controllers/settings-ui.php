<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'branding.title' => 'Plesk-branding',

    'disable-languages.disableLanguagesSuccess' => 'De markerede sprog er ikke længere tilgængelig for brugerne.',

    'edit-controls.updateSuccess' => 'Indstillingerne blev opdateret.',

    'edit-interface-view.title' => 'Grænsefladevisninger',
    'edit-interface-view.updateSuccess' => 'Indstillingerne blev opdateret.',

    'enable-languages.enableLanguagesSuccess' => 'De markerede sprog vil være til rådighed for brugerne.',

    'language-make-default.languageMakeDefaultSuccess' => 'Det valgte sprog blev indstillet som standard til Plesk.',

    'list-languages.title' => 'Sprog',
    'list-languages.mlsLimitExceeded' => "Din nuværende Plesk-licens tillader brug af %%allowedByLicense%% sprog. I øjeblikket har du %%availableToUsers%% sprog indstillet som til rådighed for brugerne. Dette antal overstiger det antal, der er givet i licensen. Vælg %%allowedByLicense%% sprog, du vil bruge, og gør resten utilgængelig for brugerne ved at klikke på deres ikoner i kolonnen 'S'.",
];