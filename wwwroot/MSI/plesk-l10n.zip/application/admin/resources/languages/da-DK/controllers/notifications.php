<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Adviseringer',

    'email-settings.title' => 'E-mail',

    'panel-settings.title' => 'Plesk UI',
    'panel-settings.notificationSettingsSaved' => 'Adviseringsindstillingerne blev gemt.',

    'panel-notifications-toggle.successfullyEnabled' => 'Adviseringen \'%%title%%\' blev aktiveret.',
    'panel-notifications-toggle.successfullyDisabled' => 'Adviseringen \'%%title%%\' blev deaktiveret.',

    'template-settings-list.hint' => 'Vælg hvilke adviseringer der skal vises ved at aktivere og deaktivere dem.',
    'template-settings-list.name' => 'Titel',
    'template-settings-list.context' => 'Kontekst',
    'template-settings-list.sendToAdmin' => 'Send til administrator',

    'template-settings-form.storagePeriod' => 'Gem adviseringer i',
    'template-settings-form.days' => 'dage',
];