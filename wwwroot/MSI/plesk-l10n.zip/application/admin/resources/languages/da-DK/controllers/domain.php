<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoDomainActivated' => 'Valgte domæner og aliasser blev aktiveret.',
    'activate.errorDomainNotActivated' => 'Nogle af de valgte domæner eller aliasser blev ikke aktiveret.',
    'activate.domainStillSuspended' => 'Kunne ikke aktivere domænet: %%reason%%',
    'activate.domainStatusOffByAdmin' => 'Domænet er suspenderet af administrator.',
    'activate.domainStatusOffWithParent' => 'Enten domæneejeren eller vedkommendes abonnement er suspenderet.',
    'activate.domainStatusOffExpired' => 'Det korresponderende abonnement er udløbet.',
    'activate.domainStatusOffBackupRestore' => 'Domænet er midlertidigt suspenderet pga. sikkerhedskopiering/gendannelse.',
    'activate.domainStatusOff' => 'Domænet er suspenderet.',
    'activate.aliasStillSuspended' => 'Kunne ikke aktivere aliasset: Måldomænet er suspenderet.',

    'add-domain-alias.noDomains' => 'Der kan ikke oprettes et alias: Der er ingen tilgængelige domæner.',

    'add-domain.noDomains' => 'Der kan ikke oprettes et addon-domæne: Der er ingen tilgængelige domæner.',

    'add-subdomain.noDomains' => 'Der kan ikke oprettes et subdomæne: Der er ingen tilgængelige domæner.',

    'disable.infoDomainDisabled' => 'De valgte domæner blev deaktiveret.',
    'disable.errorDomainNotDisabled' => 'Nogle af de valgte domæner blev ikke aktiveret.',

    'list.title' => 'Domæner',
    'list.customerLinkTitle' => 'skal du oprette en kundekonto',
    'list.subscriptionLinkTitle' => 'skal du oprette dit eget abonnement',

    'suspend.infoDomainSuspended' => 'De markerede domæner blev suspenderet.',
    'suspend.errorDomainNotSuspended' => 'Nogle af de valgte domæner blev ikke suspenderet.',
];