<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Systemopdateringer',

    'list.title' => 'Alle pakker',
    'list.hint' => 'Systempakker opdateres via systemværktøjerne (dpkg/apt eller yum). Pakker opdateres kun fra opbevaringsområder, de er installeret fra. Du kan forhindre opdatering af en pakke ved at vælge den på listen og klikke på Lås.',

    'lock.success' => 'Pakkerne blev låst.',

    'settings.title' => 'Indstillinger',
    'settings.settingsUpdated' => 'Indstillingerne blev ændret.',

    'unlock.success' => 'Pakkerne blev låst op.',

    'updates-list.title' => 'Tilgængelige opdateringer',
    'updates-list.hint' => 'Systempakker opdateres via systemværktøjerne (dpkg/apt eller yum). Pakker opdateres kun fra opbevaringsområder, de er installeret fra. Du kan forhindre opdatering af en pakke ved at vælge den på listen og klikke på Lås.',
];