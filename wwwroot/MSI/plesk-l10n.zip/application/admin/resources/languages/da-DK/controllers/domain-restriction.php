<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Tilføj et domænenavn',
    'add.domainAdded' => 'Domænenavnet %%domain%% blev føjet til liste af ikke-tilladte navne.',

    'disable.listDisabled' => 'Tjek af ikke-tilladte domænenavne blev deaktiveret.',

    'edit.title' => '%%name%%',
    'edit.domainUpdated' => 'Domænenavnet %%domain%% blev opdateret.',

    'enable.listEnabled' => 'Tjek af ikke-tilladte domænenavne blev aktiveret.',

    'list.title' => 'Ikke-tilladte domænenavne',
    'list.hint' => 'Her kan du administrere listen over ikke-tilladte domænenavne, der indeholder de mest populære domæner.  Hvis du aktiverer tjek af ikke-tilladte domænenavne (ved at klikke på Aktiver), vil brugerne ikke kunne oprette domæner med navnene på listen.  En sådan begrænsning er f.eks. nyttig til forhindring af e-mail opsnapning.  Hvis tjek er deaktiveret vil e-mails, der af dine kunder sendes til legitime virksomheder kunne modtages af kunder, der har oprettet domæner med samme navn som dem, der er ejet af de legitime virksomheder.',
    'list.warningLisDisabled' => 'Tjek af ikke-tilladte domænenavne er deaktiveret.',

    'remove.domainRemoved' => 'De valgte domænenavne blev fjernet.',
    'remove.domainNotRemoved' => 'Nogle af de valgte domænenavne blev ikke fjernet.',
    'remove.unableRemove' => 'Nogle af de angivne domænenavne blev ikke fjernet.',
];