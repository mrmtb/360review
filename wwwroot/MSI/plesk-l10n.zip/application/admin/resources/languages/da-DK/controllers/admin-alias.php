<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoAdminAliasActivated' => 'De valgte administratorkonti blev korrekt aktiverede.',
    'activate.infoAdminAliasNotActivated' => 'De valgte administratorkonti blev ikke aktiverede.',

    'create.title' => 'Tilføjelse af en administratorkonto',
    'create.infoNewAdminAliasCreated' => 'Den ekstra administratorkonto %%contact%% blev oprettet korrekt.',

    'deactivate.infoAdminAliasDeactivated' => 'De valgte administratorkonti blev korrekt suspenderede.',
    'deactivate.infoAdminAliasNotDeactivated' => 'De valgte administratorkonti blev ikke suspenderede.',

    'delete.infoAdminAliasDeleted' => 'De valgte administratorkonti blev korrekt fjernede.',
    'delete.infoAdminAliasNotDeleted' => 'De valgte administratorkonti blev ikke fjernede.',

    'edit.title' => "%%contact%%",
    'edit.infoNewAdminAliasUpdated' => 'Administratorkontoen blev korrekt opdateret.',

    'list.title' => 'Ekstra administratorkonti',
    'list.hint' => 'Her kan du oprette ekstra administratorkonti til dine teknisk support-medarbejdere, så de kan udføre forskellige administrative opgaver.',
];