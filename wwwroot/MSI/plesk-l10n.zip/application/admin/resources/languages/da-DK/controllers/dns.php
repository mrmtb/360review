<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'acl-records.title' => 'Overfør begrænsningsskabelon',

    'add-acl-record.title' => 'Tilføj IP-adresse',
    'add-acl-record.success' => 'De angivne IP-adresser blev tilføjet.',

    'delete-acl-record.success' => 'De valgte IP-adresser blev fjernet.',

    'index.title' => 'DNS-indstillinger',

    'records.title' => 'Zonepost-skabelon',

    'reset-settings.success' => 'Standardindstillingerne blev gendannet.',

    'settings.title' => 'Overordnede server-indstillinger',
    'settings.success' => 'Indstillingerne er blevet opdateret.',

    'soa-record.title' => 'Zoneindstillingsskabelon',

    'restore-default.title' => 'Gendan den standard DNS-zone skabelon.',
    'restore-default.text' => 'Bekræft at du ønsker at gendanne standardkonfigurationen af DNS-zone skabelonen.',

    'soa-sync.title' => 'Tilsidesæt SOA-indstillingerne for alle eksisterende domæner',
    'soa-sync.text' => 'Opdatere SOA-poster for alle hostede domæner ved at anvende de ændringer, der af foretaget i SOA-skabelon?',

    'sync.title' => 'Anvend DNS-skabelonændringer',
    'sync.type-option' => 'Vælg et af følgende',
    'sync.safe' => 'Anvend ændringerne på uændrede zoner. Hvis en zone er blevet tilpasset (nye poster er blevet tilføjet, eller eksisterende er blevet ændret), vil Plesk ikke anvende ændringerne fra skabelonen på sådanne zoner.',
    'sync.force' => 'Anvend ændringerne på alle zoner. Plesk vil anvende ændringerne fra skabelonen på alle DNS-zoner, inklusive de tilpassede. Bemærk, at brugermodificerede poster altid vil forblive intakte. Hvis en skabelon f.eks. indeholder en ny post, der allerede er blevet tilføjet af en kunde, vil Plesk bevare kundens post.',

    'external-dns.title' => 'Ekstern DNS',
    'external-dns.hint' => 'Her kan du konfigurere eksterne DNS-servere',
    'external-dns.success' => 'Gemt',
    'external-dns.configured' => 'Konfigureret',
    'external-dns.notConfigured' => 'Ikke konfigureret',
    'external-dns.useExtension' => 'Anvend denne udvidelse',

    'external-dns-edit.title' => 'Ekstern DNS',
];