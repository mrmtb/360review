<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.hint' => 'Beskrivelse af tilføjelse af ekstern servicenode.',
    'add.title' => 'Tilføj ekstern servicenode',
    'add.serviceNodeAdded' => 'Ekstern servicenode %%name%% er blevet tilføjet',

    'delete.infoServiceNodesDeleted' => 'De valgte servicenoder blev afbrudt.',
    'delete.infoServiceNodesNotDeleted' => 'Kunne ikke afbryde nogle af de valgte servicenoder.',
    'delete.serviceNodeIsInUse' => 'Servicenoden er i brug.',

    'edit.hint' => 'Beskrivelse af redigering af ekstern servicenode.',
    'edit.title' => 'Ekstern servicenode %%name%%',
    'edit.serviceNodeUpdated' => 'Egenskaberne for ekstern servicenode %%name%% er blevet opdateret',

    'list.hint' => 'Her kan du tilføje eksterne servicenoder',
    'list.title' => 'Servicenode',
];