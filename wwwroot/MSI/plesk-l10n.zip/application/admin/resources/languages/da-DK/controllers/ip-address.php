<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Tilføj IP-adresse',
    'add.ipAddressAdded' => 'IP-adressen %%address%% blev tilføjet.',

    'delete.infoIpAddressesDeleted' => 'De valgte IP-adresser blev fjernet.',

    'edit.title' => 'IP-adressen %%address%% på grænsefladen %%interface%%',
    'edit.ipAddressUpdated' => 'Ændringen af IP-adresse %%address%% indstillingerne er planlagt, og vil blive foretaget i baggrunden',
    'edit.ipAddressInterfaceNotAvailableWarning' => 'Netværksgrænsefladen %%interface%% findes ikke. Flyt denne IP-adresse til en anden netværksadapter eller fjern den fra listen.',

    'list.title' => 'IP-adresser',
];