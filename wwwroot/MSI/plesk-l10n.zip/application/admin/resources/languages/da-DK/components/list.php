<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'recordsTotal' => '%%total%% emner i alt',
    'pages' => 'Sider',
    'firstPage' => 'Første',
    'lastPage' => 'Sidste',
    'numberOfItemPerPage' => 'Emner pr. side',
    'hideSearch' => 'Skjul søgning',
    'showSearch' => 'Vis søgning',
    'buttonSearch' => 'Søg',
    'buttonResetSearch' => 'Nulstil søgning',
    'noEntriesFound' => 'Der blev ikke fundet nogen emner.',
    'itemsNotSelected' => 'Vælg emner først.',
    'messageBoxButtonYes' => 'Ja',
    'messageBoxButtonNo' => 'Nej',
    'messageBoxButtonOk' => 'OK',
    'allItems' => 'Alle',
];