<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Sessions-administration',

    'remove.sessionsDeleted' => 'De valgte sessioner blev fjernet.',

    'settings.title' => 'Indstillinger for session',
    'settings.settingsUpdated' => 'Indstillingerne blev ændret.',
];