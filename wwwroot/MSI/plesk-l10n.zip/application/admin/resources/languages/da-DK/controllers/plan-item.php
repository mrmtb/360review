<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Tilføj en service',
    'create.hint' => 'Her kan du tilføje et link til en ekstern service.',

    'edit.title' => 'Egenskaber for servicen %%name%%',
    'edit.hint' => 'Her angiver du servicens egenskaber.',
    'edit.errorItemNotEditable' => 'Egenskaberne for denne service er ikke tilgængelige.',

    'list.title' => 'Ekstra services',
    'list.tabTitle' => 'Ekstra services',
    'list.hint' => "Dette er en liste over de ekstra services, du kan provisionere med hostingplaner. Den viser de manuelt definerede services og services der leveres af de programmer, der installerede som Plesk-udvidelser. Manuel tilføjelse af en service er nyttig, når du ønsker at dirigere dine kunder til en ekstern online service: Dette føjer de korresponderende knapper til kundens Kundepanel. Som standard er alle ekstra services angivet i hostingplan-egenskaberne under fanen Yderligere services. Dette gør det muligt for dig og dine forhandlere at inkludere disse services i hostingplaner. Hvis du ikke ønsker at dine forhandlere skal bruge en service og kunne levere den til sine kunder, skal du bruge linket Gør utilgængelig.",
    'list.planItemsNowAvailable' => 'De valgte ekstra services er til rådighed for forhandlere.',
    'list.planItemsNowNotAvailable' => 'De valgte ekstra indstillinger ikke længere til rådighed for forhandlerne.',
    'list.cantChangePlanItemsProperties' => 'Der opstod en fejl under forsøget på at ændre servicens rådighedsindstillinger.',
    'list.infoNewPlanItemCreated' => 'Indstillingen %%name%% svarende til servicen blev føjet til plan-egenskaberne.',
    'list.infoPlanItemUpdated' => 'Planindstillingen %%name%% blev opdateret.',
    'list.planItemsDeleted' => 'De valgte planindstillinger blev slettet.',
    'list.planItemsNotDeleted' => 'Nogle af de valgte planindstillinger blev ikke slettet.',
];