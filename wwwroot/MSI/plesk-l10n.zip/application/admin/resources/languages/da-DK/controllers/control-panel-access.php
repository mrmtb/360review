<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-network.title' => 'Tilføj et netværk',
    'add-network.added' => 'Netværket %%address%% blev tilføjet.',

    'delete-network.noNetworksSpecified' => 'Vælg et eller flere netværk på IP-adgangsbegrænsningslisten.',
    'delete-network.networksDeleted' => 'De valgte netværk blev slettet.',
    'delete-network.networksNotDeleted' => 'Nogle af de valgte kunder blev ikke slettet. Detaljer: %%error%%.',

    'edit-network.title' => 'Netværksredigering',
    'edit-network.updated' => 'Netværket %%address%% blev opdateret.',

    'list.title' => 'Administration af begrænsninger i IP-adgang',
    'list.currentIpAddressDenied' => 'Adgangsbegrænsningspolitikken og listen over netværk er i øjeblikket konfigureret på en måde, så du ikke vil kunne logge på med administratorrettigheder fra din IP-adresse \'%%remoteAddress%%\'.',
    'list.allowHint' => 'Adgang til Plesk med administratorrettigheder er tilladt, bortset til netværkene på listen.',
    'list.denyHint' => 'Adgang til Plesk med administratorrettigheder er nægtet fra alle netværk, der ikke er angivet her.',

    'settings.title' => 'Indstillinger for IP-adgangsbegrænsning',
    'settings.settingsSaved' => 'IP-adgangsbegrænsningspolitik blev gemt.',
];