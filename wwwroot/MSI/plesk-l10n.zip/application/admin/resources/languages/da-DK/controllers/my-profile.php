<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-password.title' => "Skift administrators adgangskode",
    'change-password.passwordChanged' => 'Administratorens adgangskod blev ændret',

    'index.personalInfoTitle' => "Rediger administratorprofilen.",
    'index.successMessage' => "Din profil blev opdateret.",
    'index.aliasInfoTitle' => 'Ekstra administratorkonto-information',
    'index.aliasInfoUpdated' => 'Personlig information for ekstra administratorkonto blev opdateret.',
];