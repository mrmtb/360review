<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'gallery.titleScreenshot' => 'Skærmdump af %%packageName%%',
    'gallery.prevImage' => '< Foregående',
    'gallery.nextImage' => 'Næste >',
    'gallery.closeGallery' => 'Luk',
    'gallery.navigationOf' => 'af',
    'gallery.typeScreenshot' => 'skærmbilleder',
    'gallery.title' => 'Skærmbilleder',
];