<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Server-brede e-mail indstillinger',
    'index.preferencesTab' => 'Indstillinger',
    'index.spamFilteringTab' => 'Spamfiltrering',
    'index.antivirusTab' => 'Antivirus',
    'index.blockedDomainsTab' => 'Sortlist',
    'index.whiteListTab' => 'Hvidliste',
    'index.queueTab' => 'E-mail kø',
    'index.statisticsTab' => 'Statistik',
    'index.smarthostTab' => 'Smarthost',

    'mail-lists.title' => 'Konfiguration af mailliste-administrator',
    'mail-lists.configured' => 'Mailman mailingliste-administrator blev konfigureret. Knappen Opsæt mailinglisteserver bliver ikke længere vist på skærmen Funktioner og indstillinger.', // PFU
    'mail-lists.noLocalhostInServerWhiteList' => 'For at kunne bruge mailing´lister skal du have localhost (127.0.0.0/8, ::1/128) i mailserverens hvidliste. Hvis du imidlertid vil bruge udgående post-kontrol, skal du ikke have localhost i hvidlisten. Som et kompromis kan du, hvis du har aktiveret udgående mail kontrol, bruge e-mail videresendelse på mailboksen i stedet for mailinglister.',
    'mail-lists.noLocalhostInServerWhiteListIpv4' => 'For at kunne bruge mailing´lister skal du have localhost i mailserverens hvidliste. Hvis du imidlertid vil bruge udgående post-kontrol, skal du ikke have localhost i hvidlisten. Som et kompromis kan du, hvis du har aktiveret udgående mail kontrol, bruge e-mail videresendelse på mailboksen i stedet for mailinglister. Bemærk, at der ikke er nogen IPv4 (127.0.0.0/8) localhost adresser på hvidlisten lige n, så udgående postkontrol vil fungere for IPv4-adresser.',
    'mail-lists.noLocalhostInServerWhiteListIpv6' => 'For at kunne bruge mailing´lister skal du have localhost i mailserverens hvidliste. Hvis du imidlertid vil bruge udgående post-kontrol, skal du ikke have localhost i hvidlisten. Som et kompromis kan du, hvis du har aktiveret udgående mail kontrol, bruge e-mail videresendelse på mailboksen i stedet for mailinglister. Bemærk, at der ikke er nogen IPv6 localhost adresser (::1/128) på hvidlisten lige n, så udgående postkontrol vil fungere for IPv6-adresser.',
    'mail-lists.mailingListSoftwareNotInstalled' => 'Mailingliste-softwaren er ikke installeret.',
    'mail-lists.mailingListSoftwareAlreadyConfigured' => 'Mailingliste-softwaren er allerede konfigureret.',

    'customize-mailbox-quota-warning.title' => 'Mailboxkvote-advarsel tilpasning',
    'customize-mailbox-quota-warning.successMessage' => 'mailboxkvote-advarselsbesked blev ændret.',

    'customize-mailbox-quota-warning-form.subject' => 'Emne',
    'customize-mailbox-quota-warning-form.message' => 'Besked',
    'customize-mailbox-quota-warning-form.tooLongMessage' => "Meddelelse for lang Maksimal længde er %max% tegn",
];