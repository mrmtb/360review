<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'isEmpty' => 'Dette obligatoriske felt er tomt. Du skal angive en værdi i dette felt.',
    'stringLengthTooShort' => "'%value%' er mindre end '%min%' tegn langt.",
    'stringLengthTooLong' => "'%value%' er større end '%max%' tegn langt.",
    'regexNotMatch' => "'%value%' passer ikke til mønsteret '%pattern%'.",
    'notAlnum' => "'%value%' indeholder ikke-alfanumeriske tegn. Sørg for kun at bruge alfanumeriske tegn.",
    'stringEmpty' => "'%value%' er tom.",
    'stringsNotEqual' => 'Strengene er ikke identiske!',
    'passwordsNotEqual' => 'De indtastede adgangskoder er ikke ens.',
    'passwordLengthTooShort' => "adgangskoden er kortere end %min% tegn.",
    'passwordLengthTooLong' => "adgangskoden er længere end %max% tegn.",
    'passwordRegexNotMatch' => "adgangskoden passer ikke til mønsteret '%pattern%'.",
    'invalidUrl' => 'Den angivne adresse er ikke gyldig. Du skal angive en gyldig adresse, f.eks. http://eksempel.com.',
    'specialCharactersInIpAddress' => 'Den angivne IP-adresse er ugyldig.',
    'massEmailContactsNotSelected' => 'Vælg mindst én kontakt fra listen.',
    'ipAddressIsTooLong' => 'IP-adresser må ikke være længere end %max% tegn.',
    'ipAddressDescriptionTooLong' => 'Beskrivelsen må ikke være længere end %max% tegn.',

    'fail2ban.invalidIpOrCidr' => 'IP-adressen skal være en gyldig IP-adresse eller en CIDR-maske.',
];