<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Registrér ekstra webmail',
    'create.infoNewWebmailRegistered' => 'Ny webmail service blev registreret.',

    'edit.unknownWebmail' => 'Ukendt webmail',
    'edit.infoWebmailUpdated' => 'Indstillingerne for webmail-service %%name%% blev opdateret.',

    'index.title' => 'Webmail-services',
    'index.hint' => 'Du kan benytte enhver webmail-service ud over de webmail-løsninger, du installerer med Plesk Installer eller Updater. Registrér en ønsket webmail-installation i Plesk vha. nedenstående knap, og den vil vises som en webmail-mulighed til rådighed i hostingplaner og abonnementer. Hvis du har brug for midlertidigt at skjule en webmail-service, kan du deaktivere den vha, knappen herunder.',
    'index.webmailDeleted' => 'Registrering af de valgte webmail-services blev fjernet.',
    'index.webmailNotDeleted' => 'Registreringen af nogle webmail-services blev ikke fjernet.',
    'index.webmailEnabled' => 'Valgte webmail-services blev aktiveret og er nu til rådighed.',
    'index.webmailNotEnabled' => 'Nogle af de valgte webmail-muligheder blev ikke aktiveret.',
    'index.webmailDisabled' => 'Valgte webmail-muligheder blev deaktiveret og dermed ikke mere til rådighed.',
    'index.webmailNotDisabled' => 'Nogle af de valgte webmail-muligheder blev ikke deaktiveret.',
];