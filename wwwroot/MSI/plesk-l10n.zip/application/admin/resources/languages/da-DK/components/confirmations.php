<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-customer-owner.title' => 'Flytter kunder til en anden ejer',
    'change-customer-owner.description' => 'Kundekontiene vil blive flyttet til en anden ejer.  Du kan ændre serviceplaner for kundeabonnementer.  Hvis du vil bevare de ressourcer der er til rådighed for en kunde skal du lade Brugerdefineret plan være valgt',
    'change-customer-owner.ownerHint' => 'Kunderne vil blive flyttet til den valgte ejer:',
    'change-customer-owner.ipAddressHint' => 'En dedikeret IP-adresse kan ikke bevares.',
    'change-customer-owner.loading' => 'Vent venligst...',
    'change-customer-owner.ipAddressNotSelected' => 'Vælg mindst én IP-adresse for hvert abonnement.',
    'change-customer-owner.ownerNotSelected' => 'Vælg en ejer.',

    'customer.title' => 'Konverterer kunder til forhandlere',
    'customer.description' => 'Kundekontiene vil blive konverteret til forhandlerkonti.  Du kan vælge forhandlerplaner for de konverterede konti. For at bevare de ressourcer der var til rådighed for en kunde skal du vælge planen Brugerdefineret: Forhandleren vil have summen af ressourcetildelinger, tilladelser og applikationer for alle abonnementer.',
    'customer.loading' => 'Konverterer...',

    'reseller.title' => 'Konverterer forhandlere til kunder',
    'reseller.description' => 'Forhandlerne vil blive konverteret til kunder.',
    'reseller.descriptionExtended' => 'Vælg nye serviceplaner til forhandlere, der har deres egne abonnementer.  For at bevare de ressourcer der er til rådighed for en forhandler skal du vælge serviceplanen Brugerdefineret.  Hvis du vil flytte forhandlerens abonnementer til en af de eksisterende serviceplaner skal du vælge en eksisterende serviceplan.',
    'reseller.loading' => 'Konverterer...',
];