<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'operation.startActionSuccess' => 'Tjenesten blev startet',
    'operation.stopActionSuccess' => 'Tjenesten blev stoppet',
    'operation.restartActionSuccess' => 'Tjenesten blev genstartet',
    'operation.changeStartupActionSuccess' => 'Opstarttype for service ændret',

    'list.title' => 'Tjenester',

    'operation.startServiceMessage' => 'Det varer et øjeblik at starte servicen.',
    'operation.stopServiceMessage' => 'Det varer et øjeblik at stoppe servicen.',
    'operation.restartServiceMessage' => 'Det varer et øjeblik at genstarte servicen.',
    'operation.unableFetchFormData' => 'Kan ikke hente fra data: %%error%%',
    'operation.startActionError' => 'Tjeneste kan ikke startes: %%error%%',
    'operation.stopActionError' => 'Tjeneste kan ikke stoppes: %%error%%',
    'operation.restartActionError' => 'Tjeneste kan ikke genstartes: %%error%%',
    'operation.changeStartupActionError' => 'Kunne ikke ændre opstartstypen for tjenesten\': %%error%%',
];