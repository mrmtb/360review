<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Opretter en forhandlerplan',
    'create.hint' => 'Her kan du oprette en forhandlerplan i henhold til dine tilbud.',

    'edit.title' => '%%name%%',
    'edit.hint' => 'Her kan du ændre forhandlerplanen i henhold til dine tilbud. Bemærk, at ændring af planen automatisk opdaterer alle de abonnementer der er knyttet til den, bortset fra de brugerdefinerede abonnementer, der er låst mod synkronisering.',

    'list.title' => 'Forhandlerplaner',
    'list.hint' => 'Her kan du administrere dine forhandlerplaner, hvilket tillader oprettelse af forhandlerabonnementer. I modsætning til dine almindelige hostingservice-kunder, kan en forhandler kun være abonnent på én plan og vedkommende kan ikke have tilføjelser.',
    'list.tabTitle' => 'Forhandlerplaner',
    'list.infoNewPlanCreated' => 'Forhandlerplanen %%name%% blev oprettet',
    'list.infoPlanUpdated' => 'Forhandlerplanen %%name%% blev opdateret',
    'list.infoPlanUpdatedSynced' => 'Serviceplanen %%name%% blev opdateret. Alle tilknyttede forhandlerabonnementer blev synkroniseret, bortset fra de brugertilpasse abonnementer, der er låst mod synkronisering.',
    'list.infoPlanDeleted' => 'Valgte forhandlerplaner blev fjernet.',
    'list.infoPlanNotDeleted' => 'Nogle af de valgte forhandlerplaner blev ikke fjernet.',
    'list.infoPlanDuplicated' => 'De valgte serviceplaner blev duplikeret.',
    'list.infoPlanNotDuplicated' => 'Nogle af de valgte serviceplaner blev ikke duplikeret.',
];