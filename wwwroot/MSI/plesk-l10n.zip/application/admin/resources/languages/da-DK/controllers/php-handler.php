<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'PHP-indstillinger',
    'list.hint' => 'Vælg de PHP-handlere, der skal være tilgængelige. Du kan installere yderligere handlere vha %%link%%.',
    'list.hintLink' => 'Plesk Installer',
    'list.brokenDomainsError' => 'Følgende PHP-version(er) er ikke installeret: %%phpVersions%%. PHP-scripting til %%domainCount%%-domæne(r) er ikke tilgængelig. Installer de manglende PHP-versioner, eller følg instruktionerne i <a href=https://support.plesk.com/hc/en-us/articles/12377342328343>KB article</a> for at reparere PHP-scripting.',
    'list.brokenHandlersError' => 'Følgende PHP-version(er) er ikke installeret: %%phpVersions%%. Installer dem eller kør <code>plesk repair web -php-handlers</code> for at vælge en anden PHP-version.',

    'modules.canNotManageModules' => 'Adgangen til PHP handler indstillingsadministration er begrænset, da stien til PHP CLI-filen ikke er angivet.',

    'php-ini.title' => 'Indstillinger for <b>%%name%%</b>',
    'php-ini.tabTitle' => 'php.ini',
    'php-ini.success' => 'Indstillingerne blev opdateret.',

    'toggle.errorEnableBrokenHandler' => 'Handleren er beskadiget og kan ikke aktiveres.',
    'toggle.errorDisableBrokenHandler' => 'Handleren er beskadiget og kan ikke deaktiveres.',
    'toggle.infoHandlerEnabled' => 'Handleren blev aktiveret.',
    'toggle.infoHandlerDisabled' => 'Handleren blev deaktiveret.',
];