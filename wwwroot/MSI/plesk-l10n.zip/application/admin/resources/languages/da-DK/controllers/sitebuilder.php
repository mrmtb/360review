<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'settings.title' => 'Indstillinger for Prøv-og-køb tilstand',
    'settings.sitebuilderSettingsUpdated' => 'Indstillingerne blev opdateret.',
];