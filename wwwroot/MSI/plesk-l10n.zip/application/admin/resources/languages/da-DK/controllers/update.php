<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Plesk Installer',
    'index.autoinstallerRedirectError' => 'Kunne ikke starte Plesk Installer. Der er opstået følgende fejl: %%message%%',

    'product.title' => 'Plesk Installer',
    'product.autoinstallerRedirectError' => 'Kunne ikke starte Plesk Installer. Der er opstået følgende fejl: %%message%%',

    'settings.title' => 'Opdatereringsindstillinger',
    'settings.settingsUpdated' => 'Opdateringsindstillinger blev ændret.',
];