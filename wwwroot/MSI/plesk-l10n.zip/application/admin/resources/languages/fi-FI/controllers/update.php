<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Plesk-asennusohjelma',
    'index.autoinstallerRedirectError' => 'Plesk-asennusohjelmaa ei voi käynnistää. Seuraava virhe tapahtui: %%message%%',

    'product.title' => 'Plesk-asennusohjelma',
    'product.autoinstallerRedirectError' => 'Plesk-asennusohjelmaa ei voi käynnistää. Seuraava virhe tapahtui: %%message%%',

    'settings.title' => 'Asetusten päivittäminen',
    'settings.settingsUpdated' => 'Päivitysasetukset muutettiin.',
];