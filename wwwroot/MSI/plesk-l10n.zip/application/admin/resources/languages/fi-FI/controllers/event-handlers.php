<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Tapahtumakäsittelijää lisätään',
    'add.added' => 'Tapahtumakäsittelijä on lisätty.',

    'delete.noHandlersSpecified' => 'Valitse poistettavat tapahtumakäsittelijät.',
    'delete.handlersDeleted' => 'Valitut tapahtumakäsittelijät poistettiin.',
    'delete.handlersNotDeleted' => 'Joitakin valittuja tapahtumakäsittelijöitä ei poistettu. Tiedot: %%error%%.',

    'edit.title' => 'Tapahtumakäsittelijän ominaisuuksia päivitetään',
    'edit.updated' => 'Tapahtumakäsittelijä päivitettiin.',

    'list.title' => 'Tapahtumanhallinta',
];