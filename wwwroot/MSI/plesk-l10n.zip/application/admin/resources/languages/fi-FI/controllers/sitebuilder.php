<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'settings.title' => 'Kokeile & osta -tilan asetukset',
    'settings.sitebuilderSettingsUpdated' => 'Asetukset päivitettiin.',
];