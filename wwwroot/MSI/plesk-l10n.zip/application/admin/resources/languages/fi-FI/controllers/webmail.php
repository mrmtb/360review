<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Rekisteröi ylimääräinen verkkosähköposti',
    'create.infoNewWebmailRegistered' => 'Uusi verkkosähköpostipalvelu rekisteröitiin.',

    'edit.unknownWebmail' => 'Tuntematon verkkosähköposti',
    'edit.infoWebmailUpdated' => 'Verkkosähköpostipalvelun %%name%% asetukset päivitettiin.',

    'index.title' => 'Verkkosähköpostipalvelut',
    'index.hint' => 'Voit käyttää mitä tahansa verkkosähköpostipalvelua Plesk Installerilla, ts. päivitystyökalulla, asennettujen verkkosähköpostiratkaisujen lisäksi. Rekisteröi halutun WWW-sähköpostipalvelun asennus ohjauspaneelissa käyttämällä alla olevaa painiketta, jolloin asennus tulee näkyviin käytettävissä olevana WWW-sähköpostipalveluna isännöintipalveluissa ja tilauksissa. Jos verkkosähköpostipalvelun väliaikainen piilottaminen on tarpeen, poista se käytöstä alla olevalla painikkeella.',
    'index.webmailDeleted' => 'Valittujen verkkosähköpalvelujen rekisteröinti poistettiin.',
    'index.webmailNotDeleted' => 'Joidenkin verkkosähköpalvelujen rekisteröintiä ei poistettu.',
    'index.webmailEnabled' => 'Valitut verkkosähköpalvelut otettiin käyttöön ja ne ovat nyt saatavilla.',
    'index.webmailNotEnabled' => 'Joitakin valituista verkkosähköpalvelujen valinnoista ei otettu käyttöön.',
    'index.webmailDisabled' => 'Valitut verkkosähköpalvelujen valinnat poistettiin käytöstä ja ne eivät ole enää saatavilla.',
    'index.webmailNotDisabled' => 'Joitakin valituista verkkosähköpalvelujen valinnoista ei poistettu käytöstä.',
];