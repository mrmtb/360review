<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Palvelimenlaajuiset postiasetukset',
    'index.preferencesTab' => 'Asetukset',
    'index.spamFilteringTab' => 'Roskapostisuodatus',
    'index.antivirusTab' => 'Virustentorjunta',
    'index.blockedDomainsTab' => 'Musta lista',
    'index.whiteListTab' => 'Valkoinen lista',
    'index.queueTab' => 'Sähköpostijono',
    'index.statisticsTab' => 'Tilastot',
    'index.smarthostTab' => 'Smarthost',

    'mail-lists.title' => 'Postitusluettelon hallinnan määritys',
    'mail-lists.configured' => 'Postituslistan Mailman-hallinta määritettiin. Aseta postituslistojen palvelin -painike ei ole enää näkyvissä Työkalut & Asetukset -näytössä.', // PFU
    'mail-lists.noLocalhostInServerWhiteList' => 'Voit käyttää postituslistoja, kun paikallinen isäntä (127.0.0.0/8, ::1/128) on sähköpostipalvelimen valkoisella listalla. Voit käyttää lähtevän postin valvontaa, kun paikallinen isäntä on valkoisessa luettelossa. Jos olet aktivoinut lähtevän postin valvonnan, kompromissina voit käyttää postilaatikon postin edelleenlähetystä postituslistojen sijaan.',
    'mail-lists.noLocalhostInServerWhiteListIpv4' => 'Voit käyttää postituslistoja, kun paikallinen isäntä on sähköpostipalvelimen valkoisella listalla. Voit käyttää lähtevän postin valvontaa, kun paikallinen isäntä on valkoisessa luettelossa. Jos olet aktivoinut lähtevän postin valvonnan, kompromissina voit käyttää postilaatikon postin edelleenlähetystä postituslistojen sijaan. Huomaa, että sallittujen luettelossa ei ole tällä hetkellä paikallisen isännän IPv4-osoitteita (127.0.0.0/8), joten lähtevän postin valvonta toimii IPv4-osoitteille.',
    'mail-lists.noLocalhostInServerWhiteListIpv6' => 'Voit käyttää postituslistoja, kun paikallinen isäntä on sähköpostipalvelimen valkoisella listalla. Voit käyttää lähtevän postin valvontaa, kun paikallinen isäntä on valkoisessa luettelossa. Jos olet aktivoinut lähtevän postin valvonnan, kompromissina voit käyttää postilaatikon postin edelleenlähetystä postituslistojen sijaan. Huomaa, että sallittujen luettelossa ei ole tällä hetkellä paikallisen isännän IPv6-osoitteita (::1/128), joten lähtevän postin valvonta toimii IPv6-osoitteille.',
    'mail-lists.mailingListSoftwareNotInstalled' => 'Postitusluettelo-ohjelmisto ei ole asennettu.',
    'mail-lists.mailingListSoftwareAlreadyConfigured' => 'Postituslistaohjelmisto on jo määritetty.',

    'customize-mailbox-quota-warning.title' => 'Postilaatikon kiintiön varoituksen mukautus',
    'customize-mailbox-quota-warning.successMessage' => 'Postilaatikon kiintiön varoitusviestiä on muutettu.',

    'customize-mailbox-quota-warning-form.subject' => 'Aihe',
    'customize-mailbox-quota-warning-form.message' => 'Viesti',
    'customize-mailbox-quota-warning-form.tooLongMessage' => "Liian pitkä viesti. Maksimipituus on %max% merkkiä",
];