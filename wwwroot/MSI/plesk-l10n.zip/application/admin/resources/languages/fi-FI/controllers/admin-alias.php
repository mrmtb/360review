<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoAdminAliasActivated' => 'Valitut järjestelmänvalvojan tilit aktivoitiin onnistuneesti.',
    'activate.infoAdminAliasNotActivated' => 'Joitakin valituista järjestelmänvalvojan tileistä ei aktivoitu.',

    'create.title' => 'Lisätään järjestelmänvalvojatili',
    'create.infoNewAdminAliasCreated' => 'Ylimääräinen järjestelmänvalvojan tili %%contact%% luotiin onnistuneesti.',

    'deactivate.infoAdminAliasDeactivated' => 'Valitut järjestelmänvalvojan tilit keskeytettiin onnistuneesti.',
    'deactivate.infoAdminAliasNotDeactivated' => 'Joitakin valituista järjestelmänvalvojan tileistä ei keskeytetty.',

    'delete.infoAdminAliasDeleted' => 'Valitut järjestelmänvalvojan tilit poistettiin onnistuneesti.',
    'delete.infoAdminAliasNotDeleted' => 'Joitakin valituista järjestelmänvalvojan tileistä ei poistettu.',

    'edit.title' => "%%contact%%",
    'edit.infoNewAdminAliasUpdated' => 'Järjestelmänvalvojatili päivitettiin.',

    'list.title' => 'Muut järjestelmänvalvojatilit',
    'list.hint' => 'Tässä voit luoda ylimääräisiä järjestelmänvalvojan tilejä teknisen tuen teknikoillesi, jolloin he voivat suorittaa erilaisia hallinnollisia tehtäviä.',
];