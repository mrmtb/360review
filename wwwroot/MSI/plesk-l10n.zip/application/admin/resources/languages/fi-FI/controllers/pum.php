<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Järjestelmäpäivitykset',

    'list.title' => 'Kaikki paketit',
    'list.hint' => 'Järjestelmäpaketit päivitetään järjestelmätyökaluilla (dpkg/apt tai yum). Paketit päivitetään ainoastaan säilöistä, joista ne asennettiin. Voit estää paketin päivittämisen valitsemalla sen luettelosta ja napsauttamalla Lukitse.',

    'lock.success' => 'Paketit päivitettiin onnistuneesti.',

    'settings.title' => 'Asetukset',
    'settings.settingsUpdated' => 'Asetuksia muutettiin onnistuneesti.',

    'unlock.success' => 'Pakettien lukitus avattiin onnistuneesti.',

    'updates-list.title' => 'Saatavissa olevat päivitykset',
    'updates-list.hint' => 'Järjestelmäpaketit päivitetään järjestelmätyökaluilla (dpkg/apt tai yum). Paketit päivitetään ainoastaan säilöistä, joista ne asennettiin. Voit estää paketin päivittämisen valitsemalla sen luettelosta ja napsauttamalla Lukitse.',
];