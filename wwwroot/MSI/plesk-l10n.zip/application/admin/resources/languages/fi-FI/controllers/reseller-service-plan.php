<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Jälleenmyyjän suunnitelman luominen',
    'create.hint' => 'Tässä voit luoda tarjoamaa vastaavan jälleenmyyjän suunnitelman.',

    'edit.title' => '%%name%%',
    'edit.hint' => 'Tässä voit muuttaa tarjoamaa vastaavaa jälleenmyyjän suunnitelmaa. Huomaa, että suunnitelman muuttaminen päivittää automaattisesti kaikki siihen liittyvät tilaukset, lukuun ottamatta mukautettuja tilauksia, jotka on lukittu synkronoinnilta.',

    'list.title' => 'Jälleenmyyjän suunnitelmat',
    'list.hint' => 'Tässä voit hallita jälleenmyyjän suunnitelmiasi, jotka sallivat jälleenmyyjien tilauksien luomisen. Toisin kuin normaalit isännöintipalvelujen asiakkaat, jälleenmyyjä voi tilata vain yhden suunnitelman, eikä hänellä voi olla lisäosia.',
    'list.tabTitle' => 'Jälleenmyyjän suunnitelmat',
    'list.infoNewPlanCreated' => 'Jälleenmyyjän suunnitelma %%name%% luotiin.',
    'list.infoPlanUpdated' => 'Jälleenmyyjän suunnitelma %%name%% päivitettiin.',
    'list.infoPlanUpdatedSynced' => 'Palvelusuunnitelma %%name%% päivitettiin.  Kaikki kytketyt jälleenmyyjän tilaukset synkronoitiin onnistuneesti, mukautettuja ja synkronointiin lukittuja tilauksia lukuun ottamatta.',
    'list.infoPlanDeleted' => 'Valitut jälleenmyyjän suunnitelmat poistettiin.',
    'list.infoPlanNotDeleted' => 'Joitakin valituista jälleenmyyjän suunnitelmista ei poistettu.',
    'list.infoPlanDuplicated' => 'Valitut palvelusuunnitelmat kopioitiin.',
    'list.infoPlanNotDuplicated' => 'Joitakin valituista palvelusuunnitelmista ei kopioitu.',
];