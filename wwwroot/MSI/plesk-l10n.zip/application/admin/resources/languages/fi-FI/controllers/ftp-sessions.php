<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-sessions.noSessionsSpecified' => 'Valitse yksi tai useampi FTP-istunto luettelosta.',
    'delete-sessions.sessionsDeleted' => 'Valitut istunnot poistettiin.',
    'delete-sessions.sessionsNotDeleted' => 'Joitakin valituista istunnoista ei poistettu. Tiedot: %%error%%.',

    'list.title' => 'FTP-istunnot',
];