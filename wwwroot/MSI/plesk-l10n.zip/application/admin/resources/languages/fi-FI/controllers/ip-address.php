<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Lisää IP-osoite',
    'add.ipAddressAdded' => 'IP-osoite %%address%% lisättiin.',

    'delete.infoIpAddressesDeleted' => 'Valitut IP-osoitteet poistettiin.',

    'edit.title' => 'IP-osoite %%address%% liittymässä %%interface%%',
    'edit.ipAddressUpdated' => 'IP-osoitteen %%address%% asetusten muuttaminen on aikataulutettu, ja se suoritetaan taustalla',
    'edit.ipAddressInterfaceNotAvailableWarning' => 'Verkkosovitinta %%interface%% ei ole olemassa. Siirrä tämä IP-osoite toiseen verkkosovittimeen tai poista se luettelosta.',

    'list.title' => 'IP-osoitteet',
];