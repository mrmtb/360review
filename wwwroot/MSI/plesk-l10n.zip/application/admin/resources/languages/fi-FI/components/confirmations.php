<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-customer-owner.title' => 'Asiakkaiden siirtäminen toiselle omistajalle',
    'change-customer-owner.description' => 'Asiakkaan tilit siirretään toiselle omistajalle. Voit muuttaa asiakastilauksien palvelusuunnitelmia. Valitse mukautettu suunnitelma asiakkaan käytettävissä olevien resurssien säilyttämiseksi.',
    'change-customer-owner.ownerHint' => 'Asiakkaat siirretään valitulle omistajalle:',
    'change-customer-owner.ipAddressHint' => 'Erityisiä IP-osoitteita ei voida varata.',
    'change-customer-owner.loading' => 'Odota...',
    'change-customer-owner.ipAddressNotSelected' => 'Valitse vähintään yksi IP-osoite kuhunkin tilaukseen.',
    'change-customer-owner.ownerNotSelected' => 'Valitse omistaja.',

    'customer.title' => 'Asiakkaiden muuttaminen jälleenmyyjiksi',
    'customer.description' => 'Asiakastilit muutetaan jälleenmyyjän tileiksi. Voit valita jälleenmyyjän suunnitelmia muutettuja tilejä varten. Valitse mukautettu suunnitelma asiakkaan käytettävissä olevien resurssien säilyttämiseksi: jälleenmyyjällä tulee olemaan kaikkien tilauksien resurssiosuuksien, lupien ja sovelluksien kokonaismäärä.',
    'customer.loading' => 'Muutetaan...',

    'reseller.title' => 'Jälleenmyyjien muuttaminen asiakkaiksi',
    'reseller.description' => 'Jälleenmyyjät muutetaan asiakkaiksi.',
    'reseller.descriptionExtended' => 'Valitse uudet palvelusuunnitelmat jälleenmyyjille, joilla on omat tilaukset. Valitse mukautettu palvelusuunnitelma jälleenmyyjän käytettävissä olevien resurssien säilyttämiseksi. Siirrä jälleenmyyjän tilaukset johonkin olemassa olevaan palvelusuunnitelmaan valitsemalla olemassa oleva palvelusuunnitelma.',
    'reseller.loading' => 'Muutetaan...',
];