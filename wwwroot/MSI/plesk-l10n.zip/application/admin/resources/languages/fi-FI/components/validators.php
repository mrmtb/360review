<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'isEmpty' => 'Tämä pakollinen kenttä on tyhjä. Tähän kenttään on annettava arvo.',
    'stringLengthTooShort' => "'%value%' sisältää alle %min% merkkiä.",
    'stringLengthTooLong' => "'%value%' sisältää yli %max% merkkiä.",
    'regexNotMatch' => "'%value%' ei täsmää mallia '%pattern%'.",
    'notAlnum' => "'%value%' sisältää merkkejä, jotka eivät ole aakkosnumeerisia. Varmista, että käytät vain aakkosnumeerisia merkkejä.",
    'stringEmpty' => "'%value%' on tyhjä.",
    'stringsNotEqual' => 'Komentosarjat poikkeavat toisistaan.',
    'passwordsNotEqual' => 'Kirjoittamasi salasanat eivät vastaa toisiaan.',
    'passwordLengthTooShort' => "salasana on lyhyempi kuin %min% merkkiä.",
    'passwordLengthTooLong' => "salasana on pidempi kuin %max% merkkiä.",
    'passwordRegexNotMatch' => "salasana ei täsmää mallia '%pattern%'.",
    'invalidUrl' => 'Määritetty osoite ei kelpaa. Määritä kelvollinen osoite, kuten http://domain.com.',
    'specialCharactersInIpAddress' => 'Annettu IP-osoite on virheellinen.',
    'massEmailContactsNotSelected' => 'Valitse ainakin yksi yhteystieto luettelosta.',
    'ipAddressIsTooLong' => 'IP-osoite saa olla enintään %max% merkkiä pitkä.',
    'ipAddressDescriptionTooLong' => 'Kuvaus saa olla enintään %max% merkkiä pitkä.',

    'fail2ban.invalidIpOrCidr' => 'IP-osoitteen on oltava kelvollinen IP-osoite tai CIDR-peite.',
];