<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

$messages = [
    'accessDenied' => 'Sitejet Builder ei sisälly tilaukseesi. Ota Sitejet Builder käyttöön ottamalla yhteyttä hosting-palveluntarjoajaasi.',
];