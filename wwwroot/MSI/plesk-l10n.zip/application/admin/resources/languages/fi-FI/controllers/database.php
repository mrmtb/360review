<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'assign-to-subscription.databasesSuccessfullyAssignedToSubscription' => 'Tietokannat siirrettiin tilaukseen \'%%subscriptionName%%\'.',
    'assign-to-subscription.databasesNotAssignedToSubscription' => 'Tietokantoja ei voida siirtää tilaukseen \'%%subscriptionName%%\'.',
    'assign-to-subscription.subscriptionNotFound' => 'Tilausta \'%%name%%\' ei löytynyt.',
    'assign-to-subscription.isNotMainDomain' => '\'%%name%%\' ei ole tilauksen päätoimialue.',

    'settings.title' => 'Tietokannan isännöintiasetukset',
    'settings.settingsSaved' => 'Tietokannan isännöinnin asetukset tallennettiin.',

    'refresh.success' => 'Tietokantapalvelinten tiedot päivitettiin.',
];