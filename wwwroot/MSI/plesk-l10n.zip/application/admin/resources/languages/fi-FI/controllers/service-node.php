<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.hint' => 'Etäpalvelusolmun lisäämiseen liittyvä kuvaus.',
    'add.title' => 'Lisää etäpalvelusolmu',
    'add.serviceNodeAdded' => 'Etäpalvelusolmu %%name%% on lisätty',

    'delete.infoServiceNodesDeleted' => 'Valitut palvelusolmut katkaistiin onnistuneesti.',
    'delete.infoServiceNodesNotDeleted' => 'Joitakin valittuja palvelusolmuja ei voitu katkaista.',
    'delete.serviceNodeIsInUse' => 'Palvelusolmu on käytössä.',

    'edit.hint' => 'Etäpalvelusolmun muokkaamiseen liittyvä kuvaus.',
    'edit.title' => 'Etäpalvelusolmu %%name%%',
    'edit.serviceNodeUpdated' => 'Etäpalvelusolmun %%name%% ominaisuudet on päivitetty',

    'list.hint' => 'Tässä voit lisätä etäpalvelusolmuja',
    'list.title' => 'Palvelusolmut',
];