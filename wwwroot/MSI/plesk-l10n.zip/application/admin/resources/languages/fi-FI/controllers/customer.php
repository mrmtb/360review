<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-domain-alias.noDomains' => 'Aliaksen luominen ei onnistu: toimialueita ei ole käytettävissä.',

    'add-domain.noDomains' => 'Laajennusverkkotunnuksen luominen ei onnistu: toimialueita ei ole käytettävissä.',

    'add-subdomain.noDomains' => 'Alitoimialueen luominen ei onnistu: toimialueita ei ole käytettävissä.',

    'change-owner.wrongOwnerId' => 'Asiakastilin uutta omistajaa ei löydetä.',

    'change.title' => 'Tilauksiin liittyvien suunnitelmien ja lisäosien muuttaminen',

    'create.title' => 'Lisätään uusi asiakas',

    'domains.title' => 'Toimialueet',

    'list.title' => 'Asiakkaat',
    'list.infoNewCustomerCreated' => 'Asiakas %%name%% luotiin.',
    'list.infoCustomerActivated' => 'Valitut asiakkaat aktivoitiin.',
    'list.infoCustomerNotActivated' => 'Joitakin valituista asiakkaista ei aktivoitu.',
    'list.infoCustomerSuspended' => 'Valitut asiakkaat keskeytettiin.',
    'list.infoCustomerNotSuspended' => 'Joitakin valituista asiakkaista ei keskeytetty.',
    'list.infoCustomerDeleted' => 'Valitut asiakkaat poistettiin.',
    'list.infoCustomerNotDeleted' => 'Joitakin valituista asiakkaista ei poistettu.',
    'list.upgrageCustomersHint' => 'Olet päivittänyt versioon Plesk 11, joka käyttää uutta asiakas- ja yritysmallia. Voit siirtyä kokonaan uuteen malliin muuttamalla client-tilit asiakkaan tai jälleenmyyjän tileiksi. Ellet suorita tätä, asiakkaasi eivät voi luoda verkkosivustoja, vaikka heille on annettu vastaava käyttöoikeus aikaisemmin.',
    'list.upgrageCustomersLink' => 'Muuta client-tilit.',
    'list.infoCustomerToResellerConverted' => 'Valitut asiakkaat muutettiin onnistuneesti jälleenmyyjiksi.',
    'list.errorCustomerToResellerNotConverted' => 'Joitakin valittuja asiakkaita ei muutettu jälleenmyyjiksi.',
    'list.infoOwnerChanged' => 'Valitut asiakkaat siirrettiin kohteeseen %%name%%.',
    'list.infoOwnerNotChanged' => 'Joitakin valituista asiakkaista ei siirretty kohteeseen %%name%%.',

    'login-info.title' => 'Muokataan kirjautumistietoja %%name%%',

    'overview.title' => '%%name%%',

    'personal-info.title' => 'Muokataan henkilön %%name%% yhteystietoja',

    'subscriptions.title' => 'Tilaukset',
];