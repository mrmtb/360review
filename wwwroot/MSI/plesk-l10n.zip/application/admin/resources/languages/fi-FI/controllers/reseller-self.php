<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'oversell-policy.title' => 'Ylimyyntikäytännön muuttaminen',
    'oversell-policy.pageHint' => 'Tässä voit muuttaa nykyistä ylimyyntikäytäntöäsi.',
    'oversell-policy.oversellPolicyChanged' => 'Ylimyyntikäytäntö päivitettiin onnistuneesti.',
    'oversell-policy.oversellPolicyNotChanged' => 'Ylimyyntikäytäntöä ei voida päivittää.',

    'subscription-overview.title' => 'Tilausten yleiskuvaus',
    'subscription-overview.pageHint' => 'Tämä on tilauksesi yhteenveto, se sisältää tietoa käytetystä resurssimäärästä sekä tarjotuista resursseista, ylimyyntikäytännöstä, eduista ja tilauksen tarjoamista palveluista.',
    'subscription-overview.changeOversellPolicyLink' => '[Muuta]',
    'subscription-overview.oversellEnabledHint' => 'Tilauksesi sallii resurssien ylimyynnin, voit täten myydä resursseja tilaukseen määritettyä määrää enemmän. Tässä tapauksessa toimintaasi säätelee todellinen resurssien käyttö alustavan resurssien määrityksen sijaan.',
    'subscription-overview.oversellDisableHint' => 'Tilauksesi ei salli resurssien ylimyyntiä, voit täten myydä resursseja ainoastaan tilaukseen alustavasti määritettyjen resurssien verran riippumatta siitä, kuinka paljon niistä todellisuudessa käytetään.',
    'subscription-overview.tabResources' => 'Resurssit',
    'subscription-overview.tabPermissions' => 'Käyttöoikeudet',
    'subscription-overview.resourcesSummaryHint' => 'Tämä on yhteenveto tilauksen tarjoamien resurssien käytöstä.',
    'subscription-overview.showMoreResources' => 'Näytä lisää saatavilla olevia resursseja',
    'subscription-overview.hideMoreResources' => 'Näytä vähemmän resursseja',
    'subscription-overview.permissionsSummaryHint' => 'Tämä on tilauksen mukana toimitettujen palveluiden ja oikeuksien luettelo.',
    'subscription-overview.hideMorePermissions' => 'Näytä vähemmän oikeuksia',
    'subscription-overview.showMorePermissions' => 'Näytä enemmän oikeuksia',
];