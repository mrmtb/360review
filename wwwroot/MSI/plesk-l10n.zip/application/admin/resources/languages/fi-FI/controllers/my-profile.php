<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-password.title' => "Vaihdetaan järjestelmänvalvojan salasana",
    'change-password.passwordChanged' => 'Järjestelmänvalvojan salasana on muutettu.',

    'index.personalInfoTitle' => "Muokataan järjestelmänvalvojan profiilia",
    'index.successMessage' => "Profiilisi päivitettiin.",
    'index.aliasInfoTitle' => 'Ylimääräisen järjestelmänvalvojan tilin tiedot',
    'index.aliasInfoUpdated' => 'Ylimääräisen järjestelmänvalvojan tilin yhteystiedot päivitettiin.',
];