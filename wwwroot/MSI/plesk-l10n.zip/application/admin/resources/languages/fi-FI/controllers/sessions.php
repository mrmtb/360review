<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Istuntojen hallinta',

    'remove.sessionsDeleted' => 'Valitut istunnot poistettiin onnistuneesti.',

    'settings.title' => 'Istunnon asetukset',
    'settings.settingsUpdated' => 'Asetuksia muutettiin onnistuneesti.',
];