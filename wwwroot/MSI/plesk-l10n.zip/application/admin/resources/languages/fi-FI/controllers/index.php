<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'eula.title' => 'WebProsin käyttöoikeussopimus',
    'eula.popupTitle' => 'Käyttöoikeussopimus',
    'eula.updatePopupTitle' => 'Käyttöoikeussopimuksen päivitys',
    'eula.popupDescription' => 'Käyttöoikeussopimus on luettava ja hyväksyttävä tuotteen käytön jatkamiseksi.',
    'eula.updatePopupDescription' => 'WebProsin käyttöoikeussopimus on päivitetty. Päivitetty käyttöoikeussopimus on luettava ja hyväksyttävä tuotteen käytön jatkamiseksi.',
    'eula.buttonAccept' => 'Hyväksy',
    'eula.buttonDecline' => 'Hylkää',
];