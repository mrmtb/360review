<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Ilmoitukset',

    'email-settings.title' => 'Sähköposti',

    'panel-settings.title' => 'Plesk-käyttöliittymä',
    'panel-settings.notificationSettingsSaved' => 'Ilmoitusasetukset on tallennettu.',

    'panel-notifications-toggle.successfullyEnabled' => 'Ilmoitus \'%%title%%\' otettiin käyttöön.',
    'panel-notifications-toggle.successfullyDisabled' => 'Ilmoitus \'%%title%%\' poistettiin käyttöstä.',

    'template-settings-list.hint' => 'Valitse näytettävät ilmoitukset ottamalla ne käyttöön tai poistamalla ne käytöstä.',
    'template-settings-list.name' => 'Otsikko',
    'template-settings-list.context' => 'Tilannekohtainen',
    'template-settings-list.sendToAdmin' => 'Lähetä järjestelmänvalvojalle',

    'template-settings-form.storagePeriod' => 'Säilytä ilmoituksia',
    'template-settings-form.days' => 'päivää',
];