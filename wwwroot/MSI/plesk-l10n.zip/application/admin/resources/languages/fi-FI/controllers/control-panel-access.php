<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-network.title' => 'Lisää verkko',
    'add-network.added' => 'Verkko %%address%% lisättiin.',

    'delete-network.noNetworksSpecified' => 'Valitse yksi tai useampia verkkoja IP-käyttörajoitusluettelosta.',
    'delete-network.networksDeleted' => 'Valitut verkot poistettiin.',
    'delete-network.networksNotDeleted' => 'Joitakin valituista verkoista ei poistettu. Tiedot: %%error%%.',

    'edit-network.title' => 'Verkon muokkaus',
    'edit-network.updated' => 'Verkko %%address%% päivitettiin.',

    'list.title' => 'IP-käyttörajoituksen hallinta',
    'list.currentIpAddressDenied' => 'Käyttörajoituskäytäntö ja verkkojen luettelo eivät salli sisäänkirjautumista järjestelmänvalvojan oikeuksilla IP-osoitteestasi \'%%remoteAddress%%\'.',
    'list.allowHint' => 'Pleskin käyttö järjestelmänvalvojan oikeuksilla sallitaan luettelon verkkoja lukuun ottamatta.',
    'list.denyHint' => 'Pleskin käyttö järjestelmänvalvojan oikeuksilla kielletään kaikilta verkoilta, joita ei ole annettu tässä luettelossa.',

    'settings.title' => 'IP-käyttörajoituksen asetukset',
    'settings.settingsSaved' => 'IP-käyttörajoituskäytäntö tallennettiin.',
];