<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-filter.title' => 'Lisää kieltosuodatin',
    'add-filter.filterAdded' => 'Kieltosuodatin lisättiin.',
    'add-filter.errorFilterNotAdded' => 'Kieltosuodatinta ei voida lisätä: %%error%%.',

    'add-jail.title' => 'Lisää kielto',
    'add-jail.jailAdded' => 'Kielto lisättiin.',

    'add-trusted-ip.title' => 'Lisää luotettava IP-osoite',
    'add-trusted-ip.trustedListTitle' => 'Luotettavat IP-osoitteet',
    'add-trusted-ip.ipAdded' => 'IP-osoite lisättiin luotettavien osoitteiden luetteloon.',
    'add-trusted-ip.errorIpNotAdded' => 'Seuraavaa IP-osoitetta ei voida lisätä: %%error%%.',

    'edit-trusted-ip.title' => 'Muokkaa kuvausta kohteelle %%ip%%',
    'edit-trusted-ip.ipEdited' => 'IP-osoitteen kuvaus on päivitetty.',
    'edit-trusted-ip.ipAddressNotFound' => 'IP-osoitetta ei löytynyt luotettujen luettelosta.',
    'edit-trusted-ip.errorIpNotEdited' => 'IP-osoitetta ei voida muokata: %%error%%.',

    'delete-banned-ips.infoBannedIpsDeleted' => 'Valitut IP-osoitteet poistettiin kiellettyjen osoitteiden luettelosta.',
    'delete-banned-ips.infoBannedIpsNotDeleted' => 'Joitakin IP-osoitteita ei voitu poistaa kiellettyjen osoitteiden luettelosta: %%error%%.',

    'delete-filters.infoFiltersDeleted' => 'Valitut kieltosuodattimet poistettiin.',
    'delete-filters.errorFiltersNotDeleted' => 'Valittuja suodattimia ei voida poistaa: %%error%%.',
    'delete-filters.errorFiltersBuiltIn' => 'Sisään rakennettuja suodattimia ei voida poistaa.',

    'delete-jail.infoJailDeleted' => 'Kielto poistettiin.',
    'delete-jail.errorJailNotDeleted' => 'Kieltoa ei voi poistaa: %%error%%.',
    'delete-jail.errorJailsBuiltIn' => 'Sisään rakennettuja kieltoja ei voida poistaa.',

    'delete-jails.infoJailsDeleted' => 'Valitut kiellot poistettiin.',
    'delete-jails.errorJailsNotDeleted' => 'Valittuja kieltoja ei voida poistaa: %%error%%.',
    'delete-jails.errorJailsBuiltIn' => 'Sisään rakennettuja kieltoja ei voida poistaa.',

    'delete-trusted-ips.infoTrustedIpsDeleted' => 'Valitut IP-osoitteet poistettiin luotettavien osoitteiden luettelosta.',
    'delete-trusted-ips.infoTrustedIpsNotDeleted' => 'Joitakin IP-osoitteita ei voitu poistaa luotettavien osoitteiden luettelosta: %%error%%.',
    'delete-trusted-ips.warningTrustedIpsPresentOnInterfaces' => 'Jotkin poistetuista luotettavista IP-osoitteista on verkkoliittymässä(-liittymissä): %%ips%%. Ne voidaan vahingossa kieltää, mikä aiheuttaa ongelmia sivustojen tai palvelujen käytössä.',

    'disable-jails.infoJailsDisabled' => 'Valitut kiellot poistettiin käytöstä.',
    'disable-jails.errorJailsNotDisabled' => 'Valittuja kieltoja ei voida poistaa käytöstä: %%error%%.',

    'edit-filter.title' => 'Muokkaa kieltosuodatinta',
    'edit-filter.filterSaved' => 'Kieltosuodatin tallennettiin.',
    'edit-filter.errorFilterNotSaved' => 'Kieltosuodatinta ei voida tallentaa: %%error%%.',
    'edit-filter.errorFilterNotEditable' => 'Suodatinta ei voi vaihtaa.',

    'edit-jail.title' => '%%name%%',
    'edit-jail.jailSaved' => 'Kieltoasetukset tallennettiin.',
    'edit-jail.errorJailNotEditable' => 'Kieltoa ei voi muuttaa.',

    'enable-jails.infoJailsEnabled' => 'Valitut kiellot otettiin käyttöön.',
    'enable-jails.errorJailsNotEnabled' => 'Valittuja kieltoja ei voida ottaa käyttöön: %%error%%.',

    'filters-list.title' => 'Kieltosuodattimet',

    'index.title' => 'IP-osoitteen kieltäminen',
    'index.banListTab' => 'Kielletyt IP-osoitteet',
    'index.trustedListTab' => 'Luotettavat IP-osoitteet',
    'index.jailListTab' => 'Kiellot',
    'index.settingsTab' => 'Asetukset',
    'index.logListTab' => 'Lokit',
    'index.jailNotFound' => 'Kieltoa %%name%% ei löytynyt.',
    'index.filterNotFound' => 'Suodatinta %%name%% ei löytynyt.',
    'index.logFileNotFound' => 'Lokitiedostoa ei löytynyt.',
    'index.tooManyDomains' => 'Fail2Ban ei välttämättä toimi oikein, jos toimialueita on monia ja Fail2Banin on valvottava liian monia lokitiedostoja.',
    'index.errorServiceFailed' => 'IP-osoitteen estopalvelu (Fail2Ban) epäonnistui ja se ei välttämättä toimi oikein. %%link%%',
    'index.restartLink' => 'Yritä käynnistää uudelleen',

    'jail-list.failed' => 'Kieltoluetteloa ei voitu saada: %%error%%.',

    'log-view.fileIsEmpty' => 'Tiedosto on tyhjä.',

    'move-to-trusted.infoTrustedIpsAdded' => 'Valitut IP-osoitteet lisättiin luotettavien osoitteiden luetteloon.',
    'move-to-trusted.infoTrustedIpsNotAdded' => 'Joitakin IP-osoitteita ei voitu lisätä luotettavien osoitteiden luetteloon: %%error%%.',

    'overview-jail.title' => '%%name%%',
    'overview-jail.pageHint' => 'Tässä voit nähdä lisätietoa kiellosta.',
    'overview-jail.buttonEditJail' => 'Muuta asetuksia',
    'overview-jail.hintEditJail' => 'Muuta tämän kiellon asetuksia.',
    'overview-jail.buttonDisableJail' => 'Sammuta',
    'overview-jail.hintDisableJail' => 'Poista tämä kielto käytöstä.',
    'overview-jail.buttonActivateJail' => 'Ota käyttöön',
    'overview-jail.hintActivateJail' => 'Ota tämä kielto käyttöön.',
    'overview-jail.buttonRemoveJail' => 'Poista',
    'overview-jail.hintRemoveJail' => 'Poista tämä kielto.',
    'overview-jail.fieldSatatus' => 'Tila',
    'overview-jail.fieldParameters' => 'Asetukset',
    'overview-jail.enabled' => 'Aktiivinen',
    'overview-jail.disabled' => 'Passiivinen',
    'overview-jail.banListHint' => 'Tämän kiellon estämät IP-osoitteet:',

    'restart.success' => 'Palvelun uudelleen käynnistys voi viedä muutaman minuutin.',
    'restart.failed' => 'Palvelua ei voitu käynnistää uudelleen.',

    'settings.settingsSaved' => 'Asetukset on tallennettu.',
    'settings.errorSettingsNotSaved' => 'Asetuksia ei voida tallentaa: %%error%%.',
    'settings.errorServiceFailed' => 'IP-osoitteen kielto (Fail2Ban) epäonnistuifailed: %%error%%',

    'toggle-jail.infoJailEnabled' => 'Kielto oli otettu käyttöön.',
    'toggle-jail.infoJailDisabled' => 'Kielto oli poistettu käytöstä.',
    'toggle-jail.errorJailNotEnabled' => 'Kieltoa ei voi ottaa käyttöön: %%error%%.',
    'toggle-jail.errorJailNotDisabled' => 'Kieltoa ei voi poistaa käytöstä: %%error%%.',

    'add-banned-ip.title' => 'Estä IP-osoite',
    'add-banned-ip.bannedListTitle' => 'Kielletyt IP-osoitteet',
    'add-banned-ip.ipAdded' => 'IP-osoite lisättiin estettyjen luetteloon.',
    'add-banned-ip.errorIpNotAdded' => 'Seuraavaa IP-osoitetta ei voi estää: %%error%%.',
];