<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'acl-records.title' => 'Siirtorajoituksien malli',

    'add-acl-record.title' => 'Lisää IP-osoite',
    'add-acl-record.success' => 'Määritettyjen IP-osoitteiden lisääminen onnistui.',

    'delete-acl-record.success' => 'Määritettyjen IP-osoitteiden poistaminen onnistui.',

    'index.title' => 'DNS-asetukset',

    'records.title' => 'Vyöhykkeen Tietueiden Malli',

    'reset-settings.success' => 'Oletusasetusten palauttaminen onnistui.',

    'settings.title' => 'Palvelimen laajuiset asetukset',
    'settings.success' => 'Asetukset päivitettiin onnistuneesti.',

    'soa-record.title' => 'Alueen asetuksien malli',

    'restore-default.title' => 'Palauta DNS-vyöhykkeen oletusmalli',
    'restore-default.text' => 'Vahvista, että haluat palauttaa DNS-vyöhykkeen mallin oletusmääritykset.',

    'soa-sync.title' => 'Ohita SOA-asetukset kaikissa olemassa olevissa toimialueissa',
    'soa-sync.text' => 'Haluatko päivittää kaikkien isännöityjen toimialueiden SOA-tietueet SOA-malliin tehdyillä muutoksilla?',

    'sync.title' => 'Ota DNS-mallin muutokset käyttöön',
    'sync.type-option' => 'Valitse jokin seuraavista vaihtoehdoista',
    'sync.safe' => 'Käytä muutokset muuttamattomiin vyöhykkeisiin. Jos vyöhyke mukautettiin (uudet tietueet lisättiin tai olemassa olevia muutettiin), Plesk ei käytä mallin muutoksia kyseisiin alueisiin.',
    'sync.force' => 'Käytä muutokset kaikkiin vyöhykkeisiin. Plesk käyttää mallin muutokset kaikkiin DNS-vyöhykkeisiin, mukautetut mukaan lukien. Huomaa, että käyttäjän muuttamat tietueet pysyvät entisellään. Jos esimerkiksi malli sisältää uuden tietueen, jonka asiakas on jo lisännyt, Plesk säilyttää asiakkaan tietueen.',

    'external-dns.title' => 'Ulkoinen DNS',
    'external-dns.hint' => 'Tässä voit määrittää ulkoiset DNS-palvelimet',
    'external-dns.success' => 'Tallennettu',
    'external-dns.configured' => 'Määritetty',
    'external-dns.notConfigured' => 'Ei määritetty',
    'external-dns.useExtension' => 'Käytä tätä laajennusta',

    'external-dns-edit.title' => 'Ulkoinen DNS',
];