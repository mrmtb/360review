<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'recordsTotal' => '%%total%% kohdetta yhteensä',
    'pages' => 'Sivut',
    'firstPage' => 'Ensimmäinen',
    'lastPage' => 'Viimeinen',
    'numberOfItemPerPage' => 'Merkinnät sivua kohti',
    'hideSearch' => 'Piilota hakutoiminto',
    'showSearch' => 'Näytä Etsi',
    'buttonSearch' => 'Etsi',
    'buttonResetSearch' => 'Palauta haku',
    'noEntriesFound' => 'Kohteita ei löytynyt.',
    'itemsNotSelected' => 'Valitse kohteet ensin.',
    'messageBoxButtonYes' => 'Kyllä',
    'messageBoxButtonNo' => 'Ei',
    'messageBoxButtonOk' => 'OK',
    'allItems' => 'Kaikki',
];