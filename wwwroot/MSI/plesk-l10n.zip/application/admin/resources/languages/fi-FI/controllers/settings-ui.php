<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'branding.title' => 'Pleskin tuotemukautus',

    'disable-languages.disableLanguagesSuccess' => 'Valitut kielet eivät ole enää käyttäjien saatavilla.',

    'edit-controls.updateSuccess' => 'Asetukset päivitettiin onnistuneesti.',

    'edit-interface-view.title' => 'Liittymänäkymät',
    'edit-interface-view.updateSuccess' => 'Asetukset päivitettiin onnistuneesti.',

    'enable-languages.enableLanguagesSuccess' => 'Valitut kielet tulivat asiakkaiden saataville.',

    'language-make-default.languageMakeDefaultSuccess' => 'Valittu kieli asetettiin Pleskin oletukseksi.',

    'list-languages.title' => 'Kielet',
    'list-languages.mlsLimitExceeded' => "Nykyinen Pleskin käyttöoikeus sallii %%allowedByLicense%% kielen käytön. Tällä hetkellä käyttäjille on määritetty %%availableToUsers%% kieltä, mikä ylittää käyttöoikeuden salliman määrän. Valitse %%allowedByLicense%% kieltä, joita haluat käyttää, ja poista loput kielet käyttäjien käytöstä napsauttamalla vastaavia kuvakkeita 'S'-sarakkeessa.",
];