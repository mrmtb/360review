<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'admin-customers-target-list.title' => 'Järjestelmänvalvojan siirtymän tarvitsevat asiakkaat',
    'admin-customers-target-list.hint-t1s1' => 'Tämä on clientien luoma luettelo asiakkaista. Ne eivät voineet muuttaa toimialueensa rajoituksia, ja niillä oli yksi toimialue ennen päivitystä.',
    'admin-customers-target-list.hint-t1s2' => 'Tämä on clientien luoma luettelo asiakkaista. Ne pystyivät muuttamaan toimialueensa rajoituksia, ja niillä oli yksi toimialue ennen päivitystä.',
    'admin-customers-target-list.hint-t1s3' => 'Tämä on clientien luoma luettelo asiakkaista. Ne eivät voineet luoda toimialueita ja muuttaa toimialueensa rajoituksia, ja niillä oli useita toimialueita ennen päivitystä.',
    'admin-customers-target-list.hint-t1s6' => 'Tämä on clientien luoma luettelo asiakkaista. Ne pystyivät luomaan toimialueita ja muuttamaan toimialueensa rajoituksia, ja niillä oli useita toimialueita ennen päivitystä.',

    'admin-subscriptions-target-list.title' => 'Järjestelmänvalvojan siirtymän tarvitseva tilaus',
    'admin-subscriptions-target-list.hint' => 'Tämä on luettelo tilauksista, jotka on luotu toimialueista, jotka (a) kuuluivat järjestelmänvalvojalle ja (b) joissa toimialueen järjestelmänvalvojan tili on otettu käyttöön ennen päivitystä.',

    'bunch.title' => 'Suorita uuteen Pleskin liiketoimintamalliin siirtyminen loppuun',
    'bunch.noActionsDescription' => 'Järjestelmässä ei ole enää yleisiin skenaarioihin sopivia asiakkaita ja tilauksia, sinulla ei täten ole suoritettavia tehtäviä tässä välilehdessä. Siirry seuraavaan välilehteen ja siirrä jäljellä olevat asiakkaat.',
    'bunch.description' => 'Plesk 10 ja sitä uudemman version resurssin jakelumalli poikkeaa edellisistä versioista: Plesk 10 -versiosta lähtien asiakkailla ei ole omia resursseja versioiden Plesk 8 ja 9 tapaan, vaan ne saadaan tilauksien mukana. Tällä hetkellä useilla asiakkailla on vanhoja resursseja, jotka tulee siirtää oikein uuteen Plesk -malliin sopivaksi. Pleskin käytön yleisiin skenaarioihin pohjautuen Plesk analysoi kyseiset asiakkaat ja loi alle luettelon suositelluista siirtotoiminnoista. Voit suorittaa ne tai valita asiakaskohtaisen siirtymämallin. Kun asiakas on siirretty, se häviää kyseisestä luettelosta.',
    'bunch.help' => 'Lue lisätietoja siirtymästä.',
    'bunch.applyed' => 'Valitut asiakkaat ja tilaukset siirrettiin.',
    'bunch.failed' => 'Valittuja asiakkaita ja tilauksia ei voida siirtää.',

    'customers.title' => 'Täydellinen siirtymä uuteen Plesk -yritysmalliin: selektiivinen siirtymä asiakkaille',
    'customers.description' => 'Tämä on täydellinen luettelo asiakkaista, jotka tarvitsevat siirtymän. Yleisten skenaarioiden mukaisten tilien lisäksi se sisältää epäsäännöllisiä asetuksia omaavat tilit, joihin ei ole olemassa suositeltavia toimintoja. Valitse soveltuva siirtymämalli itse erityisten aikaisempien client-asetuksien, kuten rajojen, käyttöoikeuksien, toimialueiden todellisen määrän jne. pohjalta. Saat lisätietoa aikaisemman clientin rajoituksista ja luvista napsauttamalla asiakkaan nimeä ja valitsemalla asiakastilauksien luettelosta \'My Resources\'.',
    'customers.help' => 'Lue lisätietoja siirtymästä.',

    'manual-customer-solution.appliedInfo' => 'Valitut asiakkaat siirrettiin.',
    'manual-customer-solution.notAppliedInfo' => 'Kaikkia tai useita valittuja asiakkaita ei siirretty.',

    'manual-subscription-solution.appliedInfo' => 'Valitut tilaukset siirrettiin.',
    'manual-subscription-solution.notAppliedInfo' => 'Kaikkia tai useita valittuja tilauksia ei siirretty.',

    'notes.nonApplicableCustomers' => "%%count%% -asiakkaat eivät sovi mihinkään yleiseen skenaarioon, heille ei täten ole suositeltavia toimintoja. Tilien siirtämiseksi, %%link%%.",
    'notes.nonApplicableSubscriptions' => "%%count%% -tilaukset eivät sovi mihinkään yleiseen skenaarioon, heille ei täten ole suositeltavia toimintoja. Tilauksien siirtämiseksi, %%link%%.",
    'notes.manualCustomersUpgradeLink' => 'valitse niille mukautettu malli',
    'notes.manualSubscriptionsUpgradeLink' => 'valitse niille mukautettu malli',

    'reseller-customers-target-list.title' => 'Jälleenmyyjän siirtymän tarvitsevat asiakkaat',
    'reseller-customers-target-list.hint-t2s1' => 'Tämä on clientien luoma luettelo asiakkaista. Ne eivät voineet muuttaa toimialueensa rajoituksia, ja niillä oli yksi toimialue ennen päivitystä.',
    'reseller-customers-target-list.hint-t2s2' => 'Tämä on clientien luoma luettelo asiakkaista. Ne pystyivät muuttamaan toimialueensa rajoituksia, ja niillä oli yksi toimialue ennen päivitystä.',
    'reseller-customers-target-list.hint-t2s3' => 'Tämä on clientien luoma luettelo asiakkaista. Ne eivät voineet luoda toimialueita ja muuttaa toimialueensa rajoituksia, ja niillä oli useita toimialueita ennen päivitystä.',
    'reseller-customers-target-list.hint-t2s6' => 'Tämä on clientien luoma luettelo asiakkaista. Ne pystyivät luomaan toimialueita ja muuttamaan toimialueensa rajoituksia, ja niillä oli useita toimialueita ennen päivitystä.',

    'reseller-subscriptions-target-list.title' => 'Jälleenmyyjän siirtymän tarvitsevat tilaus',
    'reseller-subscriptions-target-list.hint' => 'Tämä on luettelo tilauksista, jotka on luotu toimialueista, jotka (a) kuuluivat jälleenmyyjille ja (b) joissa toimialueen järjestelmänvalvojan tili on otettu käyttöön ennen päivitystä.',

    'subscriptions.title' => 'Täydellinen siirtymä uuteen Plesk -yritysmalliin: selektiivinen siirtymä tilauksille',
    'subscriptions.description' => 'Tämä luettelo sisältää siirtymän tarvitsevat tilaukset, se sisältää samat tilaukset kuin Suositellut toimet -sivulla, mutta tässä voit valita tilaukseen parhaiten sopivan siirtymämallin. Nämä tilaukset on luotu toimialueista, jotka (a) kuuluivat järjestelmänvalvojalle tai jälleenmyyjälle ja (b) jotka olivat ottaneet käyttöön toimialueen järjestelmänvalvojan tilin.',
    'subscriptions.help' => 'Lue lisätietoja siirtymästä.',

    'tabs.bunch' => 'Suositellut toimet',
    'tabs.customers' => 'Asiakkaiden selektiivinen siirtymä',
    'tabs.subscriptions' => 'Tilauksien selektiivinen siirtymä',
];