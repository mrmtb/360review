<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-log.actionSuccess' => 'Valitut lokitiedostot poistettiin.',
    'delete-log.invalidFileName' => 'Lokitiedoston nimi on virheellinen.',
    'delete-log.actionError' => 'Lokitiedostoa %%file%% ei voitu poistaa: %%reason%%',

    'index.title' => 'Verkkosovelluksen palomuuri',
    'index.generalTab' => 'Yleiset',
    'index.settingsTab' => 'Asetukset',
    'index.settingsSaved' => 'Verkkosovelluksen palomuurin asetukset tallennettiin.',
    'index.updateFailed' => 'ModSecurity-sääntösarjaa ei voitu päivittää: %%error%%',
    'index.updateFailedShort' => 'ModSecurity-sääntösarjaa ei voitu päivittää. %%link%%',
    'index.updateFailedShortLink' => 'Tiedot',

    'log-list.title' => 'Lokitiedostojen hallinta',

    'view-log.fileNameIsUndefined' => 'Lokitiedoston nimeä ei ole määritetty.',
];