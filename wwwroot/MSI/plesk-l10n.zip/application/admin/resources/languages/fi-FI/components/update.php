<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'email.subjSuccess' => 'Plesk päivitettiin onnistuneesti',
    'email.subjFailure' => 'Plesk -päivitys epäonnistui',
    'email.bodySuccess' => "Huomio,\n\nPlesk päivitettiin onnistuneesti.\nKun haluat tarkastella muutosluetteloa, käytä seuraavaa linkkiä: %%link%%.\n\nPlesk-asennusohjelma lähetti tämän viestin automaattisesti.",
    'email.bodyFailure' => "Huomio,\n\nPlesk -päivitys epäonnistui.\n\nVoit ladata Plesk-asennusohjelman lokit käyttämällä seuraavaa linkkiä: %%link%%.\nSaat apua isännöinnin palveluntarjoajalta.\n\nPlesk-asennusohjelma lähetti tämän viestin automaattisesti.",
];