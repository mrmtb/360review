<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'clear-cache.apsCacheCleared' => 'Väliaikaiset tiedostot poistettiin.',

    'configure.title' => '%%name%%',
    'configure.applicationNotFound' => "Sovellusta, jonka tunnus on '%%id%%', ei löytynyt.",
    'configure.applicationHasNoSettings' => 'Sovelluksessa ei ole asetuksia.',
    'configure.settingsUpdated' => 'Sovelluksen asetukset päivitettiin.',
    'configure.settingsUpdateFailed' => 'Asetusten päivittäminen epäonnistui: %%error%%',
    'configure.instancesNotReconfigured' => 'Joitakin sovellusesiintymiä ei ole konfiguroitu uudelleen.',

    'index.title' => 'Sovellusholvi',

    'info.title' => '%%name%%',
    'info.hint' => 'Alla oleva luettelo sisältää tietoa verkkosivustoista, joihin sovellus on asennettu. Verkkosivustosarakkeen Ei mitään -arvo tarkoittaa, että kyseessä on ulkoinen sovellus. Kyseistä sovellusta ei voida asentaa tiettyihin asiakkaiden verkkosivustoihin; se ainoastaan tarjoaa linkin ulkoiseen palveluun.',

    'remote-app-info.title' => 'Sovelluksen tiedot',

    'update-settings.title' => 'Asetusten päivittäminen',
    'update-settings.settingsUpdated' => 'Asetukset päivitettiin.',
    'update-settings.settingsUpdateFailed' => 'Asetusten päivittäminen ei onnistu: %%error%%',

    'upload.title' => 'Lisää sovellus',
    'upload.packageInstallationError' => 'Sovellusta ei voitu lisätä: %%message%%.',
    'upload.appUploaded' => 'Sovellus ladattiin onnistuneesti.',
    'upload.appDownloadStarted' => 'Valittujen sovelluksien lataaminen.',

    'uploaded.title' => 'Omat sovellukset',
    'uploaded.hint' => 'Tässä voit lisätä tai poistaa sovelluksia sovellusvalikoimasta sekä hallita sovellusten asiakkaiden saatavuutta. Sovelluksien lisäämiseen on kaksi syytä: saatavilla olevien sovellusten luettelon laajentaminen tai palvelimen laajuisten sovellusasetuksien määrittäminen. Joitakin sovelluksia ei voida asentaa ilman vastaavaa määritystä. Kaikki lisätyt sovellukset on annettu alla olevassa luettelossa.',
    'uploaded.infoAppDeleted' => 'Valitut sovellukset poistettiin.',
    'uploaded.infoAppNotDeleted' => 'Joitakin valituista sovelluksista ei poistettu.',
    'uploaded.applicationsNowAvailable' => 'Valitut sovellukset ovat nyt asiakkaiden asennettavissa tai määritettävissä.',
    'uploaded.applicationsNowNotAvailable' => 'Valitut sovellukset eivät ole enää asiakkaiden asennettavissa tai määritettävissä.',
    'uploaded.cantChangePackageProperties' => 'Virhe yritettäessä muuttaa sovelluksen saatavuusasetuksia.',
    'uploaded.appDownloaded' => 'Valitut sovellukset ladattiin onnistuneesti.',
    'uploaded.appNotDownloaded' => 'Joitakin valittuja sovelluksia ei ladattu.',
    'uploaded.downloadInProgress' => 'Odota...',

    'usage.title' => 'Asennetut sovellukset',
    'usage.hint' => 'Alla oleva luettelo sisältää kaikki sovellukset, jotka olet joko lisännyt tai jotka asiakkaasi on asentanut. Tässä voit hallita sovelluksen asetuksia, tarkistaa päivityksiä tai poistaa sovellusten asennuksen aikana asennettuja väliaikaisia tiedostoja.',
    'usage.hintReseller' => 'Alla oleva luettelo sisältää tietoa kaikista verkkosivustojesi ja asiakkaidesi verkkosivustojen sovellusasennuksista. Napsauta sovelluksen nimeä nähdäksesi luettelon verkkosivustoista, joihin sovellus on asennettu, ja tarkistaaksesi sovelluksen päivitykset.',
];