<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Lisää palvelu',
    'create.hint' => 'Tässä voit lisätä linkin ulkoiseen palveluun.',

    'edit.title' => 'Palvelun ominaisuudet %%name%%',
    'edit.hint' => 'Tässä voit määrittää palvelun ominaisuudet.',
    'edit.errorItemNotEditable' => 'Tämän palvelun ominaisuuksia ei voi muokata.',

    'list.title' => 'Lisäpalvelut',
    'list.tabTitle' => 'Lisäpalvelut',
    'list.hint' => "Tämä on luettelo lisäpalveluista, jotka voivat valmistella isännöintisuunnitelmien kanssa. Näyttää manuaalisesti määritetyt palvelut ja Plesk -tunnisteina asennettujen sovellusten palvelut. Palvelun manuaalinen lisääminen on hyödyllistä, kun haluat ohjata asiakkaasi ulkoiseen verkkopalveluun: tämä lisää vastaavan painikkeen asiakkaiden asiakaspaneeliin. Kaikki lisäpalvelut luetellaan oletusarvoisesti isännöintisuunnitelman ominaisuuksissa Lisäpalvelut-välilehdellä. Tämän avulla sinä ja jälleenmyyjäsi voitte sisällyttää nämä palvelut isännöintisuunnitelmiin. Jos et halua jälleenmyyjien käyttävän palvelua ja tarjoavan sitä asiakkailleen, valitse Aseta pois käytettävistä -linkki.",
    'list.planItemsNowAvailable' => 'Valitut lisäpalvelut ovat jälleenmyyjien saatavilla.',
    'list.planItemsNowNotAvailable' => 'Valitut lisäpalvelut eivät ole enää jälleenmyyjien saatavilla.',
    'list.cantChangePlanItemsProperties' => 'Virhe yritettäessä muuttaa palvelun saatavuusasetuksia.',
    'list.infoNewPlanItemCreated' => 'Palvelua vastaava valinta %%name%% lisättiin suunnitelman ominaisuuksiin.',
    'list.infoPlanItemUpdated' => 'Suunnitelman valinta %%name%% päivitettiin.',
    'list.planItemsDeleted' => 'Valitut suunnitelman valinnat poistettiin.',
    'list.planItemsNotDeleted' => 'Joitakin valituista suunnitelman valinnoista ei poistettu.',
];