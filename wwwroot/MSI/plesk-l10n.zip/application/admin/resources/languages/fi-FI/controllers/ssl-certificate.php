<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Lisää SSL/TLS-varmenne',
    'add.enterCertificateName' => 'Syötä varmenteen nimi.',

    'delete.infoSslCertificatesDeleted' => 'SSL/TLS-varmenteet poistettiin.',
    'delete.infoSslCertificatesNotDeleted' => 'SSL/TLS-varmenteita ei voida poistaa.',
    'delete.certificateUsedAsDefault' => 'Yhtä varmenteista, jota olet poistamassa, käytetään paneelin varmenteena.',
    'delete.certificateAssignedOnIp' => 'yksi tai useampi varmenne on määritetty IP-osoitteille/toimialueille.',
    'delete.certificateUsedByPanel' => 'Yhtä varmenteista, jota olet poistamassa, käytetään Pleskin suojaamiseen.',
    'delete.certificateUsedByMailServer' => 'Yhtä varmenteista, jota olet poistamassa, käytetään sähköpostipalvelimen suojaamiseen.',

    'edit.title' => 'Muuta SSL/TLS-varmenteen %%name%% ominaisuuksia',
    'edit.enterCertificateName' => 'Syötä varmenteen nimi.',

    'list.title' => 'SSL/TLS-varmenteet',
    'list.certificateFound' => 'Ladatun varmenteen yksityinen avain (nimellä %%name%%) löytyi. Varmenne lisättiin onnistuneesti.',
    'list.certificatesList' => 'Varmenteiden luettelo palvelinvarannossa',
    'list.certificatesListHint' => 'Palvelinvarannossa on varmenteiden luettelo.',
    'list.currentCertificates' => 'Tällä hetkellä käytössä olevat varmenteet Plesk-palvelimen suojaamiseksi',
    'list.currentCertificatesHint' => 'Tällä hetkellä käytössä olevat varmenteet Plesk-palvelimen ja sähköpostipalvelimen suojaamiseksi',
    'list.pleskCertificate' => 'Varmenne Pleskin suojaamiseen',
    'list.mailServerCertificate' => 'Varmenne sähköpostin suojaamiseen',
    'list.serverPoolCertificateDescription' => '%%name%% palvelinvarannosta.',
    'list.domainCertificateDescription' => '%%name%% toimialueelta %%domain%%.',
    'list.change' => '[Muuta]',
    'list.none' => 'Tuntematon.',

    'secure-mail-server.title' => 'Suojaa sähköpostipalvelin',
    'secure-mail-server.hint' => 'Valitse varmenne sähköpostipalvelimen suojaamiseen.',
    'secure-mail-server.mailServerCertificateSet' => '%%name%%-varmenne asetettiin sähköpostipalvelimen suojaamiseksi.',
    'secure-mail-server.mailServerNotInstalled' => 'Sähköpostipalvelua ei ole asennettu.',

    'secure-panel.title' => 'Suojaa Plesk',
    'secure-panel.hint' => 'Valitse varmenne Pleskin suojaamiseen.',
    'secure-panel.panelCertificateSet' => '%%name%%-varmenne asetettiin Pleskin suojaamiseksi.',
];