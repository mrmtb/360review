<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Palvelimen kunto',
    'index.pageHint' => 'Tässä voit nähdä tarkkoja raportteja palvelimen kunnosta. Tarkista palvelimen kuntoa koskevien parametrien muutokset valitsemalla parametrit ja Plesk näyttää vastaavat kaaviot. Huomaa, että voit muuttaa raporttien esitysaikaa - 3 tunnista yhteen viikkoon. Tässä voit muuttaa myös kunnon valvonnan määrityksiä, jotka määrittävät punaisen ja keltaisen hälytyksen aktivoitumisen kunkin parametrin kohdalla ja valvottavat kiintolevyn resurssit. Suorita tämä lataamalla määritystiedosto alla olevalla painikkeella, muokkaamalla tiedostoa ja lataamalla oma versiosi. Jos palvelimen laitteistoa on muutettu, kyseiset muutokset on tehtävä Health Monitoriin virheettömien tilastotietojen saamiseksi.',
    'index.waitMessage' => 'Ladataan...',
    'index.buttonUpload' => 'Lataa määritystiedosto',
    'index.buttonDownload' => 'Lataa määritystiedosto',
    'index.buttonRestoreDefaults' => 'Palauta oletusmääritykset',
    'index.buttonReconfigure' => 'Tunnista laitteistomuutokset',
    'index.buttonUploadHint' => 'Lataa kunnon valvonnan määritystiedosto. Uudet määritykset otetaan käyttöön heti lataamisen jälkeen.',
    'index.buttonDownloadHint' => 'Tallenna nykyinen kunnon valvonnan määritys tietokoneeseesi.',
    'index.buttonRestoreDefaultsHint' => 'Palauta palvelimen kunnon valvonnan oletusasetukset.',
    'index.buttonReconfigureHint' => 'Välitä muutokset laitteiston määrityksessä Health Monitoriin.',
    'index.confirmRestoreDefaultsTitle' => 'Palvelimen kunnon valvonnan oletusasetuksien palauttaminen',
    'index.confirmRestoreDefaultsDescription' => 'Oletko varma, että haluat palauttaa oletusasetukset?',
    'index.confirmReconfigureTitle' => 'Laitteistomuutoksien tunnistaminen',
    'index.confirmReconfigureDescription' => 'Olet lataamassa laitteiston määrityksiä Health Monitoriin. Tämä on tarpeen, jos palvelimen laitteistoa on muutettu ja haluat tehdä kyseiset muutokset Health Monitorin tilastotietoihin. Haluatko jatkaa?',
    'index.settingsWereRestoredToDefault' => 'Oletusasetukset palautettiin.',
    'index.healthMonitorWasReconfigured' => 'Health Monitor -tiedot päivitettiin laitteiston määrityksiä koskien.',

    'parameters.loading' => 'Ladataan...',
    'parameters.selectPeriod' => 'Valitse kausi',
    'parameters.periodFromNowTo3h' => '3 tuntia',
    'parameters.periodFromNowTo6h' => '6 tuntia',
    'parameters.periodFromNowTo12h' => '12 tuntia',
    'parameters.periodFromNowTo1d' => '1 päivä',
    'parameters.periodFromNowTo3d' => '3 päivää',
    'parameters.periodFromNowTo7d' => '1 viikko',

    'thresholds-hint.waitMessage' => 'Ladataan...',

    'upload-config-file.title' => 'Lataa määritystiedosto',
    'upload-config-file.configurationUploadedSuccessfully' => 'Määritykset ladattiin ja käytettiin.',
];