<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'gallery.titleScreenshot' => 'Paketin %%packageName%% näyttökuvat',
    'gallery.prevImage' => '< Edellinen',
    'gallery.nextImage' => 'Seuraava >',
    'gallery.closeGallery' => 'Sulje',
    'gallery.navigationOf' => 'jostakin',
    'gallery.typeScreenshot' => 'näyttökuvat',
    'gallery.title' => 'Näyttökuvat',
];