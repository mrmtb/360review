<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'PHP-asetukset',
    'list.hint' => 'Valitse PHP-käsittelijät, joiden haluat olevan käytettävissä. Voit asentaa ylimääräisiä käsittelijöitä linkistä %%link%%.',
    'list.hintLink' => 'Plesk-asennusohjelma',
    'list.brokenDomainsError' => 'Seuraavia PHP-versioita ei ole asennettu: %%phpVersions%%. %%domainCount%% toimialueelle ei ole PHP-skriptausta käytettävissä. Asenna puuttuvat PHP-käsittelijät tai korjaa PHP-skriptaus noudattamalla ohjeita: <a href=https://support.plesk.com/hc/en-us/articles/12377342328343>KB article</a>.',
    'list.brokenHandlersError' => 'Seuraava(t) PHP-versio(t) on asentamatta: %%phpVersions%%. Asenna ne tai suorita <code>plesk repair web -php-handlers</code> toisen PHP-version valitsemiseksi.',

    'modules.canNotManageModules' => 'Pääsy PHP-käsittelijän asetuksien hallintaan on rajoitettu, koska polkua PHP CLI -tiedostoon ei ole määritetty.',

    'php-ini.title' => 'Kohteen <b>%%name%% asetukset</b>',
    'php-ini.tabTitle' => 'php.ini',
    'php-ini.success' => 'Asetukset päivitettiin.',

    'toggle.errorEnableBrokenHandler' => 'Käsittelijä on vaurioitunut eikä sitä voida ottaa käyttöön.',
    'toggle.errorDisableBrokenHandler' => 'Käsittelijä on vaurioitunut eikä sitä voi ottaa käyttöön.',
    'toggle.infoHandlerEnabled' => 'Käsittelijä otettiin käyttöön.',
    'toggle.infoHandlerDisabled' => 'Käsittelijä poistettiin käytöstä.',
];