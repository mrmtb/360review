<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoDomainActivated' => 'Valitut toimialueet ja aliakset aktivoitiin.',
    'activate.errorDomainNotActivated' => 'Joitakin valituista toimialueista ja aliaksista ei aktivoitu.',
    'activate.domainStillSuspended' => 'Toimialuetta ei voi aktivoida: %%reason%%',
    'activate.domainStatusOffByAdmin' => 'Järjestelmänvalvoja on keskeyttänyt toimialueen.',
    'activate.domainStatusOffWithParent' => 'Joko toimialueen omistaja tai vastaava tilaus on keskeytetty.',
    'activate.domainStatusOffExpired' => 'Vastaava tilaus on mennyt umpeen.',
    'activate.domainStatusOffBackupRestore' => 'Toimialue on keskeytetty väliaikaisesti varmuuskopiointia tai palautusta varten.',
    'activate.domainStatusOff' => 'Toimialue on peruutettu.',
    'activate.aliasStillSuspended' => 'Aliasta ei voida aktivoida: kohdetoimialue on keskeytetty.',

    'add-domain-alias.noDomains' => 'Aliaksen luominen ei onnistu: toimialueita ei ole käytettävissä.',

    'add-domain.noDomains' => 'Laajennusverkkotunnuksen luominen ei onnistu: toimialueita ei ole käytettävissä.',

    'add-subdomain.noDomains' => 'Alitoimialueen luominen ei onnistu: toimialueita ei ole käytettävissä.',

    'disable.infoDomainDisabled' => 'Valitut toimialueet poistettiin käytöstä.',
    'disable.errorDomainNotDisabled' => 'Joitakin valituista toimialueista ei poistettu käytöstä.',

    'list.title' => 'Toimialueet',
    'list.customerLinkTitle' => 'luo asiakastili',
    'list.subscriptionLinkTitle' => 'luo oma tilaus',

    'suspend.infoDomainSuspended' => 'Valitut toimialueet on peruutettu.',
    'suspend.errorDomainNotSuspended' => 'Joitakin valituista toimialueista ei keskeytetty.',
];