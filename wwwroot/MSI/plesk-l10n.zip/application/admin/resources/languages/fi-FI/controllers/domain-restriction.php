<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Lisää toimialueen nimi',
    'add.domainAdded' => 'Toimialueen nimi %%domain%% lisättiin onnistuneesti kiellettyjen nimien luetteloon.',

    'disable.listDisabled' => 'Kiellettyjen toimialueiden nimien tarkistus poistettiin käytöstä.',

    'edit.title' => '%%name%%',
    'edit.domainUpdated' => 'Toimialueen nimi %%domain%% päivitettiin onnistuneesti.',

    'enable.listEnabled' => 'Kiellettyjen toimialueiden nimien tarkistus otettiin käyttöön.',

    'list.title' => 'Kielletyt toimialueen nimet',
    'list.hint' => 'Tässä voit hallita toimialueen kiellettyjen nimien luetteloa, joka sisältää suosituimmat toimialueet. Jos otat käyttöön toimialueen kiellettyjen nimien tarkistuksen (napsauttamalla Ota käyttöön), käyttäjät eivät voi luoda toimialueita luettelon nimillä. Kyseiset rajoitukset ovat hyödyllisiä esimerkiksi sähköpostin sieppaamisen estämiseksi. Jos tarkistus on poistettu käytöstä, asiakkaidesi laillisille yhtiöille lähettämät sähköpostiviestit voivat välittyä asiakkaille, jotka asettavat samannimisiä toimialueita kuin kyseisten yhtiöiden omistamat.',
    'list.warningLisDisabled' => 'Kiellettyjen toimialueiden nimien tarkistus on poistettu käytöstä.',

    'remove.domainRemoved' => 'Valitut toimialueen nimet poistettiin.',
    'remove.domainNotRemoved' => 'Joitakin valittuja toimialueen nimiä ei poistettu.',
    'remove.unableRemove' => 'Joitakin määritetyistä toimialueen nimistä ei poistettu.',
];