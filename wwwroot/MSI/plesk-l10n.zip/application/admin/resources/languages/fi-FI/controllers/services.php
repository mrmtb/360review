<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'operation.startActionSuccess' => 'Palvelu on aloitettu',
    'operation.stopActionSuccess' => 'Palvelu on pysäytetty',
    'operation.restartActionSuccess' => 'Palvelu on käynnistetty uudelleen',
    'operation.changeStartupActionSuccess' => 'Palvelun käynnistystapaa muutettiin onnistuneesti',

    'list.title' => 'Palvelut',

    'operation.startServiceMessage' => 'Odota jonkin aikaa, että palvelu käynnistyy.',
    'operation.stopServiceMessage' => 'Odota jonkin aikaa, että palvelu pysähtyy.',
    'operation.restartServiceMessage' => 'Odota jonkin aikaa, että palvelu käynnistyy uudelleen.',
    'operation.unableFetchFormData' => 'Lomakkeen tietoja ei voida hakea: %%error%%',
    'operation.startActionError' => 'Palvelua ei voi käynnistää: %%error%%',
    'operation.stopActionError' => 'Palvelua ei voi pysäyttää: %%error%%',
    'operation.restartActionError' => 'Palvelua ei voi käynnistää uudelleen: %%error%%',
    'operation.changeStartupActionError' => 'Palvelun käynnistystyyppiä ei voida muuttaa: %%error%%',
];