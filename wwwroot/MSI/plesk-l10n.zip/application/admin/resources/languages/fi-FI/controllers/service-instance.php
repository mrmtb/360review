<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.formTitle' => 'Valitse palvelu mainokseen',
    'create.successfullyAdded' => '\'%%serviceDisplayName%%\' -palvelu luotiin onnistuneesti.',
    'create.successfullyUpdated' => '\'%%serviceDisplayName%%\' -palvelu päivitettiin onnistuneesti.',
    'create.selectServiceInstallationTitle' => 'Valitse palvelu',

    'edit.formTitle' => 'Hallitse \'%%serviceDisplayName%%\' -palvelua',
    'edit.title' => '%%subscriptionName%% -palvelut',
    'edit.successfullyUpdated' => '\'%%serviceDisplayName%%\' -palvelu päivitettiin onnistuneesti.',

    'list.hint' => 'Tässä voit hallita tilauksen palveluja',
    'list.title' => '%%subscriptionName%% -palvelut',
    'list.breadcrumb' => 'Palvelut',
    'list.infoServiceDeleted' => 'Valitut palvelut poistettiin.',
    'list.infoServiceNotDeleted' => 'Joitakin valittuja palveluja ei poistettu.',
];