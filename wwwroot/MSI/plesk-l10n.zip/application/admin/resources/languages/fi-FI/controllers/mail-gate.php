<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Ulkoiset SMTP-palvelimen asetukset',
    'index.settingsUpdated' => 'Asetukset päivitettiin.',
];