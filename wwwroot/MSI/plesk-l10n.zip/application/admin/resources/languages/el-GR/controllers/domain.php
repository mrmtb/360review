<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoDomainActivated' => 'Οι επιλεγμένοι τομείς και τα ψευδώνυμα ενεργοποιήθηκαν.',
    'activate.errorDomainNotActivated' => 'Ορισμένοι από τους επιλεγμένους τομείς ή τα ψευδώνυμα δεν ενεργοποιήθηκαν.',
    'activate.domainStillSuspended' => 'Δεν είναι δυνατή η ενεργοποίηση του τομέα: %%reason%%',
    'activate.domainStatusOffByAdmin' => 'Ο τομέας έχει ανασταλεί από το διαχειριστή.',
    'activate.domainStatusOffWithParent' => 'Έχει ανασταλεί ο κάτοχος του τομέα ή η συνδρομή του.',
    'activate.domainStatusOffExpired' => 'Η αντίστοιχη συνδρομή έχει λήξει.',
    'activate.domainStatusOffBackupRestore' => 'Ο τομέας έχει ανασταλεί προσωρινά για δημιουργία ή επαναφορά αντιγράφου ασφαλείας.',
    'activate.domainStatusOff' => 'Ο τομέας έχει ανασταλεί.',
    'activate.aliasStillSuspended' => 'Δεν είναι δυνατή η ενεργοποίηση του ψευδωνύμου: Ο τομέας προορισμού έχει ανασταλεί.',

    'add-domain-alias.noDomains' => 'Δεν είναι δυνατή η δημιουργία ψευδωνύμου: Δεν υπάρχουν διαθέσιμοι τομείς.',

    'add-domain.noDomains' => 'Δεν είναι δυνατή η δημιουργία πρόσθετου τομέα: Δεν υπάρχουν διαθέσιμοι τομείς.',

    'add-subdomain.noDomains' => 'Αδυναμία δημιουργίας υποτομέα: Δεν υπάρχουν διαθέσιμοι τομείς.',

    'disable.infoDomainDisabled' => 'Οι επιλεγμένοι τομείς απενεργοποιήθηκαν.',
    'disable.errorDomainNotDisabled' => 'Ορισμένοι από τους επιλεγμένους τομείς δεν απενεργοποιήθηκαν.',

    'list.title' => 'Τομείς',
    'list.customerLinkTitle' => 'δημιουργήστε έναν λογαριασμό πελάτη',
    'list.subscriptionLinkTitle' => 'δημιουργήστε τη δική σας συνδρομή',

    'suspend.infoDomainSuspended' => 'Οι επιλεγμένοι τομείς ανεστάλησαν.',
    'suspend.errorDomainNotSuspended' => 'Ορισμένοι από τους επιλεγμένους τομείς δεν ανεστάλησαν.',
];