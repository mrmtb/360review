<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Ρυθμίσεις PHP',
    'list.hint' => 'Επιλέξτε τους δείκτες χειρισμού PHP που θέλετε να καταστήσετε διαθέσιμους. Μπορείτε να εγκαταστήσετε πρόσθετους δείκτες χειρισμού από τη σύνδεση %%link%%.',
    'list.hintLink' => 'Πρόγραμμα εγκατάστασης Plesk',
    'list.brokenDomainsError' => 'Οι ακόλουθες εκδόσεις PHP δεν είναι εγκατεστημένες: %%phpVersions%%. Η δέσμη ενεργειών PHP για %%domainCount%% τομέα/τομείς δεν είναι διαθέσιμη. Εγκαταστήστε τις εκδόσεις PHP που λείπουν ή ακολουθήστε τις οδηγίες από το άρθρο <a href=https://support.plesk.com/hc/en-us/articles/12377342328343>στη γνωσιακή βάση</a> για να επιδιορθώσετε τη δέσμη ενεργειών PHP.',
    'list.brokenHandlersError' => 'Οι ακόλουθες εκδόσεις PHP δεν έχουν εγκατασταθεί: %%phpVersions%%. Εγκαταστήστε τες ή εκτελέστε το <code>plesk repair web -php-handlers</code> για να επιλέξετε μια άλλη έκδοση PHP.',

    'modules.canNotManageModules' => 'Η πρόσβαση στη διαχείριση των ρυθμίσεων του δείκτη χειρισμού PHP είναι περιορισμένη επειδή δεν έχει καθοριστεί η διαδρομή προς το αρχείο CLI PHP.',

    'php-ini.title' => 'Ρυθμίσεις για το <b>%%name%%</b>',
    'php-ini.tabTitle' => 'php.ini',
    'php-ini.success' => 'Οι ρυθμίσεις ενημερώθηκαν.',

    'toggle.errorEnableBrokenHandler' => 'Ο δείκτης χειρισμού είναι κατεστραμμένος και δεν μπορεί να ενεργοποιηθεί.',
    'toggle.errorDisableBrokenHandler' => 'Ο δείκτης χειρισμού είναι κατεστραμμένος και δεν μπορεί να απενεργοποιηθεί.',
    'toggle.infoHandlerEnabled' => 'Ο δείκτης χειρισμού ενεργοποιήθηκε.',
    'toggle.infoHandlerDisabled' => 'Ο δείκτης χειρισμού απενεργοποιήθηκε.',
];