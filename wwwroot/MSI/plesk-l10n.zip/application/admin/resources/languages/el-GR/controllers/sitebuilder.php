<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'settings.title' => 'Ρυθμίσεις λειτουργίας Δοκιμής και Αγοράς',
    'settings.sitebuilderSettingsUpdated' => 'Οι ρυθμίσεις ενημερώθηκαν.',
];