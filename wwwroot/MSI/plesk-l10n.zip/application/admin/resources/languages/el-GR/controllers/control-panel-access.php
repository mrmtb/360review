<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-network.title' => 'Προσθήκη δικτύου',
    'add-network.added' => 'Το δίκτυο %%address%% προστέθηκε.',

    'delete-network.noNetworksSpecified' => 'Επιλέξτε ένα ή περισσότερα δίκτυα από τη λίστα περιορισμού πρόσβασης IP.',
    'delete-network.networksDeleted' => 'Τα επιλεγμένα δίκτυα διαγράφηκαν.',
    'delete-network.networksNotDeleted' => 'Ορισμένα από τα επιλεγμένα δίκτυα δεν διαγράφηκαν. Λεπτομέρειες: %%error%%.',

    'edit-network.title' => 'Επεξεργασία δικτύου',
    'edit-network.updated' => 'Το δίκτυο %%address%% ενημερώθηκε.',

    'list.title' => 'Διαχείριση περιορισμού πρόσβασης IP',
    'list.currentIpAddressDenied' => 'Η τρέχουσα διαμόρφωση της πολιτικής περιορισμού πρόσβασης και της λίστας δικτύων δεν σας επιτρέπει να συνδεθείτε με δικαιώματα διαχειριστή από τη διεύθυνση IP σας \'%%remoteAddress%%\'.',
    'list.allowHint' => 'Η πρόσβαση στο Plesk με προνόμια διαχειριστή επιτρέπεται, με εξαίρεση τα δίκτυα της λίστας.',
    'list.denyHint' => 'Η πρόσβαση στο Plesk με προνόμια διαχειριστή απορρίπτεται από όλα τα δίκτυα που δεν παρατίθενται εδώ.',

    'settings.title' => 'Ρυθμίσεις περιορισμού πρόσβασης IP',
    'settings.settingsSaved' => 'Η πολιτική περιορισμού πρόσβασης IP αποθηκεύτηκε.',
];