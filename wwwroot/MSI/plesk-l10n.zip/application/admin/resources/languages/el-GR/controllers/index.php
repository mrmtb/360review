<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'eula.title' => 'Άδεια Χρήσης Τελικού Χρήστη του WebPros',
    'eula.popupTitle' => 'Άδεια Χρήσης Τελικού Χρήστη (EULA)',
    'eula.updatePopupTitle' => 'Ενημέρωση EULA',
    'eula.popupDescription' => 'Πρέπει να διαβάσετε και να αποδεχθείτε την EULA για να συνεχίσετε να χρησιμοποιείτε αυτό το προϊόν.',
    'eula.updatePopupDescription' => 'Η WebPros του Plesk έχει ενημερωθεί. Πρέπει να διαβάσετε και να αποδεχθείτε την ενημερωμένη EULA για να συνεχίσετε να χρησιμοποιείτε αυτό το προϊόν.',
    'eula.buttonAccept' => 'Αποδοχή',
    'eula.buttonDecline' => 'Απόρριψη',
];