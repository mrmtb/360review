<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Προσθήκη πιστοποιητικού SSL/TLS',
    'add.enterCertificateName' => 'Εισαγάγετε το όνομα του πιστοποιητικού.',

    'delete.infoSslCertificatesDeleted' => 'Τα πιστοποιητικά SSL/TLS καταργήθηκαν.',
    'delete.infoSslCertificatesNotDeleted' => 'Δεν είναι δυνατή η κατάργηση των πιστοποιητικών SSL/TLS.',
    'delete.certificateUsedAsDefault' => 'Ένα από τα πιστοποιητικά που πρόκειται να διαγράψετε, χρησιμοποιείται ως προεπιλεγμένο πιστοποιητικό.',
    'delete.certificateAssignedOnIp' => 'ένα ή περισσότερα πιστοποιητικά έχουν εκχωρηθεί στις διευθύνσεις IP/τομείς.',
    'delete.certificateUsedByPanel' => 'Ένα από τα πιστοποιητικά που πρόκειται να διαγράψετε, χρησιμοποιείται για την προστασία του Plesk.',
    'delete.certificateUsedByMailServer' => 'Ένα από τα πιστοποιητικά που πρόκειται να διαγράψετε, χρησιμοποιείται για την προστασία του διακομιστή αλληλογραφίας.',

    'edit.title' => 'Αλλαγή ιδιοτήτων του πιστοποιητικού SSL/TLS %%name%%',
    'edit.enterCertificateName' => 'Εισαγάγετε το όνομα του πιστοποιητικού.',

    'list.title' => 'Πιστοποιητικά SSL/TLS',
    'list.certificateFound' => 'Δεν βρέθηκε το ιδιωτικό κλειδί (με το όνομα %%name%%) για το απεσταλμένο πιστοποιητικό. Η προσθήκη του πιστοποιητικού ολοκληρώθηκε με επιτυχία.',
    'list.certificatesList' => 'Λίστα πιστοποιητικών στην κατηγορία διακομιστών',
    'list.certificatesListHint' => 'Αυτή είναι η λίστα πιστοποιητικών στην κατηγορία διακομιστών.',
    'list.currentCertificates' => 'Πιστοποιητικά που χρησιμοποιούνται αυτή τη στιγμή για την ασφάλιση του διακομιστή Plesk',
    'list.currentCertificatesHint' => 'Πιστοποιητικά που χρησιμοποιούνται αυτή τη στιγμή για την ασφάλιση του διακομιστή Plesk και του διακομιστή αλληλογραφίας',
    'list.pleskCertificate' => 'Πιστοποιητικό για την ασφάλιση του Plesk',
    'list.mailServerCertificate' => 'Πιστοποιητικό για την ασφάλιση της αλληλογραφίας',
    'list.serverPoolCertificateDescription' => '%%name%% από την κατηγορία διακομιστών.',
    'list.domainCertificateDescription' => '%%name%% από το %%domain%%.',
    'list.change' => '[Αλλαγή]',
    'list.none' => 'Άγνωστο.',

    'secure-mail-server.title' => 'Ασφάλιση διακομιστή αλληλογραφίας',
    'secure-mail-server.hint' => 'Επιλέξτε ένα πιστοποιητικό για την προστασία του διακομιστή αλληλογραφίας.',
    'secure-mail-server.mailServerCertificateSet' => 'Το πιστοποιητικό %%name%% ορίστηκε με επιτυχία για την ασφάλιση του διακομιστή αλληλογραφίας.',
    'secure-mail-server.mailServerNotInstalled' => 'Η υπηρεσία αλληλογραφίας δεν είναι εγκατεστημένη.',

    'secure-panel.title' => 'Ασφάλιση Plesk',
    'secure-panel.hint' => 'Επιλέξτε ένα πιστοποιητικό για την προστασία του Plesk.',
    'secure-panel.panelCertificateSet' => 'Το πιστοποιητικό %%name%% ορίστηκε με επιτυχία για την προστασία του Plesk.',
];