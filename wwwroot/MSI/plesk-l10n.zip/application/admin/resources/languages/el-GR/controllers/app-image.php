<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'gallery.titleScreenshot' => 'Στιγμιότυπα οθόνης του %%packageName%%',
    'gallery.prevImage' => '< Προηγούμενο',
    'gallery.nextImage' => 'Επόμενο >',
    'gallery.closeGallery' => 'Κλείσιμο',
    'gallery.navigationOf' => 'από',
    'gallery.typeScreenshot' => 'στιγμιότυπα οθόνης',
    'gallery.title' => 'Στιγμιότυπα οθόνης',
];