<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-password.title' => "Αλλαγή κωδικού πρόσβασης διαχειριστή",
    'change-password.passwordChanged' => 'Ο κωδικός πρόσβασης διαχειριστή άλλαξε.',

    'index.personalInfoTitle' => "Επεξεργασία προφίλ διαχειριστή",
    'index.successMessage' => "Το προφίλ σας ενημερώθηκε.",
    'index.aliasInfoTitle' => 'Πληροφορίες πρόσθετου λογαριασμού διαχειριστή',
    'index.aliasInfoUpdated' => 'Οι προσωπικές πληροφορίες του πρόσθετου λογαριασμού διαχειριστή ενημερώθηκαν.',
];