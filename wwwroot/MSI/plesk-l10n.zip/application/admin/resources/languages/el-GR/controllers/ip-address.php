<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Προσθήκη διεύθυνσης IP',
    'add.ipAddressAdded' => 'Η διεύθυνση IP %%address%% προστέθηκε.',

    'delete.infoIpAddressesDeleted' => 'Οι επιλεγμένες διευθύνσεις IP καταργήθηκαν.',

    'edit.title' => 'Διεύθυνση IP %%address%% στη διασύνδεση %%interface%%',
    'edit.ipAddressUpdated' => 'Η αλλαγή ρυθμίσεων της διεύθυνσης IP %%address%% έχει προγραμματιστεί και θα γίνει στο παρασκήνιο',
    'edit.ipAddressInterfaceNotAvailableWarning' => 'Ο προσαρμογέας δικτύου %%interface%% δεν υπάρχει.  Μετακινήστε αυτήν τη διεύθυνση IP σε άλλον προσαρμογέα δικτύου ή καταργήστε την από τη λίστα.',

    'list.title' => 'Διευθύνσεις IP',
];