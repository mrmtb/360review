<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-filter.title' => 'Προσθήκη φίλτρου jail',
    'add-filter.filterAdded' => 'Το φίλτρο jail προστέθηκε.',
    'add-filter.errorFilterNotAdded' => 'Δεν είναι δυνατή η προσθήκη του φίλτρου jail: %%error%%.',

    'add-jail.title' => 'Προσθήκη jail',
    'add-jail.jailAdded' => 'Το jail προστέθηκε.',

    'add-trusted-ip.title' => 'Προσθήκη αξιόπιστης διεύθυνσης IP',
    'add-trusted-ip.trustedListTitle' => 'Αξιόπιστες διευθύνσεις IP',
    'add-trusted-ip.ipAdded' => 'Η διεύθυνση IP προστέθηκε στη λίστα αξιόπιστων διευθύνσεων.',
    'add-trusted-ip.errorIpNotAdded' => 'Δεν είναι δυνατή η προσθήκη της διεύθυνσης IP: %%error%%.',

    'edit-trusted-ip.title' => 'Επεξεργασία περιγραφής για %%ip%%',
    'edit-trusted-ip.ipEdited' => 'Η περιγραφή της διεύθυνσης IP ενημερώθηκε.',
    'edit-trusted-ip.ipAddressNotFound' => 'Η διεύθυνση IP δεν βρέθηκε στη λίστα των αξιόπιστων διευθύνσεων.',
    'edit-trusted-ip.errorIpNotEdited' => 'Δεν είναι δυνατή η επεξεργασία της διεύθυνσης IP: %%error%%.',

    'delete-banned-ips.infoBannedIpsDeleted' => 'Οι επιλεγμένες διευθύνσεις IP καταργήθηκαν από τη λίστα απαγορευμένων διευθύνσεων.',
    'delete-banned-ips.infoBannedIpsNotDeleted' => 'Δεν είναι δυνατή η κατάργηση ορισμένων διευθύνσεων IP από τη λίστα απαγορευμένων διευθύνσεων: %%error%%.',

    'delete-filters.infoFiltersDeleted' => 'Τα επιλεγμένα φίλτρα jail καταργήθηκαν.',
    'delete-filters.errorFiltersNotDeleted' => 'Δεν είναι δυνατή η κατάργηση των επιλεγμένων φίλτρων: %%error%%.',
    'delete-filters.errorFiltersBuiltIn' => 'Δεν είναι δυνατή η κατάργηση των ενσωματωμένων φίλτρων.',

    'delete-jail.infoJailDeleted' => 'Το jail καταργήθηκε.',
    'delete-jail.errorJailNotDeleted' => 'Δεν είναι δυνατή η κατάργηση του jail: %%error%%.',
    'delete-jail.errorJailsBuiltIn' => 'Δεν είναι δυνατή η κατάργηση των ενσωματωμένων jail.',

    'delete-jails.infoJailsDeleted' => 'Τα επιλεγμένα jail καταργήθηκαν.',
    'delete-jails.errorJailsNotDeleted' => 'Δεν είναι δυνατή η κατάργηση των επιλεγμένων jail: %%error%%.',
    'delete-jails.errorJailsBuiltIn' => 'Δεν είναι δυνατή η κατάργηση των ενσωματωμένων jail.',

    'delete-trusted-ips.infoTrustedIpsDeleted' => 'Οι επιλεγμένες διευθύνσεις IP καταργήθηκαν από τη λίστα αξιόπιστων διευθύνσεων.',
    'delete-trusted-ips.infoTrustedIpsNotDeleted' => 'Δεν είναι δυνατή η κατάργηση ορισμένων διευθύνσεων IP από τη λίστα αξιόπιστων διευθύνσεων: %%error%%.',
    'delete-trusted-ips.warningTrustedIpsPresentOnInterfaces' => 'Ορισμένες από τις διαγραμμένες αξιόπιστες IP υπάρχουν τις διασυνδέσεις δικτύου: %%ips%%. Υπάρχει η πιθανότητα να απαγορευτούν κατά λάθος, με αποτέλεσμα να παρουσιαστούν ζητήματα πρόσβασης σε τοποθεσίες ή υπηρεσίες.',

    'disable-jails.infoJailsDisabled' => 'Τα επιλεγμένα jail απενεργοποιήθηκαν.',
    'disable-jails.errorJailsNotDisabled' => 'Δεν είναι δυνατή η απενεργοποίηση των επιλεγμένων jail: %%error%%.',

    'edit-filter.title' => 'Επεξεργασία φίλτρου jail',
    'edit-filter.filterSaved' => 'Το φίλτρο jail αποθηκεύτηκε.',
    'edit-filter.errorFilterNotSaved' => 'Δεν είναι δυνατή η αποθήκευση του φίλτρου jail: %%error%%.',
    'edit-filter.errorFilterNotEditable' => 'Το φίλτρο δεν μπορεί να αλλάξει.',

    'edit-jail.title' => '%%name%%',
    'edit-jail.jailSaved' => 'Οι ρυθμίσεις jail αποθηκεύτηκαν.',
    'edit-jail.errorJailNotEditable' => 'Το jail δεν μπορεί να αλλάξει.',

    'enable-jails.infoJailsEnabled' => 'Τα επιλεγμένα jail ενεργοποιήθηκαν.',
    'enable-jails.errorJailsNotEnabled' => 'Δεν είναι δυνατή η ενεργοποίηση των επιλεγμένων jail: %%error%%.',

    'filters-list.title' => 'Φίλτρα jail',

    'index.title' => 'Απαγόρευση διευθύνσεων IP',
    'index.banListTab' => 'Απαγορευμένες διευθύνσεις IP',
    'index.trustedListTab' => 'Αξιόπιστες διευθύνσεις IP',
    'index.jailListTab' => 'Jail',
    'index.settingsTab' => 'Ρυθμίσεις',
    'index.logListTab' => 'Αρχεία καταγραφής',
    'index.jailNotFound' => 'Το jail %%name%% δεν βρέθηκε.',
    'index.filterNotFound' => 'Το φίλτρο %%name%% δεν βρέθηκε.',
    'index.logFileNotFound' => 'Το αρχείο καταγραφής δεν βρέθηκε.',
    'index.tooManyDomains' => 'Το Fail2Ban μπορεί να μην λειτουργήσει κανονικά εάν υπάρχουν πολλοί τομείς και το Fail2Ban πρέπει να ελέγχει υπερβολικά μεγάλο αριθμό αρχείων καταγραφής.',
    'index.errorServiceFailed' => 'Η υπηρεσία απαγόρευσης διευθύνσεων IP (Fail2Ban) απέτυχε και ενδέχεται να μην λειτουργήσει κανονικά. %%link%%',
    'index.restartLink' => 'Πραγματοποιήστε επανεκκίνηση',

    'jail-list.failed' => 'Δεν είναι δυνατή η λήψη της λίστας των jail: %%error%%.',

    'log-view.fileIsEmpty' => 'Το αρχείο είναι κενό.',

    'move-to-trusted.infoTrustedIpsAdded' => 'Οι επιλεγμένες διευθύνσεις IP προστέθηκαν στη λίστα αξιόπιστων διευθύνσεων.',
    'move-to-trusted.infoTrustedIpsNotAdded' => 'Δεν είναι δυνατή η προσθήκη ορισμένων διευθύνσεων IP στη λίστα αξιόπιστων διευθύνσεων: %%error%%.',

    'overview-jail.title' => '%%name%%',
    'overview-jail.pageHint' => 'Εδώ μπορείτε να δείτε αναλυτικές πληροφορίες σχετικά με το jail.',
    'overview-jail.buttonEditJail' => 'Αλλαγή ρυθμίσεων',
    'overview-jail.hintEditJail' => 'Αλλαγή των ρυθμίσεων αυτού του jail.',
    'overview-jail.buttonDisableJail' => 'Απενεργοποίηση',
    'overview-jail.hintDisableJail' => 'Απενεργοποίηση αυτού του jail.',
    'overview-jail.buttonActivateJail' => 'Ενεργοποίηση',
    'overview-jail.hintActivateJail' => 'Ενεργοποίηση αυτού του jail.',
    'overview-jail.buttonRemoveJail' => 'Κατάργηση',
    'overview-jail.hintRemoveJail' => 'Κατάργηση αυτού του jail.',
    'overview-jail.fieldSatatus' => 'Κατάσταση',
    'overview-jail.fieldParameters' => 'Ρυθμίσεις',
    'overview-jail.enabled' => 'Ενεργό',
    'overview-jail.disabled' => 'Ανενεργό',
    'overview-jail.banListHint' => 'Διευθύνσεις IP που αποκλείονται από αυτό το jail:',

    'restart.success' => 'Η επανεκκίνηση της υπηρεσίας μπορεί να διαρκέσει μερικά λεπτά.',
    'restart.failed' => 'Δεν ήταν δυνατή η επανεκκίνηση της υπηρεσίας.',

    'settings.settingsSaved' => 'Οι ρυθμίσεις αποθηκεύτηκαν.',
    'settings.errorSettingsNotSaved' => 'Δεν είναι δυνατή η αποθήκευση των ρυθμίσεων: %%error%%.',
    'settings.errorServiceFailed' => 'Η υπηρεσία απαγόρευσης διευθύνσεων IP (Fail2Ban) απέτυχε: %%error%%',

    'toggle-jail.infoJailEnabled' => 'Το jail ήταν ενεργοποιημένο.',
    'toggle-jail.infoJailDisabled' => 'Το jail ήταν απενεργοποιημένο.',
    'toggle-jail.errorJailNotEnabled' => 'Δεν είναι δυνατή η ενεργοποίηση του jail: %%error%%.',
    'toggle-jail.errorJailNotDisabled' => 'Δεν είναι δυνατή η απενεργοποίηση του jail: %%error%%.',

    'add-banned-ip.title' => 'Αποκλεισμός διεύθυνσης IP',
    'add-banned-ip.bannedListTitle' => 'Απαγορευμένες διευθύνσεις IP',
    'add-banned-ip.ipAdded' => 'Η διεύθυνση IP προστέθηκε στη λίστα με τις αποκλεισμένες.',
    'add-banned-ip.errorIpNotAdded' => 'Δεν είναι δυνατός ο αποκλεισμός της διεύθυνσης IP: %%error%%.',
];