<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'leftFrameSwitcher' => 'Απόκρυψη/εμφάνιση του παραθύρου περιήγησης',
];