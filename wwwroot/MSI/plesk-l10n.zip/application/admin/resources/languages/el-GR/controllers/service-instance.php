<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.formTitle' => 'Επιλογή υπηρεσίας για προσθήκη',
    'create.successfullyAdded' => 'Η υπηρεσία \'%%serviceDisplayName%%\' δημιουργήθηκε με επιτυχία.',
    'create.successfullyUpdated' => 'Η υπηρεσία \'%%serviceDisplayName%%\' ενημερώθηκε με επιτυχία.',
    'create.selectServiceInstallationTitle' => 'Επιλογή υπηρεσίας',

    'edit.formTitle' => 'Διαχείριση της υπηρεσίας \'%%serviceDisplayName%%\'',
    'edit.title' => 'Υπηρεσίες %%subscriptionName%%',
    'edit.successfullyUpdated' => 'Η υπηρεσία \'%%serviceDisplayName%%\' ενημερώθηκε με επιτυχία.',

    'list.hint' => 'Εδώ μπορείτε να διαχειριστείτε τις υπηρεσίες στη συνδρομή',
    'list.title' => 'Υπηρεσίες %%subscriptionName%%',
    'list.breadcrumb' => 'Υπηρεσίες',
    'list.infoServiceDeleted' => 'Οι επιλεγμένες υπηρεσίες καταργήθηκαν.',
    'list.infoServiceNotDeleted' => 'Ορισμένες από τις επιλεγμένες υπηρεσίες δεν καταργήθηκαν.',
];