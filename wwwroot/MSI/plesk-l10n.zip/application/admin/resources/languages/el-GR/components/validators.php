<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'isEmpty' => 'Αυτό το απαιτούμενο πεδίο είναι κενό.  Πρέπει να εισαγάγετε μια τιμή σε αυτό το πεδίο.',
    'stringLengthTooShort' => "Το '%value%' έχει λιγότερους χαρακτήρες από %min%.",
    'stringLengthTooLong' => "Το '%value%' έχει περισσότερους χαρακτήρες από %max%.",
    'regexNotMatch' => "Το '%value%' δεν αντιστοιχεί στο μοτίβο '%pattern%'.",
    'notAlnum' => "Το '%value%' έχει μη αλφαριθμητικούς χαρακτήρες. Βεβαιωθείτε ότι χρησιμοποιείτε μόνο αλφαριθμητικούς χαρακτήρες.",
    'stringEmpty' => "Η τιμή '%value%' είναι κενή.",
    'stringsNotEqual' => 'Οι συμβολοσειρές δεν είναι ίσες.',
    'passwordsNotEqual' => 'Οι κωδικοί πρόσβασης που πληκτρολογήσατε δεν συμφωνούν μεταξύ τους.',
    'passwordLengthTooShort' => "ο κωδικός πρόσβασης περιέχει λιγότερους από %min% χαρακτήρες.",
    'passwordLengthTooLong' => "ο κωδικός πρόσβασης υπερβαίνει τους %max% χαρακτήρες.",
    'passwordRegexNotMatch' => "ο κωδικός πρόσβασης δεν αντιστοιχεί στο μοτίβο '%pattern%'.",
    'invalidUrl' => 'Η καθορισμένη διεύθυνση δεν είναι έγκυρη. Πρέπει να καθορίσετε μια έγκυρη διεύθυνση, όπως http://domain.com.',
    'specialCharactersInIpAddress' => 'Η διεύθυνση IP που παρέχεται δεν είναι έγκυρη.',
    'massEmailContactsNotSelected' => 'Επιλέξτε τουλάχιστον μία επαφή από τη λίστα.',
    'ipAddressIsTooLong' => 'Μια διεύθυνση IP δεν πρέπει να περιέχει περισσότερους από %max% χαρακτήρες.',
    'ipAddressDescriptionTooLong' => 'Η περιγραφή δεν πρέπει να περιέχει περισσότερους από %max% χαρακτήρες.',

    'fail2ban.invalidIpOrCidr' => 'Η διεύθυνση IP πρέπει να είναι έγκυρη διεύθυνση IP ή μάσκα CIDR.',
];