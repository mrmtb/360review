<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

$messages = [
    'accessDenied' => 'Το Sitejet Builder δεν περιλαμβάνεται στη συνδρομή σας. Για να ενεργοποιήσετε το Sitejet Builder, επικοινωνήστε με την υπηρεσία παροχής φιλοξενίας.',
];