<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Πρόγραμμα εγκατάστασης Plesk',
    'index.autoinstallerRedirectError' => 'Δεν ήταν δυνατή η εκκίνηση του προγράμματος εγκατάστασης Plesk. Παρουσιάστηκε το παρακάτω σφάλμα: %%message%%',

    'product.title' => 'Πρόγραμμα εγκατάστασης Plesk',
    'product.autoinstallerRedirectError' => 'Δεν ήταν δυνατή η εκκίνηση του προγράμματος εγκατάστασης Plesk. Παρουσιάστηκε το παρακάτω σφάλμα: %%message%%',

    'settings.title' => 'Ενημέρωση ρυθμίσεων',
    'settings.settingsUpdated' => 'Οι ρυθμίσεις ενημέρωσης άλλαξαν.',
];