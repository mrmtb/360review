<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Διαχείριση περιόδων λειτουργίας',

    'remove.sessionsDeleted' => 'Οι επιλεγμένες περίοδοι λειτουργίας καταργήθηκαν με επιτυχία.',

    'settings.title' => 'Ρυθμίσεις περιόδου λειτουργίας',
    'settings.settingsUpdated' => 'Οι ρυθμίσεις άλλαξαν με επιτυχία.',
];