<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-log.actionSuccess' => 'Τα επιλεγμένα αρχεία καταγραφής καταργήθηκαν.',
    'delete-log.invalidFileName' => 'Μη έγκυρο όνομα αρχείου καταγραφής.',
    'delete-log.actionError' => 'Δεν είναι δυνατή η κατάργηση του αρχείου καταγραφής %%file%%: %%reason%%',

    'index.title' => 'Τείχος προστασίας εφαρμογών web',
    'index.generalTab' => 'Γενικά',
    'index.settingsTab' => 'Ρυθμίσεις',
    'index.settingsSaved' => 'Οι ρυθμίσεις του τείχους προστασίας εφαρμογών web αποθηκεύτηκαν.',
    'index.updateFailed' => 'Η ενημέρωση του συνόλου κανόνων ModSecurity απέτυχε: %%error%%',
    'index.updateFailedShort' => 'Η ενημέρωση του συνόλου κανόνων ModSecurity απέτυχε. %%link%%',
    'index.updateFailedShortLink' => 'Λεπτομέρειες',

    'log-list.title' => 'Διαχείριση αρχείων καταγραφής',

    'view-log.fileNameIsUndefined' => 'Δεν έχει καθοριστεί όνομα αρχείου καταγραφής.',
];