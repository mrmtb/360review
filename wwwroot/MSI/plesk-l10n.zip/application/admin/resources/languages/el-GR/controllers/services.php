<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'operation.startActionSuccess' => 'Η υπηρεσία ξεκίνησε',
    'operation.stopActionSuccess' => 'Η υπηρεσία διακόπηκε',
    'operation.restartActionSuccess' => 'Η υπηρεσία επανεκκινήθηκε',
    'operation.changeStartupActionSuccess' => 'Ο τύπος εκκίνησης για την υπηρεσία άλλαξε με επιτυχία',

    'list.title' => 'Υπηρεσίες',

    'operation.startServiceMessage' => 'Περιμένετε λίγο μέχρι να εκκινηθεί η υπηρεσία.',
    'operation.stopServiceMessage' => 'Περιμένετε λίγο μέχρι να σταματήσει η υπηρεσία.',
    'operation.restartServiceMessage' => 'Περιμένετε λίγο μέχρι να επανεκκινηθεί η υπηρεσία.',
    'operation.unableFetchFormData' => 'Δεν είναι δυνατή η λήψη δεδομένων μορφής: %%error%%',
    'operation.startActionError' => 'Δεν είναι δυνατή η εκκίνηση της υπηρεσίας: %%error%%',
    'operation.stopActionError' => 'Δεν είναι δυνατή η διακοπή της υπηρεσίας: %%error%%',
    'operation.restartActionError' => 'Δεν είναι δυνατή η επανεκκίνηση της υπηρεσίας: %%error%%',
    'operation.changeStartupActionError' => 'Δεν είναι δυνατή η αλλαγή του τύπου εκκίνησης για την υπηρεσία: %%error%%',
];