<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'branding.title' => 'Εμπορική ταυτότητα Plesk',

    'disable-languages.disableLanguagesSuccess' => 'Οι επιλεγμένες γλώσσες δεν είναι πλέον διαθέσιμες στους χρήστες.',

    'edit-controls.updateSuccess' => 'Οι ρυθμίσεις ενημερώθηκαν με επιτυχία.',

    'edit-interface-view.title' => 'Προβολές περιβάλλοντος εργασίας',
    'edit-interface-view.updateSuccess' => 'Οι ρυθμίσεις ενημερώθηκαν με επιτυχία.',

    'enable-languages.enableLanguagesSuccess' => 'Οι επιλεγμένες γλώσσες είναι διαθέσιμες στους χρήστες.',

    'language-make-default.languageMakeDefaultSuccess' => 'Η επιλεγμένη γλώσσα ορίστηκε ως προεπιλογή για το Plesk.',

    'list-languages.title' => 'Γλώσσες',
    'list-languages.mlsLimitExceeded' => "Η τρέχουσα άδεια χρήσης του Plesk επιτρέπει τη χρήση %%allowedByLicense%% γλωσσών. Αυτήν τη στιγμή έχετε ρυθμίσει %%availableToUsers%% γλώσσες ως διαθέσιμες στους χρήστες, υπερβαίνοντας τον αριθμό που προβλέπει η άδεια. Επιλέξτε τις %%allowedByLicense%% γλώσσες που θέλετε να χρησιμοποιείτε και καταστήστε τις υπόλοιπες μη διαθέσιμες στους χρήστες, κάνοντας κλικ στα εικονίδιά τους στη στήλη 'S'.",
];