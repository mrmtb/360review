<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-sessions.noSessionsSpecified' => 'Επιλέξτε μία ή περισσότερες περιόδους λειτουργίας FTP από τη λίστα.',
    'delete-sessions.sessionsDeleted' => 'Οι επιλεγμένες περίοδοι λειτουργίας διαγράφηκαν.',
    'delete-sessions.sessionsNotDeleted' => 'Ορισμένες από τις επιλεγμένες περιόδους λειτουργίας δεν διαγράφηκαν. Λεπτομέρειες: %%error%%.',

    'list.title' => 'Περίοδοι λειτουργίας FTP',
];