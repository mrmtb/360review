<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'assign-to-subscription.databasesSuccessfullyAssignedToSubscription' => 'Οι βάσεις δεδομένων μετακινήθηκαν στη συνδρομή \'%%subscriptionName%%\'.',
    'assign-to-subscription.databasesNotAssignedToSubscription' => 'Δεν είναι δυνατή η μετακίνηση των βάσεων δεδομένων στη συνδρομή \'%%subscriptionName%%\'.',
    'assign-to-subscription.subscriptionNotFound' => 'Η συνδρομή \'%%name%%\' δεν βρέθηκε.',
    'assign-to-subscription.isNotMainDomain' => 'Το \'%%name%%\' δεν είναι ο κύριος τομέας στη συνδρομή.',

    'settings.title' => 'Ρυθμίσεις φιλοξενίας βάσεων δεδομένων',
    'settings.settingsSaved' => 'Οι ρυθμίσεις φιλοξενίας βάσεων δεδομένων αποθηκεύτηκαν.',

    'refresh.success' => 'Οι πληροφορίες των διακομιστών βάσης δεδομένων ανανεώθηκαν.',
];