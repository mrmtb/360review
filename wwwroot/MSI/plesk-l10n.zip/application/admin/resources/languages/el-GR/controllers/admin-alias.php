<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoAdminAliasActivated' => 'Οι επιλεγμένοι λογαριασμοί διαχειριστή ενεργοποιήθηκαν με επιτυχία.',
    'activate.infoAdminAliasNotActivated' => 'Ορισμένοι από τους επιλεγμένους λογαριασμούς διαχειριστή δεν ενεργοποιήθηκαν.',

    'create.title' => 'Προσθήκη λογαριασμού διαχειριστή',
    'create.infoNewAdminAliasCreated' => 'Ο πρόσθετος λογαριασμός διαχειριστή %%contact%% δημιουργήθηκε με επιτυχία.',

    'deactivate.infoAdminAliasDeactivated' => 'Οι επιλεγμένοι λογαριασμοί διαχειριστή ανεστάλησαν με επιτυχία.',
    'deactivate.infoAdminAliasNotDeactivated' => 'Ορισμένοι από τους επιλεγμένους λογαριασμούς διαχειριστή δεν ανεστάλησαν.',

    'delete.infoAdminAliasDeleted' => 'Οι επιλεγμένοι λογαριασμοί διαχειριστή καταργήθηκαν με επιτυχία.',
    'delete.infoAdminAliasNotDeleted' => 'Ορισμένοι από τους επιλεγμένους λογαριασμούς διαχειριστή δεν καταργήθηκαν.',

    'edit.title' => "%%contact%%",
    'edit.infoNewAdminAliasUpdated' => 'Ο λογαριασμός διαχειριστή ενημερώθηκε με επιτυχία.',

    'list.title' => 'Πρόσθετοι λογαριασμοί διαχειριστή',
    'list.hint' => 'Εδώ μπορείτε να δημιουργήσετε πρόσθετους λογαριασμούς διαχειριστή για τους μηχανικούς τεχνικής υποστήριξης σας, δίνοντάς τους τη δυνατότητα να εκτελούν μια σειρά από διαχειριστικές εργασίες.',
];