<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Ρυθμίσεις εξωτερικού διακομιστή SMTP',
    'index.settingsUpdated' => 'Οι ρυθμίσεις ενημερώθηκαν.',
];