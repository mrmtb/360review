<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Ειδοποιήσεις',

    'email-settings.title' => 'Διεύθυνση ηλ. ταχ.',

    'panel-settings.title' => 'Περιβάλλοντος εργασίας χρήστη του Plesk',
    'panel-settings.notificationSettingsSaved' => 'Οι ρυθμίσεις ειδοποιήσεων αποθηκεύτηκαν με επιτυχία.',

    'panel-notifications-toggle.successfullyEnabled' => 'Η ειδοποίηση "%%title%%" ενεργοποιήθηκε.',
    'panel-notifications-toggle.successfullyDisabled' => 'Η ειδοποίηση "%%title%%" απενεργοποιήθηκε.',

    'template-settings-list.hint' => 'Επιλέξτε ποιες ειδοποιήσεις θέλετε να βλέπετε, ενεργοποιώντας ή απενεργοποιώντας τις.',
    'template-settings-list.name' => 'Τίτλος',
    'template-settings-list.context' => 'Περιβάλλον',
    'template-settings-list.sendToAdmin' => 'Αποστολή στον διαχειριστή',

    'template-settings-form.storagePeriod' => 'Αποθήκευση ειδοποιήσεων για',
    'template-settings-form.days' => 'ημέρες',
];