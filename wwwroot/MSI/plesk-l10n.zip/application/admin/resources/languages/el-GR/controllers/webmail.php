<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Καταχώρηση πρόσθετου webmail',
    'create.infoNewWebmailRegistered' => 'Η νέα υπηρεσία webmail καταχωρήθηκε.',

    'edit.unknownWebmail' => 'Άγνωστο webmail',
    'edit.infoWebmailUpdated' => 'Οι ρυθμίσεις της υπηρεσίας webmail %%name%% ενημερώθηκαν.',

    'index.title' => 'Υπηρεσίες webmail',
    'index.hint' => 'Μπορείτε να χρησιμοποιήσετε οποιαδήποτε άλλη υπηρεσία webmail πέραν αυτών που εγκαθίστανται με το Plesk Installer, δηλαδή το Updater. Καταχωρήστε την επιθυμητή εγκατάσταση webmail στο Plesk χρησιμοποιώντας το παρακάτω κουμπί και θα εμφανιστεί ως διαθέσιμη επιλογή webmail στα προγράμματα φιλοξενίας και τις συνδρομές. Αν θέλετε να αποκρύψετε προσωρινά μια υπηρεσία webmail, απενεργοποιήστε την χρησιμοποιώντας το παρακάτω κουμπί.',
    'index.webmailDeleted' => 'Η καταχώρηση των επιλεγμένων υπηρεσιών webmail καταργήθηκε.',
    'index.webmailNotDeleted' => 'Η καταχώρηση ορισμένων υπηρεσιών webmail δεν καταργήθηκε.',
    'index.webmailEnabled' => 'Οι επιλεγμένες υπηρεσίες webmail ενεργοποιήθηκαν και είναι πλέον διαθέσιμες.',
    'index.webmailNotEnabled' => 'Ορισμένες από τις επιλεγμένες υπηρεσίες webmail δεν ενεργοποιήθηκαν.',
    'index.webmailDisabled' => 'Οι επιλεγμένες υπηρεσίες webmail απενεργοποιήθηκαν και κατέστησαν μη διαθέσιμες.',
    'index.webmailNotDisabled' => 'Ορισμένες από τις επιλεγμένες υπηρεσίες webmail δεν απενεργοποιήθηκαν.',
];