<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'oversell-policy.title' => 'Αλλαγή πολιτικής υπερπώλησης',
    'oversell-policy.pageHint' => 'Από εδώ μπορείτε να αλλάξετε την τρέχουσα πολιτική υπερπώλησής σας.',
    'oversell-policy.oversellPolicyChanged' => 'Η πολιτική υπερπώλησης ενημερώθηκε με επιτυχία.',
    'oversell-policy.oversellPolicyNotChanged' => 'Δεν είναι δυνατή η ενημέρωση της πολιτικής υπερπώλησης.',

    'subscription-overview.title' => 'Επισκόπηση συνδρομής',
    'subscription-overview.pageHint' => 'Αυτή είναι η επισκόπηση της συνδρομής σας και περιλαμβάνει πληροφορίες σχετικά με την ποσότητα χρησιμοποιούμενων πόρων σε σύγκριση με την αρχική κατανομή, την πολιτική υπερπώλησης, τα προνόμια και τις υπηρεσίες που παρέχονται με τη συγκεκριμένη συνδρομή.',
    'subscription-overview.changeOversellPolicyLink' => '[αλλαγή]',
    'subscription-overview.oversellEnabledHint' => 'Η συνδρομή σας επιτρέπει την υπερπώληση πόρων, κάτι που σημαίνει ότι μπορείτε να πωλείτε περισσότερους πόρους από όσους σας παρέχονται αρχικά με τη συνδρομή.  Σε αυτήν την περίπτωση, η δραστηριότητά σας θα διέπεται από καθεστώς πραγματικής χρήσης πόρων και όχι από την αρχική κατανομή πόρων.',
    'subscription-overview.oversellDisableHint' => 'Η συνδρομή σας απαγορεύει την υπερπώληση πόρων, κάτι που σημαίνει ότι μπορείτε να πωλείτε μόνο όσους πόρους σας παρέχονται αρχικά με τη συνδρομή, ανεξαρτήτως του ποσοστού των πόρων που χρησιμοποιείτε στην πραγματικότητα.',
    'subscription-overview.tabResources' => 'Πόροι',
    'subscription-overview.tabPermissions' => 'Δικαιώματα',
    'subscription-overview.resourcesSummaryHint' => 'Αυτή είναι μια σύνοψη των ορίων χρήσης των πόρων που παρέχονται με τη συνδρομή.',
    'subscription-overview.showMoreResources' => 'Εμφάνιση περισσότερων διαθέσιμων πόρων',
    'subscription-overview.hideMoreResources' => 'Εμφάνιση λιγότερων πόρων',
    'subscription-overview.permissionsSummaryHint' => 'Αυτή είναι μια λίστα με τις υπηρεσίες και τα προνόμια που παρέχονται με τη συνδρομή.',
    'subscription-overview.hideMorePermissions' => 'Εμφάνιση λιγότερων δικαιωμάτων',
    'subscription-overview.showMorePermissions' => 'Εμφάνιση περισσότερων δικαιωμάτων',
];