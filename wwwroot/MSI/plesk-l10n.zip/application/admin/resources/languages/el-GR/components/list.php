<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'recordsTotal' => '%%total%% στοιχεία συνολικά',
    'pages' => 'Σελίδες',
    'firstPage' => 'Πρώτη',
    'lastPage' => 'Τελευταία',
    'numberOfItemPerPage' => 'Καταχωρήσεις ανά σελίδα',
    'hideSearch' => 'Απόκρυψη αναζήτησης',
    'showSearch' => 'Εμφάνιση αναζήτησης',
    'buttonSearch' => 'Αναζήτηση',
    'buttonResetSearch' => 'Επαναφορά αναζήτησης',
    'noEntriesFound' => 'Δεν βρέθηκαν στοιχεία.',
    'itemsNotSelected' => 'Επιλέξτε τα στοιχεία πρώτα.',
    'messageBoxButtonYes' => 'Ναι',
    'messageBoxButtonNo' => 'όχι',
    'messageBoxButtonOk' => 'OK',
    'allItems' => 'Όλες',
];