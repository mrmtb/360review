<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'oversell-policy.title' => 'Änderung der Überbuchungsregeln',
    'oversell-policy.pageHint' => 'Hier können Sie Ihre aktuellen Überbuchungsregeln ändern.',
    'oversell-policy.oversellPolicyChanged' => 'Überbuchungsregeln wurden erfolgreich aktualisiert.',
    'oversell-policy.oversellPolicyNotChanged' => 'Überbuchungsregeln konnten nicht aktualisiert werden.',

    'subscription-overview.title' => 'Abonnement-Zusammenfassung',
    'subscription-overview.pageHint' => 'Dies ist eine Zusammenfassung Ihres Abonnements. Sie beinhaltet Informationen zu den verbrauchten vs. bereitgestellten Ressourcen, Überbuchungsregeln, Berechtigungen und Services, die zu dem Abonnement gehören.',
    'subscription-overview.changeOversellPolicyLink' => '[ändern]',
    'subscription-overview.oversellEnabledHint' => 'Ihr Abonnement erlaubt die Überbuchung von Ressourcen, was bedeutet, dass Sie mehr Ressourcen verkaufen können als in Ihrem Abonnement zugewiesen wurden. In diesem Fall wird der tatsächliche Ressourcenverbrauch nicht von den anfänglich zugewiesen Ressourcen beeinflusst.',
    'subscription-overview.oversellDisableHint' => 'Ihre Abonnement lässt die Überbuchung von Ressourcen nicht zu. Das bedeutet, dass Sie nur so viele Ressourcen verkaufen können wie anfangs im Abonnement zugewiesen wurden, unabhängig davon, wie viele dieser Ressourcen tatsächlich verwendet werden.',
    'subscription-overview.tabResources' => 'Ressourcen',
    'subscription-overview.tabPermissions' => 'Berechtigungen',
    'subscription-overview.resourcesSummaryHint' => 'Dies ist eine Zusammenfassung, die einen Überblick über die Nutzung der mit diesem Abonnement bereitgestellten Ressourcen gibt.',
    'subscription-overview.showMoreResources' => 'Weitere verfügbare Ressourcen anzeigen',
    'subscription-overview.hideMoreResources' => 'Weniger Ressourcen anzeigen',
    'subscription-overview.permissionsSummaryHint' => 'Hier werden die Services und Berechtigungen des Abonnements aufgelistet.',
    'subscription-overview.hideMorePermissions' => 'Weniger Berechtigungen anzeigen',
    'subscription-overview.showMorePermissions' => 'Mehr Berechtigungen anzeigen',
];