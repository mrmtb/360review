<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoDomainActivated' => 'Die ausgewählten Domains und Aliase wurden aktiviert.',
    'activate.errorDomainNotActivated' => 'Einige der ausgewählten Domains oder Aliase wurden nicht aktiviert.',
    'activate.domainStillSuspended' => 'Die Domain kann nicht aktiviert werden: %%reason%%',
    'activate.domainStatusOffByAdmin' => 'Die Domain wurde vom Administrator gesperrt.',
    'activate.domainStatusOffWithParent' => 'Entweder der Domain-Inhaber oder dessen Abonnement ist gesperrt.',
    'activate.domainStatusOffExpired' => 'Das dazugehörige Abonnement ist abgelaufen.',
    'activate.domainStatusOffBackupRestore' => 'Die Domain ist vorübergehend für ein Backup oder eine Wiederherstellung gesperrt.',
    'activate.domainStatusOff' => 'Die Domain ist gesperrt.',
    'activate.aliasStillSuspended' => 'Der Alias kann nicht aktiviert werden: Die Zieldomain ist gesperrt.',

    'add-domain-alias.noDomains' => 'Ein Alias kann nicht erstellt werden: Keine Domains verfügbar.',

    'add-domain.noDomains' => 'Eine Add-on-Domain kann nicht erstellt werden: Keine Domains verfügbar.',

    'add-subdomain.noDomains' => 'Eine Subdomain kann nicht erstellt werden: Keine Domains verfügbar.',

    'disable.infoDomainDisabled' => 'Die ausgewählten Domains wurden deaktiviert.',
    'disable.errorDomainNotDisabled' => 'Einige der ausgewählten Domains wurden nicht deaktiviert.',

    'list.title' => 'Domains',
    'list.customerLinkTitle' => 'ein Kundenkonto erstellen',
    'list.subscriptionLinkTitle' => 'Ihr eigenes Abonnement erstellen',

    'suspend.infoDomainSuspended' => 'Die ausgewählten Domains wurden gesperrt.',
    'suspend.errorDomainNotSuspended' => 'Einige der ausgewählten Domains wurden nicht gesperrt.',
];