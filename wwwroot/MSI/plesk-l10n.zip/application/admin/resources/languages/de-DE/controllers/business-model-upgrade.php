<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'admin-customers-target-list.title' => 'Kunden des Administrators, die zur Übernahme bereit sind',
    'admin-customers-target-list.hint-t1s1' => 'Dies ist eine Liste mit Kunden, die anhand von Kunden des alten Geschäftsmodells erstellt wurden. Diesen Kunden war nicht erlaubt, Domaingrenzen zu ändern und sie besaßen eine Domain vor dem Upgrade.',
    'admin-customers-target-list.hint-t1s2' => 'Dies ist eine Liste mit Kunden, die anhand von Kunden des alten Geschäftsmodells erstellt wurden. Diesen Kunden war erlaubt, Domaingrenzen zu ändern und sie besaßen eine Domain vor dem Upgrade.',
    'admin-customers-target-list.hint-t1s3' => 'Dies ist eine Liste mit Kunden, die anhand von Kunden des alten Geschäftsmodells erstellt wurden. Diesen Kunden war nicht erlaubt, Domains zu erstellen sowie Domaingrenzen zu ändern und sie besaßen mehrere Domains vor dem Upgrade.',
    'admin-customers-target-list.hint-t1s6' => 'Dies ist eine Liste mit Kunden, die anhand von Kunden des alten Geschäftsmodells erstellt wurden. Diesen Kunden war erlaubt, Domains zu erstellen sowie Domaingrenzen zu ändern und sie besaßen mehrere Domains vor dem Upgrade.',

    'admin-subscriptions-target-list.title' => 'Abonnement des Administrators, das zur Übernahme bereit ist',
    'admin-subscriptions-target-list.hint' => 'Dies ist eine Liste mit Abonnements, die anhand von Domains erstellt wurden, die (a) zu einem Administrator gehörten und (b) für die vor dem Upgrade ein Domainadministratorkonto aktiviert wurde.',

    'bunch.title' => 'Wechsel auf das neue Plesk Business-Modell abschließen',
    'bunch.noActionsDescription' => 'Es sind keine Kunden und Abonnements mehr in dem System vorhanden, die den allgemeinen Szenarien entsprechen. Das bedeutet, dass Sie auf dieser Registerkarte keine Aktion mehr durchführen müssen. Bitte gehen Sie zur nächsten Registerkarte und übernehmen Sie die verbleibenden Kunden.',
    'bunch.description' => 'Die Methode der Ressourcenverteilung in Plesk 10 und neueren Versionen unterscheidet sich von vorherigen Versionen: Ab Version 10 haben Kunden keine eigenen Ressourcen, wie es in Plesk 8 und 9 der Fall war. Sie erhalten sie stattdessen durch Abonnements. Im Moment existieren mehrere Kunden mit Legacy-Ressourcen, die richtig übernommen werden müssen, damit sie in das neue Plesk Modell passen. Basierend auf der allgemein üblichen Nutzung von Plesk wurden diese Kunden analysiert und es wurde eine Liste mit empfohlenen Aktionen für die Übernahme erstellt (siehe unten). Sie können anhand der Empfehlungen fortfahren oder ein Übernahmeschema pro Kunden auswählen. Sobald ein Kunde in das neue Modell übernommen wurde, verschwindet er aus der Liste.',
    'bunch.help' => 'Erfahren Sie mehr über die Übernahme.',
    'bunch.applyed' => 'Die ausgewählten Kunden und Abonnements wurden übernommen.',
    'bunch.failed' => 'Die ausgewählten Kunden und Abonnements können nicht übernommen werden.',

    'customers.title' => 'Wechsel auf das neue Plesk Business-Modell abschließen: Selektive Übernahme für Kunden',
    'customers.description' => 'Dies ist eine vollständige Liste mit Kunden, die übernommen werden müssen. Zusammen mit den Konten, die den allgemeinen Szenarien entsprechen, werden auch die mit ungleichen Einstellungen aufgeführt, für die keine empfohlenen Aktionen vorhanden sind. Für diese Kunden müssen Sie selbst ein entsprechendes Übernahmeschema auswählen, basierend auf den vorigen Kundeneinstellungen, wie beispielsweise Grenzen, Berechtigungen, Anzahl an Domains und so weiter. Um die zuvor festgelegten Grenzen und Berechtigungen eines Kunden anzuzeigen, klicken Sie auf den Namen des Kunden und dann \'Meine Ressourcen\' in einer Liste mit den Kunden-Abonnements.',
    'customers.help' => 'Erfahren Sie mehr über die Übernahme.',

    'manual-customer-solution.appliedInfo' => 'Die ausgewählten Kunden wurden übernommen.',
    'manual-customer-solution.notAppliedInfo' => 'Alle oder einige der ausgewählten Kunden wurden nicht übernommen.',

    'manual-subscription-solution.appliedInfo' => 'Die ausgewählten Abonnements wurden übernommen.',
    'manual-subscription-solution.notAppliedInfo' => 'Alle oder einige der ausgewählten Abonnements wurden nicht übernommen.',

    'notes.nonApplicableCustomers' => "%%count%% Kunden passen in keines der allgemeinen Szenarien, daher gibt es keine empfohlenen Aktionen für sie. Zu Übernahme der Konten gehen Sie folgendermaßen vor: %%link%%.",
    'notes.nonApplicableSubscriptions' => "%%count%% Abonnements passen in keines der allgemeinen Szenarien, daher gibt es keine empfohlenen Aktionen für sie. Zu Übernahme der Abonnements gehen Sie folgendermaßen vor: %%link%%.",
    'notes.manualCustomersUpgradeLink' => 'wählen Sie ein Kundenschema für Sie aus',
    'notes.manualSubscriptionsUpgradeLink' => 'wählen Sie ein Kundenschema für Sie aus',

    'reseller-customers-target-list.title' => 'Kunden des Resellers, die zur Übernahme bereit sind',
    'reseller-customers-target-list.hint-t2s1' => 'Dies ist eine Liste mit Kunden, die anhand von Kunden des alten Geschäftsmodells erstellt wurden. Diesen Kunden war nicht erlaubt, Domaingrenzen zu ändern und sie besaßen eine Domain vor dem Upgrade.',
    'reseller-customers-target-list.hint-t2s2' => 'Dies ist eine Liste mit Kunden, die anhand von Kunden des alten Geschäftsmodells erstellt wurden. Diesen Kunden war erlaubt, Domaingrenzen zu ändern und sie besaßen eine Domain vor dem Upgrade.',
    'reseller-customers-target-list.hint-t2s3' => 'Dies ist eine Liste mit Kunden, die anhand von Kunden des alten Geschäftsmodells erstellt wurden. Diesen Kunden war nicht erlaubt, Domains zu erstellen sowie Domaingrenzen zu ändern und sie besaßen mehrere Domains vor dem Upgrade.',
    'reseller-customers-target-list.hint-t2s6' => 'Dies ist eine Liste mit Kunden, die anhand von Kunden des alten Geschäftsmodells erstellt wurden. Diesen Kunden war erlaubt, Domains zu erstellen sowie Domaingrenzen zu ändern und sie besaßen mehrere Domains vor dem Upgrade.',

    'reseller-subscriptions-target-list.title' => 'Abonnements des Resellers, die zur Übernahme bereit sind',
    'reseller-subscriptions-target-list.hint' => 'Dies ist eine Liste mit Abonnements, die anhand von Domains erstellt wurden, die (a) zu Resellern gehörten und (b) für die vor dem Upgrade ein Domainadministratorkonto aktiviert wurde.',

    'subscriptions.title' => 'Wechsel auf das neue Plesk Business-Modell abschließen: Selektive Übernahme für Abonnements',
    'subscriptions.description' => 'Das ist eine Liste mit Abonnements, die zur Übernahme bereit sind. Sie beinhaltet dieselben Abonnements wie die Seite mit den Empfohlenen Aktionen, aber hier können Sie das Übernahmeschema auswählen, das am besten zu einem bestimmten Abonnement passt. Das sind Abonnements, die anhand von Domains erstellt wurden, die (a) zu einem Administrator oder Reseller gehört haben und (b) für die ein Domainadministratorkonto aktiviert wurde.',
    'subscriptions.help' => 'Erfahren Sie mehr über die Übernahme.',

    'tabs.bunch' => 'Empfohlene Aktionen',
    'tabs.customers' => 'Benutzerdefinierte Übernahme von Kunden',
    'tabs.subscriptions' => 'Benutzerdefinierte Übernahme von Abonnements',
];