<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Sitzungsverwaltung',

    'remove.sessionsDeleted' => 'Die ausgewählten Sitzungen wurden erfolgreich entfernt.',

    'settings.title' => 'Sitzungseinstellungen',
    'settings.settingsUpdated' => 'Die Einstellungen wurden erfolgreich geändert.',
];