<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'eula.title' => 'WebPros Endbenutzer-Lizenzvertrag',
    'eula.popupTitle' => 'EULA',
    'eula.updatePopupTitle' => 'Aktualisierung des Endbenutzer-Lizenzvertrags',
    'eula.popupDescription' => 'Lesen Sie sich den Endbenutzer-Lizenzvertrag durch und akzeptieren Sie ihn, um das Produkt weiter verwenden zu können.',
    'eula.updatePopupDescription' => 'Der Endbenutzer-Lizenzvertrag von WebPros wurde aktualisiert. Lesen Sie sich den aktualisierten Endbenutzer-Lizenzvertrag durch und akzeptieren Sie ihn, um das Produkt weiter verwenden zu können.',
    'eula.buttonAccept' => 'Akzeptieren',
    'eula.buttonDecline' => 'Ablehnen',
];