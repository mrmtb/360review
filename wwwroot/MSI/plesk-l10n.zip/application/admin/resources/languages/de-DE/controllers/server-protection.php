<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-filter.title' => 'Jail-Filter hinzufügen',
    'add-filter.filterAdded' => 'Der Jail-Filter wurde hinzugefügt.',
    'add-filter.errorFilterNotAdded' => 'Der Jail-Filter kann nicht hinzugefügt werden: %%error%%.',

    'add-jail.title' => 'Jail hinzufügen',
    'add-jail.jailAdded' => 'Die Jail wurde hinzugefügt.',

    'add-trusted-ip.title' => 'Vertrauenswürdige IP-Adresse hinzufügen',
    'add-trusted-ip.trustedListTitle' => 'Vertrauenswürdige IP-Adressen',
    'add-trusted-ip.ipAdded' => 'Die IP-Adresse wurde zur Liste der vertrauenswürdigen IP-Adressen hinzugefügt.',
    'add-trusted-ip.errorIpNotAdded' => 'Die IP-Adresse kann nicht hinzugefügt werden: %%error%%.',

    'edit-trusted-ip.title' => 'Bearbeiten Sie die Beschreibung für %%ip%%',
    'edit-trusted-ip.ipEdited' => 'Die Beschreibung der IP-Adresse wurde aktualisiert.',
    'edit-trusted-ip.ipAddressNotFound' => 'Die IP-Adresse wurde nicht auf der Liste vertrauenswürdiger Netzwerke gefunden.',
    'edit-trusted-ip.errorIpNotEdited' => 'Sie können die IP-Adresse nicht bearbeiten: %%error%%.',

    'delete-banned-ips.infoBannedIpsDeleted' => 'Die ausgewählten IP-Adressen wurden von der Liste der gesperrten Adressen entfernt.',
    'delete-banned-ips.infoBannedIpsNotDeleted' => 'Einige IP-Adressen können nicht von der Liste der gesperrten Adressen entfernt werden: %%error%%.',

    'delete-filters.infoFiltersDeleted' => 'Die ausgewählten Jail-Filter wurden entfernt.',
    'delete-filters.errorFiltersNotDeleted' => 'Die ausgewählten Filter können nicht entfernt werden: %%error%%.',
    'delete-filters.errorFiltersBuiltIn' => 'Die integrierten Filter können nicht entfernt werden.',

    'delete-jail.infoJailDeleted' => 'Die Jail wurde entfernt.',
    'delete-jail.errorJailNotDeleted' => 'Die Jail kann nicht entfernt werden: %%error%%.',
    'delete-jail.errorJailsBuiltIn' => 'Die integrierten Jails können nicht entfernt werden.',

    'delete-jails.infoJailsDeleted' => 'Die ausgewählten Jails wurden entfernt.',
    'delete-jails.errorJailsNotDeleted' => 'Die ausgewählten Jails können nicht entfernt werden: %%error%%.',
    'delete-jails.errorJailsBuiltIn' => 'Die integrierten Jails können nicht entfernt werden.',

    'delete-trusted-ips.infoTrustedIpsDeleted' => 'Die ausgewählten IP-Adressen wurden von der Liste der vertrauenswürdigen Adressen entfernt.',
    'delete-trusted-ips.infoTrustedIpsNotDeleted' => 'Einige IP-Adressen können nicht von der Liste der vertrauenswürdigen Adressen entfernt werden: %%error%%.',
    'delete-trusted-ips.warningTrustedIpsPresentOnInterfaces' => 'Einige der vertrauenswürdigen IPs, die gelöscht wurden, sind in Netzwerkschnittstellen zu finden: %%ips%%. Möglicherweise wurden sie versehentlich gesperrt und dies führt nun zu Problemen beim Zugriff auf Websites oder Dienste.',

    'disable-jails.infoJailsDisabled' => 'Die ausgewählten Jails wurden ausgeschaltet.',
    'disable-jails.errorJailsNotDisabled' => 'Die ausgewählten Jails können nicht ausgeschaltet werden: %%error%%.',

    'edit-filter.title' => 'Jail-Filter bearbeiten',
    'edit-filter.filterSaved' => 'Der Jail-Filter wurde gespeichert.',
    'edit-filter.errorFilterNotSaved' => 'Der Jail-Filter kann nicht gespeichert werden: %%error%%.',
    'edit-filter.errorFilterNotEditable' => 'Der Filter kann nicht geändert werden.',

    'edit-jail.title' => '%%name%%',
    'edit-jail.jailSaved' => 'Die Jail-Einstellungen wurden gespeichert.',
    'edit-jail.errorJailNotEditable' => 'Jail kann nicht geändert werden.',

    'enable-jails.infoJailsEnabled' => 'Die ausgewählten Jails wurden eingeschaltet.',
    'enable-jails.errorJailsNotEnabled' => 'Die ausgewählten Jails können nicht eingeschaltet werden: %%error%%.',

    'filters-list.title' => 'Jail-Filter',

    'index.title' => 'Sperren von IP-Adressen',
    'index.banListTab' => 'Gesperrte IP-Adressen',
    'index.trustedListTab' => 'Vertrauenswürdige IP-Adressen',
    'index.jailListTab' => 'Jails',
    'index.settingsTab' => 'Einstellungen',
    'index.logListTab' => 'Protokolle',
    'index.jailNotFound' => 'Die Jail %%name%% konnte nicht gefunden werden.',
    'index.filterNotFound' => 'Der Filter %%name%% konnte nicht gefunden werden.',
    'index.logFileNotFound' => 'Die Protokolldatei konnte nicht gefunden werden.',
    'index.tooManyDomains' => 'Fail2Ban funktioniert möglicherweise nicht einwandfrei, wenn es zu viele Domains gibt und Fail2Ban zu viele Protokolldateien überwachen muss.',
    'index.errorServiceFailed' => 'Der Service zum Sperren von IP-Adressen (Fail2Ban) ist fehlgeschlagen und funktioniert möglicherweise nicht korrekt. %%link%%',
    'index.restartLink' => 'Neustart versuchen',

    'jail-list.failed' => 'Die Liste der Jails kann nicht abgerufen werden: %%error%%.',

    'log-view.fileIsEmpty' => 'Die Datei ist leer.',

    'move-to-trusted.infoTrustedIpsAdded' => 'Die ausgewählten IP-Adressen wurden zur Liste der vertrauenswürdigen Adressen hinzugefügt.',
    'move-to-trusted.infoTrustedIpsNotAdded' => 'Einige IP-Adressen können nicht zur Liste der vertrauenswürdigen Adressen hinzugefügt werden: %%error%%.',

    'overview-jail.title' => '%%name%%',
    'overview-jail.pageHint' => 'Hier können Sie detaillierte Informationen über die Jail einsehen.',
    'overview-jail.buttonEditJail' => 'Einstellungen ändern',
    'overview-jail.hintEditJail' => 'Ändern Sie die Einstellungen dieser Jail.',
    'overview-jail.buttonDisableJail' => 'Deaktivieren',
    'overview-jail.hintDisableJail' => 'Schalten Sie diese Jail aus.',
    'overview-jail.buttonActivateJail' => 'Aktivieren',
    'overview-jail.hintActivateJail' => 'Schalten Sie diese Jail ein.',
    'overview-jail.buttonRemoveJail' => 'Entfernen',
    'overview-jail.hintRemoveJail' => 'Entfernen Sie diese Jail.',
    'overview-jail.fieldSatatus' => 'Status',
    'overview-jail.fieldParameters' => 'Einstellungen',
    'overview-jail.enabled' => 'Aktiv',
    'overview-jail.disabled' => 'Inaktiv',
    'overview-jail.banListHint' => 'Von dieser Jail blockierte IP-Adressen:',

    'restart.success' => 'Der Neustart des Service kann einige Minuten dauern.',
    'restart.failed' => 'Der Service konnte nicht neu gestartet werden.',

    'settings.settingsSaved' => 'Die Einstellungen wurden gespeichert.',
    'settings.errorSettingsNotSaved' => 'Die Einstellungen können nicht gespeichert werden: %%error%%.',
    'settings.errorServiceFailed' => 'Die Ausführung des Service zum Sperren von IP-Adressen (Fail2Ban) ist fehlgeschlagen: %%error%%',

    'toggle-jail.infoJailEnabled' => 'Die Jail wurde eingeschaltet.',
    'toggle-jail.infoJailDisabled' => 'Die Jail wurde ausgeschaltet.',
    'toggle-jail.errorJailNotEnabled' => 'Die Jail kann nicht eingeschaltet werden: %%error%%.',
    'toggle-jail.errorJailNotDisabled' => 'Die Jail kann nicht ausgeschaltet werden: %%error%%.',

    'add-banned-ip.title' => 'IP-Adresse blockieren',
    'add-banned-ip.bannedListTitle' => 'Gesperrte IP-Adressen',
    'add-banned-ip.ipAdded' => 'Die IP-Adresse wurde zur Liste der blockierten IP-Adressen hinzugefügt.',
    'add-banned-ip.errorIpNotAdded' => 'Die IP-Adresse kann nicht blockiert werden: %%error%%.',
];