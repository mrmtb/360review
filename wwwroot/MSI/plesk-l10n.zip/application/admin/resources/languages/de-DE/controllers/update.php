<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Plesk Installer',
    'index.autoinstallerRedirectError' => 'Der Plesk Installer kann nicht gestartet werden. Fehler: %%message%%',

    'product.title' => 'Plesk Installer',
    'product.autoinstallerRedirectError' => 'Der Plesk Installer kann nicht gestartet werden. Fehler: %%message%%',

    'settings.title' => 'Update-Einstellungen',
    'settings.settingsUpdated' => 'Die Update-Einstellungen wurden geändert.',
];