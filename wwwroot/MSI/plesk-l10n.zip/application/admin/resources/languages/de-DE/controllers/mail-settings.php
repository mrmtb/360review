<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Serverweite E-Mail-Einstellungen',
    'index.preferencesTab' => 'Einstellungen',
    'index.spamFilteringTab' => 'Spamfilterung',
    'index.antivirusTab' => 'Virenschutz',
    'index.blockedDomainsTab' => 'Blacklist',
    'index.whiteListTab' => 'Whitelist',
    'index.queueTab' => 'E-Mail-Warteschlange',
    'index.statisticsTab' => 'Statistiken',
    'index.smarthostTab' => 'Smarthost',

    'mail-lists.title' => 'Mailinglisten-Manager konfigurieren',
    'mail-lists.configured' => 'Der Mailman-Mailinglistenmanager wurde konfiguriert. Der Button \'Mailinglistenserver einrichten\' wird nicht mehr auf der Seite \'Tools & Einstellungen\'\\ angezeigt.', // PFU
    'mail-lists.noLocalhostInServerWhiteList' => 'Um Mailinglisten verwenden zu können, muss localhost (127.0.0.0/8, ::1/128) in der Whitelist des Mailservers vorhanden sein. Jedoch sollten Sie für die Verwendung der Postausgangskontrolle localhost nicht in die Whitelist aufnehmen. Wenn Sie also die Postausgangskontrolle aktiviert haben, können Sie als Kompromiss für das Postfach die E-Mail-Weiterleitung anstelle von Mailinglisten verwenden.',
    'mail-lists.noLocalhostInServerWhiteListIpv4' => 'Um Mailinglisten verwenden zu können, muss localhost in der Whitelist des Mailservers vorhanden sein. Jedoch sollten Sie für die Verwendung der Postausgangskontrolle localhost nicht in die Whitelist aufnehmen. Wenn Sie also die Postausgangskontrolle aktiviert haben, können Sie als Kompromiss für das Postfach die E-Mail-Weiterleitung anstelle von Mailinglisten verwenden. Beachten allerdings, dass es jetzt keine IPv4-localhost-Adressen (127.0.0.0/8) in der Whitelist gibt, d.h. die Postausgangskontrolle wird für IPv4-Adressen funktionieren.',
    'mail-lists.noLocalhostInServerWhiteListIpv6' => 'Um Mailinglisten verwenden zu können, muss localhost in der Whitelist des Mailservers vorhanden sein. Jedoch sollten Sie für die Verwendung der Postausgangskontrolle localhost nicht in die Whitelist aufnehmen. Wenn Sie also die Postausgangskontrolle aktiviert haben, können Sie als Kompromiss für das Postfach die E-Mail-Weiterleitung anstelle von Mailinglisten verwenden. Beachten allerdings, dass es jetzt keine IPv6-localhost-Adressen (::1/128) in der Whitelist gibt, d.h. die Postausgangskontrolle wird für IPv6-Adressen funktionieren.',
    'mail-lists.mailingListSoftwareNotInstalled' => 'Mailinglisten-Software ist nicht installiert.',
    'mail-lists.mailingListSoftwareAlreadyConfigured' => 'Mailinglisten-Software ist bereits konfiguriert.',

    'customize-mailbox-quota-warning.title' => 'Personalisierung der Warnung zum Postfachkontingent',
    'customize-mailbox-quota-warning.successMessage' => 'Warnmeldung zum Postfachkontingent wurde geändert.',

    'customize-mailbox-quota-warning-form.subject' => 'Betreff',
    'customize-mailbox-quota-warning-form.message' => 'Nachricht',
    'customize-mailbox-quota-warning-form.tooLongMessage' => "Zu lange Nachricht. Maximale Länge: %max% Zeichen",
];