<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Einstellungen für externen SMTP-Server',
    'index.settingsUpdated' => 'Die Einstellungen wurden aktualisiert.',
];