<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Domainnamen hinzufügen',
    'add.domainAdded' => 'Der Domainname %%domain%% wurde erfolgreich zur Liste der unzulässigen Namen hinzugefügt.',

    'disable.listDisabled' => 'Die Überprüfung auf unzulässige Domainnamen wurde ausgeschaltet.',

    'edit.title' => '%%name%%',
    'edit.domainUpdated' => 'Der Domainname %%domain%% wurde erfolgreich aktualisiert.',

    'enable.listEnabled' => 'Die Überprüfung auf unzulässige Domainnamen wurde eingeschaltet.',

    'list.title' => 'Unzulässige Domainnamen',
    'list.hint' => 'Hier können Sie die Liste der unzulässigen Domainnamen verwalten. Diese enthält die bekanntesten Domains. Wenn Sie die Überprüfung auf unzulässige Domainnamen einschalten (durch Klicken auf "Aktivieren"), können Nutzer keine Domains mit den Namen aus dieser Liste erstellen. Eine derartige Einschränkung ist zum Beispiel nützlich, um das Abfangen von E-Mals zu verhindern. Wenn die Überprüfung ausgeschaltet ist, können E-Mail-Nachrichten, die von Ihren Kunden an rechtmäßige Unternehmen gesendet werden, von denjenigen Kunden abgefangen werden, die gleichnamige Domains eingerichtet haben.',
    'list.warningLisDisabled' => 'Die Überprüfung auf unzulässige Domainnamen ist ausgeschaltet.',

    'remove.domainRemoved' => 'Die ausgewählten Domainnamen wurden entfernt.',
    'remove.domainNotRemoved' => 'Einige der ausgewählten Domainnamen wurden nicht entfernt.',
    'remove.unableRemove' => 'Einige der angegebenen Domainnamen wurden nicht entfernt.',
];