<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'SSL/TLS-Zertifikat hinzufügen',
    'add.enterCertificateName' => 'Geben Sie den Zertifikatsnamen ein.',

    'delete.infoSslCertificatesDeleted' => 'SSL/TLS-Zertifikate wurden entfernt.',
    'delete.infoSslCertificatesNotDeleted' => 'Die SSL/TLS-Zertifikate können nicht entfernt werden.',
    'delete.certificateUsedAsDefault' => 'Eines der Zertifikate, die Sie löschen möchten, wird als Standardzertifikat verwendet.',
    'delete.certificateAssignedOnIp' => 'Eines oder mehrere Zertifikate sind den IP-Adressen/Domains zugewiesen.',
    'delete.certificateUsedByPanel' => 'Eines der Zertifikate, die Sie löschen möchten, wird zum Schutz von Plesk verwendet.',
    'delete.certificateUsedByMailServer' => 'Eines der Zertifikate, die Sie löschen möchten, wird zum Schutz des Mailservers verwendet.',

    'edit.title' => 'Eigenschaften von SSL/TLS-Zertifikat %%name%% ändern',
    'edit.enterCertificateName' => 'Geben Sie den Zertifikatsnamen ein.',

    'list.title' => 'SSL/TLS-Zertifikate',
    'list.certificateFound' => 'Der private Schlüssel (Name: %%name%%) für das hochgeladene Zertifikat wurde nicht gefunden. Das Zertifikat wurde erfolgreich hinzugefügt.',
    'list.certificatesList' => 'Liste der Zertifikate im Serverpool',
    'list.certificatesListHint' => 'Dies ist die Liste der Zertifikate im Serverpool.',
    'list.currentCertificates' => 'Derzeit zum Schutz des Plesk Servers verwendete Zertifikate',
    'list.currentCertificatesHint' => 'Derzeit zum Schutz des Plesk Servers und Mailservers verwendete Zertifikate',
    'list.pleskCertificate' => 'Zertifikat zum Schutz von Plesk',
    'list.mailServerCertificate' => 'Zertifikat zum Schutz von E-Mails',
    'list.serverPoolCertificateDescription' => '%%name%% aus Serverpool.',
    'list.domainCertificateDescription' => '%%name%% von %%domain%%.',
    'list.change' => '[Ändern]',
    'list.none' => 'Unbekannt.',

    'secure-mail-server.title' => 'Mailserver schützen',
    'secure-mail-server.hint' => 'Wählen Sie ein Zertifikat zum Schutz des Mailservers aus.',
    'secure-mail-server.mailServerCertificateSet' => 'Das Zertifikat %%name%% wurde erfolgreich zum Schutz des Mailservers eingerichtet.',
    'secure-mail-server.mailServerNotInstalled' => 'Der E-Mail-Service ist nicht installiert.',

    'secure-panel.title' => 'Plesk schützen',
    'secure-panel.hint' => 'Wählen Sie ein Zertifikat zum Schutz von Plesk aus.',
    'secure-panel.panelCertificateSet' => 'Das Zertifikat %%name%% wurde erfolgreich zum Schutz von Plesk eingerichtet.',
];