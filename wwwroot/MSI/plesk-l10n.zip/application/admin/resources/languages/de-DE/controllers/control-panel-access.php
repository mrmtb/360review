<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-network.title' => 'Netzwerk hinzufügen',
    'add-network.added' => 'Das Netzwerk %%address%% wurde hinzugefügt.',

    'delete-network.noNetworksSpecified' => 'Wählen Sie ein oder mehrere Netzwerke aus der Liste der Beschränkungen für IP-Adressen aus.',
    'delete-network.networksDeleted' => 'Die ausgewählten Netzwerke wurden gelöscht.',
    'delete-network.networksNotDeleted' => 'Einige der ausgewählten Netzwerke wurden nicht gelöscht. Details: %%error%%.',

    'edit-network.title' => 'Netzwerkbearbeitung',
    'edit-network.updated' => 'Das Netzwerk %%address%% wurde aktualisiert.',

    'list.title' => 'Verwaltung von IP-Zugriffsbeschränkungen',
    'list.currentIpAddressDenied' => 'Die Richtlinie für Zugriffsbeschränkungen und die Liste der Netzwerke erlauben die Anmeldung mit Administratorberechtigungen nicht von Ihrer IP-Adresse %%remoteAddress%%.',
    'list.allowHint' => 'Der Zugriff auf Plesk mit Administratorberechtigungen ist erlaubt, mit Ausnahme der Netzwerke in der Liste.',
    'list.denyHint' => 'Der Zugriff mit Administratorberechtigungen von hier nicht aufgelisteten Netzwerken auf Plesk ist nicht zulässig.',

    'settings.title' => 'Einstellungen der IP-Zugriffsbeschränkung',
    'settings.settingsSaved' => 'Die Richtlinie für IP-Zugriffsbeschränkungen wurde gespeichert.',
];