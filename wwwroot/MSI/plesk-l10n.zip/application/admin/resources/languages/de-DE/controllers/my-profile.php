<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-password.title' => "Administratorpasswort ändern",
    'change-password.passwordChanged' => 'Das Administratorpasswort wurde geändert.',

    'index.personalInfoTitle' => "Administrator-Profile bearbeiten",
    'index.successMessage' => "Ihr Profil wurde aktualisiert.",
    'index.aliasInfoTitle' => 'Informationen zum zusätzlichen Administratorkonto',
    'index.aliasInfoUpdated' => 'Die persönlichen Informationen des zusätzlichen Administratorkontos wurden aktualisiert.',
];