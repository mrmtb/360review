<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'acl-records.title' => 'Transferbeschränkungen-Template',

    'add-acl-record.title' => 'IP-Adresse hinzufügen',
    'add-acl-record.success' => 'Die angegebenen IP-Adressen wurden hinzugefügt.',

    'delete-acl-record.success' => 'Die ausgewählten IP-Adressen wurden entfernt.',

    'index.title' => 'DNS-Einstellungen',

    'records.title' => 'Vorlage für Zoneneintrag',

    'reset-settings.success' => 'Die Standardeinstellungen wurden wiederhergestellt.',

    'settings.title' => 'Serverweite Einstellungen',
    'settings.success' => 'Die Einstellungen wurden aktualisiert.',

    'soa-record.title' => 'Vorlage für Zoneneinstellungen',

    'restore-default.title' => 'Wiederherstellen des Standard-DNS-Zonen-Templates',
    'restore-default.text' => 'Bitte bestätigen Sie, dass Sie die Standardkonfiguration des DNS-Zonen-Templates wiederherstellen wollen.',

    'soa-sync.title' => 'SOA-Einstellungen für alle vorhandenen Domains überschreiben',
    'soa-sync.text' => 'Sollen die SOA-Einträge aller gehosteten Domains aktualisiert werden, indem die Änderungen aus dem SOA-Template übernommen werden?',

    'sync.title' => 'Änderungen des DNS-Templates anwenden',
    'sync.type-option' => 'Wählen Sie eines von Folgendem',
    'sync.safe' => 'Änderungen auf ungeänderte Zonen anwenden. Wenn eine Zone angepasst wurde (neue Einträge hinzugefügt oder vorhandene geändert), wendet Plesk die Änderungen aus dem Template nicht auf solche Zonen an.',
    'sync.force' => 'Änderungen auf alle Zonen anwenden. Plesk wird die Änderungen aus dem Template auf alle DNS-Zonen anwenden, einschließlich angepasster Zonen. Beachten Sie, dass von Benutzern modifizierte Einträge immer unverändert bleiben. Wenn das Template zum Beispiel einen Eintrag enthält, der bereits von einem Kunden hinzugefügt wurde, behält Plesk den Eintrag des Kunden.',

    'external-dns.title' => 'Externer DNS',
    'external-dns.hint' => 'Hier können Sie externe DNS-Server konfigurieren',
    'external-dns.success' => 'gespeichert',
    'external-dns.configured' => 'Konfiguriert',
    'external-dns.notConfigured' => 'Nicht konfiguriert',
    'external-dns.useExtension' => 'Verwenden Sie diese Erweiterung',

    'external-dns-edit.title' => 'Externer DNS',
];