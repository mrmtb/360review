<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

$messages = [
    'accessDenied' => 'Sitejet Builder ist nicht in Ihrem Abonnement enthalten. Um Sitejet Builder zu aktivieren, wenden Sie sich an Ihren Hosting-Provider.',
];