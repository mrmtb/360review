<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'IP-Adresse hinzufügen',
    'add.ipAddressAdded' => 'Die IP-Adresse %%address%% wurde hinzugefügt.',

    'delete.infoIpAddressesDeleted' => 'Die ausgewählten IP-Adressen wurden entfernt.',

    'edit.title' => 'IP-Adresse %%address%% auf der Schnittstelle %%interface%%',
    'edit.ipAddressUpdated' => 'Die Änderung der Einstellungen für die IP-Adresse %%address%% sind geplant und werden im Hintergrund ausgeführt',
    'edit.ipAddressInterfaceNotAvailableWarning' => 'Der Netzwerkadapter %%interface%% existiert nicht. Verschieben Sie diese IP-Adresse auf einen anderen Netzwerkadapter oder entfernen Sie ihn aus der Liste.',

    'list.title' => 'IP-Adressen',
];