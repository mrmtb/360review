<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Weiteren Webmail registrieren',
    'create.infoNewWebmailRegistered' => 'Es wurde ein neuer Webmail-Service registriert.',

    'edit.unknownWebmail' => 'Unbekannter Webmail',
    'edit.infoWebmailUpdated' => 'Die Einstellungen des Webmail-Services %%name%% wurden aktualisiert.',

    'index.title' => 'Webmail-Services',
    'index.hint' => 'Sie können einen beliebigen Webmail-Service zusätzlich zu den Webmail-Lösungen einsetzen, die Sie mit dem Plesk Installer (aka Updater) installieren. Benutzen Sie die Schaltfläche unten und registrieren Sie eine gewünschte Webmail-Installation im Panel. Sie wird als verfügbare Webmail-Option in den Hosting-Paketen und Abonnements angezeigt. Wenn Sie einen Webmail-Service vorübergehend ausblenden wollen, deaktivieren Sie diesen Service über die Schaltfläche unten.',
    'index.webmailDeleted' => 'Die Registrierung der ausgewählten weiteren Webmail-Services wurde entfernt.',
    'index.webmailNotDeleted' => 'Die Registrierung einiger Webmail-Services wurde entfernt.',
    'index.webmailEnabled' => 'Die ausgewählten Webmail-Services wurden aktiviert und sind jetzt verfügbar.',
    'index.webmailNotEnabled' => 'Einige der ausgewählten Webmail-Optionen wurden aktiviert.',
    'index.webmailDisabled' => 'Die ausgewählten Webmail-Optionen wurden deaktiviert und sind nicht verfügbar.',
    'index.webmailNotDisabled' => 'Einige der ausgewählten Webmail-Optionen wurden deaktiviert.',
];