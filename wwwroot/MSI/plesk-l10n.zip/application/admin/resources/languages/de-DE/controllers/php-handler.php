<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'PHP-Einstellungen',
    'list.hint' => 'Wählen Sie die PHP-Handler aus, die Sie verfügbar machen möchten. Zusätzliche Handler können Sie über den %%link%% installieren.',
    'list.hintLink' => 'Plesk Installer',
    'list.brokenDomainsError' => 'The folgende PHP-Version(en) ist/sind nicht installiert: %%phpVersions%%. PHP-Scripting für %%domainCount%% Domain(s) ist nicht verfügbar. Installieren Sie die fehlenden PHP-Versionen oder folgen Sie den Anweisungen des <a href=https://support.plesk.com/hc/en-us/articles/12377342328343>KB-Artikels</a>, um PHP-Scripting zu reparieren.',
    'list.brokenHandlersError' => 'Die folgenden PHP-Versionen sind nicht installiert: %%phpVersions%%. Installieren Sie sie oder führen Sie <code>plesk repair web -php-handlers</code> aus, um eine andere PHP-Version auszuwählen.',

    'modules.canNotManageModules' => 'Der Zugriff auf die Verwaltung der PHP-Handler-Einstellungen ist begrenzt, da der Pfad zur PHP-CLI-Datei nicht angegeben ist.',

    'php-ini.title' => 'Einstellungen für <b> %%name%%</b>',
    'php-ini.tabTitle' => 'php.ini',
    'php-ini.success' => 'Die Einstellungen wurden aktualisiert.',

    'toggle.errorEnableBrokenHandler' => 'Der Handler ist beschädigt und kann nicht aktiviert werden.',
    'toggle.errorDisableBrokenHandler' => 'Der Handler ist beschädigt und kann nicht deaktiviert werden.',
    'toggle.infoHandlerEnabled' => 'Der Handler wurde aktiviert.',
    'toggle.infoHandlerDisabled' => 'Der Handler wurde deaktiviert.',
];