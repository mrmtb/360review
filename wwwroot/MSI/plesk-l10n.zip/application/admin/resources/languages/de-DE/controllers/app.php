<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'clear-cache.apsCacheCleared' => 'Die temporären Dateien wurden entfernt.',

    'configure.title' => '%%name%%',
    'configure.applicationNotFound' => "Die Anwendung mit ID '%%id%%' wurde nicht gefunden.",
    'configure.applicationHasNoSettings' => 'Die Anwendung hat keine Einstellungen.',
    'configure.settingsUpdated' => 'Anwendungs-Einstellungen wurden aktualisiert.',
    'configure.settingsUpdateFailed' => 'Eigenschaften der Anwendungen konnten nicht aktualisiert werden: %%error%%',
    'configure.instancesNotReconfigured' => 'Einige der ausgewählten Anwendung-Instanzen wurden nicht neu konfiguriert.',

    'index.title' => 'Application Vault',

    'info.title' => '%%name%%',
    'info.hint' => 'Die nachfolgende Liste enthält Informationen über die Websites, in denen die Anwendung installiert ist. Der Wert "Keine" in der Spalte "Website" bedeutet, dass die Anwendung extern ist. Eine derartige Anwendung kann nicht in der Website eines bestimmten Kunden installiert werden. Sie stellt nur einen Link zu einem externen Service zur Verfügung.',

    'remote-app-info.title' => 'Anwendungs-Details',

    'update-settings.title' => 'Update-Einstellungen',
    'update-settings.settingsUpdated' => 'Die Einstellungen wurden aktualisiert.',
    'update-settings.settingsUpdateFailed' => 'Die Einstellungen können nicht aktualisiert werden: %%error%%',

    'upload.title' => 'Anwendung hinzufügen',
    'upload.packageInstallationError' => 'Die Anwendung konnte nicht hinzugefügt werden: %%message%%.',
    'upload.appUploaded' => 'Die Anwendung wurde erfolgreich hochgeladen.',
    'upload.appDownloadStarted' => 'Die ausgewählten Anwendungen werden heruntergeladen.',

    'uploaded.title' => 'Meine Anwendungen',
    'uploaded.hint' => 'Hier können Sie Anwendungen zum Application Vault hinzufügen oder daraus entfernen und die Verfügbarkeit der Anwendungen für Kunden verwalten. Es gibt zwei Gründe für das Hinzufügen von Anwendungen: Sie wollen die Liste der verfügbaren Anwendungen erweitern oder die serverweiten Einstellungen von Anwendungen konfigurieren. Einige Anwendungen können nicht ohne eine derartige Konfiguration installiert werden. Alle hinzugefügten Anwendungen sind nachfolgend aufgeführt.',
    'uploaded.infoAppDeleted' => 'Die ausgewählten Anwendungen werden gelöscht.',
    'uploaded.infoAppNotDeleted' => 'Einige der ausgewählten Anwendungen wurden nicht gelöscht.',
    'uploaded.applicationsNowAvailable' => 'Die ausgewählten Anwendungen sind jetzt für die Installation durch Kunden oder für die Konfiguration verfügbar.',
    'uploaded.applicationsNowNotAvailable' => 'Die ausgewählten Anwendungen sind für die Installation durch Kunden oder für die Konfiguration nicht mehr verfügbar.',
    'uploaded.cantChangePackageProperties' => 'Beim Versuch die Verfügbarkeitseinstellungen der Anwendung zu ändern ist ein Fehler aufgetreten.',
    'uploaded.appDownloaded' => 'Die ausgewählten Anwendungen wurden erfolgreich heruntergeladen.',
    'uploaded.appNotDownloaded' => 'Einige der ausgewählten Anwendungen wurden nicht heruntergeladen.',
    'uploaded.downloadInProgress' => 'Bitte warten...',

    'usage.title' => 'Installierte Anwendungen',
    'usage.hint' => 'Die nachfolgende Liste führt alle Anwendungen auf, die von Ihren Kunden hinzugefügt oder installiert wurden. Hier können Sie Anwendungseinstellungen verwalten, nach Updates suchen oder temporäre Dateien entfernen, die während der Installation von Anwendungen hinzugefügt wurden.',
    'usage.hintReseller' => 'Die nachfolgende Liste führt Informationen über alle Anwendungsinstallationen auf Ihren Websites und den Websites Ihrer Kunden auf. Klicken Sie auf den Namen einer Anwendung, um eine Liste der Websites anzuzeigen, auf denen die Anwendung installiert ist und suchen Sie nach Updates für die Anwendung.',
];