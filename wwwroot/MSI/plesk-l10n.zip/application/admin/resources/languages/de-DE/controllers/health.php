<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Serverzustand',
    'index.pageHint' => 'Hier finden Sie detaillierte Berichte zum Zustand des Servers. Um zu sehen, wie sich die Server-Zustandsparameter verändert haben, wählen Sie die Parameter aus und Plesk wird Ihnen die entsprechenden Grafiken anzeigen. Bitte beachten Sie, dass Sie den Zeitraum für die Berichte ändern können (von den letzten 3 Stunden bis hin zu einer Woche). Hier können Sie außerdem die Konfiguration der Systemüberwachung ändern. Sie legt fest, wann rote und gelbe Warnzeichen für jeden Parameter angezeigt werden sollen und welche Festplattenressourcen überwacht werden sollen. Um die Konfiguration zu ändern, laden Sie sich eine Konfigurationsdatei über die unten stehende Schaltfläche herunter, bearbeiten Sie die Datei und laden Sie Ihre Version hoch. Wenn die Server-Hardware geändert wurde, sollten Sie diese Änderungen in die Systemüberwachung übertragen, damit Sie die korrekten Statistiken erhalten.',
    'index.waitMessage' => 'Wird geladen...',
    'index.buttonUpload' => 'Konfigurationsdatei hochladen',
    'index.buttonDownload' => 'Konfigurationsdatei herunterladen',
    'index.buttonRestoreDefaults' => 'Auf Standardkonfiguration zurücksetzen',
    'index.buttonReconfigure' => 'Hardware-Änderungen ermitteln',
    'index.buttonUploadHint' => 'Laden Sie Ihre Datei zur Konfiguration der Systemüberwachung hoch. Die neue Konfiguration wird übernommen, sobald der Upload abgeschlossen wurde.',
    'index.buttonDownloadHint' => 'Speichern Sie die aktuelle Systemüberwachungs-Konfiguration auf Ihrem Computer.',
    'index.buttonRestoreDefaultsHint' => 'Stellen Sie die Standardeinstellungen der Server-Systemüberwachung wieder her.',
    'index.buttonReconfigureHint' => 'Übertragen Sie die Änderungen in der Hardware-Konfiguration an die Systemüberwachung.',
    'index.confirmRestoreDefaultsTitle' => 'Die Standardeinstellungen der Server-Systemüberwachung werden wiederhergestellt',
    'index.confirmRestoreDefaultsDescription' => 'Sind Sie sicher, dass Sie die Standardeinstellungen wiederherstellen möchten?',
    'index.confirmReconfigureTitle' => 'Hardware-Änderungen werden herausgefunden',
    'index.confirmReconfigureDescription' => 'Sie sind im Begriff, die Hardware-Konfiguration in der Systemüberwachung zu aktualisieren. Dies ist angebracht, wenn die Server-Hardware geändert wurde und Sie sie diese Änderungen in den Statistiken der Systemüberwachung widerspiegeln möchten. Fortfahren?',
    'index.settingsWereRestoredToDefault' => 'Die Standardeinstellungen wurden wiederhergestellt.',
    'index.healthMonitorWasReconfigured' => 'Die Informationen der Systemüberwachung zur Hardware-Konfiguration wurden aktualisiert.',

    'parameters.loading' => 'Wird geladen...',
    'parameters.selectPeriod' => 'Zeitraum auswählen',
    'parameters.periodFromNowTo3h' => '3 Stunden',
    'parameters.periodFromNowTo6h' => '6 Stunden',
    'parameters.periodFromNowTo12h' => '12 Stunden',
    'parameters.periodFromNowTo1d' => '1 Tag',
    'parameters.periodFromNowTo3d' => '3 Tage',
    'parameters.periodFromNowTo7d' => '1 Woche',

    'thresholds-hint.waitMessage' => 'Wird geladen...',

    'upload-config-file.title' => 'Konfigurationsdatei hochladen',
    'upload-config-file.configurationUploadedSuccessfully' => 'Konfiguration wurde hochgeladen und übernommen.',
];