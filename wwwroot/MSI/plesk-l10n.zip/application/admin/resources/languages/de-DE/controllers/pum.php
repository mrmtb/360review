<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Systemupdates',

    'list.title' => 'Alle Pakete',
    'list.hint' => 'Systempakete werden durch systemeigene Tools aktualisiert (dpkg/apt oder yum). Pakete werden nur von Repositorys aktualisiert, von denen sie installiert wurden. Um zu verhindern, dass ein Paket aktualisiert wird, wählen Sie es in der Liste aus und klicken Sie auf "Sperren".',

    'lock.success' => 'Die Pakete wurden erfolgreich gesperrt.',

    'settings.title' => 'Einstellungen',
    'settings.settingsUpdated' => 'Die Einstellungen wurden erfolgreich geändert.',

    'unlock.success' => 'Die Pakete wurden erfolgreich entsperrt.',

    'updates-list.title' => 'Verfügbare Updates',
    'updates-list.hint' => 'Systempakete werden durch systemeigene Tools aktualisiert (dpkg/apt oder yum). Pakete werden nur von Repositorys aktualisiert, von denen sie installiert wurden. Um zu verhindern, dass ein Paket aktualisiert wird, wählen Sie es in der Liste aus und klicken Sie auf "Sperren".',
];