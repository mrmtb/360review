<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'settings.title' => 'Einstellungen für Try&Buy-Modus',
    'settings.sitebuilderSettingsUpdated' => 'Die Einstellungen wurden aktualisiert.',
];