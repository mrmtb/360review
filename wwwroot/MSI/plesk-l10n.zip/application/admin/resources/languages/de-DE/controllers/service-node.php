<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.hint' => 'Beschreibung zum Hinzufügen eines Remote Service Node.',
    'add.title' => 'Remote Service Node hinzufügen',
    'add.serviceNodeAdded' => 'Remote Service Node %%name%% wurde hinzugefügt',

    'delete.infoServiceNodesDeleted' => 'Die ausgewählten Service Nodes wurden erfolgreich getrennt.',
    'delete.infoServiceNodesNotDeleted' => 'Die Verbindung einiger ausgewählter Service Nodes kann nicht getrennt werden.',
    'delete.serviceNodeIsInUse' => 'Der Service Node wird gerade verwendet.',

    'edit.hint' => 'Beschreibung zum Bearbeiten eines Remote Service Node.',
    'edit.title' => 'Remote Service Node %%name%%',
    'edit.serviceNodeUpdated' => 'Die Einstellungen des Remote Service Node %%name%% wurden aktualisiert',

    'list.hint' => 'Hier können Sie Remote Service Nodes hinzufügen',
    'list.title' => 'Service-Nodes',
];