<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'operation.startActionSuccess' => 'Service wurde gestartet',
    'operation.stopActionSuccess' => 'Service wurde gestoppt',
    'operation.restartActionSuccess' => 'Service wurde neu gestartet',
    'operation.changeStartupActionSuccess' => 'Der Starttyp für den Dienst wurde erfolgreich geändert',

    'list.title' => 'Dienste',

    'operation.startServiceMessage' => 'Der Neustart des Dienstes kann einige Zeit in Anspruch nehmen.',
    'operation.stopServiceMessage' => 'Das Anhalten des Dienstes kann einige Zeit in Anspruch nehmen.',
    'operation.restartServiceMessage' => 'Der Neustart des Dienstes kann einige Zeit in Anspruch nehmen.',
    'operation.unableFetchFormData' => 'Das Abrufen von Formulardaten ist nicht möglich: %%error%%',
    'operation.startActionError' => 'Der Start des Dienstes ist nicht möglich: %%error%%',
    'operation.stopActionError' => 'Das Beenden des Dienstes ist nicht möglich: %%error%%',
    'operation.restartActionError' => 'Der Neustart des Dienstes ist nicht möglich: %%error%%',
    'operation.changeStartupActionError' => 'Starttyp für Dienst kann nicht geändert werden: %%error%%',
];