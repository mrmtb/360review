<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-domain-alias.noDomains' => 'Ein Alias kann nicht erstellt werden: Keine Domains verfügbar.',

    'add-domain.noDomains' => 'Eine Add-on-Domain kann nicht erstellt werden: Keine Domains verfügbar.',

    'add-subdomain.noDomains' => 'Eine Subdomain kann nicht erstellt werden: Keine Domains verfügbar.',

    'change-owner.wrongOwnerId' => 'Der neue Besitzer des Kundenkontos kann nicht gefunden werden.',

    'change.title' => 'Ändern der mit Abonnements verbundenen Pakete und Add-ons',

    'create.title' => 'Hinzufügen eines neuen Kunden',

    'domains.title' => 'Domains',

    'list.title' => 'Kunden',
    'list.infoNewCustomerCreated' => 'Der Kunde %%name%% wurde erstellt.',
    'list.infoCustomerActivated' => 'Die ausgewählten Kunden wurden aktiviert.',
    'list.infoCustomerNotActivated' => 'Einige der ausgewählten Kunden wurden nicht aktiviert.',
    'list.infoCustomerSuspended' => 'Die ausgewählten Kunden wurden gesperrt.',
    'list.infoCustomerNotSuspended' => 'Einige der ausgewählten Kunden wurden nicht gesperrt.',
    'list.infoCustomerDeleted' => 'Ausgewählte Kunden wurden deaktiviert',
    'list.infoCustomerNotDeleted' => 'Einige der ausgewählten Kunden wurden nicht gelöscht.',
    'list.upgrageCustomersHint' => 'Sie haben ein Upgrade auf Plesk 11 durchgeführt, das auf einem neuen Kunden- und Business-Modell basiert. Um den Wechsel auf das neue Modell abzuschließen, müssen Sie die Kundenkonten (Clients) in die neuen Kundenkonten (Customers) oder Reseller-Konten umwandeln. Solange Sie dies nicht tun, sind Ihre Kunden nicht in der Lage, Websites zu erstellen, auch wenn Sie zuvor die notwendige Berechtigung erhalten haben.',
    'list.upgrageCustomersLink' => 'Kundenkonten konvertieren.',
    'list.infoCustomerToResellerConverted' => 'Die ausgewählten Kunden wurden erfolgreich in Reseller umgewandelt.',
    'list.errorCustomerToResellerNotConverted' => 'Einige der ausgewählten Kunden wurden nicht in Reseller umgewandelt.',
    'list.infoOwnerChanged' => 'Die ausgewählten Kunden wurden zu %%name%% verschoben.',
    'list.infoOwnerNotChanged' => 'Einige der ausgewählten Kunden wurden nicht zu %%name%% verschoben.',

    'login-info.title' => 'Bearbeitung der Logindaten von %%name%%',

    'overview.title' => '%%name%%',

    'personal-info.title' => 'Kontaktdaten von %%name%% bearbeiten',

    'subscriptions.title' => 'Abonnements',
];