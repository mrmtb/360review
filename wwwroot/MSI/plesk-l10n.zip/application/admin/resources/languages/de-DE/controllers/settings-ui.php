<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'branding.title' => 'Plesk Branding',

    'disable-languages.disableLanguagesSuccess' => 'Die ausgewählten Sprachen sind nicht mehr für Benutzer verfügbar.',

    'edit-controls.updateSuccess' => 'Die Einstellungen wurden erfolgreich aktualisiert.',

    'edit-interface-view.title' => 'Ansichten der Benutzeroberfläche',
    'edit-interface-view.updateSuccess' => 'Die Einstellungen wurden erfolgreich aktualisiert.',

    'enable-languages.enableLanguagesSuccess' => 'Die ausgewählten Sprachen sind für Benutzer verfügbar.',

    'language-make-default.languageMakeDefaultSuccess' => 'Die ausgewählte Sprache wurde als Standard für Plesk festgelegt.',

    'list-languages.title' => 'Sprachen',
    'list-languages.mlsLimitExceeded' => "Ihre aktuelle Plesk Lizenz ermöglicht die Verwendung von %%allowedByLicense%% Sprachen. Derzeit haben Sie festgelegt, dass für Ihre Benutzer %%availableToUsers%% Sprachen verfügbar sind. Diese Zahl übersteigt die in der Lizenz zulässige Zahl. Bitte wählen Sie %%allowedByLicense%% zu verwendende Sprachen aus und deaktivieren Sie die restlichen für Benutzer, indem Sie auf die jeweiligen Symbole in der Spalte 'S' klicken.",
];