<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'gallery.titleScreenshot' => 'Screenshots von %%packageName%%',
    'gallery.prevImage' => '< Zurück',
    'gallery.nextImage' => 'Weiter >',
    'gallery.closeGallery' => 'Schließen',
    'gallery.navigationOf' => 'von',
    'gallery.typeScreenshot' => 'Screenshots',
    'gallery.title' => 'Screenshots',
];