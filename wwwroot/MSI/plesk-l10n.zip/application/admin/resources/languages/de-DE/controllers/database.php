<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'assign-to-subscription.databasesSuccessfullyAssignedToSubscription' => 'Die Datenbanken wurden zum Abonnement \'%%subscriptionName%%\' verschoben.',
    'assign-to-subscription.databasesNotAssignedToSubscription' => 'Das Verschieben der Datenbanken zum Abonnement \'%%subscriptionName%%\' ist nicht möglich.',
    'assign-to-subscription.subscriptionNotFound' => 'Das Abonnement \'%%name%%\' wurde nicht gefunden.',
    'assign-to-subscription.isNotMainDomain' => '\'%%name%%\' ist nicht die Hauptdomain in dem Abonnement.',

    'settings.title' => 'Datenbankhosting-Einstellungen',
    'settings.settingsSaved' => 'Die Datenbankhosting-Einstellungen wurden gespeichert.',

    'refresh.success' => 'Die Informationen zu den Datenbankservern wurden aktualisiert.',
];