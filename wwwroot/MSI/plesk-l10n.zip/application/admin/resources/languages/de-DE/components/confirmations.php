<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-customer-owner.title' => 'Verschieben von Kundenkonten zu anderem Verantwortlichen',
    'change-customer-owner.description' => 'Die Kundenkonten werden zu einem anderen Verantwortlichen verschoben. Sie können Service-Pakete für Kunden-Abonnements ändern. Wenn Sie die Ressourcen, die einem Kunden zur Verfügung stehen, beibehalten wollen, dann lassen Sie das benutzerdefinierte Paket ausgewählt.',
    'change-customer-owner.ownerHint' => 'Die Kundenkonten werden zum ausgewählten Verantwortlichen verschoben:',
    'change-customer-owner.ipAddressHint' => 'Eine dedizierte IP-Adresse kann nicht beibehalten werden.',
    'change-customer-owner.loading' => 'Bitte warten...',
    'change-customer-owner.ipAddressNotSelected' => 'Wählen Sie mindestens eine IP-Adresse für jedes Abonnement aus.',
    'change-customer-owner.ownerNotSelected' => 'Wählen Sie einen Verantwortlichen (Besitzer) aus.',

    'customer.title' => 'Kunden in Reseller umwandeln',
    'customer.description' => 'Die aufgeführten Kundenkonten werden in Reseller-Konten umgewandelt. Sie können Reseller-Pakete für die umgewandelten Konten wählen. Wenn Sie die Ressourcen, die einem Kunden zur Verfügung standen, beibehalten wollen, wählen Sie das benutzerdefinierte Paket aus: Der Reseller wird die Summe der Ressourcenverteilungen, Berechtigungen und Anwendungen aller Abonnements besitzen.',
    'customer.loading' => 'Umwandeln...',

    'reseller.title' => 'Reseller in Kunden umwandeln',
    'reseller.description' => 'Die aufgelisteten Reseller werden in Kunden umgewandelt.',
    'reseller.descriptionExtended' => 'Wählen Sie neue Service-Pakete für Reseller, die ihre eigenen Abonnements besitzen. Wenn Sie die Ressourcen, die einem Reseller zur Verfügung stehen, beibehalten wollen, dann wählen Sie das benutzerdefinierte Service-Paket aus. Um die Abonnements des Resellers in eines der vorhandenen Service-Pakete zu verschieben, müssen Sie ein vorhandenes Service-Paket auswählen.',
    'reseller.loading' => 'Umwandeln...',
];