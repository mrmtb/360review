<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-log.actionSuccess' => 'Die ausgewählten Protokolldateien wurden entfernt.',
    'delete-log.invalidFileName' => 'Der Name der Protokolldatei ist ungültig.',
    'delete-log.actionError' => 'Die Protokolldatei %%file%% kann nicht entfernt werden: %%reason%%',

    'index.title' => 'Web Application Firewall',
    'index.generalTab' => 'Allgemein',
    'index.settingsTab' => 'Einstellungen',
    'index.settingsSaved' => 'Die Einstellungen zur Web Application Firewall wurden gespeichert.',
    'index.updateFailed' => 'Der ModSecurity-Regelsatz konnte nicht aktualisiert werden: %%error%%',
    'index.updateFailedShort' => 'Der ModSecurity-Regelsatz konnte nicht aktualisiert werden. %%link%%',
    'index.updateFailedShortLink' => 'Details',

    'log-list.title' => 'Verwaltung der Protokolldateien',

    'view-log.fileNameIsUndefined' => 'Der Name der Protokolldatei ist nicht definiert.',
];