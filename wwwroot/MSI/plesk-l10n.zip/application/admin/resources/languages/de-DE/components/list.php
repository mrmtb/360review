<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'recordsTotal' => '%%total%% Element(e) gesamt',
    'pages' => 'Seiten',
    'firstPage' => 'Erste',
    'lastPage' => 'Letzte',
    'numberOfItemPerPage' => 'Einträge pro Seite',
    'hideSearch' => 'Suche ausblenden',
    'showSearch' => 'Suche anzeigen',
    'buttonSearch' => 'Suchen',
    'buttonResetSearch' => 'Suche zurücksetzen',
    'noEntriesFound' => 'Keine Elemente gefunden.',
    'itemsNotSelected' => 'Wählen Sie zuerst Elemente aus.',
    'messageBoxButtonYes' => 'Ja',
    'messageBoxButtonNo' => 'Nein',
    'messageBoxButtonOk' => 'OK',
    'allItems' => 'Alle',
];