<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoAdminAliasActivated' => 'Die ausgewählten Administratorkonten wurden erfolgreich aktiviert.',
    'activate.infoAdminAliasNotActivated' => 'Einige ausgewählte Administratorkonten wurden nicht aktiviert.',

    'create.title' => 'Hinzufügen eines Administratorkontos',
    'create.infoNewAdminAliasCreated' => 'Das zusätzliche Administratorkonto %%contact%% wurde erfolgreich erstellt.',

    'deactivate.infoAdminAliasDeactivated' => 'Die ausgewählten Administratorkonten wurden erfolgreich gesperrt.',
    'deactivate.infoAdminAliasNotDeactivated' => 'Einige ausgewählte Administratorkonten wurden nicht gesperrt.',

    'delete.infoAdminAliasDeleted' => 'Die ausgewählten Administratorkonten wurden erfolgreich entfernt.',
    'delete.infoAdminAliasNotDeleted' => 'Einige ausgewählte Administratorkonten wurden nicht entfernt.',

    'edit.title' => "%%contact%%",
    'edit.infoNewAdminAliasUpdated' => 'Das Administratorkonto wurde erfolgreich aktualisiert.',

    'list.title' => 'Zusätzliche Administratorkonten',
    'list.hint' => 'Hier können Sie zusätzliche Administratorkonten für Ihre Mitarbeiter aus dem technischen Support erstellen. Diese ermöglichen es ihnen, diverse Administrationsaufgaben durchzuführen.',
];