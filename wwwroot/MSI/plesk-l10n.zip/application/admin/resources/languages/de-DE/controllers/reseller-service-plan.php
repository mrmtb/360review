<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Reseller-Paket erstellen',
    'create.hint' => 'Hier können Sie ein Reseller-Paket entsprechend Ihrem Angebot erstellen.',

    'edit.title' => '%%name%%',
    'edit.hint' => 'Hier können Sie das Reseller-Paket entsprechend Ihrem Angebot ändern. Bitte beachten Sie, dass durch das Ändern des Pakets automatisch alle zugehörigen Abonnements aktualisiert werden, mit Ausnahme der benutzerdefinierten Abonnements, die für die Synchronisierung gesperrt wurden.',

    'list.title' => 'Reseller-Pakete',
    'list.hint' => 'Hier verwalten Sie Ihre Reseller-Pakete, die das Erstellen von Reseller-Abonnements zulassen. Anders als Ihre regulärer Hosting-Service-Kunde, kann ein Reseller nur ein einziges Paket abonnieren und keine Add-ons besitzen.',
    'list.tabTitle' => 'Reseller-Pakete',
    'list.infoNewPlanCreated' => 'Das Reseller-Paket %%name%% wurde erstellt.',
    'list.infoPlanUpdated' => 'Das Reseller-Paket %%name%% wurde aktualisiert.',
    'list.infoPlanUpdatedSynced' => 'Das Service-Paket %%name%% wurde aktualisiert. Alle zugehörigen Reseller-Abonnements wurden synchronisiert, außer den benutzerdefinierten Abonnements, die für die Synchronisierung gesperrt wurden.',
    'list.infoPlanDeleted' => 'Die ausgewählten Reseller-Pakete wurden entfernt.',
    'list.infoPlanNotDeleted' => 'Einige der ausgewählten Reseller-Pakete wurden nicht entfernt.',
    'list.infoPlanDuplicated' => 'Die ausgewählten Service-Pakete wurden erfolgreich dupliziert.',
    'list.infoPlanNotDuplicated' => 'Einige der ausgewählten Service-Pakete wurden nicht dupliziert.',
];