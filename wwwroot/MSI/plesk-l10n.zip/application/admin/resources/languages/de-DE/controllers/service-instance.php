<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.formTitle' => 'Hinzuzufügenden Service wählen',
    'create.successfullyAdded' => 'Der Service \'%%serviceDisplayName%%\' wurde erfolgreich erstellt.',
    'create.successfullyUpdated' => 'Der Service \'%%serviceDisplayName%%\' wurde erfolgreich aktualisiert.',
    'create.selectServiceInstallationTitle' => 'Service auswählen',

    'edit.formTitle' => 'Service \'%%serviceDisplayName%%\' verwalten',
    'edit.title' => 'Services von %%subscriptionName%%',
    'edit.successfullyUpdated' => 'Der Service \'%%serviceDisplayName%%\' wurde erfolgreich aktualisiert.',

    'list.hint' => 'Hier können Sie im Abonnement befindliche Services verwalten',
    'list.title' => 'Services von %%subscriptionName%%',
    'list.breadcrumb' => 'Dienstleistungen',
    'list.infoServiceDeleted' => 'Die ausgewählten Services wurden entfernt.',
    'list.infoServiceNotDeleted' => 'Einige der ausgewählten Services wurden nicht entfernt.',
];