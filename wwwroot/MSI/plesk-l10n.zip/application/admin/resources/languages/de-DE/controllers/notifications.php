<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Benachrichtigungen',

    'email-settings.title' => 'E-Mail-Adresse',

    'panel-settings.title' => 'Plesk Benutzeroberfläche',
    'panel-settings.notificationSettingsSaved' => 'Die Benachrichtigungseinstellungen wurden erfolgreich gespeichert.',

    'panel-notifications-toggle.successfullyEnabled' => 'Die Benachrichtigung \'%%title%%\' wurde aktiviert.',
    'panel-notifications-toggle.successfullyDisabled' => 'Die Benachrichtigung \'%%title%%\' wurde deaktiviert.',

    'template-settings-list.hint' => 'Wählen Sie aus, welche Benachrichtigungen Sie sehen möchten, indem Sie sie aktivieren oder deaktivieren.',
    'template-settings-list.name' => 'Titel',
    'template-settings-list.context' => 'Kontext',
    'template-settings-list.sendToAdmin' => 'An Administrator senden',

    'template-settings-form.storagePeriod' => 'Benachrichtigungen speichern für',
    'template-settings-form.days' => 'Tage',
];