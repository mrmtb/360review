<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-sessions.noSessionsSpecified' => 'Wählen Sie eine oder mehrere FTP-Sitzungen aus der Liste aus.',
    'delete-sessions.sessionsDeleted' => 'Die ausgewählten Sitzungen wurden gelöscht.',
    'delete-sessions.sessionsNotDeleted' => 'Einige der ausgewählten Sitzungen wurden nicht gelöscht. Details: %%error%%.',

    'list.title' => 'FTP-Sitzungen',
];