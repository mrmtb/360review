<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'isEmpty' => 'Dieses erforderliche Feld ist leer. Sie müssen einen Wert für das Feld angeben.',
    'stringLengthTooShort' => "'%value%' enthält weniger als %min% Zeichen.",
    'stringLengthTooLong' => "'%value%' enthält mehr als %max% Zeichen.",
    'regexNotMatch' => "'%value%' stimmt nicht mit dem Muster '%pattern%' überein.",
    'notAlnum' => "'%value%' enthält nicht-alphanumerische Zeichen. Sie dürfen nur alphanumerische Zeichen verwenden.",
    'stringEmpty' => "'%value%' ist leer.",
    'stringsNotEqual' => 'Zeichenfolgen stimmen nicht überein.',
    'passwordsNotEqual' => 'Die eingegebenen Passwörter stimmen nicht überein.',
    'passwordLengthTooShort' => "Das Passwort ist kürzer als %min% Zeichen.",
    'passwordLengthTooLong' => "Das Passwort ist länger als %max% Zeichen.",
    'passwordRegexNotMatch' => "Das Passwort entspricht nicht dem Muster '%pattern%'.",
    'invalidUrl' => 'Die angegebene Adresse ist ungültig. Sie müssen eine gültige Adresse angeben, z. B. http://domain.com.',
    'specialCharactersInIpAddress' => 'Die angegebene IP-Adresse ist ungültig.',
    'massEmailContactsNotSelected' => 'Wählen Sie mindestens einen Kontakt aus der Liste aus.',
    'ipAddressIsTooLong' => 'Eine IP-Adresse darf nicht länger als %max% Zeichen sein.',
    'ipAddressDescriptionTooLong' => 'Die Beschreibung darf nicht länger als %max% Zeichen sein.',

    'fail2ban.invalidIpOrCidr' => 'Die IP-Adresse muss eine gültige IP-Adresse oder eine CIDR-Maske sein.',
];