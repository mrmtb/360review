<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'email.subjSuccess' => 'Plesk wurde erfolgreich aktualisiert',
    'email.subjFailure' => 'Das Plesk Update ist fehlgeschlagen',
    'email.bodySuccess' => "Achtung,\n\nPlesk wurde erfolgreich aktualisiert.\nWenn Sie die Liste der Änderungen sehen wollen, besuchen Sie bitte %%link%%.\n\nDiese Nachricht wurde automatisch vom Plesk Installer versandt.",
    'email.bodyFailure' => "Achtung,\n\nDas Plesk Update ist fehlgeschlagen.\n\nSie können die Protokolldateien des Plesk Installers unter folgendem Link herunterladen: %%link%%.\nWenn Sie Hilfe benötigen, wenden Sie sich bitte an Ihren Hosting-Provider.\n\nDiese Nachricht wurde automatisch vom Plesk Installer versandt.",
];