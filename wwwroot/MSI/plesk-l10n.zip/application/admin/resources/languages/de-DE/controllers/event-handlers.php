<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Ereignis-Handler hinzufügen',
    'add.added' => 'Der Ereignis-Handler wurde hinzugefügt.',

    'delete.noHandlersSpecified' => 'Wählen Sie die Ereignishandler aus, die entfernt werden sollen.',
    'delete.handlersDeleted' => 'Die ausgewählten Ereignis-Handler wurden entfernt.',
    'delete.handlersNotDeleted' => 'Einige der ausgewählten Ereignis-Handler wurden nicht entfernt. Details: %%error%%.',

    'edit.title' => 'Eigenschaften des Ereignis-Handlers aktualisieren',
    'edit.updated' => 'Der Ereignis-Handler wurde aktualisiert.',

    'list.title' => 'Ereignis-Manager',
];