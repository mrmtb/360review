<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Service hinzufügen',
    'create.hint' => 'Hier können Sie einen Link zu einem externen Service hinzufügen',

    'edit.title' => 'Die Eigenschaften des Services %%name%%',
    'edit.hint' => 'Hier können Sie die Eigenschaften des Services angeben.',
    'edit.errorItemNotEditable' => 'Die Eigenschaften von diesem Service sind nicht editierbar.',

    'list.title' => 'Zusätzliche Services',
    'list.tabTitle' => 'Zusätzliche Services',
    'list.hint' => "Hier finden Sie eine Liste zusätzlicher Services, die Sie mit Hosting-Paketen bereitstellen können. Sie zeigt die manuell definierten Services sowie Services, die von Anwendungen bereitgestellt werden, welche als Plesk Erweiterungen installiert sind. Einen Service manuell hinzuzufügen, ist nützlich, wenn Sie Ihre Kunden zu einem externen Online-Service leiten möchten. Hierdurch wird eine entsprechende Schaltfläche im Kunden-Panel hinzugefügt. Standardmäßig werden alle zusätzlichen Services in den Hosting-Paket-Eigenschaften auf der Registerkarte \"Zusätzliche Services\" aufgelistet. Dadurch können Sie und Ihre Reseller diese Services in die Hosting-Pakete aufnehmen. Wenn Sie nicht zulassen wollen, dass Ihre Reseller einen Service verwenden und für Ihre Kunden bereitstellen, können Sie den Link \"Verfügbarkeit aufheben\" verwenden.",
    'list.planItemsNowAvailable' => 'Die ausgewählten zusätzlichen Services sind für Reseller verfügbar.',
    'list.planItemsNowNotAvailable' => 'Die ausgewählten zusätzlichen Services sind nicht mehr für Reseller verfügbar.',
    'list.cantChangePlanItemsProperties' => 'Beim Versuch die Verfügbarkeitseinstellungen für den Service zu ändern ist ein Fehler aufgetreten.',
    'list.infoNewPlanItemCreated' => 'Die zu dem Service zugehörige Option %%name%% wurde zu den Paketeigenschaften hinzugefügt.',
    'list.infoPlanItemUpdated' => 'Die Paketoption %%name%% wurde aktualisiert.',
    'list.planItemsDeleted' => 'Die ausgewählten Paket-Optionen wurden gelöscht.',
    'list.planItemsNotDeleted' => 'Einige der ausgewählten Paket-Optionen wurden nicht gelöscht.',
];