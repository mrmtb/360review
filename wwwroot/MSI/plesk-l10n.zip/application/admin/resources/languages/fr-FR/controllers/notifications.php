<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Notifications',

    'email-settings.title' => 'Adresse mail',

    'panel-settings.title' => 'Interface utilisateur de Plesk',
    'panel-settings.notificationSettingsSaved' => 'Les paramètres de notification ont bien été enregistrés.',

    'panel-notifications-toggle.successfullyEnabled' => 'La notification "%%title%%" a été activée.',
    'panel-notifications-toggle.successfullyDisabled' => 'La notification "%%title%%" a été désactivée.',

    'template-settings-list.hint' => 'Choisir les notifications à afficher en les activant ou en les désactivant.',
    'template-settings-list.name' => 'Titre',
    'template-settings-list.context' => 'Contexte',
    'template-settings-list.sendToAdmin' => 'Envoyer à l\'administrateur',

    'template-settings-form.storagePeriod' => 'Enregistrer les notifications pour',
    'template-settings-form.days' => 'jours',
];