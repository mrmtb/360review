<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Santé du serveur',
    'index.pageHint' => 'Sur cette page, vous pouvez voir les rapports détaillés sur la santé du serveur. Pour voir comment les paramètres de santé du serveur évoluent, sélectionnez les paramètres et Plesk affichera alors les graphiques appropriés. Notez que vous pouvez changer la période concernée par le rapport : des 3 dernières heures à une semaine. Sur cette page, vous pouvez également changer la configuration du moniteur de santé. Celle-ci définit quand les alarmes rouge et jaune doivent apparaître pour chaque paramètre et quelles ressources du disque dur doivent être surveillées. Pour ce faire, téléchargez un fichier de configuration à l\'aide du bouton ci-dessous, éditez le fichier et envoyez votre version. Si le matériel du serveur a été changé, vous devez étendre ces changements au Moniteur de santé pour obtenir des statistiques correctes.',
    'index.waitMessage' => 'Chargement en cours...',
    'index.buttonUpload' => 'Envoyer le fichier de configuration',
    'index.buttonDownload' => 'Télécharger le fichier de configuration',
    'index.buttonRestoreDefaults' => 'Revenir à la configuration par défaut',
    'index.buttonReconfigure' => 'Détecter les changements matériels',
    'index.buttonUploadHint' => 'Envoyez votre fichier de configuration du moniteur de santé. La nouvelle configuration sera appliquée dès que l\'envoi sera terminé.',
    'index.buttonDownloadHint' => 'Sauvegardez la configuration du moniteur de santé actuel sur votre ordinateur.',
    'index.buttonRestoreDefaultsHint' => 'Restaurez les paramètres par défaut du moniteur de santé du serveur.',
    'index.buttonReconfigureHint' => 'Propagez les changements de la configuration matérielle au moniteur de santé.',
    'index.confirmRestoreDefaultsTitle' => 'Restauration des paramètres par défaut du moniteur de santé du serveur',
    'index.confirmRestoreDefaultsDescription' => 'Voulez-vous vraiment restaurer les paramètres par défaut ?',
    'index.confirmReconfigureTitle' => 'Identification des changements matériels',
    'index.confirmReconfigureDescription' => 'Vous êtes sur le point de mettre à jour la configuration matérielle dans le moniteur de santé. Cela a son importance si le matériel du serveur a été changé et si vous voulez refléter ces changements dans les statistiques du moniteur de santé. Voulez-vous continuer malgré tout ?',
    'index.settingsWereRestoredToDefault' => 'Les paramètres par défaut ont été restaurés.',
    'index.healthMonitorWasReconfigured' => 'Les informations du moniteur de santé sur la configuration matérielle ont été mises à jour.',

    'parameters.loading' => 'Chargement en cours...',
    'parameters.selectPeriod' => 'Sélectionner la période',
    'parameters.periodFromNowTo3h' => '3 heures',
    'parameters.periodFromNowTo6h' => '6 heures',
    'parameters.periodFromNowTo12h' => '12 heures',
    'parameters.periodFromNowTo1d' => '1 jour',
    'parameters.periodFromNowTo3d' => '3 jours',
    'parameters.periodFromNowTo7d' => '1 semaine',

    'thresholds-hint.waitMessage' => 'Chargement en cours...',

    'upload-config-file.title' => 'Envoyer le fichier de configuration',
    'upload-config-file.configurationUploadedSuccessfully' => 'La configuration a été envoyée et appliquée.',
];