<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'gallery.titleScreenshot' => 'Captures d\'écran de %%packageName%%',
    'gallery.prevImage' => '< Précédent',
    'gallery.nextImage' => 'Suivant >',
    'gallery.closeGallery' => 'Fermer',
    'gallery.navigationOf' => 'sur',
    'gallery.typeScreenshot' => 'Captures d\'écran',
    'gallery.title' => 'Captures d\'écran',
];