<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Ajouter une adresse IP',
    'add.ipAddressAdded' => 'L\'adresse %%address%% a été ajoutée.',

    'delete.infoIpAddressesDeleted' => 'Les adresses IP sélectionnées ont été supprimées.',

    'edit.title' => 'Adresse IP %%address%% sur l\'interface %%interface%%',
    'edit.ipAddressUpdated' => 'Le changement des paramètres de l\'adresse IP %%address%% a été planifié et sera appliqué en arrière-plan.',
    'edit.ipAddressInterfaceNotAvailableWarning' => 'L\'adaptateur réseau %%interface%% n\'existe pas. Migrez cette adresse IP vers un autre adaptateur réseau ou supprimez-la de la liste.',

    'list.title' => 'Adresses IP',
];