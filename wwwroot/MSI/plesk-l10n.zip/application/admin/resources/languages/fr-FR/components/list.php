<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'recordsTotal' => '%%total%% élément(s) au total',
    'pages' => 'Pages',
    'firstPage' => 'Premier',
    'lastPage' => 'Dernier',
    'numberOfItemPerPage' => 'Entrées par page',
    'hideSearch' => 'Masquer la recherche',
    'showSearch' => 'Afficher la recherche',
    'buttonSearch' => 'Rechercher',
    'buttonResetSearch' => 'Réinitialiser la recherche',
    'noEntriesFound' => 'Aucun élément trouvé.',
    'itemsNotSelected' => 'Sélectionnez en premier les éléments.',
    'messageBoxButtonYes' => 'Oui',
    'messageBoxButtonNo' => 'Non',
    'messageBoxButtonOk' => 'OK',
    'allItems' => 'Tout',
];