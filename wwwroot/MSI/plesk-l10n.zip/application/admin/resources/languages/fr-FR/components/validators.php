<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'isEmpty' => 'Ce champ obligatoire est vide. Vous devez indiquer une valeur dans ce champ.',
    'stringLengthTooShort' => "'%value%' comporte moins de caractères que le nombre requis de caractères : %min%.",
    'stringLengthTooLong' => "'%value%' comporte plus de caractères que le nombre autorisé de caractères : %max%.",
    'regexNotMatch' => "'%value%' ne correspond pas au modèle '%pattern%'.",
    'notAlnum' => "'%value%' contient des caractères non alphanumériques. Assurez-vous que vous utilisez des caractères alphanumériques.",
    'stringEmpty' => "'%value%' est vide.",
    'stringsNotEqual' => 'Les chaînes sont différentes.',
    'passwordsNotEqual' => 'Les mots de passe que vous avez saisis ne sont pas identiques.',
    'passwordLengthTooShort' => "le mot de passe contient moins de %min% caractères.",
    'passwordLengthTooLong' => "la longueur du mot de passe dépasse les %max% caractères.",
    'passwordRegexNotMatch' => "Le mot de passe ne correspond pas au modèle '%pattern%'.",
    'invalidUrl' => 'L\'adresse indiquée n\'est pas valide. Vous devez indiquer une adresse valide comme http://domain.com.',
    'specialCharactersInIpAddress' => 'L\'adresse IP fournie n\'est pas valide.',
    'massEmailContactsNotSelected' => 'Sélectionnez au moins un contact dans la liste.',
    'ipAddressIsTooLong' => 'Une adresse IP doit comporter moins de %max% caractères.',
    'ipAddressDescriptionTooLong' => 'La description doit comporter moins de %max% caractères.',

    'fail2ban.invalidIpOrCidr' => 'L\'adresse IP doit être une adresse IP valide ou un masque CIDR.',
];