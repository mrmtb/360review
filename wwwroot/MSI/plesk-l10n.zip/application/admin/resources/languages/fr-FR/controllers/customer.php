<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-domain-alias.noDomains' => 'Impossible de créer un alias : il n\'y a aucun domaine disponible.',

    'add-domain.noDomains' => 'Impossible de créer un domaine supplémentaire : il n\'y a aucun domaine disponible.',

    'add-subdomain.noDomains' => 'Impossible de créer un sous-domaine : il n\'y a aucun domaine disponible.',

    'change-owner.wrongOwnerId' => 'Impossible de trouver le nouveau propriétaire du compte client.',

    'change.title' => 'Changement des packs et des add-ons associés aux abonnements',

    'create.title' => 'Ajouter un client',

    'domains.title' => 'Domaines',

    'list.title' => 'Clients',
    'list.infoNewCustomerCreated' => 'Le client %%name%% a été créé.',
    'list.infoCustomerActivated' => 'Les clients sélectionnés ont été activés.',
    'list.infoCustomerNotActivated' => 'Certains clients sélectionnés n\'ont pas été activés.',
    'list.infoCustomerSuspended' => 'Les clients sélectionnés ont été suspendus.',
    'list.infoCustomerNotSuspended' => 'Certains clients sélectionnés n\'ont pas été suspendus.',
    'list.infoCustomerDeleted' => 'Les clients sélectionnés ont été supprimés.',
    'list.infoCustomerNotDeleted' => 'Certains clients sélectionnés n\'ont pas été supprimés.',
    'list.upgrageCustomersHint' => 'Vous avez mis à niveau vers Plesk 11 qui emploie un nouveau modèle commercial / client. Pour terminer la transition vers le nouveau modèle, convertissez les comptes client en comptes utilisateur ou revendeur. Dans le cas contraire, vos utilisateurs ne pourront pas créer de site Web, même s\'ils disposaient précédemment de l\'autorisation requise.',
    'list.upgrageCustomersLink' => 'Convertissez les comptes client.',
    'list.infoCustomerToResellerConverted' => 'Les clients sélectionnés ont bien été convertis en revendeurs.',
    'list.errorCustomerToResellerNotConverted' => 'Certains clients sélectionnés n\'ont pas été convertis en revendeurs.',
    'list.infoOwnerChanged' => 'Les clients sélectionnés ont bien été déplacés vers %%name%%.',
    'list.infoOwnerNotChanged' => 'Certains des clients sélectionnés n\'ont pas été déplacés vers %%name%%.',

    'login-info.title' => 'Édition des infos de connexion de %%name%%',

    'overview.title' => '%%name%%',

    'personal-info.title' => 'Édition des informations de contact de %%name%%',

    'subscriptions.title' => 'Abonnements',
];