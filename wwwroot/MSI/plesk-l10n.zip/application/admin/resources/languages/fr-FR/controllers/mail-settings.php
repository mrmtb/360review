<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Paramètres de la messagerie pour l\'ensemble du serveur',
    'index.preferencesTab' => 'Paramètres',
    'index.spamFilteringTab' => 'Anti-spam',
    'index.antivirusTab' => 'Antivirus',
    'index.blockedDomainsTab' => 'Liste noire',
    'index.whiteListTab' => 'Liste blanche',
    'index.queueTab' => 'File d\'attente des mails',
    'index.statisticsTab' => 'Statistiques',
    'index.smarthostTab' => 'Hôte intelligent',

    'mail-lists.title' => 'Configurer le gestionnaire de listes de diffusion',
    'mail-lists.configured' => 'Le gestionnaire de listes de diffusion Mailman a été configuré. Le bouton Configurer le serveur de listes de diffusion ne sera plus affiché sur la page Outils & Paramètres.', // PFU
    'mail-lists.noLocalhostInServerWhiteList' => 'Pour utiliser des listes de diffusion, vous devez avoir un hôte local (127.0.0.0/8, ::1/128) dans la liste blanche du serveur de messagerie. Toutefois, pour utiliser le contrôle des mails sortants, vous ne devez pas avoir d\'hôte local dans la liste blanche. Vous pouvez appliquer le compromis suivant : si vous avez activé le contrôle des mails sortants, utilisez le transfert de mails sur la boîte mail au lieu des listes de diffusion.',
    'mail-lists.noLocalhostInServerWhiteListIpv4' => 'Pour utiliser les listes de diffusion, vous avez besoin d\'un hôte local dans la liste blanche du serveur de messagerie. Toutefois, pour utiliser le contrôle des mails sortants, vous ne devez pas avoir d\'hôte local dans la liste blanche. Vous pouvez appliquer le compromis suivant : si vous avez activé le contrôle des mails sortants, utilisez le transfert de mails sur la boîte mail au lieu des listes de diffusion. Remarque : il n\'y a aucune adresse d\'hôte local IPv4 (127.0.0.0/8) dans la liste blanche actuellement, le contrôle des mails sortants fonctionnera donc pour les adresses IPv4.',
    'mail-lists.noLocalhostInServerWhiteListIpv6' => 'Pour utiliser les listes de diffusion, vous avez besoin d\'un hôte local dans la liste blanche du serveur de messagerie. Toutefois, pour utiliser le contrôle des mails sortants, vous ne devez pas avoir d\'hôte local dans la liste blanche. Vous pouvez appliquer le compromis suivant : si vous avez activé le contrôle des mails sortants, utilisez le transfert de mails sur la boîte mail au lieu des listes de diffusion. Remarque : il n\'y a aucune adresse d\'hôte local IPv6 (::1/128) dans la liste blanche actuellement, le contrôle des mails sortants fonctionnera donc pour les adresses IPv6.',
    'mail-lists.mailingListSoftwareNotInstalled' => 'Le logiciel de liste de diffusion n\'est pas installé.',
    'mail-lists.mailingListSoftwareAlreadyConfigured' => 'Le logiciel de liste de diffusion est déjà configuré.',

    'customize-mailbox-quota-warning.title' => 'Personnalisation du message d\'avertissement de quota de la boîte aux lettres',
    'customize-mailbox-quota-warning.successMessage' => 'Le message d\'avertissement relatif au quota de la boîte mail a été modifié.',

    'customize-mailbox-quota-warning-form.subject' => 'Sujet',
    'customize-mailbox-quota-warning-form.message' => 'Message',
    'customize-mailbox-quota-warning-form.tooLongMessage' => "Message trop long. Longueur maximum : %max% caractères.",
];