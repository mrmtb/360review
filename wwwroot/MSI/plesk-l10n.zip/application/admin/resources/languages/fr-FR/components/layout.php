<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'leftFrameSwitcher' => 'Masquer/Afficher le volet de navigation',
];