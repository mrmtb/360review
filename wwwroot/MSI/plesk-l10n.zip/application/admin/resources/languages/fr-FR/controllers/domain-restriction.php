<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Ajouter un nom de domaine',
    'add.domainAdded' => 'Le nom de domaine %%domain%% a bien été ajouté à la liste des noms de domaine interdits.',

    'disable.listDisabled' => 'La vérification des noms de domaine interdits était désactivée.',

    'edit.title' => '%%name%%',
    'edit.domainUpdated' => 'Le nom de domaine %%domain%% a bien été mis à jour.',

    'enable.listEnabled' => 'La vérification des noms de domaine interdits était activée.',

    'list.title' => 'Noms de domaine interdits',
    'list.hint' => 'Sur cette page, vous pouvez gérer la liste des noms de domaine interdits, celle-ci contenant les domaines les plus populaires. Si vous activez la vérification des noms de domaine interdits (pour cela, cliquez sur Activer), les utilisateurs ne pourront créer aucun domaine avec un nom mentionné sur cette liste. Ce type de restriction est pratique notamment pour prévenir l\'interception de mails. Si la vérification est désactivée, les mails envoyés par vos clients à des entreprises légitimes peuvent être reçus par les clients qui ont configuré des domaines portant le même nom que ceux de ces entreprises.',
    'list.warningLisDisabled' => 'La vérification des noms de domaine interdits est désactivée.',

    'remove.domainRemoved' => 'Les noms de domaine sélectionnés ont été supprimés.',
    'remove.domainNotRemoved' => 'Certains des noms de domaine sélectionnés n\'ont pas été supprimés.',
    'remove.unableRemove' => 'Certains des noms de domaine indiqués n\'ont pas été supprimés.',
];