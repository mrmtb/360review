<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'assign-to-subscription.databasesSuccessfullyAssignedToSubscription' => 'Les bases de données ont été déplacées vers l\'abonnement \'%%subscriptionName%%\'.',
    'assign-to-subscription.databasesNotAssignedToSubscription' => 'Impossible de déplacer les bases de données vers l\'abonnement \'%%subscriptionName%%\'.',
    'assign-to-subscription.subscriptionNotFound' => 'L\'abonnement \'%%name%%\' n\'a pas été trouvé.',
    'assign-to-subscription.isNotMainDomain' => '\'%%name%%\' n\'est pas le domaine principal de l\'abonnement.',

    'settings.title' => 'Paramètres d\'hébergement de la base de données',
    'settings.settingsSaved' => 'Les paramètres d\'hébergement de la base de données ont été enregistrés.',

    'refresh.success' => 'Les informations sur le serveur de bases de données ont été actualisées.',
];