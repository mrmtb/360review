<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'clear-cache.apsCacheCleared' => 'Les fichiers temporaires ont été supprimés.',

    'configure.title' => '%%name%%',
    'configure.applicationNotFound' => "Impossible de trouver l'application avec l'ID '%%id%%'.",
    'configure.applicationHasNoSettings' => 'L\'application n\'a aucun paramètre.',
    'configure.settingsUpdated' => 'Les paramètres de l\'application ont été mis à jour.',
    'configure.settingsUpdateFailed' => 'Les paramètres des applications n\'ont pas pu être mis à jour.%%error%%',
    'configure.instancesNotReconfigured' => 'Certaines des instances de l\'application n\'ont pas été reconfigurées.',

    'index.title' => 'Référentiel d\'applications',

    'info.title' => '%%name%%',
    'info.hint' => 'La liste ci-dessous contient les informations sur les sites Web sur lequel l\'application est installée. La valeur Aucune dans la colonne Site Web signifie que l\'application est externe. Impossible d\'installer une telle application sur un site web d\'un certain client ; il n\'offre qu\'un lien vers un service externe.',

    'remote-app-info.title' => 'Détails de l\'application',

    'update-settings.title' => 'Paramètres de mise à jour',
    'update-settings.settingsUpdated' => 'Les paramètres ont été mis à jour.',
    'update-settings.settingsUpdateFailed' => 'Impossible de mettre à jour les paramètres : %%error%%',

    'upload.title' => 'Ajouter une application',
    'upload.packageInstallationError' => 'L\'application n\'a pas pu être ajoutée : %%message%%.',
    'upload.appUploaded' => 'L\'application a bien été envoyée.',
    'upload.appDownloadStarted' => 'Téléchargement des applications sélectionnées.',

    'uploaded.title' => 'Mes applications',
    'uploaded.hint' => 'Sur cette page, vous pouvez ajouter ou supprimer des applications à partir du Référentiel d\'applications. Vous pouvez aussi y gérer la disponibilité des applications pour les clients. ll y a deux raisons pour ajouter les applications : étendre la liste des applications disponibles ou configurer les paramètres valables pour l\'ensemble des serveurs des applications. Certaines applications ne peuvent pas être installées sans une telle configuration. Toutes les applications ajoutées sont listées ci-dessous.',
    'uploaded.infoAppDeleted' => 'Les applications sélectionnées ont été supprimées.',
    'uploaded.infoAppNotDeleted' => 'Certaines applications sélectionnées n\'ont pas été supprimées.',
    'uploaded.applicationsNowAvailable' => 'Les applications sélectionnées sont désormais disponibles pour l\'installation par les clients ou pour la configuration.',
    'uploaded.applicationsNowNotAvailable' => 'Les applications sélectionnées ne sont plus disponibles pour l\'installation par les clients ou pour la configuration.',
    'uploaded.cantChangePackageProperties' => 'Une erreur s\'est produite en essayant de changer les paramètres de disponibilité de l\'application.',
    'uploaded.appDownloaded' => 'Les applications sélectionnées ont bien été téléchargées.',
    'uploaded.appNotDownloaded' => 'Certaines des applications sélectionnées n\'ont pas été téléchargées.',
    'uploaded.downloadInProgress' => 'Veuillez patienter...',

    'usage.title' => 'Applications installées',
    'usage.hint' => 'La liste ci-dessous contient toutes les applications que vous avez installées par vous-même ou que vos clients ont installées. Sur cette page, vous pouvez gérer les paramètres d\'applications, vérifier les mises à jour ou supprimer les fichiers temporaires qui ont été ajoutés lors des installations des applications.',
    'usage.hintReseller' => 'La liste ci-dessous affiche les informations sur toutes les installations des applications sur vos sites et sur les sites de vos clients. Cliquez sur un nom d\'application pour voir une liste des sites Web sur lesquels l\'application est installée et pour vérifier les mises à jour pour l\'application.',
];