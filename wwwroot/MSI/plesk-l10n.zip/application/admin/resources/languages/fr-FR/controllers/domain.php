<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoDomainActivated' => 'Les domaines et alias sélectionnés étaient activés.',
    'activate.errorDomainNotActivated' => 'Certains domaines ou alias sélectionnés n\'étaient pas activés.',
    'activate.domainStillSuspended' => 'Impossible d\'activer le domaine : %%reason%%',
    'activate.domainStatusOffByAdmin' => 'Le domaine est suspendu par l\'administrateur.',
    'activate.domainStatusOffWithParent' => 'Le propriétaire du domaine ou leur abonnement est suspendu.',
    'activate.domainStatusOffExpired' => 'L\'abonnement correspondant a expiré.',
    'activate.domainStatusOffBackupRestore' => 'Ce domaine est temporairement suspendu pour la sauvegarde ou la restauration.',
    'activate.domainStatusOff' => 'Le domaine est suspendu.',
    'activate.aliasStillSuspended' => 'Impossible d\'activer l\'alias : le domaine cible est suspendu.',

    'add-domain-alias.noDomains' => 'Impossible de créer un alias : il n\'y a aucun domaine disponible.',

    'add-domain.noDomains' => 'Impossible de créer un domaine supplémentaire : il n\'y a aucun domaine disponible.',

    'add-subdomain.noDomains' => 'Impossible de créer un sous-domaine : il n\'y a aucun domaine disponible.',

    'disable.infoDomainDisabled' => 'Les domaines sélectionnés ont été désactivés.',
    'disable.errorDomainNotDisabled' => 'Certains domaines sélectionnés n\'ont pas été désactivés.',

    'list.title' => 'Domaines',
    'list.customerLinkTitle' => 'créer un compte client',
    'list.subscriptionLinkTitle' => 'créer votre abonnement personnel',

    'suspend.infoDomainSuspended' => 'Les domaines sélectionnés ont été suspendus.',
    'suspend.errorDomainNotSuspended' => 'Certains domaines sélectionnés n\'ont pas été suspendus.',
];