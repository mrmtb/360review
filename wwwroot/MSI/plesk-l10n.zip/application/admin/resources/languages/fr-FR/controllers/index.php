<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'eula.title' => 'Contrat de Licence Utilisateur Final WebPros',
    'eula.popupTitle' => 'CLUF',
    'eula.updatePopupTitle' => 'Mise à jour du CLUF',
    'eula.popupDescription' => 'Vous devez lire et accepter le CLUF avant de poursuivre l\'utilisation du produit.',
    'eula.updatePopupDescription' => 'Le CLUF WebPros a été mis à jour. Vous devez lire et accepter le CLUF mis à jour avant de poursuivre l\'utilisation du produit.',
    'eula.buttonAccept' => 'J\'accepte',
    'eula.buttonDecline' => 'Je refuse',
];