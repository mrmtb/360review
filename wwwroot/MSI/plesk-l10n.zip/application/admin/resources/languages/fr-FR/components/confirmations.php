<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-customer-owner.title' => 'Déplacement des clients vers un autre propriétaire',
    'change-customer-owner.description' => 'Les comptes client seront déplacés vers un autre propriétaire. Vous pouvez modifier les packs de services pour les abonnements client. Afin de conserver les ressources disponibles pour un client, laissez le pack de services Personnalisé sélectionné.',
    'change-customer-owner.ownerHint' => 'Les clients seront déplacés vers le propriétaire sélectionné :',
    'change-customer-owner.ipAddressHint' => 'Il n\'est pas possible de conserver une adresse IP dédiée.',
    'change-customer-owner.loading' => 'Veuillez patienter...',
    'change-customer-owner.ipAddressNotSelected' => 'Sélectionnez au moins une adresse IP pour chaque abonnement.',
    'change-customer-owner.ownerNotSelected' => 'Sélectionnez un propriétaire.',

    'customer.title' => 'Conversion des clients en revendeurs',
    'customer.description' => 'Les comptes client suivants seront convertis en comptes revendeur. Vous pouvez choisir les packs revendeurs pour les comptes convertis. Afin de conserver les ressources qui sont disponibles pour un client, sélectionnez le pack Personnalisé : le revendeur aura la totalité des allocations de ressources, des droits et applications de tous les abonnements.',
    'customer.loading' => 'Conversion...',

    'reseller.title' => 'Conversion des revendeurs en clients',
    'reseller.description' => 'Les revendeurs seront convertis en clients.',
    'reseller.descriptionExtended' => 'Choisissez les nouveaux packs de services pour les revendeurs qui ont leurs propres abonnements. Afin de conserver les ressources disponibles pour un revendeur, sélectionnez le Pack de services personnalisé. Pour déplacer les abonnements du revendeur vers l\'un des packs de services existants, sélectionnez un pack de services existant.',
    'reseller.loading' => 'Conversion...',
];