<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'admin-customers-target-list.title' => 'Clients de l\'admin qui ont besoin d\'être transférés',
    'admin-customers-target-list.hint-t1s1' => 'Voici la liste d\'utilisateurs, créée à partir des clients non autorisés à modifier les limites de domaine et disposant d\'un domaine avant mise à niveau.',
    'admin-customers-target-list.hint-t1s2' => 'Voici la liste d\'utilisateurs, créée à partir des clients autorisés à modifier les limites de domaine et disposant d\'un domaine avant mise à niveau.',
    'admin-customers-target-list.hint-t1s3' => 'Voici la liste d\'utilisateurs, créée à partir des clients non autorisés à créer des domaines, modifier les limites de domaine et disposant de plusieurs domaines avant mise à niveau.',
    'admin-customers-target-list.hint-t1s6' => 'Voici la liste d\'utilisateurs, créée à partir des clients autorisés à créer des domaines, modifier les limites de domaine et disposant de plusieurs domaines avant mise à niveau.',

    'admin-subscriptions-target-list.title' => 'Abonnements de l\'admin qui ont besoin d\'être transférés',
    'admin-subscriptions-target-list.hint' => 'Voici la liste d\'abonnements, créée à partir des domaines qui (a) appartenaient à un administrateur et (b) pour lesquels le compte administrateur de domaines était activé avant la mise à niveau.',

    'bunch.title' => 'Terminer la transition vers le nouveau modèle commercial Plesk',
    'bunch.noActionsDescription' => 'Aucun client et abonnement correspondant aux scénarios n\'est laissé dans le système. Vous n\'avez donc rien à faire. Veuillez aller dans le prochain onglet et transférez les clients restants.',
    'bunch.description' => 'Le modèle de répartition des ressources de Plesk 10 et des versions ultérieures est différent de celui des versions précédentes : depuis Plesk 10 (et contrairement à Plesk 8 et 9), les utilisateurs ne disposent plus de ressources personnelles mais en obtiennent par abonnement. Actuellement, plusieurs utilisateurs disposant de ressources héritées devraient être migrés correctement pour correspondre au nouveau modèle Plesk. Sur la base de cas d\'utilisation courants de Plesk, Plesk a analysé ces utilisateurs et généré une liste d\'actions de migration recommandées, disponible ci-dessous. Vous pouvez poursuivre ou sélectionner un modèle de transition par client. Une fois qu\'un utilisateur est migré, il disparaît de la liste.',
    'bunch.help' => 'En savoir plus sur le transfert.',
    'bunch.applyed' => 'Les clients et abonnements sélectionnés ont été transférés.',
    'bunch.failed' => 'Impossible de transférer les clients et abonnements sélectionnés.',

    'customers.title' => 'Terminer la transition vers le nouveau modèle commercial Plesk : migration sélective des clients',
    'customers.description' => 'C\'est une liste de clients qui ont besoin d\'être transférés. Outre les comptes correspondants aux scénarios communs, elle inclut ceux avec des paramètres irréguliers pour lesquels aucune action n\'est recommandée. Vous devez choisir un plan de transfert applicable vous-même, en partant des paramètres d\'un ancien client particulier, comme les limites, droits, nombre réel de domaines, etc. Pour découvrir les limites et droits d\'un ancien client, cliquez sur le nom du client puis sur \'Mes ressources\' dans une liste d\'abonnements clients.',
    'customers.help' => 'En savoir plus sur le transfert.',

    'manual-customer-solution.appliedInfo' => 'Les clients sélectionnés ont été transférés.',
    'manual-customer-solution.notAppliedInfo' => 'Tous les clients sélectionnés ou plusieurs d\'entre eux n\'ont pas été transférés.',

    'manual-subscription-solution.appliedInfo' => 'Les abonnements sélectionnés ont été transférés.',
    'manual-subscription-solution.notAppliedInfo' => 'Tous les abonnements sélectionnés ou plusieurs d\'entre eux n\'ont pas été transférés.',

    'notes.nonApplicableCustomers' => "%%count%% clients ne correspondent à aucun scénario commun. Aucune action ne leur est recommandée. Pour transférer les comptes, %%link%%.",
    'notes.nonApplicableSubscriptions' => "%%count%% abonnements ne correspondent à aucun scénario commun. Aucune action ne leur est recommandée. Pour transférer les abonnements, %%link%%.",
    'notes.manualCustomersUpgradeLink' => 'sélectionner un plan personnalisé pour eux',
    'notes.manualSubscriptionsUpgradeLink' => 'sélectionner un plan personnalisé pour eux',

    'reseller-customers-target-list.title' => 'Clients des revendeurs qui ont besoin d\'être transférés',
    'reseller-customers-target-list.hint-t2s1' => 'Voici la liste d\'utilisateurs, créée à partir des clients non autorisés à modifier les limites de domaine et disposant d\'un domaine avant mise à niveau.',
    'reseller-customers-target-list.hint-t2s2' => 'Voici la liste d\'utilisateurs, créée à partir des clients autorisés à modifier les limites de domaine et disposant d\'un domaine avant mise à niveau.',
    'reseller-customers-target-list.hint-t2s3' => 'Voici la liste d\'utilisateurs, créée à partir des clients non autorisés à créer des domaines, modifier les limites de domaine et disposant de plusieurs domaines avant mise à niveau.',
    'reseller-customers-target-list.hint-t2s6' => 'Voici la liste d\'utilisateurs, créée à partir des clients autorisés à créer des domaines, modifier les limites de domaine et disposant de plusieurs domaines avant mise à niveau.',

    'reseller-subscriptions-target-list.title' => 'Abonnements des revendeurs qui ont besoin d\'être transférés',
    'reseller-subscriptions-target-list.hint' => 'Voici la liste d\'abonnements, créée à partir des domaines qui (a) appartenaient à des revendeurs et (b) pour lesquels le compte administrateur de domaines était activé avant la mise à niveau.',

    'subscriptions.title' => 'Terminer la transition vers le nouveau modèle commercial Plesk : migration sélective des abonnements',
    'subscriptions.description' => 'Voici une liste d\'abonnements qui ont besoin d\'être transférés. Elle contient les mêmes abonnements que la page Actions recommandées mais ici, vous pouvez sélectionner le plan de transfert qui correspond le plus à un abonnement particulier. Voici une liste d\'abonnements créés à partir des domaines qui (a) appartenaient à l\'admin ou à un revendeur et (b) avaient activé le compte administrateur de domaines.',
    'subscriptions.help' => 'En savoir plus sur le transfert.',

    'tabs.bunch' => 'Actions recommandées',
    'tabs.customers' => 'Transfert sélectif des clients',
    'tabs.subscriptions' => 'Transfert sélectif des abonnements',
];