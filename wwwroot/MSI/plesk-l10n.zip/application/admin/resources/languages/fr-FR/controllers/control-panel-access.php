<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-network.title' => 'Ajouter un réseau',
    'add-network.added' => 'Le réseau %%address%% a été ajouté.',

    'delete-network.noNetworksSpecified' => 'Sélectionner un ou plusieurs réseaux dans la liste des restrictions d\'accès par IP.',
    'delete-network.networksDeleted' => 'Les réseaux sélectionnés ont été supprimés.',
    'delete-network.networksNotDeleted' => 'Certains des réseaux sélectionnés n\'ont pas été supprimés. Détails : %%error%%.',

    'edit-network.title' => 'Édition du réseau',
    'edit-network.updated' => 'Le réseau %%address%% a été mis à jour.',

    'list.title' => 'Gestion des restrictions d\'accès de l\'IP',
    'list.currentIpAddressDenied' => 'La politique de restriction de l\'accès et la liste des réseaux sont actuellement configurées de sorte que vous ne pourrez pas vous connecter à l\'aide des droits de l\'administrateur à partir de votre adresse IP \'%%remoteAddress%%\'.',
    'list.allowHint' => 'L\'accès à Plesk avec les privilèges administrateur est autorisé, sauf pour les réseaux indiqués dans la liste.',
    'list.denyHint' => 'L\'accès à Plesk avec les privilèges administrateur est refusé depuis tous les réseaux qui ne sont pas répertoriés ici.',

    'settings.title' => 'Paramètres de restriction d\'accès de l\'IP',
    'settings.settingsSaved' => 'La politique de restrictions d\'accès de l\'IP a été enregistrée.',
];