<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-sessions.noSessionsSpecified' => 'Sélectionnez une ou plusieurs sessions FTP depuis la liste.',
    'delete-sessions.sessionsDeleted' => 'Les sessions sélectionnées ont été supprimées.',
    'delete-sessions.sessionsNotDeleted' => 'Certaines des sessions sélectionnées n\'ont pas été supprimées. Détails : %%error%%.',

    'list.title' => 'Sessions FTP',
];