<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Paramètres du serveur SMTP externe',
    'index.settingsUpdated' => 'Les paramètres ont été mis à jour.',
];