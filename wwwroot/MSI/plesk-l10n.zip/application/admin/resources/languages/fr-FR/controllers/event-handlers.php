<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Ajout du gestionnaire d\'événements',
    'add.added' => 'Le gestionnaire d\'événement a été ajouté.',

    'delete.noHandlersSpecified' => 'Sélectionnez les gestionnaires d\'événements à supprimer.',
    'delete.handlersDeleted' => 'Les gestionnaires d\'événements sélectionnés ont été supprimés.',
    'delete.handlersNotDeleted' => 'Certains des gestionnaires d\'événements sélectionnés n\'ont pas été supprimés. Détails : %%error%%.',

    'edit.title' => 'Mise à jour des propriétés du gestionnaire d\'événements',
    'edit.updated' => 'Le gestionnaire d\'événements a été mis à jour.',

    'list.title' => 'Gestionnaire d\'événements',
];