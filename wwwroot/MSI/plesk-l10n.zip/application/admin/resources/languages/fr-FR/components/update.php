<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'email.subjSuccess' => 'Plesk a bien été mis à jour.',
    'email.subjFailure' => 'Échec de la mise à jour de Plesk',
    'email.bodySuccess' => "Attention,\n\nPlesk a bien été mis à jour.\nPour afficher la liste des changements, cliquez sur ce lien %%link%%.\n\nCe message a été envoyé automatiquement par le Programme d'installation de Plesk.",
    'email.bodyFailure' => "Attention,\n\nla mise à jour de Plesk a échoué.\n\nVous pouvez télécharger les journaux du Programme d'installation de Plesk depuis le lien suivant : %%link%%.\nContactez votre hébergeur pour obtenir de l'aide.\n\nCe message a été envoyé automatiquement par le Programme d'installation de Plesk.",
];