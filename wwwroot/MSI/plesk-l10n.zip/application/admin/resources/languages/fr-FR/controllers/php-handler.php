<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Paramètres PHP',
    'list.hint' => 'Sélectionnez les gestionnaires PHP que vous voulez rendre disponible. Vous pouvez installer des gestionnaires supplémentaires à l\'aide du %%link%%.',
    'list.hintLink' => 'Programme d\'installation de Plesk',
    'list.brokenDomainsError' => 'La ou les versions de PHP suivantes ne sont pas installées : %%phpVersions%%. Le script PHP pour %%domainCount%% domaine(s) n\'est pas disponible. Installez les versions de PHP manquantes ou suivez les instructions disponibles dans l\'<a href=https://support.plesk.com/hc/en-us/articles/12377342328343>article de la base de connaissances</a> pour réparer le script PHP.',
    'list.brokenHandlersError' => 'La ou les versions de PHP suivantes ne sont pas installées : %%phpVersions%%. Installez ces versions ou exécutez <code>plesk repair web -php-handlers</code> pour sélectionner une autre version de PHP.',

    'modules.canNotManageModules' => 'L\'accès à la gestion des paramètres du gestionnaire PHP est limité, car le chemin d\'accès au fichier CLI PHP n\'est pas indiqué.',

    'php-ini.title' => 'Paramètres pour <b> %%name%%</b>',
    'php-ini.tabTitle' => 'php.ini',
    'php-ini.success' => 'Les paramètres ont été mis à jour.',

    'toggle.errorEnableBrokenHandler' => 'Le gestionnaire est corrompu et ne peut pas être activé.',
    'toggle.errorDisableBrokenHandler' => 'Le gestionnaire est corrompu et ne peut pas être désactivé.',
    'toggle.infoHandlerEnabled' => 'Le gestionnaire a été activé.',
    'toggle.infoHandlerDisabled' => 'Le gestionnaire a été désactivé.',
];