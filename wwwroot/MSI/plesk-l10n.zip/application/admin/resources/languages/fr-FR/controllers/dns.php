<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'acl-records.title' => 'Template de restrictions des transferts',

    'add-acl-record.title' => 'Ajouter une adresse IP',
    'add-acl-record.success' => 'Les adresses IP spécifiées ont été ajoutées.',

    'delete-acl-record.success' => 'Les adresses IP sélectionnées ont été supprimées.',

    'index.title' => 'Paramètres DNS',

    'records.title' => 'Template d\'enregistrements de la zone',

    'reset-settings.success' => 'Les paramètres par défaut ont été restaurés.',

    'settings.title' => 'Paramètres valables pour tout le serveur',
    'settings.success' => 'Les paramètres ont bien été mis à jour.',

    'soa-record.title' => 'Template des paramètres de la zone',

    'restore-default.title' => 'Restaurer le template par défaut de zone DNS',
    'restore-default.text' => 'Voulez-vous vraiment restaurer la configuration par défaut du template de zone DNS ?',

    'soa-sync.title' => 'Remplacer les paramètres SOA de tous les domaines existants',
    'soa-sync.text' => 'Mettre à jour les entrées SOA de tous les domaines hébergés en appliquant les modifications faites sur le template SOA ?',

    'sync.title' => 'Appliquer les modifications du template DNS',
    'sync.type-option' => 'Choisir l\'une des options suivantes',
    'sync.safe' => 'Appliquez les modifications à toutes les zones intactes. Si une zone a été personnalisée (de nouveaux enregistrements ont été ajoutés ou des entrées existantes ont été modifiées), Plesk n\'appliquera pas les modifications du template à ces zones.',
    'sync.force' => 'Appliquez les modifications à toutes les zones. Plesk applique les modifications du template à toutes les zones DNS, y compris les zones personnalisées. Notez que toutes les entrées modifiées par l\'utilisateur restent intactes. Par exemple, si le template contient une nouvelle entrée déjà ajoutée par un client, Plesk conserve l\'entrée du client.',

    'external-dns.title' => 'DNS externe',
    'external-dns.hint' => 'Sur cette page, vous pouvez configurer les serveurs DNS externes.',
    'external-dns.success' => 'Enregistré',
    'external-dns.configured' => 'Configuré',
    'external-dns.notConfigured' => 'Non configuré',
    'external-dns.useExtension' => 'Utiliser cette extension',

    'external-dns-edit.title' => 'DNS externe',
];