<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-password.title' => "Changement du mot de passe de l'administrateur",
    'change-password.passwordChanged' => 'Le mot de passe de l\'administrateur a été changé.',

    'index.personalInfoTitle' => "Édition du profil d'administrateur",
    'index.successMessage' => "Votre profil a été mis à jour.",
    'index.aliasInfoTitle' => 'Informations sur le compte administrateur supplémentaire',
    'index.aliasInfoUpdated' => 'Le profil du compte administrateur supplémentaire a été mis à jour.',
];