<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoAdminAliasActivated' => 'Les comptes administrateur sélectionnés ont bien été activés.',
    'activate.infoAdminAliasNotActivated' => 'Certains comptes administrateur sélectionnés n\'ont pas été activés.',

    'create.title' => 'Ajout d\'un compte administrateur',
    'create.infoNewAdminAliasCreated' => 'Le compte administrateur supplémentaire %%contact%% a bien été créé.',

    'deactivate.infoAdminAliasDeactivated' => 'Les comptes administrateur sélectionnés ont bien été suspendus.',
    'deactivate.infoAdminAliasNotDeactivated' => 'Certains comptes administrateur sélectionnés n\'ont pas été suspendus.',

    'delete.infoAdminAliasDeleted' => 'Les comptes administrateur sélectionnés ont bien été supprimés.',
    'delete.infoAdminAliasNotDeleted' => 'Certains comptes administrateur sélectionnés n\'ont pas été supprimés.',

    'edit.title' => "%%contact%%",
    'edit.infoNewAdminAliasUpdated' => 'Le compte administrateur a bien été mis à jour.',

    'list.title' => 'Comptes administrateur supplémentaires',
    'list.hint' => 'Vous pouvez créer des comptes administrateur supplémentaires pour vos ingénieurs de l\'assistance technique. Ceci leur permet de réaliser tout un panel de tâches administratives.',
];