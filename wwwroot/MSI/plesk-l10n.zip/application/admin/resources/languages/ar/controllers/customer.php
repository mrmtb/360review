<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-domain-alias.noDomains' => 'يتعذر إنشاء اسم مستعار: لا توجد نطاقات متاحة.',

    'add-domain.noDomains' => 'يتعذر إنشاء نطاق الوظيفة الإضافية: لا توجد نطاقات متاحة.',

    'add-subdomain.noDomains' => 'يتعذر إنشاء نطاق فرعي: لا توجد نطاقات متاحة.',

    'change-owner.wrongOwnerId' => 'يتعذر العثور على مالك جديد لحساب العميل.',

    'change.title' => 'تغيير الخطة والوظيفة الإضافية المقترنة بالاشتراكات',

    'create.title' => 'إضافة عميل جديد',

    'domains.title' => 'المجالات',

    'list.title' => 'العملاء',
    'list.infoNewCustomerCreated' => 'تم إنشاء العميل %%name%%.',
    'list.infoCustomerActivated' => 'تم تفعيل العملاء المحددين.',
    'list.infoCustomerNotActivated' => 'لم يتم تفعيل بعض العملاء المحددين.',
    'list.infoCustomerSuspended' => 'تم إيقاف العملاء المحددين مؤقتًا.',
    'list.infoCustomerNotSuspended' => 'لم يتم تعليق بعض العملاء المحددين.',
    'list.infoCustomerDeleted' => 'تم حذف العملاء المحددين.',
    'list.infoCustomerNotDeleted' => 'لم يتم حذف بعض العملاء المحددين.',
    'list.upgrageCustomersHint' => 'لقد قمت بالترقية إلى Plesk 11، الذي يستخدم نموذجًا جديدًا للعميل والأعمال. للانتهاء من عملية التبديل إلى النموذج الجديد، حوّل حسابات الوكيل إلى حسابات عميل أو حسابات بائع تجزئة. إذا لم تقم بذلك، فلن يستطيع عملاؤك إنشاء مواقع الويب حتى في حالة منحهم هذا الإذن من قبل.',
    'list.upgrageCustomersLink' => 'تحويل حسابات العميل.',
    'list.infoCustomerToResellerConverted' => 'تم تحويل العملاء المحددين إلى بائعي تجزئة بنجاح.',
    'list.errorCustomerToResellerNotConverted' => 'لم يتم تحويل بعض العملاء المحددين إلى بائعي تجزئة.',
    'list.infoOwnerChanged' => 'تم نقل العملاء المحددين إلى %%name%%.',
    'list.infoOwnerNotChanged' => 'لم يتم نقل بعض العملاء المحددين إلى %%name%%.',

    'login-info.title' => 'تعديل معلومات تسجيل الدخول الخاصة بـ %%name%%',

    'overview.title' => '%%name%%',

    'personal-info.title' => 'تعديل معلومات جهة الاتصال الخاصة بـ %%name%%',

    'subscriptions.title' => 'اشتراكات',
];