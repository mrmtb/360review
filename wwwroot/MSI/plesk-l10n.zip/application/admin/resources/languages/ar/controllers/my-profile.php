<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-password.title' => "‫تغيير كلمة مرور المسؤول‬",
    'change-password.passwordChanged' => '‫تم تغيير كلمة مرور المسؤول.‬',

    'index.personalInfoTitle' => "‫تحرير ملف تعريف المسؤول‬",
    'index.successMessage' => "‫تم تحديث ملف تعريفك.‬",
    'index.aliasInfoTitle' => '‫معلومات حساب المسؤول الإضافي‬',
    'index.aliasInfoUpdated' => '‫تم تحديث المعلومات الشخصية لحساب المسؤول الإضافي.‬',
];