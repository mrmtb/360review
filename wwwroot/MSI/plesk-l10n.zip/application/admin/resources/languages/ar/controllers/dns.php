<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'acl-records.title' => 'نقل قالب القيود',

    'add-acl-record.title' => 'إضافة عنوان IP',
    'add-acl-record.success' => 'أُضيفت عناوين IP المحددة بنجاح.',

    'delete-acl-record.success' => 'تمت إزالة عناوين IP المحددة بنجاح.',

    'index.title' => 'إعدادات DNS',

    'records.title' => 'قالب سجلات المنطقة',

    'reset-settings.success' => 'تمت استعادة الإعدادات الافتراضية بنجاح.',

    'settings.title' => 'الإعدادات على مستوى الخادم',
    'settings.success' => 'تم تحديث الإعدادات بنجاح.',

    'soa-record.title' => 'قالب إعدادات المنطقة',

    'restore-default.title' => 'استعادة قالب منطقة DNS الافتراضي',
    'restore-default.text' => 'يرجى تأكيد رغبتك في استعادة التكوين الافتراضي لقالب منطقة DNS.',

    'soa-sync.title' => 'تجاوز إعدادات البنية الخدمية "SOA" لجميع النطاقات الحالية',
    'soa-sync.text' => 'تحديث سجلات SOA لجميع النطاقات المستضافة من خلال تطبيق التغييرات التي تم إجراؤها على نموذج SOA؟',

    'sync.title' => 'تطبيق تغييرات قالب DNS',
    'sync.type-option' => 'اختر أيًا مما يلي',
    'sync.safe' => 'تطبيق التغييرات على المناطق التي لم يحدث لها تعديل. إذا تم تخصيص منطقة معينة (سجلات جديدة تمت إضافتها أو أخرى موجودة تم تغييرها)، فلن يطبق Plesk التغييرات من القالب على تلك المناطق.',
    'sync.force' => 'تطبيق التغييرات على جميع المناطق. سيطبق Plesk التغييرات من القالب على جميع مناطق DNS ويشمل ذلك المناطق المخصصة. لاحظ أن السجلات المعدلة بواسطة المستخدم تظل كما هي. على سبيل المثال، إذا كان القالب يتضمن سجلاً جديدًا تمت إضافته بالفعل عن طريق أحد العملاء، فسيحتفظ Plesk بسجل العميل.',

    'external-dns.title' => 'نظام DNS الخارجي',
    'external-dns.hint' => 'هنا يمكنك تكوين خوادم DNS الخارجية',
    'external-dns.success' => 'تم الحفظ',
    'external-dns.configured' => 'تم تكوينه',
    'external-dns.notConfigured' => 'غير مكوّن',
    'external-dns.useExtension' => 'استخدم هذا الملحق',

    'external-dns-edit.title' => 'نظام DNS الخارجي',
];