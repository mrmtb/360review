<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'oversell-policy.title' => 'تغيير سياسة زيادة المبيعات',
    'oversell-policy.pageHint' => 'هنا حيث يمكنك تغيير سياسة زيادة المبيعات الحالية.',
    'oversell-policy.oversellPolicyChanged' => 'تم تحديث سياسة زيادة المبيعات بنجاح.',
    'oversell-policy.oversellPolicyNotChanged' => 'يتعذر تحديث سياسة زيادة المبيعات في البيع.',

    'subscription-overview.title' => 'نظرة عامة على الاشتراك',
    'subscription-overview.pageHint' => 'هذه نظرة عامة عن اشتراكك، وتتضمن معلومات حول مقدار الموارد المستخدمة مقابل المُقدّمة، وسياسة الإفراط في البيع والمزايا والخدمات المُقدّمة مع الاشتراك.',
    'subscription-overview.changeOversellPolicyLink' => '[تغيير]',
    'subscription-overview.oversellEnabledHint' => 'يسمح اشتراكك بوجود الموارد المبالغ في بيعها، مما يعني أنه يمكنك بيع موارد أكثر من المقدار المخصص مع اشتراكك. وفي هذه الحالة، تخضع لاستخدام المورد الفعلي بدلاً من تخصيص المورد الأولي.',
    'subscription-overview.oversellDisableHint' => 'يحظر اشتراكك الموارد المبالغ في بيعها، مما يعني أنه يمكنك فقط بيع موارد بالقدر المخصص منذ البداية مع اشتراك، بغض النظر عن مقدار تلك الموارد المستخدمة فعليًا.',
    'subscription-overview.tabResources' => 'الموارد',
    'subscription-overview.tabPermissions' => 'الأذونات',
    'subscription-overview.resourcesSummaryHint' => 'هذا ملخص عن استخدام الموارد المقدّمة مع الاشتراك.',
    'subscription-overview.showMoreResources' => 'إظهار المزيد من الموارد المتوفرة',
    'subscription-overview.hideMoreResources' => 'إظهار القليل من الموارد',
    'subscription-overview.permissionsSummaryHint' => 'هذه قائمة بالخدمات والمزايا المُقدمة مع الاشتراك.',
    'subscription-overview.hideMorePermissions' => 'إظهار أذونات أقل',
    'subscription-overview.showMorePermissions' => 'إظهار المزيد من الأذونات',
];