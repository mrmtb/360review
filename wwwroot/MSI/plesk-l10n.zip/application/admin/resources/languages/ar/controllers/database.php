<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'assign-to-subscription.databasesSuccessfullyAssignedToSubscription' => 'تم نقل قواعد البيانات إلى الاشتراك /"%%subscriptionName%%/".',
    'assign-to-subscription.databasesNotAssignedToSubscription' => 'يتعذر نقل قواعد البيانات إلى الاشتراك /"%%subscriptionName%%/".',
    'assign-to-subscription.subscriptionNotFound' => 'لم يتم العثور على الاشتراك /"%%name%%/".',
    'assign-to-subscription.isNotMainDomain' => '/"%%name%%/" ليس المجال الرئيسي على الاشتراك.',

    'settings.title' => 'إعدادات استضافة قاعدة البيانات',
    'settings.settingsSaved' => 'تم حفظ إعدادات استضافة قاعدة البيانات.',

    'refresh.success' => 'تم تحديث معلومات خوادم قاعدة البيانات.',
];