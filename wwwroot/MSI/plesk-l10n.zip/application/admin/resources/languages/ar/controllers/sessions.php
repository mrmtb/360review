<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => '‫إدارة الجلسات‬',

    'remove.sessionsDeleted' => '‫تمت إزالة جلسات العمل المحددة بنجاح.‬',

    'settings.title' => '‫إعدادات الجلسة‬',
    'settings.settingsUpdated' => '‫تم تغيير الإعدادات بنجاح.‬',
];