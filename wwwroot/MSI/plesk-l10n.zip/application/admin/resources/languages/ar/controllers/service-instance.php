<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.formTitle' => 'اختيار خدمة للإضافة',
    'create.successfullyAdded' => 'تم إنشاء خدمة /"%%serviceDisplayName%%/" بنجاح.',
    'create.successfullyUpdated' => 'تم تحديث خدمة /"%%serviceDisplayName%%/" بنجاح.',
    'create.selectServiceInstallationTitle' => 'تحديد خدمة',

    'edit.formTitle' => 'إدارة خدمة /"%%serviceDisplayName%%/"',
    'edit.title' => 'خدمات %%subscriptionName%%',
    'edit.successfullyUpdated' => 'تم تحديث خدمة /"%%serviceDisplayName%%/" بنجاح.',

    'list.hint' => 'هنا يمكنك إدارة الخدمات على الاشتراك',
    'list.title' => 'خدمات %%subscriptionName%%',
    'list.breadcrumb' => 'خدمات',
    'list.infoServiceDeleted' => 'تمت إزالة الخدمات المحددة.',
    'list.infoServiceNotDeleted' => 'لم تتم إزالة بعض الخدمات المحددة.',
];