<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.hint' => 'وصف حول إضافة عقدة الخدمة البعيدة.',
    'add.title' => 'إضافة عقدة الخدمة البعيدة',
    'add.serviceNodeAdded' => 'تمت إضافة عقدة الخدمة البعيدة %%name%%',

    'delete.infoServiceNodesDeleted' => 'تم فصل عُقد الخدمات المحددة بنجاح.',
    'delete.infoServiceNodesNotDeleted' => 'يتعذر فصل بعض عُقد الخدمة المحددة.',
    'delete.serviceNodeIsInUse' => 'عقدة الخدمة قيد الاستخدام.',

    'edit.hint' => 'وصف حول تحرير عقدة الخدمة البعيدة.',
    'edit.title' => 'عقدة الخدمة البعيدة %%name%%',
    'edit.serviceNodeUpdated' => 'تم تحديث خصائص عقدة الخدمة البعيدة %%name%%',

    'list.hint' => 'هنا يمكنك إضافة عُقد الخدمة البعيدة',
    'list.title' => 'عُقد الخدمة',
];