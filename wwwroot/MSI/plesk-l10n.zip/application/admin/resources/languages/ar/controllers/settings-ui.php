<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'branding.title' => 'علامة Plesk التجارية',

    'disable-languages.disableLanguagesSuccess' => 'لم تعد اللغات المحددة متاحة للمستخدمين.',

    'edit-controls.updateSuccess' => '‫تم تحديث الإعدادات بنجاح.‬',

    'edit-interface-view.title' => '‫طرق عرض الواجهة‬',
    'edit-interface-view.updateSuccess' => '‫تم تحديث الإعدادات بنجاح.‬',

    'enable-languages.enableLanguagesSuccess' => 'أصبحت اللغات المحددة متاحة للمستخدمين.',

    'language-make-default.languageMakeDefaultSuccess' => 'تم تعيين اللغة المحددة لغةً افتراضية لموقع Plesk.',

    'list-languages.title' => '‫اللغات‬',
    'list-languages.mlsLimitExceeded' => "تتيح لك رخصة Plesk الحالية استخدام اللغات %%allowedByLicense%%. في الوقت الحالي، لديك اللغات %%availableToUsers%% التي تم إتاحتها للمستخدمين، والتي تتجاوز العدد الذي توفره الرخصة. يُرجى تحديد اللغات %%allowedByLicense%% التي ترغب في استخدامها، واجعل اللغات المتبقية غير مُتاحة للمستخدمين بالنقر فوق رموزها في العمود \\&apos;S\\&apos;.",
];