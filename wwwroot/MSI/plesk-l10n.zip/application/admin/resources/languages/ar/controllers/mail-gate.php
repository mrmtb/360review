<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'إعدادات خادم SMTP الخارجي',
    'index.settingsUpdated' => 'تم تحديث الإعدادات.',
];