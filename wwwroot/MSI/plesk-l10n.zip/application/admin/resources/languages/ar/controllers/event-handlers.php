<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => '‫إضافة معالج الأحداث‬',
    'add.added' => '‫تمت إضافة معالج الأحداث.‬',

    'delete.noHandlersSpecified' => '‫حدد معالجات الأحداث التي ترغب في إزالتها.‬',
    'delete.handlersDeleted' => '‫تمت إزالة معالجات الأحداث المحددة.‬',
    'delete.handlersNotDeleted' => '‫لم تتم إزالة بعض معالجات الأحداث.‬ ‫تفاصيل: %%error%%.‬',

    'edit.title' => '‫تحديث خصائص معالج الأحداث‬',
    'edit.updated' => '‫تم تحديث معالج الأحداث.‬',

    'list.title' => '‫مدير الأحداث‬',
];