<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'gallery.titleScreenshot' => 'لقطات الشاشة لـ %%packageName%%',
    'gallery.prevImage' => '< السابق',
    'gallery.nextImage' => 'التالي>',
    'gallery.closeGallery' => 'إغلاق',
    'gallery.navigationOf' => 'من',
    'gallery.typeScreenshot' => 'لقطات الشاشة',
    'gallery.title' => 'لقطات الشاشة',
];