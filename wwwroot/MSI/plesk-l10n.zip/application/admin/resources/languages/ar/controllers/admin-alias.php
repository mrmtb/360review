<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoAdminAliasActivated' => 'تم تنشيط حسابات المسؤول المحددة بنجاح.',
    'activate.infoAdminAliasNotActivated' => 'لم يتم تنشيط بعض حسابات المسؤول المحددة.',

    'create.title' => 'إضافة حساب مسؤول',
    'create.infoNewAdminAliasCreated' => 'تم إنشاء حساب المسؤول الإضافي %%contact%% بنجاح.',

    'deactivate.infoAdminAliasDeactivated' => 'تم إيقاف حسابات المسؤول المحددة مؤقتًا بنجاح.',
    'deactivate.infoAdminAliasNotDeactivated' => 'لم يتم إيقاف بعض حسابات المسؤول المحددة مؤقتًا.',

    'delete.infoAdminAliasDeleted' => 'تمت إزالة حسابات المسؤول المحددة بنجاح.',
    'delete.infoAdminAliasNotDeleted' => 'لم تتم إزالة بعض حسابات المسؤول المحددة.',

    'edit.title' => "%%contact%%",
    'edit.infoNewAdminAliasUpdated' => 'تم تحديث حساب المسؤول بنجاح.',

    'list.title' => 'حسابات المسؤول الإضافية',
    'list.hint' => 'هنا يمكنك إنشاء حسابات مسؤول إضافية لمهندسي الدعم الفني لديك، مما يُمكّنهم من تنفيذ مجموعة متنوعة من المهام الإدارية.',
];