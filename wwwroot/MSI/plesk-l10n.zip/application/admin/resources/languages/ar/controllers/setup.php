<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'progress.setupProgress' => 'جاري تهيئة منصة Plesk...',
];