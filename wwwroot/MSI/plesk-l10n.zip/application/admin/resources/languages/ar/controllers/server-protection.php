<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-filter.title' => 'إضافة عامل تصفية أداة الحماية.',
    'add-filter.filterAdded' => 'تمت إضافة عامل تصفية أداة الحماية.',
    'add-filter.errorFilterNotAdded' => 'تتعذر إضافة عامل تصفية أداة الحماية: %%error%%.',

    'add-jail.title' => 'إضافة أداة حماية',
    'add-jail.jailAdded' => 'تمت إضافة أداة الحماية.',

    'add-trusted-ip.title' => 'إضافة عنوان IP موثوق به',
    'add-trusted-ip.trustedListTitle' => 'عناوين IP الموثوق بها',
    'add-trusted-ip.ipAdded' => 'تمت إضافة عنوان IP إلى قائمة العناوين الموثوق بها.',
    'add-trusted-ip.errorIpNotAdded' => 'تتعذر إضافة عنوان IP: %%error%%.',

    'edit-trusted-ip.title' => 'تحرير وصف %%ip%%',
    'edit-trusted-ip.ipEdited' => 'تم تحديث وصف عنوان IP.',
    'edit-trusted-ip.ipAddressNotFound' => 'لم يُعثر على عنوان IP على القائمة الموثوقة.',
    'edit-trusted-ip.errorIpNotEdited' => 'تعذر تحرير عنوان IP: %%error%%.',

    'delete-banned-ips.infoBannedIpsDeleted' => 'تمت إزالة عناوين IP المحددة من قائمة العناوين المحظورة.',
    'delete-banned-ips.infoBannedIpsNotDeleted' => 'تتعذر إزالة بعض عناوين IP من قائمة العناوين المحظورة: %%error%%.',

    'delete-filters.infoFiltersDeleted' => 'تمت إزالة عوامل تصفية أداة الحماية.',
    'delete-filters.errorFiltersNotDeleted' => 'تتعذر إزالة عوامل التصفية المحددة: %%error%%.',
    'delete-filters.errorFiltersBuiltIn' => 'تتعذر إزالة عوامل التصفية المضمنة.',

    'delete-jail.infoJailDeleted' => 'تمت إزالة أداة الحماية.',
    'delete-jail.errorJailNotDeleted' => 'تتعذر إزالة أداة الحماية: %%error%%.',
    'delete-jail.errorJailsBuiltIn' => 'تتعذر إزالة أدوات الحماية المضمنة.',

    'delete-jails.infoJailsDeleted' => 'تمت إزالة أدوات الحماية المحددة.',
    'delete-jails.errorJailsNotDeleted' => 'تتعذر إزالة أدوات الحماية المحددة: %%error%%.',
    'delete-jails.errorJailsBuiltIn' => 'تتعذر إزالة أدوات الحماية المضمنة.',

    'delete-trusted-ips.infoTrustedIpsDeleted' => 'تمت إزالة عناوين IP المحددة من قائمة العناوين الموثوق بها.',
    'delete-trusted-ips.infoTrustedIpsNotDeleted' => 'تتعذر إزالة بعض عناوين IP من قائمة العناوين الموثوق بها: %%error%%.',
    'delete-trusted-ips.warningTrustedIpsPresentOnInterfaces' => 'توجد بعض عناوين IP الموثوق بها المحذوفة على واجهة (واجهات) الشبكة: %%ips%%. يمكن أن يكون تم حظرهم بالخطأ مما تسبب في حدوث مشكلات في عمليات الوصول إلى المواقع أو الخدمات.',

    'disable-jails.infoJailsDisabled' => 'تم إيقاف أدوات الحماية المحددة.',
    'disable-jails.errorJailsNotDisabled' => 'يتعذر إيقاف أدوات الحماية المحددة: %%error%%.',

    'edit-filter.title' => 'تحرير عامل تصفية أداة الحماية.',
    'edit-filter.filterSaved' => 'تم حفظ عامل تصفية أداة الحماية.',
    'edit-filter.errorFilterNotSaved' => 'يتعذر حفظ عامل تصفية أداة الحماية: %%error%%.',
    'edit-filter.errorFilterNotEditable' => 'لا يمكن تغيير عامل التصفية.',

    'edit-jail.title' => '%%name%%',
    'edit-jail.jailSaved' => 'تم حفظ إعدادات أداة الحماية.',
    'edit-jail.errorJailNotEditable' => 'لا يمكن تغيير أداة الحماية.',

    'enable-jails.infoJailsEnabled' => 'تم تشغيل أدوات الحماية المحددة.',
    'enable-jails.errorJailsNotEnabled' => 'يتعذر تشغيل أدوات الحماية المحددة: %%error%%.',

    'filters-list.title' => 'عوامل تصفية أداة الحماية',

    'index.title' => 'حظر عنوان IP',
    'index.banListTab' => 'عناوين IP المحظورة',
    'index.trustedListTab' => 'عناوين IP الموثوق بها',
    'index.jailListTab' => 'أدوات الحماية',
    'index.settingsTab' => 'الإعدادات',
    'index.logListTab' => 'السجلات',
    'index.jailNotFound' => 'لم يتم العثور على أداة الحماية %%name%%..',
    'index.filterNotFound' => 'لم يتم العثور على عامل التصفية %%name%%.',
    'index.logFileNotFound' => 'لم يتم العثور على ملف السجل.',
    'index.tooManyDomains' => 'قد لا يعمل Fail2Ban بشكل صحيح إذا كان هناك العديد من المجالات ويتعين على Fail2Ban مراقبة عدد كبير جدًا من ملفات السجل.',
    'index.errorServiceFailed' => 'فشلت خدمة حظر عنوان IP (Fail2Ban) وقد لا تعمل بشكل صحيح. %%link%%',
    'index.restartLink' => 'محاولة إعادة التشغيل',

    'jail-list.failed' => 'غير قادر على الحصول على قائمة العزل: %%error%%.',

    'log-view.fileIsEmpty' => 'الملف فارغ.',

    'move-to-trusted.infoTrustedIpsAdded' => 'تمت إضافة عناوين IP المحددة إلى قائمة العناوين الموثوق بها.',
    'move-to-trusted.infoTrustedIpsNotAdded' => 'تتعذر إضافة بعض عناوين IP إلى قائمة العناوين الموثوق بها: %%error%%.',

    'overview-jail.title' => '%%name%%',
    'overview-jail.pageHint' => 'هنا يمكنك الاطلاع على المعلومات التفصيلية حول أداة الحماية.',
    'overview-jail.buttonEditJail' => 'تغيير الإعدادات',
    'overview-jail.hintEditJail' => 'تغيير إعدادات أداة الحماية هذه.',
    'overview-jail.buttonDisableJail' => 'إيقاف التشغيل',
    'overview-jail.hintDisableJail' => 'إيقاف أداة الحماية هذه.',
    'overview-jail.buttonActivateJail' => 'تشغيل',
    'overview-jail.hintActivateJail' => 'تشغيل أداة الحماية هذه.',
    'overview-jail.buttonRemoveJail' => 'إزالة',
    'overview-jail.hintRemoveJail' => 'إزالة أداة الحماية هذه.',
    'overview-jail.fieldSatatus' => 'الحالة',
    'overview-jail.fieldParameters' => 'الإعدادات',
    'overview-jail.enabled' => 'نشط',
    'overview-jail.disabled' => 'غير نشط',
    'overview-jail.banListHint' => 'عناوين IP التي تم حظرها بواسطة أداة الخدمة هذه:',

    'restart.success' => 'قد يستغرق إعادة تشغيل الخدمة القليل من الدقائق.',
    'restart.failed' => 'تتعذر إعادة تشغيل الخدمة.',

    'settings.settingsSaved' => 'تم حفظ الإعدادات.',
    'settings.errorSettingsNotSaved' => 'يتعذر حفظ الإعدادات: %%error%%.',
    'settings.errorServiceFailed' => 'فشلت خدمة حظر عنوان IP (Fail2Ban): %%error%%',

    'toggle-jail.infoJailEnabled' => 'تم تشغيل أداة الحماية.',
    'toggle-jail.infoJailDisabled' => 'تم إيقاف أداة الحماية.',
    'toggle-jail.errorJailNotEnabled' => 'يتعذر تشغيل أداة الحماية: %%error%%.',
    'toggle-jail.errorJailNotDisabled' => 'يتعذر إيقاف أداة الحماية: %%error%%.',

    'add-banned-ip.title' => 'حظر عنوان IP',
    'add-banned-ip.bannedListTitle' => 'عناوين IP المحظورة',
    'add-banned-ip.ipAdded' => 'أُضيف عنوان IP إلى قائمة العناوين المحظورة.',
    'add-banned-ip.errorIpNotAdded' => 'يتعذر حظر عنوان IP: %%error%%.',
];