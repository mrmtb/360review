<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'operation.startActionSuccess' => 'تم بدء الخدمة',
    'operation.stopActionSuccess' => 'تم إيقاف الخدمة',
    'operation.restartActionSuccess' => 'تمت إعادة تشغيل الخدمة',
    'operation.changeStartupActionSuccess' => '‫تم تغيير نوع البدء للخدمة بنجاح‬',

    'list.title' => '‫خدمات‬',

    'operation.startServiceMessage' => '‫يُرجى الانتظار لبعض الوقت لتشغيل الخدمة.‬',
    'operation.stopServiceMessage' => '‫يُرجى الانتظار لبعض الوقت لإيقاف الخدمة.‬',
    'operation.restartServiceMessage' => '‫يُرجى الانتظار لبعض الوقت لإعادة تشغيل الخدمة.‬',
    'operation.unableFetchFormData' => '‫يتعذر إحضار بيانات النموذج: %%error%%‬',
    'operation.startActionError' => '‫يتعذر تشغيل الخدمة: %%error%%‬',
    'operation.stopActionError' => '‫يتعذر إيقاف الخدمة: %%error%%‬',
    'operation.restartActionError' => '‫يتعذر إعادة تشغيل الخدمة: %%error%%‬',
    'operation.changeStartupActionError' => '‫تعذر تعيين نوع البدء للخدمة: %%error%%',
];