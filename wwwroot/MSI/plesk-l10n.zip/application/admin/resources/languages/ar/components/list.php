<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'recordsTotal' => 'إجمالي العناصر %%total%%',
    'pages' => 'الصفحات',
    'firstPage' => 'الأول',
    'lastPage' => 'آخر',
    'numberOfItemPerPage' => 'المدخلات حسب الصفحة',
    'hideSearch' => 'إخفاء البحث',
    'showSearch' => 'إظهار البحث',
    'buttonSearch' => 'بحث',
    'buttonResetSearch' => 'إعادة تعيين البحث',
    'noEntriesFound' => 'لا توجد عناصر.',
    'itemsNotSelected' => 'تحديد العناصر أولاً.',
    'messageBoxButtonYes' => 'نعم',
    'messageBoxButtonNo' => 'لا',
    'messageBoxButtonOk' => 'موافق',
    'allItems' => 'الجميع',
];