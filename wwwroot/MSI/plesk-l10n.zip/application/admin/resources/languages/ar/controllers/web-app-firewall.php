<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-log.actionSuccess' => 'تمت إزالة ملفات السجل المحددة.',
    'delete-log.invalidFileName' => 'اسم ملف السجل غير صالح.',
    'delete-log.actionError' => 'تتعذر إزالة ملف السجل %%file%%: %%reason%%',

    'index.title' => 'جدار حماية تطبيق الويب',
    'index.generalTab' => 'عام',
    'index.settingsTab' => 'الإعدادات',
    'index.settingsSaved' => 'تم حفظ إعدادات جدار حماية تطبيق الويب.',
    'index.updateFailed' => 'فشل في تحديث قاعدة ModSecurity المُعيّنة: %%error%%',
    'index.updateFailedShort' => 'فشل في تحديث مجموعة قواعد ModSecurity. %%link%%',
    'index.updateFailedShortLink' => 'تفاصيل',

    'log-list.title' => 'إدارة ملفات السجل',

    'view-log.fileNameIsUndefined' => 'اسم ملف السجل غير محدد.',
];