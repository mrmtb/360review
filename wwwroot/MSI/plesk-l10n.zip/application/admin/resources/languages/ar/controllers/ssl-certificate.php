<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'إضافة شهادة SSL/TLS',
    'add.enterCertificateName' => 'أدخل اسم الشهادة.',

    'delete.infoSslCertificatesDeleted' => 'تمت إزالة شهادات SSL/TLS.',
    'delete.infoSslCertificatesNotDeleted' => 'تتعذر إزالة شهادات SSL/TLS.',
    'delete.certificateUsedAsDefault' => 'تُستخدَم إحدى الشهادات التي ستقوم بحذفها كالشهادة الافتراضية.',
    'delete.certificateAssignedOnIp' => 'تم تعيين شهادة أو عدة شهادات لعناوين IP / المجالات.',
    'delete.certificateUsedByPanel' => 'تُستخدَم إحدى الشهادات التي أنت على وشك حذفها لتأمين النظام الأساسي Plesk.',
    'delete.certificateUsedByMailServer' => 'تُستخدَم إحدى الشهادات التي أنت على وشك حذفها لتأمين خادم البريد.',

    'edit.title' => 'تغيير خصائص شهادة SSL/TLS %%name%%',
    'edit.enterCertificateName' => 'أدخل اسم الشهادة.',

    'list.title' => 'شهادات SSL/TLS',
    'list.certificateFound' => 'تم العثور على المفتاح الخاص (الذي يحمل اسم %%name%%) للشهادة المُحمّلة. تمت إضافة الشهادة بنجاح.',
    'list.certificatesList' => 'قائمة الشهادات الموجودة في تجميع الخادم',
    'list.certificatesListHint' => 'توجد قائمة من الشهادات في تجمع الخادم.',
    'list.currentCertificates' => 'الشهادات المستخدمة حاليًا لتأمين خادم Plesk',
    'list.currentCertificatesHint' => 'الشهادات المستخدمة حاليًا لتأمين خادم Plesk وخادم البريد',
    'list.pleskCertificate' => 'شهادة لتأمين Plesk',
    'list.mailServerCertificate' => 'شهادة لتأمين البريد',
    'list.serverPoolCertificateDescription' => '%%name%% من تجميع الخادم.',
    'list.domainCertificateDescription' => '%%name%% من %%domain%%.',
    'list.change' => '[تغيير]',
    'list.none' => 'غير معروف.',

    'secure-mail-server.title' => 'تأمين خادم البريد',
    'secure-mail-server.hint' => 'حدد شهادة لتأمين خادم البريد.',
    'secure-mail-server.mailServerCertificateSet' => 'تم تعيين الشهادة %%name%% بنجاح لتأمين خادم البريد.',
    'secure-mail-server.mailServerNotInstalled' => 'لم يتم تثبيت خدمة البريد.',

    'secure-panel.title' => 'تأمين Plesk',
    'secure-panel.hint' => 'حدد شهادة لتأمين النظام الأساسي Plesk.',
    'secure-panel.panelCertificateSet' => 'تم تعيين الشهادة %%name%% بنجاح لتأمين النظام الأساسي Plesk.',
];