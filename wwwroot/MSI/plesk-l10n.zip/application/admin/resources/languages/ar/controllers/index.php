<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'eula.title' => 'اتفاقية ترخيص المستخدم النهائي الخاصة بمنصة WebPros',
    'eula.popupTitle' => 'اتفاقية ترخيص المستخدم النهائي (EULA)',
    'eula.updatePopupTitle' => 'تحديث اتفاقية ترخيص المستخدم النهائي',
    'eula.popupDescription' => 'تحتاج إلى قراءة اتفاقية ترخيص المستخدم النهائي وقبولها ليتسنى لك مواصلة استخدام المنتج.',
    'eula.updatePopupDescription' => 'لقد تم تحديث اتفاقية ترخيص المستخدم النهائي الخاصة بمنصة WebPros. تحتاج إلى قراءة اتفاقية ترخيص المستخدم النهائي المُحدثة وقبولها ليتسنى لك مواصلة استخدام المنتج.',
    'eula.buttonAccept' => 'قبول',
    'eula.buttonDecline' => 'رفض',
];