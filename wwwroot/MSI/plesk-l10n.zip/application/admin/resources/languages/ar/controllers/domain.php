<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoDomainActivated' => 'تم تفعيل المجالات أو الأسماء المستعارة المحددة.',
    'activate.errorDomainNotActivated' => 'لم يتم تفعيل بعض المجالات أو الأسماء المستعارة المحددة.',
    'activate.domainStillSuspended' => 'يتعذر تفعيل المجال: %%reason%%',
    'activate.domainStatusOffByAdmin' => 'المجال موقف مؤقتًا من قبل المسؤول.',
    'activate.domainStatusOffWithParent' => 'يتم تعليق إما مالك المجال أو اشتراكه.',
    'activate.domainStatusOffExpired' => 'الاشتراك المقابل منتهية صلاحيته.',
    'activate.domainStatusOffBackupRestore' => 'المجال موقف مؤقتًا تجاه إجراء النسخ الاحتياطي أو الاستعادة.',
    'activate.domainStatusOff' => 'المجال موقف مؤقتًا.',
    'activate.aliasStillSuspended' => 'يتعذر تفعيل الأسماء المستعارة: المجال المستهدف موقف مؤقتًا.',

    'add-domain-alias.noDomains' => 'يتعذر إنشاء اسم مستعار: لا توجد نطاقات متاحة.',

    'add-domain.noDomains' => 'يتعذر إنشاء نطاق الوظيفة الإضافية: لا توجد نطاقات متاحة.',

    'add-subdomain.noDomains' => 'يتعذر إنشاء نطاق فرعي: لا توجد نطاقات متاحة.',

    'disable.infoDomainDisabled' => 'تم تعطيل المجالات المحددة.',
    'disable.errorDomainNotDisabled' => 'لم يتم تعطيل بعض المجالات المحددة.',

    'list.title' => 'المجالات',
    'list.customerLinkTitle' => 'إنشاء حساب عميل',
    'list.subscriptionLinkTitle' => 'إنشاء اشتراكك الخاص',

    'suspend.infoDomainSuspended' => 'تم إيقاف المجالات المحددة مؤقتًا.',
    'suspend.errorDomainNotSuspended' => 'لم يتم تعليق بعض المجالات المحددة.',
];