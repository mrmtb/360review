<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Plesk Installer',
    'index.autoinstallerRedirectError' => 'يتعذر بدء Plesk Installer. وقع الخطأ التالي: %%message%%',

    'product.title' => 'Plesk Installer',
    'product.autoinstallerRedirectError' => 'يتعذر بدء Plesk Installer. وقع الخطأ التالي: %%message%%',

    'settings.title' => 'إعدادات التحديث',
    'settings.settingsUpdated' => 'تم تغيير إعدادات التحديث.',
];