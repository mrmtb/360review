<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'إعدادات PHP',
    'list.hint' => 'حدد معالجات PHP التي ترغب في جعلها متوفرة. يمكنك تثبيت معالجات إضافية باستخدام %%link%%.',
    'list.hintLink' => 'Plesk Installer',
    'list.brokenDomainsError' => 'لم يتم تثبيت إصدار (إصدارات) PHP التالية: %%phpVersions%%. البرمجة النصية لـ PHP لـ %%domainCount%% نطاق (نطاقات) غير متوفرة. ثبِّت إصدارات PHP المفقودة أو اتبع التعليمات الواردة في <a href=https://support.plesk.com/hc/en-us/articles/12377342328343>مقال قاعدة المعارف</a> لإصلاح البرمجة النصية لـ PHP.',
    'list.brokenHandlersError' => 'لم يُثبَّت إصدار (إصدارات) PHP التالية: %%phpVersions%%. ثبتها أو شغِّل <code>plesk repair web -php-handlers</code> لتحديد إصدار PHP آخر.',

    'modules.canNotManageModules' => 'الوصول إلى إدارة إعدادات معالج PHP محدود نظرًا لعدم تحديد مسار وصول إلى ملف PHP CLI.',

    'php-ini.title' => 'إعدادات لـ <b>%%name%%.</b>',
    'php-ini.tabTitle' => 'php.ini',
    'php-ini.success' => 'تم تحديث الإعدادات.',

    'toggle.errorEnableBrokenHandler' => 'المعالج تالف ويتعذر تمكينه.',
    'toggle.errorDisableBrokenHandler' => 'المعالج تالف ويتعذر تعطيله.',
    'toggle.infoHandlerEnabled' => 'تم تمكين المعالج.',
    'toggle.infoHandlerDisabled' => 'تم تعطيل المعالج.',
];