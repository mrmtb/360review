<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => '‫الإعلامات‬',

    'email-settings.title' => 'البريد الإلكتروني',

    'panel-settings.title' => 'واجهة المُستخدِم لمنصة Plesk',
    'panel-settings.notificationSettingsSaved' => 'تم حفظ إعدادات الإشعار بنجاح.',

    'panel-notifications-toggle.successfullyEnabled' => 'تم تمكين الإشعار \'%%title%%\'.',
    'panel-notifications-toggle.successfullyDisabled' => 'تم تعطيل الإشعار \'%%title%%\'.',

    'template-settings-list.hint' => 'اختر الإشعارات التي تريد رؤيتها عن طريق تشغيلها أو إيقاف تشغيلها.',
    'template-settings-list.name' => '‫العنوان‬',
    'template-settings-list.context' => 'السياق',
    'template-settings-list.sendToAdmin' => 'الإرسال إلى المسؤول',

    'template-settings-form.storagePeriod' => 'إشعارات المتجر بخصوص',
    'template-settings-form.days' => '‫أيام‬',
];