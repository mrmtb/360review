<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'email.subjSuccess' => 'تم تحديث Plesk بنجاح',
    'email.subjFailure' => 'فشل تحديث Plesk',
    'email.bodySuccess' => "تنبيه، تم تحديث Plesk بنجاح. لعرض قائمة التغييرات، تفضل بزيارة %%link%%. تم إرسال هذه الرسالة تلقائيًا بواسطة تطبيق Plesk Installer.",
    'email.bodyFailure' => "تنبيه، فشل تحديث Plesk. يمكنك تنزيل سجلات تطبيق Plesk Installer من الرابط التالي: %%link%%. اتصل على موفر الاستضافة للحصول على مساعدة الدعم. تم إرسال هذه الرسالة تلقائيًا بواسطة تطبيق Plesk Installer.",
];