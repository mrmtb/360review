<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

$messages = [
    'accessDenied' => 'لم يتم تضمين Sitejet Builder في اشتراكك. لتمكين Sitejet Builder، اتصل بمزود الاستضافة الخاص بك.',
];