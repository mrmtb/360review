<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'تسجيل بريد الويب إضافي',
    'create.infoNewWebmailRegistered' => 'تم تسجيل خدمة webmail جديدة.',

    'edit.unknownWebmail' => 'webmail غير معروف',
    'edit.infoWebmailUpdated' => 'تم تحديث إعدادات خدمة webmail‏ %%name%%.',

    'index.title' => 'خدمات بريد الويب',
    'index.hint' => 'يمكنك استخدام أي خدمة webmail بالإضافة إلى حلول webmail التي تُثبّتها مع Plesk Installer‏، aka Updater. سجل تثبيت webmail المرغوب في اللوحة باستخدام الزر الموجود أدناه، وسيظهر كخيار webmail متوفر في خطط الاستضافة والاشتراكات. إذا كنت تحتاج إلى إخفاء خدمة webmail بشكل مؤقت، فعطّلها باستخدام الزر الموجود أدناه.',
    'index.webmailDeleted' => 'تمت إزالة تسجيل خدمات webmail المحددة.',
    'index.webmailNotDeleted' => 'لم تتم إزالة تسجيل بعض خدمات webmail.',
    'index.webmailEnabled' => 'تم تمكين خدمات webmail المحددة وأصبحت الآن متوفرة.',
    'index.webmailNotEnabled' => 'لم يتم تمكين بعض خيارات webmail المحددة.',
    'index.webmailDisabled' => 'تم تعطيل خيارات webmail المحددة وأصبحت غير متوفرة.',
    'index.webmailNotDisabled' => 'لم يتم تعطيل بعض خيارات webmail المحددة.',
];