<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-network.title' => '‫إضافة شبكة‬',
    'add-network.added' => '‫تمت إضافة الشبكة %%address%%.‬',

    'delete-network.noNetworksSpecified' => '‫حدد شبكة واحدة أو شبكات متعددة من قائمة تقييد وصول IP.‬',
    'delete-network.networksDeleted' => '‫تم حذف الشبكات المحددة.‬',
    'delete-network.networksNotDeleted' => '‫لم يتم حذف بعض الشبكات المحددة.‬ ‫تفاصيل: %%error%%.‬',

    'edit-network.title' => '‫تحرير الشبكة‬',
    'edit-network.updated' => '‫تم تحديث الشبكة %%address%%.‬',

    'list.title' => '‫إدارة تقييد الوصول إلى IP‬',
    'list.currentIpAddressDenied' => '‫يتم تكوين سياسة تقييد الوصول وقائمة الشبكات حاليًا بطريقة لا تُمكّنك من تسجيل الدخول بحقوق المسؤول من عنوان IP الخاص بك "%%remoteAddress%%".‬',
    'list.allowHint' => '‫يُسمح بالوصول إلى Plesk بامتيازات المسؤول، باستثناء الشبكات الموجودة في القائمة.‬',
    'list.denyHint' => '‫الوصول إلى Plesk بامتيازات المسؤول مرفوض من جميع الشبكات التي لم يتم إدراجها هنا.‬',

    'settings.title' => '‫إعدادات تقييد الوصول إلى IP‬',
    'settings.settingsSaved' => '‫تم حفظ سياسة تقييد الوصول إلى IP.‬',
];