<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-customer-owner.title' => 'جارٍ نقل العملاء إلى مالك آخر',
    'change-customer-owner.description' => 'سيتم نقل حسابات العميل إلى مالك آخر. يمكنك تغيير خطط الخدمة لاشتراكات العميل. للحفاظ على الموارد المتوفرة لأحد العملاء، اترك الخطة المخصصة محددة.',
    'change-customer-owner.ownerHint' => 'سيتم نقل العملاء إلى المالك المحدد:',
    'change-customer-owner.ipAddressHint' => 'يتعذر الحفاظ على عنوان IP المخصص.',
    'change-customer-owner.loading' => 'يُرجى الانتظار...',
    'change-customer-owner.ipAddressNotSelected' => 'حدد عنوان IP واحدًا على الأقل لكل اشتراك.',
    'change-customer-owner.ownerNotSelected' => 'تحديد مالك:',

    'customer.title' => 'تحويل العملاء إلى بائعي التجزئة',
    'customer.description' => 'سيتم تحويل حسابات العميل إلى حسابات بائع تجزئة. يمكنك اختيار خطط بائع التجزئة للحسابات المحوّلة. للحفاظ على الموارد المتوفرة لأحد العملاء، حدد الخطة المخصصة: سيكون لدى بائع التجزئة مجموعة من حصص الموارد والأذونات وتطبيقات جميع الاشتراكات.',
    'customer.loading' => 'جارٍ التحويل...',

    'reseller.title' => 'تحويل بائعي التجزئة إلى عملاء',
    'reseller.description' => 'سيتم تحويل بائعي التجزئة إلى عملاء.',
    'reseller.descriptionExtended' => 'اختر خطط الخدمة الجديدة لبائعي التجزئة الذين لديهم اشتراكات خاصة بهم. للحفاظ على الموارد المتوفرة لأحد بائعي التجزئة، حدد خطة الخدمة المخصصة. لنقل اشتراكات بائع التجزئة إلى إحدى خطط الخدمة الموجودة، حدد خطة خدمة موجودة.',
    'reseller.loading' => 'جارٍ التحويل...',
];