<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'clear-cache.apsCacheCleared' => 'تمت إزالة الملفات المؤقتة.',

    'configure.title' => '%%name%%',
    'configure.applicationNotFound' => "لم يتم العثور على التطبيق ذي المعرّف /\"%%id%%/\".",
    'configure.applicationHasNoSettings' => 'التطبيق بلا إعدادات.',
    'configure.settingsUpdated' => 'تم تحديث إعدادات التطبيق.',
    'configure.settingsUpdateFailed' => 'فشل في تحديث إعدادات التطبيق: %%error%%',
    'configure.instancesNotReconfigured' => 'لم يتم تكوين بعض مثيلات التطبيق.',

    'index.title' => 'مخزن التطبيقات',

    'info.title' => '%%name%%',
    'info.hint' => 'تحتوي القائمة الموجودة أدناه على معلومات حول مواقع الويب التي يتم تثبيت التطبيق عليها. تشير القيمة "بدون" في عمود موقع الويب إلى أن التطبيق خارجي. يتعذر تثبيت هذا التطبيق على موقع ويب لعميل معين؛ فهو يوفر رابطًا فقط إلى إحدى الخدمات الخارجية.',

    'remote-app-info.title' => 'تفاصيل التطبيق',

    'update-settings.title' => 'إعدادات التحديث',
    'update-settings.settingsUpdated' => 'تم تحديث الإعدادات.',
    'update-settings.settingsUpdateFailed' => 'يتعذر تحديث الإعدادات: %%error%%',

    'upload.title' => 'إضافة تطبيق',
    'upload.packageInstallationError' => 'لا يمكن إضافة التطبيق: %%message%%.',
    'upload.appUploaded' => 'تم تحميل التطبيق بنجاح.',
    'upload.appDownloadStarted' => 'تنزيل التطبيقات المحددة.',

    'uploaded.title' => 'تطبيقاتي',
    'uploaded.hint' => 'هنا يمكنك إضافة التطبيقات أو إزالتها من مخزن التطبيقات وكذلك إدارة توفر التطبيقات للعملاء. يوجد سببان لإضافة التطبيقات: توسيع قائمة التطبيقات المتوفرة أو تكوين إعدادات التطبيقات على مستوى الخادم. يتعذر تثبيت بعض التطبيقات بدون هذا التكوين. تُدرج جميع التطبيقات المضافة أدناه.',
    'uploaded.infoAppDeleted' => 'تم حذف التطبيقات المحددة.',
    'uploaded.infoAppNotDeleted' => 'لم يتم حذف بعض التطبيقات المحددة.',
    'uploaded.applicationsNowAvailable' => 'التطبيقات المحددة متوفرة الآن للتثبيت من قبل العملاء أو للتكوين.',
    'uploaded.applicationsNowNotAvailable' => 'لم تعد التطبيقات المحددة متوفرة للتثبيت من قبل العملاء أو للتكوين.',
    'uploaded.cantChangePackageProperties' => 'حدث خطأ عند محاولة تغيير إعدادات توفر التطبيق.',
    'uploaded.appDownloaded' => 'تم تنزيل التطبيقات المحددة بنجاح.',
    'uploaded.appNotDownloaded' => 'لم يتم تنزيل بعض التطبيقات المحددة.',
    'uploaded.downloadInProgress' => 'يُرجى الانتظار...',

    'usage.title' => 'تطبيقات مُثبّتة',
    'usage.hint' => 'تحتوي القائمة الموجودة أدناه على جميع التطبيقات سواء التي تضيفها أو التي يُثبّتها عملاؤك. هنا يمكنك إدارة إعدادات التطبيق أو التحقق من التحديثات أو إزالة الملفات المؤقتة التي أُضيفت أثناء عمليات تثبيت التطبيقات.',
    'usage.hintReseller' => 'تعرض القائمة الموجودة أدناه معلومات بشأن جميع عمليات تثبيت التطبيقات على مواقعك وعلى مواقع عملائك. انقر فوق اسم التطبيق لرؤية قائمة بمواقع الويب التي يتم تثبيت التطبيق عليها، وللتحقق من التحديثات المخصصة للتطبيق.',
];