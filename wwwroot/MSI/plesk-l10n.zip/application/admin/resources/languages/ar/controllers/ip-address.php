<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'إضافة عنوان IP',
    'add.ipAddressAdded' => 'تمت إضافة عنوان %%IP %%address.',

    'delete.infoIpAddressesDeleted' => 'تمت إزالة عناوين IP المحددة.',

    'edit.title' => 'عنوان %%IP %%address%% على الواجهة %%interface%%',
    'edit.ipAddressUpdated' => 'تمت جدولة عملية تغيير إعدادات عنوان IP %%address%% وستُجرى في الخلفية',
    'edit.ipAddressInterfaceNotAvailableWarning' => 'محول الشبكة %%interface%% غير موجود. نقل عنوان IP هذا من محول الشبكة الآخر أو إزالته من القائمة.',

    'list.title' => 'عناوين IP',
];