<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'isEmpty' => 'هذا الحقل المطلوب فارغ. يجب عليك إدخال قيمة لهذا الحقل.',
    'stringLengthTooShort' => "/\"%value%/\" أقل من %min% لطول الحروف.",
    'stringLengthTooLong' => "/\"%value%/\" أكبر من %max% لطول الحروف.",
    'regexNotMatch' => "/\"%value%/\" غير متطابقة مع النمط /\"%pattern%/\".",
    'notAlnum' => "لا تحتوي /\"%value%/\" على حروف أبجدية رقمية. تأكد من استخدام حروف أبجدية رقمية فقط.",
    'stringEmpty' => "/\"%value%/\" فارغة.",
    'stringsNotEqual' => 'السلاسل غير متساوية.',
    'passwordsNotEqual' => 'كلمات المرور التي أدخلتها غير متطابقة مع بعضها البعض.',
    'passwordLengthTooShort' => "كلمة المرور أقصر من %min% من الحروف.",
    'passwordLengthTooLong' => "كلمة المرور أطول من %max% من الحروف.",
    'passwordRegexNotMatch' => "كلمة المرور غير متطابقة مع النمط /\"%pattern%/\"",
    'invalidUrl' => 'العنوان المحدد غير صالح. يجب تحديد عنوان صالح مثل http://domain.com.',
    'specialCharactersInIpAddress' => 'عنوان IP المُدخَل غير صالح.',
    'massEmailContactsNotSelected' => 'حدد جهة اتصال واحدة على الأقل من القائمة.',
    'ipAddressIsTooLong' => 'يجب ألا يزيد عنوان IP عن %max% أحرف.',
    'ipAddressDescriptionTooLong' => 'يجب ألا يزيد الوصف عن %max% أحرف.',

    'fail2ban.invalidIpOrCidr' => 'يجب أن يكون عنوان IP عنوان IP صالحًا أو قناع CIDR.',
];