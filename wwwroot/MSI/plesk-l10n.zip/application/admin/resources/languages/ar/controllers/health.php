<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'سلامة الخادم',
    'index.pageHint' => 'هنا يمكنك رؤية تقارير مُفصلة بشأن سلامة الخادم. لمعرفة كيف يتم تغيير معلمات سلامة الخادم، حدد المعلمات، وستعرض لك منصة Plesk المخططات المناسبة. لاحظ أنه يمكنك تغيير الفترة التي يتم تقديم التقارير خلالها - من آخر 3 ساعات إلى أسبوع. هنا يمكنك أيضًا تغيير تكوين جهاز مراقبة السلامة الذي يحدد متى يجب أن تظهر الإنذارات الحمراء والصفراء لكل معلمة، وأي من موارد القرص الثابت يجب مراقبتها. وللقيام بذلك، قم بتنزيل ملف التكوين باستخدام الزر الموجود أدناه، وقم بتحرير الملف، ثم قم بتحميل الإصدار الخاص بك. في حالة تغيير جهاز الخادم، يلزم عليك نشر هذه التغييرات على جهاز مراقبة السلامة للحصول على الإحصائيات المناسبة.',
    'index.waitMessage' => 'جارٍ التحميل...',
    'index.buttonUpload' => 'تحميل ملف التكوين',
    'index.buttonDownload' => 'تنزيل ملف التكوين',
    'index.buttonRestoreDefaults' => 'عودة إلى التكوين الافتراضي',
    'index.buttonReconfigure' => 'الكشف عن تغييرات الأجهزة',
    'index.buttonUploadHint' => 'تحميل ملف تكوين جهاز عرض الصحة الخاص بك. سيتم تطبيق التكوين الجديد الآن عندما يكتمل التحميل.',
    'index.buttonDownloadHint' => 'احفظ تكوين جهاز عرض الصحة الحالية إلى جهاز الكمبيوتر الخاص بك.',
    'index.buttonRestoreDefaultsHint' => 'استعادة الإعدادات الافتراضية لجهاز عرض صحة الخادم.',
    'index.buttonReconfigureHint' => 'نشر التغييرات في تكوين الأجهزة على جهاز عرض الصحة.',
    'index.confirmRestoreDefaultsTitle' => 'استعادة الإعدادات الافتراضية لجهاز عرض صحة الخادم',
    'index.confirmRestoreDefaultsDescription' => 'هل ترغب بالتأكيد في استعادة الإعدادات الافتراضية؟',
    'index.confirmReconfigureTitle' => 'الكشف عن تغييرات الأجهزة',
    'index.confirmReconfigureDescription' => 'أنت على وشك تحديث تكوين الأجهزة في جهاز عرض الصحة. يصبح هذا ذا صلة إذا تم تغيير جهاز الخادم وكنت تريد إظهار هذه التغييرات في إحصائيات جهاز عرض الصحة. هل تود المتابعة؟',
    'index.settingsWereRestoredToDefault' => 'تمت استعادة الإعدادات الافتراضية.',
    'index.healthMonitorWasReconfigured' => 'تم تحديث معلومات جهاز عرض الصحة المتعلقة بتكوين الأجهزة.',

    'parameters.loading' => 'جارٍ التحميل...',
    'parameters.selectPeriod' => 'تحديد الفترة',
    'parameters.periodFromNowTo3h' => '3 ساعات',
    'parameters.periodFromNowTo6h' => '6 ساعات',
    'parameters.periodFromNowTo12h' => '12 ساعة',
    'parameters.periodFromNowTo1d' => 'يوم واحد',
    'parameters.periodFromNowTo3d' => '3 أيام',
    'parameters.periodFromNowTo7d' => 'أسبوع واحد',

    'thresholds-hint.waitMessage' => 'جارٍ التحميل...',

    'upload-config-file.title' => 'تحميل ملف التكوين',
    'upload-config-file.configurationUploadedSuccessfully' => 'تم تحميل التكوين وتطبيقه.',
];