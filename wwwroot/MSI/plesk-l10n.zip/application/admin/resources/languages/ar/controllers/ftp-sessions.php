<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-sessions.noSessionsSpecified' => '‫تحديد واحدة أو أكثر من جلسات عمل FTP من القائمة.‬',
    'delete-sessions.sessionsDeleted' => '‫تم حذف جلسات العمل المحددة.‬',
    'delete-sessions.sessionsNotDeleted' => '‫لم يتم حذف بعض جلسات العمل المحددة.‬ ‫تفاصيل: %%error%%.‬',

    'list.title' => '‫جلسات FTP‬',
];