<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'settings.title' => 'تجربة إعدادات الوضع وشراؤها',
    'settings.sitebuilderSettingsUpdated' => 'تم تحديث الإعدادات.',
];