<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'wrongParameters' => 'Wrong entry parameters',
    'emptyParameter' => 'is empty',
];
