<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'info.title' => 'Tell us whether you accept cookies',
    'info.necessaryCookiesMessage' => 'By logging in to Plesk, you allow us to use necessary сookies.',
    'info.message' => '%%cookieInformationLink%% about how you use Plesk. It helps us to improve our services so that you could make the most out of Plesk.',
    'info.cookieInformationLink' => 'Cookies collect information',
    'info.acceptButton' => 'Accept all cookies',
    'info.acceptNecessaryCookiesButton' => 'Accept necessary cookies',
    'info.preferencesButton' => 'Set cookie preferences',

    'preferences.title' => 'Cookies in Plesk',
    'preferences.description' => 'Cookies are files saved on your phone, tablet, or computer when you visit Plesk. We use cookies to make Plesk work, to have it operate smoothly, and to collect certain information.',
    'preferences.settingsTitle' => 'Cookie settings',
    'preferences.settingsDescription' => 'We use 3 types of cookies. Enable those you allow us to use.',
    'preferences.analyticsTitle' => 'Cookies that help us to improve the product',
    'preferences.analyticsDescription' => 'We use anonymous tracking cookies to collect information on how you use Plesk. It helps us make Plesk better. Tracking cookies do not identify anyone. They store anonymized information about Plesk pages you visited, time your spent on them, and page objects you clicked on. We do not share the collected data with third-party services.',
    'preferences.marketingTitle' => 'Cookies that help with our communications and marketing',
    'preferences.marketingDescription' => 'These cookies collect information about your Plesk preferences and help us provide you with personal recommendations.',
    'preferences.necessaryTitle' => 'Strictly necessary cookies',
    'preferences.necessaryDescription' => 'These cookies enable Plesk core functions such as security, network management, and accessibility. These cookies always need to be on. Necessary cookies also include functional cookies that are in charge of personalization and usability improvements (for example, language settings, font size, and prefilled forms). You may disable necessary cookies in your %%browserSettingsLink%% but this may affect Plesk.',
    'preferences.browserSettingsLink' => 'browser settings',
    'preferences.pleskCookiesLink' => 'See the detailed description of the used cookies',
    'preferences.on' => 'On',
    'preferences.off' => 'Off',
    'preferences.submitButton' => 'Save changes',
    'preferences.cancelButton' => 'Cancel',
];
