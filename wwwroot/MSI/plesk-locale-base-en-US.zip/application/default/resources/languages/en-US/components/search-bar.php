<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'nothingFound' => 'No results found.',
    'fieldStub' => 'Search...',
    'fieldStubHint' => 'Search for domains, extensions, and more…',
    'moreResultsFound' => 'More than %%limit%% results were found. Please refine your search.',
    'recentSearch' => 'Recent search results:',
    'recentSearchHint' => 'The latest search results will be shown here. Come back for quick access to the pages you looked for.',
    'removeFromRecent' => 'Remove from recent results',
];
