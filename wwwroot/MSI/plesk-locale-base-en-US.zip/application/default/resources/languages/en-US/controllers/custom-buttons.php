<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Settings of a Link to an Additional Service',
    'create.buttonCreated' => 'The button %%button%% was created.',

    'edit.title' => 'Settings of a Link to an Additional Service',
    'edit.buttonUpdated' => 'The properties of the button %%button%% were changed.',

    'list.title' => 'Links to Additional Services',

    'remove.customButtonsRemoved' => 'The selected links to additional services were successfully removed.',
    'remove.customButtonsNotRemoved' => 'Unable to remove the selected links to additional services.',

    'toggle.buttonToggledPrivate' => "The button %%button%% is no longer available to other users.",
    'toggle.buttonToggledPublic' => "The button %%button%% is now available to other users.",
];
