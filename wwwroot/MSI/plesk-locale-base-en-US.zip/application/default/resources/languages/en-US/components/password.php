<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'meter.title' => 'Password Strength',
    'meter.description' => 'To improve your password:',
    'meter.yourPasswordIsStrong' => 'Your password is strong, but you can make it even stronger by increasing its length.',
    'meter.verdictVeryWeak' => 'Very weak',
    'meter.verdictWeak' => 'Weak',
    'meter.verdictMedium' => 'Medium',
    'meter.verdictStrong' => 'Strong',
    'meter.verdictVeryStrong' => 'Very strong',

    'generator.generate' => 'Generate',
    'generator.show' => 'Show',
    'generator.hide' => 'Hide',

    'suggestions.l33t' => "Avoid predictable letter substitutions like '@' for 'a'.",
    'suggestions.reverseWords' => 'Avoid reversed spellings of common words.',
    'suggestions.allUppercase' => 'Capitalize some, but not all letters.',
    'suggestions.capitalization' => 'Capitalize more than the first letter.',
    'suggestions.dates' => 'Avoid dates and years that are associated with you.',
    'suggestions.recentYears' => 'Avoid recent years.',
    'suggestions.associatedYears' => 'Avoid years that are associated with you.',
    'suggestions.sequences' => 'Avoid common character sequences.',
    'suggestions.repeated' => 'Avoid repeated words and characters.',
    'suggestions.longerKeyboardPattern' => 'Use longer keyboard patterns and change typing direction multiple times.',
    'suggestions.anotherWord' => 'Add more words that are less common.',
    'suggestions.useWords' => 'Use multiple words, but avoid common phrases.',
    'suggestions.noNeed' => 'You can create strong passwords without using symbols, numbers, or uppercase letters.',
    'suggestions.pwned' => 'If you use this password elsewhere, you should change it.',
];
