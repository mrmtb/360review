<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'client-configuration-link.action' => 'Show link',
    'client-configuration-link.title' => 'Mail configurator link',
];
