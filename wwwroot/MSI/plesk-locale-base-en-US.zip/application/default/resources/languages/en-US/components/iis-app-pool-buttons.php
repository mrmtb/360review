<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'buttonEnable' => 'Switch On',
    'buttonEnableHint' => 'Enable dedicated IIS application pool.',
    'buttonDisable' => 'Switch Off',
    'buttonDisableHint' => 'Disable dedicated IIS application pool.',
    'buttonStart' => 'Start',
    'buttonStartHint' => 'Start IIS application pool.',
    'buttonStop' => 'Stop',
    'buttonStopHint' => 'Stop IIS application pool.',
    'buttonRecycle' => 'Recycle',
    'buttonRecycleHint' => 'Recycle IIS application pool.',
    'waitMessage' => 'Please wait...',
];
