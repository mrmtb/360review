<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'master-key-processing-state.wait' => 'Please wait while Plesk tries to obtain the license.',
    'master-key-processing-state.networkError' => 'Please check your network connection and wait while Plesk tries to obtain the license again or contact Plesk support: %%link%%',
    'master-key-processing-state.unknownError' => 'An error occurred while obtaining the license. Please contact Plesk support: %%link%%',

    'ServerMailAntivirusPromo.noAntivirus' => 'There is no antivirus installed on the server.',
    'ServerMailAntivirusPromo.warning' => 'You may be vulnerable to online threats such as viruses, malware, phishing scams, and more.',
    'ServerMailAntivirusPromo.promoDescription' => 'Select one of the following options to install an antivirus and purchase a license:',
    'ServerMailAntivirusPromo.recommended' => '(recommended)',
    'ServerMailAntivirusPromo.needActivation' => 'The \'%%name%%\' is installed and needs to be activated.',
    'ServerMailAntivirusPromo.toEnable' => 'To protect the server,',
    'ServerMailAntivirusPromo.purchase' => 'purchase a license',
    'ServerMailAntivirusPromo.enableAt' => 'Enable the antivirus in',

    'ListFilterPanel.title' => 'Filter',
    'ListFilterPanel.clear' => 'Clear',

    'ListFilterForm.apply' => 'Apply Filters',

    'TrafficUsage.TotalUsageInfo.usage' => 'Total usage: %%usage%%',
    'TrafficUsage.TotalUsageInfo.usageWithInterval' => 'Total usage, %%month%% %%year%%: %%usage%%',
    'TrafficUsage.TotalUsageInfo.usedLimited' => '%%used%% of %%limit%% (%%percent%%%)',

    'LocaleSwitcher.defaultLocale' => 'Default',
    'LocaleSwitcher.localeLabel' => 'Interface language',
];
