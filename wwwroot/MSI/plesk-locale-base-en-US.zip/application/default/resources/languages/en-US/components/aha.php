<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'voteTitle' => 'Tell us what you think about Plesk',
    'voteQuestion' => 'How likely is it that you recommend Plesk to a friend or a colleague?',
    'voteRequire' => 'Please provide your vote.',
    'voteLegendBad' => 'Not likely at all',
    'voteLegendGood' => 'Extremely likely',
    'voteGoodHint' => 'Please tell us what made you feel that Plesk is the right solution for you. We\'d love to know whether it was a particular action, feature, overall impression or something else.',
    'voteBetterHint' => 'Let us know what we can improve the things that are important for you!',
    'voteButtonOk' => 'Send Feedback',
    'thankTitle' => 'Thank you for the feedback',
    'thankHint' => 'Your feedback is very appreciated. It is very important to us to know how we can improve your experience with Plesk.',
    'thankButtonClose' => 'Close',
];
