<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'bootstrapInProgressMessage' => 'The repair operation is in progress. You will be redirected to the login page when it completes.',
    'bootstrapLinkTitle' => 'Repair the failed upgrade or installation.',
];
