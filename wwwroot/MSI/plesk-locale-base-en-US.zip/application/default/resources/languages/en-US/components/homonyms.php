<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'match' => 'The %%domainName%% matches both a domain name and %%homonymType%% name.',
    'certificate' => 'SSL/TLS certificate',
    'user' => 'additional user',
    'role' => 'role',
    'ftpUser' => 'FTP user',
    'webUser' => 'web user',
    'protectedDirectory' => 'protected directory',
    'otherMatchesFound' => 'Some other matches were found.',
    'subscriptionRemovalDescription' => 'If you remove a subscription, you might not be able to recover it, so we require your confirmation to proceed.',
    'subscriptionRemovalConfirmation' => 'I confirm I want to remove the selected subscriptions.',
    'webspaceRemovalDescription' => 'If you remove a subscription, you might not be able to recover it, so we require your confirmation to proceed.',
    'webspaceRemovalConfirmation' => 'I confirm I want to remove the selected subscriptions.',
    'domainRemovalDescription' => 'If you remove a domain, you might not be able to recover it, so we require your confirmation to proceed.',
    'domainRemovalConfirmation' => 'I confirm I want to remove the selected domains.',
    'loading' => 'Loading...',
];
