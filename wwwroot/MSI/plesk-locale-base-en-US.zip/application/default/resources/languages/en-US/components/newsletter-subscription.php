<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'title' => 'Subscribe to our newsletters',
    'reconfirmTitle' => 'WebPros newsletters',
    'text' => 'Would you like to receive security-related, technical and general product information in your personalized WebPros newsletter?',
    'consent' => 'By clicking the "Consent and Subscribe" button below, I agree that the WebPros companies listed here may use my name and email address (%%adminEmail%%) for the purpose of providing me with personalized marketing content such as newsletters and individual offers related to WebPros products. The companies asking for your consent are: WebPros International LLC and WebPros International GmbH. Information will be used pursuant the %%privacyPolicy%% until my consent is withdrawn and may internally be shared with other entities of the WebPros group. I can modify or withdraw my consent at any time by clicking the link in any communication received or by emailing privacy@plesk.com',
    'reconfirmConsent' => 'By clicking the "Reconfirm consent" button below, I revoke my previous consent and agree that the WebPros companies listed here may use my name and email address (%%adminEmail%%) for the purpose of providing me with personalized marketing content such as newsletters and individual offers related to WebPros products. The companies asking for your consent are: WebPros International LLC and WebPros International GmbH. Information will be used pursuant the %%privacyPolicy%% until my consent is withdrawn and may internally be shared with other entities of the WebPros group. I can modify or withdraw my consent at any time by clicking the link in any communication received or by emailing privacy@plesk.com',
    'privacyPolicy' => 'WebPros Privacy Policy',
    'subscribeButton' => 'Consent and Subscribe',
    'reconfirmButton' => 'Reconfirm consent',
    'closeButton' => 'No, Thanks',
    'subscribeMessage' => 'You are now subscribed to personalized WebPros newsletters. You can unsubscribe at any time by editing your profile.',
    'noReconfirmMessage' => 'You kept your subscription to WebPros newsletters.',
    'errorMessage' => 'Could not save your subscription status.',
    'consentGivenInfo' => 'We hope you\'ve been enjoying our generic WebPros newsletter. We can now provide you with an improved alternative - personalized with useful information and handy tips, according to your needs. To receive your personalized WebPros newsletter, click "Reconfirm consent".',
];
