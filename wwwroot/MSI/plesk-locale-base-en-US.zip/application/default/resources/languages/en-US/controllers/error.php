<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'error.title' => 'Server Error',

    'error.repairKitDescription' => 'You may be able to resolve the issue automatically using Repair Kit.',
    'error.repairKitAdminDescription' => 'If you are the server administrator, try resolving the issue using our troubleshooting tool, Repair Kit.',
    'error.repairKitOpen' => 'Open Repair Kit',
    'error.repairKitOpenNote' => 'You will be asked to enter the Plesk administrator password.',
    'error.repairKitUnavailable' => 'Repair Kit is unavailable. To restore it, log in to the server via SSH, run the command \'systemctl restart plesk - repaird\', and then refresh this page.',

    'error.reportErrorMessage' => 'Need help resolving the issue?',
    'error.visitHelpCenter' => 'Visit Plesk Help Center.',

    'error.networkError' => 'Network error',
    'error.networkErrorDescription' => 'Your connection is unstable.',

    'error.helpActions' => 'That\'s what you can do',
    'error.reloadPage' => 'Reload Page',
    'error.backToPreviousPage' => 'Back to Previous Page',
    'error.homePage' => 'Home Page',
    'error.searchKbArticle' => 'Search for related Knowledge Base articles',
    'error.invalidUrl' => 'An invalid URL was requested.',

    'error.reportProblem' => 'Report a problem',
    'error.documentation' => 'Documentation',
    'error.knowledgeBase' => 'Knowledge base',
    'error.forum' => 'Forum',
    'error.youTube' => 'YouTube',
    'error.facebook' => 'Facebook',
];
