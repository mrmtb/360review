<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'recovery-password.action' => 'Show link',
    'recovery-password.actionLabel' => 'Password reset link',
    'recovery-password.title' => 'Password reset link',
    'recovery-password.text' => 'You can copy the link to clipboard or send it to %%email%%',
    'recovery-password.sendButton' => 'Send to Email',
    'recovery-password.copyButton' => 'Copy to Clipboard',
    'recovery-password.closeButton' => 'Cancel',
    'recovery-password.linkSendedMessage' => 'The password reset link was sent',
];
