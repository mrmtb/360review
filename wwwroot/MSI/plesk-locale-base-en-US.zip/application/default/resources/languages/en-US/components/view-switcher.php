<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'title' => 'Change View',
    'serviceProviderView' => 'Service Provider view',
    'serviceProviderViewHint' => 'for web hosting providers',
    'serviceProviderViewRecommended' => 'recommended for web hosting providers',
    'powerUserView' => 'Power User view',
    'powerUserViewHint' => 'for developers and web agencies',
    'powerUserViewRecommended' => 'recommended for developers and web agencies',
    'currentViewMessage' => 'You are currently in %%view%% (%%hint%%).',
    'actionMessage' => '%%switchLink%% (%%recommended%%) or %%helpLink%%.',
    'switchView' => 'Switch to %%view%%',
    'learnMore' => 'learn more about views',
    'powerUserViewWarning' => "If customers were added in Service Provider View, their domains aren't shown in Power User View. Only admin's domains are available in this view.",
    'confirmationBoxText' => 'Do you want to hide the Change View menu?',
    'confirmationBoxDescription' => 'Note that hiding the menu will remove it permanently. You will still be able to switch between views in Tools & Settings > Interface Management.',
    'confirmationBoxButtonYes' => 'Yes',
    'confirmationBoxButtonNo' => 'No',
];
