<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'common.label' => 'Go to another object:',
    'common.description' => 'Select another object.',
    'common.refineSearchMessage' => 'Please refine the search criteria to find the objects you are looking for, or go to %%link%%.',
    'common.listOfAllObjects' => 'the list of all objects',

    'customers.label' => 'Go to another customer:',
    'customers.myObjectsLabel' => 'More customers of %%name%%:',
    'customers.otherObjectsLabel' => 'Customers of other providers:',
    'customers.moreObjectsAvailable' => 'There are %%count%% more customers available.',
    'customers.refineSearchMessage' => 'Please refine the search criteria to find the customers you are looking for, or go to %%link%%.',
    'customers.listOfAllObjects' => 'the list of all customers',
    'customers.description' => 'Select another customer.',

    'dockercontainers.label' => 'Go to another container:',
    'dockercontainers.description' => 'Select another container.',

    'domains.label' => 'Go to another domain:',
    'domains.myObjectsLabel' => 'More domains of %%name%%:',
    'domains.otherObjectsLabel' => 'Domains of other subscribers:',
    'domains.moreObjectsAvailable' => 'There are %%count%% more domains available.',
    'domains.refineSearchMessage' => 'Please refine the search criteria to find the domains you are looking for, or go to %%link%%.',
    'domains.listOfAllObjects' => 'the list of all domains',
    'domains.description' => 'Select another domain.',

    'resellers.label' => 'Go to another reseller:',
    'resellers.moreObjectsAvailable' => 'There are %%count%% more resellers available.',
    'resellers.refineSearchMessage' => 'Please refine the search criteria to find the resellers you are looking for, or go to %%link%%.',
    'resellers.listOfAllObjects' => 'the list of all resellers',
    'resellers.description' => 'Select another reseller.',

    'subscriptions.label' => 'Go to another subscription:',
    'subscriptions.myObjectsLabel' => 'More subscriptions of %%name%%:',
    'subscriptions.otherObjectsLabel' => 'Subscriptions of other subscribers:',
    'subscriptions.moreObjectsAvailable' => 'There are %%count%% more subscriptions available.',
    'subscriptions.refineSearchMessage' => 'Please refine the search criteria to find the subscriptions you are looking for, or go to %%link%%.',
    'subscriptions.listOfAllObjects' => 'the list of all subscriptions',
    'subscriptions.description' => 'Select another subscription.',
];
