<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'updateCredentialsFailed' => 'Failed to update the user credentials for the application "%%appName%%": %%errorMessage%%',
];
