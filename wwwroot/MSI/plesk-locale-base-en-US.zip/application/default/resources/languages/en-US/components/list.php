<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'recordsTotal' => '{total, plural, one {# item} other {# items}} total',
    'pages' => 'Pages',
    'firstPage' => 'First',
    'lastPage' => 'Last',
    'numberOfItemPerPage' => 'Entries per page',
    'searchPlaceholder' => 'Search...',
    'hideSearch' => 'Hide Search',
    'showSearch' => 'Show Search',
    'buttonSearch' => 'Search',
    'buttonResetSearch' => 'Reset Search',
    'noEntries' => 'No items.',
    'noEntriesFound' => 'No items found.',
    'itemsNotSelected' => 'Select items first.',
    'allItems' => 'All',
    'loadingTitle' => 'Please wait. Loading...',
    'timeoutMessage' => 'This operation is taking too long. Check the results in a few minutes.',
    'emptyViewTitle' => 'Looks like there\'s nothing here!',
    'emptyViewFilteredTitle' => 'Could not find any items matching the filter',
    'emptyViewFilteredDescription' => 'Refine your query or remove some of the criteria from the filter and try again.',
];
