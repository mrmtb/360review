<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'logIn' => 'Log in',
    'identityName' => 'Subscriber %%identity%%',
    'loggedInAs' => 'Logged in as',
    'impersonatedInAs' => 'Subscriber',
    'myProfile' => 'Edit Profile',
    'logOut' => 'Log out',
    'backToAdmin' => 'Back to Administrator',
    'readManual' => 'Read the Guide',
    'sureToLogout' => 'Are you sure you want to log out?',
    'impersonatedName' => 'logged in as %%identity%%',
    'userFeedback' => 'Suggest an Idea',
    'facebookJoinCommunity' => 'Join Us on Facebook',
    'twitterFollow' => 'Follow @Plesk',
    'provideRating' => 'Share an Opinion',
    'linkToCookies' => 'Cookies',
    'darkThemeOn' => 'Switch to dark theme',
    'darkThemeOff' => 'Switch to light theme',
];
