<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

$messages = [
    'header.text' => 'Build professional websites with Sitejet Builder for free!',
    'text' => 'Join thousands of Sitejet website builders and access designer-built templates with an AI-driven text generator, or code your own conversion-driven and SEO-friendly websites in no time.',
    'buttonText' => 'Create a website',
    'forumLinkText' => 'Discuss on the forum',
    'feedbackLinkText' => 'Share feedback',
];
