<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'sell_service' => 'Allow to sell the \'%%serviceName%%\' service',
    'sell_service_hint' => '',
];
