<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'trialLicenseWarningAdmin' => 'days remaining for trial version',
    'buyLicenseButton' => 'Buy License',
    'installLicenseButton' => 'Already have a license?',
    'testLicenseWarningAdmin' => 'Your Plesk is operating with a license that is not intended for production use.',
    'testLicenseWarningClient' => 'This installation of Plesk is operating with a license that is not intended for production use. Contact your server administrator to resolve this issue.',
    'trialOverTitle' => 'Your trial is almost over',
    'trialOverText' => 'Your trial period will end soon. To continue using Plesk once your trial is over, buy a license.',
    'defaultLicenseWarningAdmin' => 'In order to use Plesk, buy and install a new license key.',
    'expiredLicenseWarningAdmin' => 'Your license key has expired. In order to use Plesk, buy and install a new license key.',
    'demoLicenseWarningAdmin' => 'Enjoyed the demo?',
    'demoLicenseTryPlesk' => 'Learn how to %%link%%.',
    'demoLicenseTryPleskLink' => 'try Plesk on your own or cloud server',
    'getTrialButton' => 'Get Trial',
    'licenseLimitsMessage' => 'Insufficient resources. To proceed, upgrade your Plesk license.',
    'licenseLimitsMessageNoPermission' => 'There are no available resources. Contact your service provider to resolve this issue.',
    'licenseExpirationWarningSubject' => 'Your license has expired',
    'licenseExpirationWarning' => 'Your Plesk license has expired. Because of that, some critical services have become unavailable. Your websites may be at risk!',
];
