<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'title' => 'Choose a way of creating a website',
    'applications.blank-site.title' => 'Blank website',
    'applications.blank-site.description' => 'A starter page for your HTML or PHP site (the previous default)',
    'applications.upload-files.title' => 'Upload files',
    'applications.upload-files.description' => 'From a local machine',
    'applications.selectedOption' => 'This is the first step of creating a %%entity%% with the %%optionName%% option.',
    'applications.selectedOptionIcon' => 'Option icon',
    'applications.domainEntity' => 'domain',
    'applications.subscriptionEntity' => 'subscription',
    'applications.mail-hosting.title' => 'Mail hosting',
    'applications.mail-hosting.description' => 'Create a new domain for mail hosting only',
];
