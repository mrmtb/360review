<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'additional-key-update.title' => 'Retrieve Additional Key',
    'additional-key-update.resultDescription' => 'The status of the additional key update',
    'additional-key-update.newKey' => 'Additional key properties',

    'primary-key-update.title' => 'Retrieve Keys',
    'primary-key-update.resultDescription' => 'The status of the keys\' update',
    'primary-key-update.newKey' => 'Plesk key properties',
    'primary-key-update.newAdditionalKey' => 'A new additional key received',

    'dns-zone-check.title' => 'Testing the DNS Zone %%zoneName%% on %%nameServer%%',
    'dns-zone-check.unableCheckError' => 'Unable to test the zone on the name server: This DNS zone is served on another server.',
    'dns-zone-check.description' => 'Plesk gets the list of DNS records from the third-party DNS server and checks if A, AAAA, CNAME, and MX records are present and point to the IP address selected in Plesk for the domain.',

    'DirectoryBrowserDialog.title' => 'Select a directory',
    'DirectoryBrowserDialog.select' => 'Select',
];
