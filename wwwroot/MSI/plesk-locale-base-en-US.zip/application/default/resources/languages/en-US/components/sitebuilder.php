<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'sitesWithoutHostingCannotBeEditedWithSitebuilder' => 'Presence Builder cannot edit a site which is not hosted on the server.',
    'hostingMustSupportPhp5ToEditSiteWithSitebuilder' => 'For editing sites with Presence Builder, the hosting account must support PHP version 5.0 or later.',
    'sitesWithoutHostingCannotBePublishedWithSitebuilder' => 'You need to configure web hosting for a site before you can edit it with Presence Builder.',
];
