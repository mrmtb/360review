<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'error' => 'Error',
    'info' => 'Information',
    'warning' => 'Warning',

    'reason.client.active' => 'The user account is active.',
    'reason.client.inactive' => 'The user account is suspended.',
    'reason.client.inactiveByAdmin' => 'The сlient account is suspended by the administrator.',
    'reason.client.inactiveByReseller' => 'The client account is suspended by a reseller.',
    'reason.client.inactiveWithParent' => "The client account is suspended because its owner was suspended.",
    'reason.client.inactiveExpired' => 'The client account has expired.',

    'reason.domain.active' => 'The domain is active.',
    'reason.domain.inactive' => 'The domain is inactive.',
    'reason.domain.inactiveByAdmin' => 'The domain was suspended by the administrator.',
    'reason.domain.inactiveByReseller' => 'The domain was suspended by a reseller.',
    'reason.domain.inactiveByClient' => 'The domain was suspended by the client.',
    'reason.domain.inactiveWithParent' => "The user account and the user's domain were suspended.",
    'reason.domain.inactiveExpired' => 'The domain has expired.',
    'reason.domain.inactiveBackupRestore' => 'The domain is temporarily suspended for backing up or restoring.',

    'reason.reseller.active' => "The user account is active.",
    'reason.reseller.inactive' => "The user account was suspended.",
    'reason.reseller.inactiveByAdmin' => "The user account was suspended by the service provider.",
    'reason.reseller.inactiveWithParent' => "The user account was suspended by the service provider.",
    'reason.reseller.inactiveExpired' => "The user account\'s subscription has expired.",
    'reason.reseller.inactiveBackupRestore' => "The user account is temporarily suspended for backing up or restoring.",

    'reason.subscription.active' => "The subscription is active.",
    'reason.subscription.inactive' => "The subscription is suspended: All services provided with the subscription are frozen and not accessible to Internet users.",
    'reason.subscription.inactiveExpired' => 'The subscription is suspended because it is expired: All services provided with the subscription are frozen and not accessible to Internet users.',
];
