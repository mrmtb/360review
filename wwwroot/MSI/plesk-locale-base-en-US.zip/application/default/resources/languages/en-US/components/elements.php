<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'access.onAccess' => 'Granted',
    'access.offAccess' => 'Denied',
    'access.notConfigured' => 'Access is denied because some settings are not configured.',

    'double-list-selector.selectedTitle' => 'Selected:',
    'double-list-selector.unselectedTitle' => 'Available:',
    'double-list-selector.searchTitle' => 'Search...',
    'double-list-selector.loadingTitle' => 'Please wait. Loading...',
    'double-list-selector.selectedEmpty' => 'No objects selected',
    'double-list-selector.unselectedEmpty' => 'No objects available',
    'double-list-selector.controlText-none' => 'Click the objects or use checkboxes',
    'double-list-selector.controlText-first' => 'Select {count, plural, one {# object} other {# objects}}',
    'double-list-selector.controlText-second' => 'Clear {count, plural, one {# object} other {# objects}}',

    'file.fileUploadErrorIniSize' => 'The file you are trying to upload exceeds the defined ini size.',
    'file.fileUploadErrorFormSize' => 'The file you are trying to upload exceeds the defined form size.',
    'file.fileUploadErrorPartial' => 'The file was uploaded only partially.',
    'file.fileUploadErrorNoFile' => 'The file was not uploaded.',
    'file.fileUploadErrorNoTmpDir' => 'No temporary directory was found for the file you are trying to upload.',
    'file.fileUploadErrorCantWrite' => 'The file you are trying to upload cannot be written.',
    'file.fileUploadErrorExtension' => 'The extension returned an error while uploading the file.',
    'file.fileUploadErrorAttack' => 'The file was uploaded illegally, possible intrusion attempt.',
    'file.fileUploadErrorFileNotFound' => 'The file you are trying to upload was not found.',
    'file.fileUploadErrorUnknown' => 'Unknown error occurred while uploading the file.',
    'file.fileExtensionFalse' => 'The file you are trying to upload has extension which is not allowed.',

    'lookup.loading' => "Loading...",
    'lookup.nothingFound' => "No matches found",
    'lookup.moreObjectsAvailable' => 'There are %%count%% more objects available.',

    'switch.onState' => 'On',
    'switch.offState' => 'Off',
];
