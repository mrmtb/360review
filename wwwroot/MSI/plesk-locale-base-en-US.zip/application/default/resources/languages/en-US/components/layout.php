<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'removeSidebarSurveyQuestion' => 'Will you be upset if we remove this column?',
    'threeMinutesSurveyLink' => 'Take a 3-minutes survey',
];
