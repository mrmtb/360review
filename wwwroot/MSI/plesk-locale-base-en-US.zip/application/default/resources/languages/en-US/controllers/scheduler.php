<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-task.title' => 'Schedule a Task',
    'add-task.success' => 'The new task was successfully scheduled.',
    'add-task.successRunNow' => 'The scheduled task settings were saved. The task was launched successfully.',

    'edit-task.title' => 'Schedule a Task',
    'edit-task.success' => 'The scheduled task was successfully updated.',
    'edit-task.successRunNow' => 'The scheduled task settings were saved. The task was launched successfully.',

    'settings.title' => 'Scheduled Tasks\' Settings',
    'settings.success' => 'The scheduled tasks\' settings were successfully updated.',

    'tasks-list.title' => 'Scheduled Tasks',
    'tasks-list.titleForObject' => 'Scheduled Tasks for %%name%%',
    'tasks-list.turnOnSuccess' => 'The scheduled task %%name%% was switched on.',
    'tasks-list.turnOffSuccess' => 'The scheduled task %%name%% was switched off.',
];
