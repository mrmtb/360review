<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'subscription' => 'Subscription',
    'subscription_powerUser' => 'Webspace',
    'allSubscriptions' => 'All subscriptions',
    'allSubscriptions_powerUser' => 'All webspaces',
    'allSubscriptionsLimitOverusedDescription' => 'The option to display all subscriptions is unavailable because the number of subscriptions on your account (%%value%%) is greater than %%limit%%.',
];
