<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'placeholder' => 'YYYY-MM[-DD[ HH:MM[:SS]]]]',
];
