<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'icpPermit' => 'ICP Permit',
    'icpStatusNotAllowed' => 'Not Permitted',
    'icpStatusNotAllowedDescription' => 'ICP status is Not Permitted.',
    'icpStatusAllowedDescription' => 'ICP status is Permitted.',
    'enterIcpPermit' => 'Enter Permit ID',
    'changeIcpPermit' => 'Change Permit ID',
    'enterFormTitle' => 'Enter Permit ID for %%domainName%%',
    'changeFormTitle' => 'Change Permit ID for %%domainName%%',
    'grantIcpStatus' => 'Grant Approval',
    'revokeIcpStatus' => 'Revoke Approval',
    'icpStatusChanged' => 'ICP settings of %%domainName%% were saved.',
];
