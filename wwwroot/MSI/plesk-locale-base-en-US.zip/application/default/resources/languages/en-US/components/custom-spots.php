<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'next' => 'Next >>',
    'prev' => '<< Previous',
    'loading' => 'Loading...',
];
