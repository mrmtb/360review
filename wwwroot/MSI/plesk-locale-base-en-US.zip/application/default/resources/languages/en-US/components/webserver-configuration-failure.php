<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'message' => 'New configuration files for the Apache web server were not created due to the errors in configuration templates: %%error%%. Detailed error descriptions were sent to you by email. %%howToFix%% Please resolve the issues and click %%link%% to generate broken configuration files once again or %%linkAll%% to generate all configuration files.',
    'knownIssue' => 'To fix the issue, follow the instructions described in KB: %%kbArticle%%',
    'link' => 'here',
    'linkAll' => 'here',
    'moduleLink' => 'See the details in Configuration Troubleshooter',
    'messageInProgress' => 'Web server configuration is in progress. Do not leave this page until the operation is completed.',
    'messageSuccess' => 'Web server configuration is successfully completed: New configuration files were created and applied to the web server.',
    'messageFailure' => 'Unable to configure the web server: ',
];
