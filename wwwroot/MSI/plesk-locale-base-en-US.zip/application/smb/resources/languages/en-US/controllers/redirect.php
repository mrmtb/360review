<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'custom-button.buttonNotFound' => 'The button was not found. Probably, it was removed.',

    'pleskin.possiblePhishingDetected' => 'Possible phishing attempt detected: The link you used attempted to redirect you to another site.',
];
