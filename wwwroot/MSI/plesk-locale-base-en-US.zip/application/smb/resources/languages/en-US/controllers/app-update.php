<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'download-progress.title' => 'Downloading update for application %%name%%',
    'download-progress.description' => 'The application update is being downloaded for installation. Please do not access your hosted files until the installation is finished.',
    'download-progress.downloadTaskNotFound' => "The application download task with ID '%%id%%' was not found",

    'index.title' => 'Update for %%service%%',
    'index.upLevel' => 'Up level',
    'index.instanceNotFound' => "The service instance with ID '%%id%%' was not found",
    'index.updateNotFound' => "The update for service instance with ID '%%instanceId%%' was not found",
    'index.updateNow' => "Update Now",
    'index.whatsNew' => "What's new in this version.",
    'index.changeLogDate' => "%%version%% (%%release%%) on %%date%%",
    'index.changeLog' => "%%version%% (%%release%%)",
    'index.moreInfo' => "More info at %%appHomePage%%",
    'index.appHomePage' => "Application home page",
    'index.noUpdateDescriptionFound' => "Update description was not found",

    'update.title' => 'Update for %%name%%',
    'update.instanceNotFound' => "The service instance with ID '%%id%%' was not found.",
    'update.successfullyUpdated' => 'The update was installed.',
    'update.updateFailed' => 'Update failed: %%description%%',
    'update.noUpdateFound' => 'No updates found.',
    'update.incorrectUpdateInformation' => 'The update information is incorrect.',
    'update.requirementsFailedForDomainAndThereAreOtherDomains' => 'Unable to install the app on website %%domain%% because hosting settings of this website do not meet the installation requirements. These requirements are listed below. Try installing the application on another website or contact your hosting provider to resolve this issue.',
    'update.requirementsFailedApplicationIncompatible' => 'Unable to install the app because its installation requirements are not met. Contact your hosting provider to resolve this problem.',
];
