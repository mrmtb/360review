<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Redirecting to application',
    'index.permissionDeniedPersonalAccount' => 'Access to personal service of another user is prohibited.',
];
