<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'domain-outgoing-messages.fieldOutgoingMessages' => 'Limit on outgoing messages',
    'domain-outgoing-messages.fieldOutgoingMessagesDefaultOption' => 'Default value',
    'domain-outgoing-messages.fieldOutgoingMessagesCustomOption' => 'Custom value for the domain',
    'domain-outgoing-messages.fieldOutgoingMessagesCustomOptionHint' => 'messages per hour',
    'domain-outgoing-messages.fieldOutgoingMessagesCustomOptionUnlimited' => 'Unlimited',
    'domain-outgoing-messages.outgoingSpamSettingsPopupFormTitle' => 'Limiting Outgoing Messages',
    'domain-outgoing-messages.outgoingSpamSettingsPopupFormHint' => 'Here you can change the limit on the number of outgoing messages for the selected domains. From each domain, it will not be possible to send more messages than the specified limit. You might want to increase the limit if your mailboxes are used for mailing lists, or decrease the limit to prevent excessive outgoing mail.',
    'domain-outgoing-messages.selectedDomainsHint' => 'Applied to domains',

    'email-outgoing-messages.fieldOutgoingMessages' => 'Limit on outgoing messages',
    'email-outgoing-messages.fieldOutgoingMessagesDefaultOption' => 'Default value',
    'email-outgoing-messages.fieldOutgoingMessagesCustomOption' => 'Custom value for the mailbox',
    'email-outgoing-messages.fieldOutgoingMessagesCustomOptionHint' => 'messages per hour',
    'email-outgoing-messages.fieldOutgoingMessagesCustomOptionUnlimited' => 'Unlimited',
    'email-outgoing-messages.outgoingSpamSettingsPopupFormTitle' => 'Limiting Outgoing Messages',
    'email-outgoing-messages.outgoingSpamSettingsPopupFormHint' => 'Here you can change the limit on the number of outgoing messages for the selected mailboxes. From each mailbox, it will not be possible to send more messages than the specified limit. You might want to increase the limit if your mailboxes are used for mailing lists, or decrease the limit to prevent excessive outgoing mail.',
    'email-outgoing-messages.selectedDomainsHint' => 'Applied to mailboxes',
];
