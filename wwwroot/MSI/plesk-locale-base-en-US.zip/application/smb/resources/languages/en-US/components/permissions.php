<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'userManagement' => 'Manage users and roles',
    'webSitesAndDomainsManagement' => 'Create and manage sites',
    'logRotationManagement' => 'Configure log rotation',
    'anonymousFtpManagement' => 'Configure anonymous FTP service',
    'scheduledTasksManagement' => 'Create and manage scheduled tasks',
    'spamfilterManagement' => 'Configure spam filter',
    'antivirusManagement' => 'Configure antivirus',
    'databasesManagement' => 'Create and manage databases',
    'backupRestoreManagement' => 'Configure and perform data backup and restoration',
    'browseStats' => 'View statistics',
    'applicationsManagement' => 'Install and manage applications',
    'sitebuilderManagement' => 'Design sites in Presence Builder',
    'filesManagement' => 'Upload and manage files',
    'ftpAccountsManagement' => 'Create and manage additional FTP accounts',
    'dnsManagement' => 'Manage DNS settings',
    'mailManagement' => 'Create and manage mail accounts',
    'mailListsManagement' => 'Create and manage mailing lists',
    '_errorAccessDenied' => 'Access to the location %%location%% is denied.',
];
