<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoUsersActivated' => 'The selected user accounts were activated. These users can access Plesk now.',
    'activate.infoUsersNotActivated' => 'Unable to activate some of the selected user accounts.',

    'create.title' => 'Create User Account',

    'deactivate.infoUsersDeactivated' => 'The selected user accounts were suspended. These users cannot access Plesk now.',
    'deactivate.infoUsersNotDeactivated' => 'Unable to suspend some of the selected user accounts.',

    'delete-current.unknownUser' => 'Unable to find the user account. Probably it was removed by someone else when you changed its settings.',
    'delete-current.infoUserDeleted' => 'The user account was removed.',
    'delete-current.infoUserNotDeleted' => 'Unable to remove the user account.',

    'delete.infoUsersDeleted' => 'The selected user accounts were removed.',
    'delete.infoUsersNotDeleted' => 'Unable to remove some of the selected user accounts.',

    'edit.unknownUser' => 'The user account was not found. This could happen if the user account was removed by someone else while you were changing its settings.',
    'edit.accessDenied' => 'Access denied.',
    'edit.accessDeniedForAdminAlias' => 'Access denied for admin aliases',

    'index.title' => 'Users',

    'list.title' => 'User Accounts',
    'list.hint' => 'If you want to allow other users to access Plesk in order to manage websites, install applications, or use email services under your domains, then you need to create user accounts.',
    'list.sectionTools' => 'Tools',
    'list.infoNewUserCreated' => 'The user account %%name%% was created.',
    'list.infoUserUpdated' => 'The user account %%name%% was updated.',
    'list.usageTitle' => '%%created%% users created out of %%allowed%% allowed',
    'list.usageLink' => 'Buy additional User Pack',
    'list.contactToProvider' => 'To obtain an additional User Pack, contact your service provider.',

    'overview.title' => '%%name%%',
    'overview.userInfoHint' => 'This is the summary of user settings and permissions.',
    'overview.unknownUser' => 'Unable to find the user account. It was probably removed by someone else while you were changing its settings.',
    'overview.accessDenied' => 'Access denied.',
    'overview.buttonEditUserProperties' => 'Change Settings',
    'overview.hintEditUserProperties' => 'Change user settings.',
    'overview.buttonDeleteUser' => 'Remove',
    'overview.hintDeleteUser' => 'Remove this user account.',
    'overview.generalSectionTitle' => 'General',
    'overview.contactName' => 'Contact name',
    'overview.email' => 'Email address',
    'overview.externalEmail' => 'External email address',
    'overview.phone' => 'Phone number',
    'overview.imNumber' => 'Instant messenger',
    'overview.permissionsSectionTitle' => 'Permissions',
    'overview.permissionsSectionHint' => 'A user role defines the permissions list for this user. From this page, you can edit the user role properties or change the settings of apps available to this user.',
    'overview.roleTitle' => 'Role',
    'overview.editRole' => 'edit',
    'overview.configureService' => 'change settings',
    'overview.createNewService' => 'change settings',
    'overview.permissionGranted' => 'Granted',
    'overview.permissionDenied' => 'Denied',
    'overview.installedAt' => 'Installed at',
    'overview.accountServiceNotConfigured' => 'Not Configured',
    'overview.removeUserConfirmationTitle' => 'Remove this user account?',
    'overview.removeUserConfirmationYes' => 'Yes',
    'overview.removeUserConfirmationNo' => 'No',
    'overview.limitSubscription' => 'Access to subscriptions',
    'overview.deletedSubscription' => 'Removed subscription',
];
