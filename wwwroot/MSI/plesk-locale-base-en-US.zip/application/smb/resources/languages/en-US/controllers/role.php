<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Create User Role',

    'delete.infoRolesDeleted' => 'The selected user roles were removed.',
    'delete.infoRolesNotDeleted' => 'Unable to remove some of the selected user roles.',

    'edit.title' => '%%name%%',
    'edit.unknownRole' => 'The role was not found. This could happen if the role was removed by someone else while you were trying to change its properties.',
    'edit.possiblePhishingDetected' => 'Possible phishing attempt detected: The link you used attempted to redirect you to another site.',

    'list.title' => 'User Roles',
    'list.hint' => 'Assign roles to users to give them access to apps and services hosted on your account. There are several predefined user roles. You can modify them or create your own custom roles.',
    'list.sectionTools' => 'Tools',
    'list.buttonAddNewRole' => 'Create User Role',
    'list.infoNewRoleCreated' => 'The user role %%name%% was created.',
    'list.infoRoleUpdated' => 'The user role %%name%% was updated.',
    'list.hintAddNewRole' => 'Create a user role. User roles allow to effectively group users and thus simplify assignment of privileges and provisioning of services to these users.',
];
