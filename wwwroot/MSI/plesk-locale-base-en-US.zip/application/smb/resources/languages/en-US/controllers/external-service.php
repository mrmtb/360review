<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.connecting' => 'Contacting service, please wait ...',
    'index.error' => 'Service connection failed.',
    'index.errorNoTarget' => 'Target parameter is required.',
    'index.errorNoParam' => 'Parameter %%param%% is required.',
    'index.buttonClose' => 'Close',
];
