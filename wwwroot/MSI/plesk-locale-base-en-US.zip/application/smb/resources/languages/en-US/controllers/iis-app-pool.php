<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'settings.title' => 'IIS Application Pool %%name%%',
    'settings.settingsUpdated' => 'The IIS application pool settings were successfully updated.',
    'settings.sharedMode' => 'Unable to manage the IIS application pool because all websites are using a single shared application pool.',
    'settings.wrongHostingType' => 'This operation is available only for domains with web hosting.',
];
