<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Add SSL/TLS Certificate',
    'add.enterCertificateName' => 'Enter the certificate name.',

    'delete.infoSslCertificatesDeleted' => 'SSL/TLS certificates were removed.',
    'delete.infoSslCertificatesNotDeleted' => 'Unable to remove SSL/TLS certificates.',
    'delete.certificateUsedAsDefault' => 'One of the certificates that you are going to remove is used as the default certificate.',
    'delete.certificateAssignedOnIp' => 'One or more certificates are used by websites.',
    'delete.certificateUsedByPanel' => 'One of the certificates you are going to delete is used for securing Plesk.',
    'delete.certificateUsedByMailServer' => 'One of the certificates you are going to delete is used for securing the mail server.',

    'edit.title' => 'Change Properties of SSL/TLS Certificate %%name%%',
    'edit.enterCertificateName' => 'Enter the certificate name.',

    'list.title' => 'SSL/TLS Certificates',
    'list.titleForObject' => 'SSL/TLS Certificates for %%name%%',
    'list.certificateFound' => 'The private key for the uploaded certificate was found under the name %%name%%. The certificate was successfully added.',

    'webmail.webmailSecureSuccess' => 'Webmail was secured with the selected certificate.',
    'webmail.webmailSecureFailure' => 'Unable to secure webmail with the selected certificate.',
    'webmail.noPrivateKey' => 'The private key (*.key) is absent. Upload it to secure webmail.',
    'webmail.noCertificate' => 'The certificate (*.crt) is absent. Upload it to secure webmail.',

    'mail.mailSecureSuccess' => 'Mail was secured with the selected certificate.',
    'mail.mailSecureFailure' => 'Unable to secure mail with the selected certificate.',
    'mail.serverCertificateNotSelected' => 'The certificate was assigned, but mail for the domain was not secured. To finish securing mail for the domain, %%certLink%%.',
    'mail.serverCertificatesList' => 'secure the mail server',
    'mail.noPrivateKey' => 'The private key (*.key) is absent. Upload it to secure the mail server.',
    'mail.noCertificate' => 'The certificate (*.crt) is absent. Upload it to secure the mail server.',
];
