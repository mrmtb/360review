<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'limits.noLicense' => 'To use Odin Small Business Panel, you have to install a valid license key.',
    'limits.noLicenseNonAdmin' => 'A valid license key must be installed to use Odin Small Business Panel. Contact your system administrator or IT department to resolve this issue.',
    'limits.isExpired' => 'Your license key has expired. To continue using the Panel you must purchase a commercial license key. Expiration date: %%limit%%. Current date: %%current%%.',
    'limits.isExpiredNonAdmin' => 'Panel license key has expired. Contact your system administrator or IT department to resolve this issue.',
    'limits.usersLimitReached' => 'You have reached the limit on the number of user accounts allowed by your license key. User accounts allowed: %%limit%%. User accounts created: %%used%%.',
    'limits.usersLimitOverused' => 'You have created more user accounts than allowed by your license key. User accounts allowed: %%limit%%. User accounts created: %%used%%.',
    'limits.usersLimitOverusedNonAdmin' => 'The number of created user accounts is more than allowed by the license key. Contact your system administrator or IT department to resolve this issue.',
    'limits.mailnamesLimitReached' => 'You have reached the limit on the number of email addresses allowed by your license key. Email addresses allowed: %%limit%%. Email addresses created: %%used%%.',
    'limits.domainsLimitReached' => 'You have reached the limit on number of websites allowed by your license key. Websites allowed: %%limit%%. Websites hosted: %%used%%.',

    'properties.dateNever' => 'Never',
    'properties.dateInstant' => 'Instant',
    'properties.boolTrue' => 'True',
    'properties.boolFalse' => 'False',
    'properties.undefined' => 'Undefined',
    'properties.unlimited' => 'Unlimited',

    'scheduled-updates.keyUpdateProblem' => 'The following error was reported during the update of license key %%keyNumber%% for product %%apsPackageName%% (%%productName%%): %%errorMessage%%',
    'scheduled-updates.unknownKeyNumber' => 'unknown',
    'scheduled-updates.unknownProductName' => 'unknown',
];
