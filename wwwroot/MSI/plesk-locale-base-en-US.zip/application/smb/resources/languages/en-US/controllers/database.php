<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'assign-to-subscription.databasesSuccessfullyAssignedToSubscription' => 'The databases were moved to the subscription \'%%subscriptionName%%\'.',
    'assign-to-subscription.databasesNotAssignedToSubscription' => 'Unable to move the databases to the subscription \'%%subscriptionName%%\'.',
    'assign-to-subscription.subscriptionNotFound' => 'The subscription \'%%name%%\' was not found.',
    'assign-to-subscription.isNotMainDomain' => '\'%%name%%\' is not the main domain on the subscription.',

    'clone.title' => 'Copy %%database%% Database',
    'clone.cloneAlreadyRunning' => 'Please wait until the current database copying task is finished.',

    'create-user.title' => 'Adding Database User',
    'create-user.userSaved' => 'The database user %%login%% was successfully created.',

    'create.title' => 'Add a Database',
    'create.databaseCreated' => 'The database %%name%% was created.',

    'delete-users.infoDatabaseUsersDeleted' => 'The selected database users were removed.',
    'delete-users.infoDatabaseUsersNotDeleted' => 'Unable to remove some of the selected database users.',

    'delete.infoDatabasesDeleted' => 'The selected databases were removed.',
    'delete.infoDatabasesNotDeleted' => 'Unable to remove some of the selected databases.',

    'download-dump.subscriptionIsTurnedOff' => 'Unable to export a dump: the subscription is suspended.',
    'download-dump.dumpNameTooLong' => 'The dump file name is too long.',

    'edit-user.title' => 'Database User %%user%%',
    'edit-user.userSaved' => 'The database user\'s %%login%% account was successfully updated.',
    'edit-user.confirmationYes' => 'Yes',
    'edit-user.confirmationNo' => 'No',
    'edit-user.confirmationWait' => 'Please wait...',
    'edit-user.confirmText' => 'Please confirm that you want to grant the selected global privileges to the database user.',
    'edit-user.hidePrivileges' => 'Hide privileges.',
    'edit-user.showPrivileges' => 'Show privileges.',

    'index.title' => 'Databases',
    'index.pageHint' => 'This is where you can manage databases of subscriptions.',
    'index.subscription' => 'Subscription',

    'list.title' => 'Databases',
    'list.titleForObject' => 'Databases for %%name%%',
    'list.hint' => 'Here you can create new or manage existing databases.',
    'list.buttonAddNewDatabase' => 'Add Database',
    'list.buttonAddNewDatabaseHint' => 'Create a database.',
    'list.buttonUsersManagement' => 'User Management',
    'list.buttonDatabaseServers' => 'Database Servers',
    'list.buttonBackup' => 'Backup Manager',
    'list.tools' => 'Tools',
    'list.showMore' => 'Show More',
    'list.showLess' => 'Show Less',

    'make-default-user.infoDefaultUserSet' => 'The selected database user was marked as default.',
    'make-default-user.infoDefaultUserNotSet' => 'Unable to mark user as default.',

    'repair-orphaned.title' => 'Repair Orphaned User %%userName%%',
    'repair-orphaned.success' => 'The orphaned user was successfully repaired.',

    'repair-results.title' => 'Database %%name%% Repair Results',

    'repair.title' => 'Database \'%%name%%\' Checking Results',

    'upload-dump.fileNotUploaded' => 'Unable to import the dump file.',
    'upload-dump.noFilesInZipArchive' => 'There are no files in the uploaded ZIP archive.',
    'upload-dump.unableOpenFile' => 'Unable to open the uploaded file.',
    'upload-dump.unableOpenZipArchive' => 'Unable to open the uploaded zip archive.',
    'upload-dump.unableOpenGzipArchive' => 'Unable to open the uploaded gzip archive.',
    'upload-dump.subscriptionIsTurnedOff' => 'Unable to import the dump: the subscription is suspended.',

    'users-list.title' => 'Database Users',
    'users-list.buttonAddUser' => 'Add Database User',
    'users-list.buttonAddUserHint' => 'Create a user account for database access.',

    'userNotFound' => 'Database user not found',
];
