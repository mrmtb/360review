<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    '1' => 'Sunday',
    '2' => 'Monday',
    '3' => 'Tuesday',
    '4' => 'Wednesday',
    '5' => 'Thursday',
    '6' => 'Friday',
    '7' => 'Saturday',
    'short1' => 'Sun',
    'short2' => 'Mon',
    'short3' => 'Tue',
    'short4' => 'Wed',
    'short5' => 'Thu',
    'short6' => 'Fri',
    'short7' => 'Sat',
];
