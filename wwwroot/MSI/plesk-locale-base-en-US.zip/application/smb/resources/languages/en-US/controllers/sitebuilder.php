<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'site-removed.siteRemoveDone' => 'Presence Builder website was removed.',
];
