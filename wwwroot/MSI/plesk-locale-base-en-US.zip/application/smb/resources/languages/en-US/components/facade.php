<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'aps.packageNotFound' => 'Specified package does not exist',
    'aps.serviceNotFound' => 'Specified service does not exist',
    'aps.packageFileNotFound' => 'Specified file does not exist',
    'aps.serviceInstanceNotFound' => 'Requested application instance does not exist',
    'aps.incompatibleRequirements' => 'Some requirements for installing the application could not be satisfied.',
];
