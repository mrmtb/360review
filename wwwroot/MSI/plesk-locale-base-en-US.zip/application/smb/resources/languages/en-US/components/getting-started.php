<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'title' => 'Getting Started',
    'hello' => 'Hello, %%username%%',
    'welcome' => 'We are pleased to welcome you to Odin Small Business Panel!',
    'guideInfo' => 'To get you started with our product quickly, we have prepared a special wizard that will walk you through your first steps in Odin Small Business Panel.',
    'guideLinkInfo' => 'If you want to open the wizard later, it is always accessible through the link that is currently highlighted in the top right corner of the screen.',
    'buttonStartWizard' => 'Start the Wizard',
    'buttonCancel' => 'No, Thanks',
];
