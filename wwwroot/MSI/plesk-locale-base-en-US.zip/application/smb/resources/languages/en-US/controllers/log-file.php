<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'browser.title' => 'Logs of %%domain%%',
    'browser.breadcrumbTitle' => 'Logs',
    'browser.customTitle' => 'Log Browser file %%pathbar%%',
    'browser.invalidLogFormat' => 'Log file has unsupported format',

    'delete.actionSuccess' => 'The selected log files were deleted.',
    'delete.invalidFileName' => 'Invalid log file name.',
    'delete.actionError' => 'Unable to delete %%file%%: %%reason%%',

    'list.title' => 'Manage Log Files of %%domain%%',
    'list.breadcrumbTitle' => 'Manage Log Files',

    'settings.title' => 'Configure the Log Rotation',
    'settings.settingsSaved' => 'Log file rotation settings for %%domain%% were successfully changed.',

    'view.title' => 'Log Files Viewer',
    'view.fileIsEmpty' => 'File is empty.',
    'view.fileNameIsUndefined' => 'Log file name is undefined.',
    'view.fileNotFound' => 'Log file not found.',
];
