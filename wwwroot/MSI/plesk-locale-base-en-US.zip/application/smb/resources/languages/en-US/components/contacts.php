<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'imTypeOther' => 'Other',
    'phoneTypeWork' => 'Work',
    'phoneTypeHome' => 'Home',
    'phoneTypeCellular' => 'Mobile',
    'phoneTypeOther' => 'Other',
];
