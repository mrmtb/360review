<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    '_shared.privateTab' => 'Personal Files',
    '_shared.privateTabDescription' => 'Your personal files are stored here. Only you have access to them.',
    '_shared.sharedTab' => 'Shared Files',
    '_shared.sharedTabDescription' => 'Files shared between employees are stored here. Only employees authorized in Plesk have access to them.',
    '_shared.externalTab' => 'Public Files',
    '_shared.externalTabDescription' => 'Files published on the web for your customers are stored here. Everyone who knows a link to this directory or its files can access them.',
    '_shared.externalProtected' => 'Password-protected files',
    '_shared.webDavHint' => 'You can connect this web folder to your computer and work with it directly in your OS.',
    '_shared.webDavHowtoLink' => 'How do I do it?',
    '_shared.uploadButton' => 'Upload Files',
    '_shared.privateFolder' => 'Personal',
    '_shared.sharedFolder' => 'Shared',
    '_shared.externalFolder' => 'Public',
    '_shared.protectedFolder' => 'Protected',
    '_shared.loading' => 'Please wait. Loading...',
    '_shared.serviceTemporarilyUnavailable' => 'The File Sharing service is temporarily unavailable because the site is down for maintenance.',
    '_shared.unauthorized' => 'Unable to access File Sharing repository with the system user name "%%login%%": Wrong username or password.',
    '_shared.phpFpmNotCompatible' => 'The File Sharing service is not compatible with PHP-FPM. To use the File Sharing service, select another PHP handler on the domain %%domainName%%.',

    'change-credentials.credentialsChanged' => 'Credentials for file sharing were changed.',
    'change-credentials.willBeAppliedAfterApacheRestartIntervalInLessThanMinute' => 'The changes will be applied in less than a minute.',
    'change-credentials.willBeAppliedAfterApacheRestartInterval' => 'The changes will be applied in %%restartInterval%% minutes.',

    'create-folder.folderCreated' => '%%folder%% folder was successfully created.',

    'index.title' => 'File Sharing',
];
