<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Add a web user',
    'create.userSaved' => 'The web user account %%login%% was created.',

    'delete.infoWebUsersDeleted' => 'Web user accounts were removed.',
    'delete.infoWebUsersNotDeleted' => 'Unable to remove web users.',

    'edit.title' => '%%name%%',
    'edit.userSaved' => "Web user %%login%%'s account settings were changed.",

    'list.title' => 'Web users',
    'list.titleForObject' => 'Web users of domain %%name%%',
    'list.hint' => 'View and manage users who have personal web pages on your websites. Web user accounts cannot log in to Plesk, and can only host their sites within a single directory under one of your sites. If scripting is enabled, web users can access all files of a subscription. Web users\' sites can have addresses like www.example.com/~username.',

    'settings.title' => 'Settings',
    'settings.settingsSaved' => 'Settings of web user accounts under the domain %%domain%% were changed.',
];
