<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Master SSL/TLS Domain',
    'index.success' => 'Master SSL/TLS domain was set up.',
];
