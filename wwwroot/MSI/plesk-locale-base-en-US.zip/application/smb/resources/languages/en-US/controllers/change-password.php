<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change.title' => 'Your New Password',
    'change.invalidLink' => 'The password recovery link you have followed is not valid. Please try again or contact your server administrator.',
    'change.passwordChanged' => 'Your password has been changed.',

    'get-link.title' => 'Password Recovery',
    'get-link.invalidAccount' => 'The user account you have specified could not be found in the system. Please specify a valid user account.',
    'get-link.messageSent' => 'A message with instructions on how to recover your password was sent to your email address.',
    'get-link.mailSubject' => 'Password recovery',
    'get-link.mailContent' => "Hello, %%name%%.\n\nYou are receiving this email because you have requested a new password for your user account. If you did not request a new password, ignore this email. If you keep receiving this email, please contact your server administrator immediately.\n\nTo get a new password for your user account, open the following link in your browser:\n%%link%%\n\nContact your server administrator if you encounter any difficulties in getting a new password for your user account.",
];
