<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'My Apps',
    'index.buttonsAreaDescription' => 'Use the links below to access or manage the applications installed on your websites.',
];
