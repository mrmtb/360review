<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'email.subjSuccess' => 'Odin Small Business Panel was successfully updated',
    'email.subjFailure' => 'Odin Small Business Panel update failed',
    'email.bodySuccess' => "Attention,\n\nOdin Small Business Panel was successfully updated.\nTo view the list of changes, visit %%link%%.\n\nThis message was sent automatically by Plesk Installer.",
    'email.bodyFailure' => "Attention,\n\nThe update of Odin Small Business Panel has failed.\n\nYou can download Plesk Installer logs at the following link: %%link%%.\nContact your Hosting Provider for support assistance.\n\nThis message was sent automatically by Plesk Installer.",
];
