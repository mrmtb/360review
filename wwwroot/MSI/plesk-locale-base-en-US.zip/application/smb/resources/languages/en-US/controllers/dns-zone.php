<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'acl-records.title' => 'Zone Transfers',

    'add-acl-record.title' => 'Add IP Address',
    'add-acl-record.success' => 'The specified IP addresses were added to the list of addresses to which the transfer of the zone %%name%% is allowed.',

    'delete-acl-record.success' => 'The selected IP addresses were removed from the list of addresses to which DNS zone transfers are allowed.',

    'add-record.masterTitle' => 'Add a Resource Record to the Zone',
    'add-record.slaveTitle' => 'Add a Primary DNS Server',
    'add-record.offTitle' => 'Add a Name Server',

    'delete.unableDeleteRecord' => 'Unable to delete the record: %%reason%%',

    'edit-record.masterTitle' => 'Edit the Resource Record',
    'edit-record.slaveTitle' => 'Specify the Primary DNS Server',
    'edit-record.offTitle' => 'Specify the Name Server',

    'index.title' => 'DNS Settings',
    'index.titleForObject' => 'DNS Settings for %%name%%',

    'records-list.title' => 'Records',
    'records-list.dnsZoneMasterTitle' => 'The Plesk\'s DNS server acts as a primary name server for the DNS zone %%name%%',
    'records-list.dnsZoneSlaveTitle' => 'The Plesk\'s DNS server acts as a secondary name server for the DNS zone %%name%%',
    'records-list.dnsZoneOffTitle' => 'Name servers for the DNS zone %%name%%',
    'records-list.serviceNotSupported' => 'The DNS service is not installed.',
    'records-list.dnsZoneNotSynchronized' => 'The DNS zone was modified. If you would like to apply changes in the DNS template to this zone, either click the \'Apply DNS Template Changes\' button on this page or go to the Server Administration Panel > Tools & Settings > DNS Template Settings > Apply DNS Template Changes and choose the \'Apply the changes to all zones\' option.',
    'records-list.updatedSuccessfully' => 'The changes made to DNS records were successfully saved.',
    'records-list.revertedSuccessfully' => 'The changes made to DNS records were cancelled.',
    'records-list.dnsZoneNotCreated' => 'Unable to perform the action because the DNS zone %%name%% is not created yet.',

    'restore-default.title' => 'Restore the DNS Zone',
    'restore-default.zoneIsNotMaster' => 'Unable to restore the records in the DNS zone %%name%% because the zone is served by another DNS server.',
    'restore-default.success' => 'The DNS zone %%name%% was restored.',

    'soa-record.title' => 'Settings',
    'soa-record.zoneIsNotMaster' => 'Unable to change the properties of the SOA record because the DNS zone %%name%% is served by another server.',
    'soa-record.success' => 'The SOA record properties of the DNS zone %%name%% were updated.',
    'soa-record.restoreDefaultSuccess' => 'The default SOA record in the DNS zone %%name%% was restored.',

    'external-dns.title' => 'External DNS',
    'external-dns.hint' => 'Here you can configure external DNS servers for your domain',
    'external-dns.success' => 'Saved',
    'external-dns.configured' => 'Configured',
    'external-dns.notConfigured' => 'Not configured',
    'external-dns.useExtension' => 'Use this extension',

    'sync-zone.notSupportedOnWindowsPlatform' => "Syncing with the DNS template is not supported on Windows systems.",
    'sync-zone.syncZoneDisabledWarning' => 'Unable to apply DNS template changes to the zone because the zone is served by another DNS server.',
    'sync-zone.success' => 'The changes of the DNS template were successfully applied to the zone.',
    'sync-zone.successPartially' => 'The changes of the DNS template were applied to the zone, but some records from the template were not transferred: %%details%%',

    'toggle-type.successMaster' => 'This DNS server now acts as the primary name server for the zone %%name%%.',
    'toggle-type.successSlave' => 'This DNS server now acts as a secondary name server for the zone %%name%%.',

    'turn-off.success' => 'The local DNS service for the DNS zone %%name%% is switched off.',

    'turn-on.success' => 'The DNS zone %%name%% is now served by the local DNS server.',

    'who-is.title' => 'Whois Information for %%name%%',
    'who-is.error' => 'Whois is unavailable for %%name%%',
];
