<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'string.literalBytes' => 'B',
    'string.tera' => 'T',
    'string.giga' => 'G',
    'string.mega' => 'M',
    'string.kilo' => 'K',
];
