<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'anonymous.title' => 'Anonymous FTP',
    'anonymous.ipv6NotAllowedAccessedByIpv4' => "You can set up the anonymous FTP service only on IPv4 addresses.\nAnonymous FTP will only work at %%dnsRec%% or if %%domainName%% is accessed from IPv4 networks.",
    'anonymous.ipv6NotAllowed' => "You can set up the anonymous FTP service only on IPv4 addresses.\nAnonymous FTP will work only if %%domainName%% is accessed from IPv4 networks.",
    'anonymous.turnOn' => 'Switch On',
    'anonymous.turnOnHint' => 'Switch on the anonymous FTP service for the domain.',
    'anonymous.turnOff' => 'Switch Off',
    'anonymous.turnOffHint' => 'Switch off the anonymous FTP service for the domain.',
    'anonymous.settingsSaved' => 'Anonymous FTP settings were saved.',

    'create-user.title' => 'Add an Additional FTP Account',
    'create-user.userCreated' => 'Additional FTP account was successfully created.',

    'edit-user.title' => '%%name%%',
    'edit-user.userEdited' => 'Additional FTP account was successfully saved.',

    'users-list.title' => 'FTP Accounts',
    'users-list.titleForObject' => 'FTP Accounts of %%name%%',
    'users-list.hint' => 'Here you can create new and manage existing FTP accounts.',
    'users-list.headerType' => 'T',
    'users-list.headerName' => 'Name',
    'users-list.headerHome' => 'Home',
    'users-list.brokenDir' => 'non-existent physical directory',
    'users-list.typeHosting' => 'Subscription owner\'s FTP account',
    'users-list.typeWeb' => 'Web user\'s FTP account',
    'users-list.typeFtp' => 'Additional FTP account',
    'users-list.buttonAddUser' => 'Add an FTP Account',
    'users-list.buttonAddUserHint' => 'Create an additional FTP account.',
    'users-list.buttonRemoveUser' => 'Remove',
    'users-list.buttonRemoveUserHint' => 'Remove the selected FTP accounts.',
    'users-list.confirmOnDelete' => 'Remove the selected FTP accounts?',
    'users-list.infoUsersDeleted' => 'The selected FTP accounts were removed.',
    'users-list.infoUsersNotDeleted' => 'Unable to remove some of the selected FTP accounts.',
];
