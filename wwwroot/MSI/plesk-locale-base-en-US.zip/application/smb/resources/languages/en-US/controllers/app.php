<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    '_shared.title' => 'Applications',
    '_shared.titleForDomain' => 'Applications of %%name%%',
    '_shared.tabMarketTitle' => 'Featured Applications',
    '_shared.tabMarketDescription' => 'View and install most recommended and popular apps on your websites.',
    '_shared.tabCatalogTitle' => 'All Available Applications',
    '_shared.tabCatalogDescription' => 'View and install free and commercial apps on your websites. Apps packaged in APS format only require several clicks to be installed on your websites.',
    '_shared.tabInstalledTitle' => 'Manage My Applications',
    '_shared.tabInstalledDescription' => 'Manage apps installed on your websites.',

    'available.title' => 'Applications',
    'available.tabTitle' => 'Available Applications',
    'available.catalogConfigurationFileBroken' => 'The configuration file of Application Catalog is corrupted',
    'available.installApplicationDeniedSubscriptionIsTurnedOff' => 'Unable to install the application: the subscription is suspended.',

    'download-progress-data.applicationDownloadError' => 'The following error has occurred during the download of application: %%message%%',

    'download-progress.titleInstall' => 'Downloading %%name%%...',
    'download-progress.description' => 'The application is being downloaded for installation. Please do not access your hosted files until the installation is finished.',
    'download-progress.downloadTaskNotFound' => "The application download task with ID '%%id%%' was not found",

    'force-update-all-applications.forceUpdateEnabled' => 'Force updates are turned on for all applications.',

    'get-install-prefix.noContextFound' => 'Unable to find the website specified for the app installation.',

    'install-progress-data.applicationDownloadError' => 'The following error has occurred during the installation of application: %%message%%',

    'install-progress.titleInstall' => 'Installing %%name%%...',
    'install-progress.description' => 'The application is being installed. Please do not access your hosted files until the installation is finished.',
    'install-progress.taskNotFound' => "The application installation task with ID '%%id%%' was not found",

    'install.title' => 'Installation of %%name%%',
    'install.serviceNotFound' => "The service with ID '%%id%%' was not found.",
    'install.applicationNotFound' => "The app with ID '%%id%%' was not found.",
    'install.install' => 'Install',
    'install.applicationDescriptionNotFound' => 'The file that contains the app description was not found.',
    'install.applicationConfigurationError' => 'The following error has occurred during the configuration of app: %%message%%.',
    'install.noContextFound' => 'Unable to find the website specified for the app installation.',
    'install.noSubscriptionFound' => 'Unable to find the subscription specified for the app installation.',
    'install.scanLinkTitle' => 'Scan',
    'install.requirementsFailedForDomainAndThereAreOtherDomains' => 'Unable to install the app on website %%domain%% because hosting settings of this website do not meet the installation requirements. These requirements are listed below. Try installing the application on another website or contact your hosting provider to resolve this issue.',
    'install.requirementsFailedApplicationIncompatible' => 'Unable to install the app because its installation requirements are not met. Contact your hosting provider to resolve this problem.',
    'install.requirements' => 'Requirements',
    'install.httpsContentHint' => 'To provide secure access to this application, install it on a website with SSL/TLS support. Such websites have addresses starting with "https". To install the application to a directory other than the website root, specify the directory name.',
    'install.someContextsAreHidden' => 'Apps cannot be installed on https sites of some of your domains because SSL/TLS support is not activated for these domains. To activate the SSL/TLS support, go to Websites & Domains and click Hosting Settings next to a domain name in the list.',
    'install.someContextsAreHiddenBySameSSLCompatibilityMode' => 'The "https" sites for some of your domains are not listed as available for the app installation because they work in the compatibility mode for the legacy option "Separate SSL/TLS and non-SSL/TLS content". Turn the mode off in a domain hosting settings: Go to Websites & Domains and click the domain name in the list. Note that turning the mode off is an irreversible operation which will make content of the legacy \'httpsdocs\' folder unavailable on the web.',
    'install.globalSettingsNotSet' => 'Unable to install %%name%%. It requires preliminary configuration by your hosting provider.',
    'install.globalSettingsNotSetAdmin' => 'Unable to install %%name%%. It requires preliminary configuration of server-wide settings. You can configure the app in the Server Administration Panel > Tools & Settings > Application Vault.',
    'install.loading' => 'Loading...',

    'installed.title' => 'Applications',
    'installed.tabTitle' => 'My Apps',
    'installed.tools' => 'Tools',
    'installed.buttonAddApplication' => 'Add Application from Local Storage',
    'installed.buttonApsCatalog' => 'Add Application from Application Catalog',
    'installed.catalogConfigurationFileBroken' => 'The configuration file of Application Catalog is corrupted',
    'installed.whereAreApps' => "The list below contains information about all installed apps. The None value in the Installation path column means that the app is external. Such an app cannot be installed on any of your websites; it only provides a link to an external service.",
    'installed.installAppHint' => "Select an application to install from one of our <a href=\"%%marketplace%%\">featured applications</a> or browse through <a href=\"%%apscatalog%%\">all available applications</a>.",

    'market.catalogConfigurationFileBroken' => 'The configuration file of Application Catalog is corrupted',
    'market.installApplicationDeniedSubscriptionIsTurnedOff' => 'Unable to install the application: the subscription is suspended.',

    'select.title' => 'Select a Service',
    'select.applicationNotFound' => "The app with ID '%%id%%' was not found.",
    'select.applicationDescriptionAcquiringError' => "An error has occurred during the acquiring of application description",
    'select.serviceDescription' => '%%name%%: %%summary%%',
    'select.select' => 'Select',
];
