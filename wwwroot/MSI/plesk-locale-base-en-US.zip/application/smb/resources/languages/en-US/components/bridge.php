<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'backup.unableToRestore' => 'Unable to restore the data',
    'backup.dumpNotFound' => 'Backup file \'%%id%%\' not found',
    'backup.unableToGetLogForUnfinishedTask' => 'Unable to retrieve the log file because the task is not finished yet',
    'backup.unableToOpenLogFile' => 'Unable to open the log file',
    'backup.ipConflict' => 'Unable to restore the data: IP address \'%%ip%%\' is required',
    'backup.dbServerConflict' => 'Unable to restore the data: database server \'%%type%%:%%host%%:%%port%%\' is required',
    'backup.unresolvedConflict' => 'Unable to restore the data: %%type%% %%name%% cannot be restored',
    'backup.domainsLimitConflict' => 'Unable to restore the data: the limit on the number of websites allowed by your license key will be exceeded. Websites required: %%requested%%; websites available: %%limit%%.',

    'domain.canNotRedirectToItself' => 'Redirect address can not be set to domain name.',

    'mail.list.incorrectSubscriber' => "Subscriber's email address is incorrect: %%subscriber%%",

    'mail.spamfilter.invalidAddresses' => 'The following email addresses are invalid: %%invalidAddresses%%',
    'mail.spamfilter.invalidNetworks' => 'The following network addresses are invalid: %%invalidNetworks%%',
    'mail.spamfilter.exceededAddressesAvailable' => 'Only %%available%% unique email addresses can be added.',
];
