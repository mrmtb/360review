<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'My Profile',
    'index.profileSaved' => 'Profile was updated.',
    'index.redirectTab' => 'Mail Forwarding',
    'index.autoResponderTab' => 'Mail Auto-Reply',
    'index.accessDenied' => 'Access denied for admin aliases',
];
