<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'aps.administrativeAccountIn' => 'Administrative access',
    'aps.accessToApplication' => 'Public access',
    'aps.personalAccountIn' => 'Personal access',
    'aps.administrativeAccountInShort' => 'Administrative access',
    'aps.accessToApplicationShort' => 'Public access',
    'aps.personalAccountInShort' => 'Personal access',
];
