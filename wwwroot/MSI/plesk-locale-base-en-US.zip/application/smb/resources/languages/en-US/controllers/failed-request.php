<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete.actionSuccess' => 'The selected log files were deleted.',
    'delete.invalidFileName' => 'Invalid log file name.',
    'delete.actionError' => 'Unable to delete %%file%%: %%reason%%',

    'disable-tracing.successUpdate' => 'Failed request tracing was stopped.',

    'download.actionError' => 'Unable to create the archive: %%reason%%.',

    'enable-tracing.title' => 'Start the Failed Requests Tracing',

    'list.title' => 'Failed Requests Tracing on %%name%%',
    'list.wrongHostingType' => 'This operation is available only for domains with web hosting.',
    'list.breadcrumbTitle' => 'Failed Requests Tracing',
    'list.hint' => 'Tracing of failed requests is resource-intensive, and we recommend that you turn off tracing as soon as enough failed requests have been traced.',
    'list.tracingEnabled' => 'Failed request tracing is turned on. It will be automatically turned off after %%date%%.',
    'list.disableNow' => 'Turn off now',
];
