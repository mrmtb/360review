<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Web Application Firewall for %%domain%%',
    'index.breadcrumbTitle' => 'Web Application Firewall',
    'index.settingsSaved' => 'The web application firewall settings for your website were saved.',
];
