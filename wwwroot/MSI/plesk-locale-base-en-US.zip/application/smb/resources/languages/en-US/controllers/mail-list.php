<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Create Mailing List',

    'delete.infoMailListsDeleted' => 'Selected mailing lists were deleted.',
    'delete.infoMailListsNotDeleted' => 'Unable to delete some of the selected mailing lists.',

    'edit.unknownMailList' => 'Mailing list was not found. This can happen if mailing list was removed by someone else while you tried to access it.',

    'list.title' => 'Mail',
    'list.titleForDomain' => 'Mail of %%name%%',
    'list.tabTitle' => 'Mailing Lists',
    'list.hint' => 'This is where you create and manage mailing lists. A mailing list is a means to send an email message to multiple recipients at once. Mailing lists are commonly used for sending newsletters and organizing email discussion forums.',
    'list.buttonAddNewMailList' => 'Create Mailing List',
    'list.hintAddNewMailList' => 'Create a mailing list and subscribe users to it.',
    'list.infoNewMailListCreated' => 'The mailing list %%name%% was created.',
    'list.infoMailListUpdated' => 'The settings of the mailing list %%name%% were saved.',
];
