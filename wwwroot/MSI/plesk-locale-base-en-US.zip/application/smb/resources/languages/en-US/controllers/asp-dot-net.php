<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'settings.title' => 'ASP.NET Configuration for %%name%%',
    'settings.serverTitle' => "ASP.NET Server-Wide Configuration",
    'settings.vdirTitle' => "ASP.NET Configuration for the Virtual Directory %%vdir%%",
    'settings.notSupported' => 'ASP.NET support is switched off for this website.',
    'settings.success' => 'ASP.NET settings were successfully changed.',
    'settings.confirmationButtonYes' => 'Yes',
    'settings.confirmationButtonNo' => 'No',
    'settings.restoreDefault' => 'Restore Default Configuration',
    'settings.restoreDefaultHint' => 'Restore the default ASP.NET settings.',
    'settings.restoreDefaultConfirmation' => 'Restore the default ASP.NET settings?',
    'settings.restoreDefaultSuccess' => 'ASP.NET default settings were successfully restored.',
    'settings.restoreDefaultFailed' => 'ASP.NET settings restore failed.',
    'settings.changeVersion' => 'Change Version',
    'settings.changeVersionHint' => 'Change the ASP.NET version used by this domain.',
];
