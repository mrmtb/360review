<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'customize-list-columns.title' => 'Columns of the %%service%% Settings List',
    'customize-list-columns.pageHint' => 'Each setting is presented by a column in the settings list. Here you can specify what settings to display in this list or, in other words, what columns you want to appear in the settings list.',

    'delete-instance.infoServiceDeleted' => 'The selected service instances were removed.',
    'delete-instance.infoServiceNotDeleted' => 'Unable to remove some of the selected service instances.',
];
