<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'branding.title' => 'Plesk Branding',

    'disable-languages.disableLanguagesSuccess' => 'The selected languages are no longer available to users.',

    'edit-controls.updateSuccess' => 'The settings were updated successfully.',

    'edit-interface-view.title' => 'Interface Views',
    'edit-interface-view.updateSuccess' => 'The settings were updated successfully.',

    'enable-languages.enableLanguagesSuccess' => 'The selected languages become available to users.',

    'language-make-default.languageMakeDefaultSuccess' => 'The selected language was set as the default for Plesk.',

    'list-languages.title' => 'Languages',
    'list-languages.mlsLimitExceeded' => "Your current Plesk license allows using %%allowedByLicense%% languages. At the moment, you have %%availableToUsers%% languages set as available to users, which exceeds the number provided with the license. Please select %%allowedByLicense%% languages you want to use, and make the rest unavailable to users by clicking their icons in the 'S' column.",
];
