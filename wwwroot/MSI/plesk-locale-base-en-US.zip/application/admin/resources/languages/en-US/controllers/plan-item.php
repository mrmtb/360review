<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Add a Service',
    'create.hint' => 'This is where you add a link to an external service.',

    'edit.title' => 'Properties of the Service %%name%%',
    'edit.hint' => 'This is where you specify the properties of the service.',
    'edit.errorItemNotEditable' => 'The properties of this service are not editable.',

    'list.title' => 'Additional Services',
    'list.tabTitle' => 'Additional Services',
    'list.hint' => "This is a list of additional services which you can provision with hosting plans. It shows the manually defined services and services provided by the applications installed as Plesk extensions. Adding a service manually is useful when you want to direct your customers to an external online service: this adds a corresponding button to Customer Panel. By default, all additional services are listed in hosting plan properties, on the Additional Services tab. This lets you and your resellers include these services in hosting plans. If you do not want your resellers to use a service and provide it to their customers, use the Make Unavailable link.",
    'list.planItemsNowAvailable' => 'The selected additional services are available to resellers.',
    'list.planItemsNowNotAvailable' => 'The selected additional services are no longer available to resellers.',
    'list.cantChangePlanItemsProperties' => 'An error occurred on attempt to change availability settings for the service.',
    'list.infoNewPlanItemCreated' => 'The option %%name%% corresponding to the service was added to the plan properties.',
    'list.infoPlanItemUpdated' => 'Plan option %%name%% was updated.',
    'list.planItemsDeleted' => 'The selected plan options were deleted.',
    'list.planItemsNotDeleted' => 'Some of the selected plan options were not deleted.',
];
