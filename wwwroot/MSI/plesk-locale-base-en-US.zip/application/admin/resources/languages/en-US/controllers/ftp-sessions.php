<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-sessions.noSessionsSpecified' => 'Select one or more FTP sessions from the list.',
    'delete-sessions.sessionsDeleted' => 'The selected sessions were deleted.',
    'delete-sessions.sessionsNotDeleted' => 'Some of the selected sessions were not deleted. Details: %%error%%.',

    'list.title' => 'FTP Sessions',
];
