<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Add SSL/TLS Certificate',
    'add.enterCertificateName' => 'Enter the certificate name.',

    'delete.infoSslCertificatesDeleted' => 'SSL/TLS certificates were removed.',
    'delete.infoSslCertificatesNotDeleted' => 'Unable to remove SSL/TLS certificates.',
    'delete.certificateUsedAsDefault' => 'One of the certificates you are going to delete is used as the default certificate.',
    'delete.certificateAssignedOnIp' => 'One or several certificates are assigned to the IP addresses/domains.',
    'delete.certificateUsedByPanel' => 'One of the certificates you are going to delete is used for securing Plesk.',
    'delete.certificateUsedByMailServer' => 'One of the certificates you are going to delete is used for securing the mail server.',

    'edit.title' => 'Change Properties of SSL/TLS Certificate %%name%%',
    'edit.enterCertificateName' => 'Enter the certificate name.',

    'list.title' => 'SSL/TLS Certificates',
    'list.certificateFound' => 'The private key (with the name %%name%%) for the uploaded certificate was found. The certificate was successfully added.',
    'list.certificatesList' => 'List of certificates in server pool',
    'list.certificatesListHint' => 'There are the list of certificates in the server pool.',
    'list.currentCertificates' => 'Certificates currently in use for securing Plesk server',
    'list.currentCertificatesHint' => 'Certificates currently in use for securing Plesk server and mail server',
    'list.pleskCertificate' => 'Certificate for securing Plesk',
    'list.mailServerCertificate' => 'Certificate for securing mail',
    'list.serverPoolCertificateDescription' => '%%name%% from server pool.',
    'list.domainCertificateDescription' => '%%name%% from %%domain%%.',
    'list.change' => '[Change]',
    'list.none' => 'Unknown.',

    'secure-mail-server.title' => 'Secure Mail Server',
    'secure-mail-server.hint' => 'Select a certificate for securing the mail server.',
    'secure-mail-server.mailServerCertificateSet' => 'The %%name%% certificate was successfully set to secure the mail server.',
    'secure-mail-server.mailServerNotInstalled' => 'The mail service is not installed.',

    'secure-panel.title' => 'Secure Plesk',
    'secure-panel.hint' => 'Select a certificate for securing Plesk.',
    'secure-panel.panelCertificateSet' => 'The %%name%% certificate was successfully set to secure Plesk.',
];
