<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Plesk Installer',
    'index.autoinstallerRedirectError' => 'Unable to start Plesk Installer. The following error has occurred: %%message%%',

    'product.title' => 'Plesk Installer',
    'product.autoinstallerRedirectError' => 'Unable to start Plesk Installer. The following error has occurred: %%message%%',

    'settings.title' => 'Update Settings',
    'settings.settingsUpdated' => 'Update settings were changed.',
];
