<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'gallery.titleScreenshot' => 'Screenshots of %%packageName%%',
    'gallery.prevImage' => '< Previous',
    'gallery.nextImage' => 'Next >',
    'gallery.closeGallery' => 'Close',
    'gallery.navigationOf' => 'of',
    'gallery.typeScreenshot' => 'screenshots',
    'gallery.title' => 'Screenshots',
];
