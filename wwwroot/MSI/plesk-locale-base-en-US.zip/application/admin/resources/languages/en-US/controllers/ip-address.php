<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Add IP address',
    'add.ipAddressAdded' => 'The IP address %%address%% was added.',

    'delete.infoIpAddressesDeleted' => 'The selected IP addresses were removed.',

    'edit.title' => 'IP address %%address%% on the interface %%interface%%',
    'edit.ipAddressUpdated' => 'The change of the IP address %%address%% settings has been scheduled and will be done in the background',
    'edit.ipAddressInterfaceNotAvailableWarning' => 'Network adapter %%interface%% does not exist. Move this IP address to another network adapter or remove it from the list.',

    'list.title' => 'IP Addresses',
];
