<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Adding Event Handler',
    'add.added' => 'The event handler was added.',

    'delete.noHandlersSpecified' => 'Select the event handlers to be removed.',
    'delete.handlersDeleted' => 'The selected event handlers were removed.',
    'delete.handlersNotDeleted' => 'Some of the selected event handlers were not removed. Details: %%error%%.',

    'edit.title' => 'Updating Event Handler Properties',
    'edit.updated' => 'The event handler was updated.',

    'list.title' => 'Event Manager',
];
