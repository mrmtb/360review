<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'External SMTP Server Settings',
    'index.settingsUpdated' => 'The settings were updated.',
];
