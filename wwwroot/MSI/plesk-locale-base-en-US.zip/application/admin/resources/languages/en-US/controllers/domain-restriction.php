<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add.title' => 'Add a Domain Name',
    'add.domainAdded' => 'The domain name %%domain%% was successfully added to the list of prohibited names.',

    'disable.listDisabled' => 'The checking for the prohibited domain names was turned off.',

    'edit.title' => '%%name%%',
    'edit.domainUpdated' => 'The domain name %%domain%% was successfully updated.',

    'enable.listEnabled' => 'The checking for the prohibited domain names was turned on.',

    'list.title' => 'Prohibited Domain Names',
    'list.hint' => 'Here you can manage the list of prohibited domain names, which contains the most popular domains. If you turn on checking for prohibited domain names (by clicking Enable), users will be unable to create domains with the names from this list. Such restriction is useful, for example, for preventing mail interception. If the checking is turned off, email messages sent by your customers to legitimate companies can be received by the customers who set up domains with the same names as owned by these companies.',
    'list.warningLisDisabled' => 'The checking for prohibited domain names is turned off.',

    'remove.domainRemoved' => 'The selected domain names were removed.',
    'remove.domainNotRemoved' => 'Some of the selected domain names were not removed.',
    'remove.unableRemove' => 'Some of the specified domain names were not removed.',
];
