<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.formTitle' => 'Choose service for add',
    'create.successfullyAdded' => 'The \'%%serviceDisplayName%%\' service was successfully created.',
    'create.successfullyUpdated' => 'The \'%%serviceDisplayName%%\' service was successfully updated.',
    'create.selectServiceInstallationTitle' => 'Select service',

    'edit.formTitle' => 'Manage the \'%%serviceDisplayName%%\' Service',
    'edit.title' => 'Services of %%subscriptionName%%',
    'edit.successfullyUpdated' => 'The \'%%serviceDisplayName%%\' service was successfully updated.',

    'list.hint' => 'Here you can manage services on subscription',
    'list.title' => 'Services of %%subscriptionName%%',
    'list.breadcrumb' => 'Services',
    'list.infoServiceDeleted' => 'Selected services were removed.',
    'list.infoServiceNotDeleted' => 'Some of the selected services were not removed.',
];
