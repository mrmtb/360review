<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'acl-records.title' => 'Transfer Restrictions Template',

    'add-acl-record.title' => 'Add IP Address',
    'add-acl-record.success' => 'The specified IP addresses were successfully added.',

    'delete-acl-record.success' => 'The selected IP addresses were successfully removed.',

    'index.title' => 'DNS Settings',

    'records.title' => 'Zone Records Template',

    'reset-settings.success' => 'The default settings were successfully restored.',

    'settings.title' => 'Server-wide Settings',
    'settings.success' => 'The settings were successfully updated.',

    'soa-record.title' => 'Zone Settings Template',

    'restore-default.title' => 'Restore the Default DNS Zone Template',
    'restore-default.text' => 'Please confirm that you want to restore the default configuration of the DNS zone template.',

    'soa-sync.title' => 'Override SOA settings for all existing domains',
    'soa-sync.text' => 'Update SOA records of all hosted domains by applying the changes made to the SOA template?',

    'sync.title' => 'Apply DNS Template Changes',
    'sync.type-option' => 'Choose one of the following',
    'sync.safe' => 'Apply the changes to unaltered zones. If a zone was customized (new records were added or existing ones were changed), Plesk will not apply the changes from the template to such zones.',
    'sync.force' => 'Apply the changes to all zones. Plesk will apply changes from the template to all DNS zones including the customized ones. Note that user-modified records always remain intact. For example, if the template contains a new record that was already added by a customer, Plesk will keep the customer\'s record.',

    'external-dns.title' => 'External DNS',
    'external-dns.hint' => 'Here you can configure external DNS servers',
    'external-dns.success' => 'Saved',
    'external-dns.configured' => 'Configured',
    'external-dns.notConfigured' => 'Not configured',
    'external-dns.useExtension' => 'Use this extension',

    'external-dns-edit.title' => 'External DNS',
];
