<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'PHP Settings',
    'list.hint' => 'Select the PHP handlers you want to make available. You can install additional handlers using the %%link%%.',
    'list.hintLink' => 'Plesk Installer',
    'list.brokenDomainsError' => 'The following PHP version(s) are not installed: %%phpVersions%%. PHP scripting for %%domainCount%% domain(s) is unavailable. Install the missing PHP versions or follow the instructions from the <a href=https://support.plesk.com/hc/en-us/articles/12377342328343>KB article</a> to repair PHP scripting.',
    'list.brokenHandlersError' => 'The following PHP version(s) are not installed: %%phpVersions%%. Install them or run <code>plesk repair web -php-handlers</code> to select another PHP version.',

    'modules.canNotManageModules' => 'Access to PHP handler settings management is limited because the path to the PHP CLI file is not specified.',

    'php-ini.title' => 'Settings for <b>%%name%%</b>',
    'php-ini.tabTitle' => 'php.ini',
    'php-ini.success' => 'The settings were updated.',

    'toggle.errorEnableBrokenHandler' => 'The handler is corrupted and cannot be enabled.',
    'toggle.errorDisableBrokenHandler' => 'The handler is corrupted and cannot be disabled.',
    'toggle.infoHandlerEnabled' => 'The handler was enabled.',
    'toggle.infoHandlerDisabled' => 'The handler was disabled.',
];
