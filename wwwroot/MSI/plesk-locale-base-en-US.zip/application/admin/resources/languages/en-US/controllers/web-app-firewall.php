<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'delete-log.actionSuccess' => 'The selected log files were removed.',
    'delete-log.invalidFileName' => 'The log file name is invalid.',
    'delete-log.actionError' => 'Unable to remove the log file %%file%%: %%reason%%',

    'index.title' => 'Web Application Firewall',
    'index.generalTab' => 'General',
    'index.settingsTab' => 'Settings',
    'index.settingsSaved' => 'The web application firewall settings were saved.',
    'index.updateFailed' => 'Failed to update the ModSecurity rule set: %%error%%',
    'index.updateFailedShort' => 'Failed to update the ModSecurity rule set. %%link%%',
    'index.updateFailedShortLink' => 'Details',

    'log-list.title' => 'Log Files Management',

    'view-log.fileNameIsUndefined' => 'The log file name is not defined.',
];
