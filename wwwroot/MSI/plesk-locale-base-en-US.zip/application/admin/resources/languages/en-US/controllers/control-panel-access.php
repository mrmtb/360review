<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-network.title' => 'Add a Network',
    'add-network.added' => 'The network %%address%% was added.',

    'delete-network.noNetworksSpecified' => 'Select one or several networks from the IP access restriction list.',
    'delete-network.networksDeleted' => 'The selected networks were deleted.',
    'delete-network.networksNotDeleted' => 'Some of the selected networks were not deleted. Details: %%error%%.',

    'edit-network.title' => 'Network Editing',
    'edit-network.updated' => 'The network %%address%% was updated.',

    'list.title' => 'IP Access Restriction Management',
    'list.currentIpAddressDenied' => 'The access restriction policy and the list of networks are currently configured the way you will not be able to log in with administrator\'s rights from your IP address \'%%remoteAddress%%\'.',
    'list.allowHint' => 'Access to Plesk with administrator\'s privileges is allowed, excluding the networks in the list.',
    'list.denyHint' => 'Access to Plesk with administrator\'s privileges is denied from all networks that are not listed here.',

    'settings.title' => 'IP Access Restriction Settings',
    'settings.settingsSaved' => 'The IP access restriction policy was saved.',
];
