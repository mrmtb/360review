<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Notifications',

    'email-settings.title' => 'Email',

    'panel-settings.title' => 'Plesk UI',
    'panel-settings.notificationSettingsSaved' => 'The notification settings were successfully saved.',

    'panel-notifications-toggle.successfullyEnabled' => 'The notification \'%%title%%\' was enabled.',
    'panel-notifications-toggle.successfullyDisabled' => 'The notification \'%%title%%\' was disabled.',

    'template-settings-list.hint' => 'Choose which notifications to see by turning them on or off.',
    'template-settings-list.name' => 'Title',
    'template-settings-list.context' => 'Context',
    'template-settings-list.sendToAdmin' => 'Send to Administrator',

    'template-settings-form.storagePeriod' => 'Store notifications for',
    'template-settings-form.days' => 'days',
];
