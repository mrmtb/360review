<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'list.title' => 'Sessions Management',

    'remove.sessionsDeleted' => 'The selected sessions were successfully removed.',

    'settings.title' => 'Session Settings',
    'settings.settingsUpdated' => 'The settings were successfully changed.',
];
