<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Register Additional Webmail',
    'create.infoNewWebmailRegistered' => 'New webmail service was registered.',

    'edit.unknownWebmail' => 'Unknown webmail',
    'edit.infoWebmailUpdated' => 'Settings of webmail service %%name%% were updated.',

    'index.title' => 'Webmail Services',
    'index.hint' => 'You can employ any webmail service in addition to webmail solutions that you install with Plesk Installer, aka Updater. Register a desired webmail installation in the Panel using the button below, and it will appear as available webmail option in hosting plans and subscriptions. If you need to hide a webmail service temporarily, disable it using the button below.',
    'index.webmailDeleted' => 'Registration of the selected webmail services was removed.',
    'index.webmailNotDeleted' => 'Registration of some webmail services was not removed.',
    'index.webmailEnabled' => 'Selected webmail services were enabled and now are available.',
    'index.webmailNotEnabled' => 'Some of the selected webmail options were not enabled.',
    'index.webmailDisabled' => 'Selected webmail options were disabled and became unavailable.',
    'index.webmailNotDisabled' => 'Some of the selected webmail options were not disabled.',
];
