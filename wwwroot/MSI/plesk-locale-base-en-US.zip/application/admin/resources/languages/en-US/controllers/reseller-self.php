<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'oversell-policy.title' => 'Changing Oversell Policy',
    'oversell-policy.pageHint' => 'This is where you can change your current oversell policy.',
    'oversell-policy.oversellPolicyChanged' => 'Oversell policy was updated successfully.',
    'oversell-policy.oversellPolicyNotChanged' => 'Oversell policy cannot be updated.',

    'subscription-overview.title' => 'Subscription Overview',
    'subscription-overview.pageHint' => 'This is the overview of your subscription, it includes information on the amount of used vs. provided resources, oversell policy, privileges and services provided with the subscription.',
    'subscription-overview.changeOversellPolicyLink' => '[change]',
    'subscription-overview.oversellEnabledHint' => 'Your subscription allows overselling resources, which means that you can sell more resources than the amount allocated with your subscription. In this case, you are governed by actual resource usage instead of initial resource allocation.',
    'subscription-overview.oversellDisableHint' => 'Your subscription prohibits overselling resources, which means that you can only sell as much resources as initially allocated with the subscription, no matter how much of them is actually used.',
    'subscription-overview.tabResources' => 'Resources',
    'subscription-overview.tabPermissions' => 'Permissions',
    'subscription-overview.resourcesSummaryHint' => 'This is a summary on usage of resources provided with the subscription.',
    'subscription-overview.showMoreResources' => 'Show more available resources',
    'subscription-overview.hideMoreResources' => 'Show less resources',
    'subscription-overview.permissionsSummaryHint' => 'This is a list of services and privileges provided with the subscription.',
    'subscription-overview.hideMorePermissions' => 'Show Less Permissions',
    'subscription-overview.showMorePermissions' => 'Show More Permissions',
];
