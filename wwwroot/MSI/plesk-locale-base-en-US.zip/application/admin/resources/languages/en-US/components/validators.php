<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'isEmpty' => 'This required field is empty. You need to provide a value for this field.',
    'stringLengthTooShort' => "'%value%' is less than %min% characters long.",
    'stringLengthTooLong' => "'%value%' is greater than %max% characters long.",
    'regexNotMatch' => "'%value%' does not match against pattern '%pattern%'.",
    'notAlnum' => "'%value%' has non-alphanumeric characters. Make sure you are using only alphanumeric characters.",
    'stringEmpty' => "'%value%' is empty.",
    'stringsNotEqual' => 'Strings are not equal.',
    'passwordsNotEqual' => 'The passwords you entered do not match each other.',
    'passwordLengthTooShort' => "the password is shorter than %min% characters.",
    'passwordLengthTooLong' => "the password is longer than %max% characters.",
    'passwordRegexNotMatch' => "the password does not match pattern '%pattern%'.",
    'invalidUrl' => 'Specified address is not valid. You need to specify a valid address like http://domain.com.',
    'specialCharactersInIpAddress' => 'The provided IP address is invalid.',
    'massEmailContactsNotSelected' => 'Select at least one contact from list.',
    'ipAddressIsTooLong' => 'An IP address must be no longer than %max% characters.',
    'ipAddressDescriptionTooLong' => 'The description must be no longer than %max% characters.',

    'fail2ban.invalidIpOrCidr' => 'The IP address must be a valid IP address or a CIDR mask.',
];
