<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

$messages = [
    'accessDenied' => 'Sitejet Builder is not included in your subscription. To enable Sitejet Builder, contact your hosting provider.',
];
