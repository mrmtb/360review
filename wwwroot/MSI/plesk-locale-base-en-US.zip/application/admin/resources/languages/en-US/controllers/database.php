<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'assign-to-subscription.databasesSuccessfullyAssignedToSubscription' => 'The databases were moved to the subscription \'%%subscriptionName%%\'.',
    'assign-to-subscription.databasesNotAssignedToSubscription' => 'Unable to move the databases to the subscription \'%%subscriptionName%%\'.',
    'assign-to-subscription.subscriptionNotFound' => 'The subscription \'%%name%%\' was not found.',
    'assign-to-subscription.isNotMainDomain' => '\'%%name%%\' is not the main domain on the subscription.',

    'settings.title' => 'Database Hosting Settings',
    'settings.settingsSaved' => 'Database hosting settings were saved.',

    'refresh.success' => 'Database servers\' information was refreshed.',
];
