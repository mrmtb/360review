<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'create.title' => 'Creating Reseller Plan',
    'create.hint' => 'This is where you create a reseller plan corresponding to your offering.',

    'edit.title' => '%%name%%',
    'edit.hint' => 'This is where you change the reseller plan corresponding to your offering. Note that changing the plan automatically updates all subscriptions associated with it, except for the customized subscriptions, which are locked for syncing.',

    'list.title' => 'Reseller Plans',
    'list.hint' => 'This is where you manage your reseller plans which allow creating reseller subscriptions. Unlike your regular hosting service customers, a reseller can be subscribed to only one plan and cannot have add-ons.',
    'list.tabTitle' => 'Reseller Plans',
    'list.infoNewPlanCreated' => 'Reseller plan %%name%% was created.',
    'list.infoPlanUpdated' => 'Reseller plan %%name%% was updated.',
    'list.infoPlanUpdatedSynced' => 'Service plan %%name%% was updated. All associated reseller subscriptions were successfully synced, except for the customized subscriptions, which are locked for syncing.',
    'list.infoPlanDeleted' => 'Selected reseller plans were removed.',
    'list.infoPlanNotDeleted' => 'Some of the selected reseller plans were not removed.',
    'list.infoPlanDuplicated' => 'The selected service plans were successfully duplicated.',
    'list.infoPlanNotDuplicated' => 'Some of selected service plans were not duplicated.',
];
