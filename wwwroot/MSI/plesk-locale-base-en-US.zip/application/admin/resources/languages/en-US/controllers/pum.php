<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'System Updates',

    'list.title' => 'All Packages',
    'list.hint' => 'System packages are updated via the system tools (dpkg/apt or yum). Packages are only updated from repositories they were installed from. To prevent a package from being updated, select it in the list and click Lock.',

    'lock.success' => 'The packages were successfully locked.',

    'settings.title' => 'Settings',
    'settings.settingsUpdated' => 'The settings were successfully changed.',

    'unlock.success' => 'The packages were successfully unlocked.',

    'updates-list.title' => 'Available Updates',
    'updates-list.hint' => 'System packages are updated via the system tools (dpkg/apt or yum). Packages are only updated from repositories they were installed from. To prevent a package from being updated, select it in the list and click Lock.',
];
