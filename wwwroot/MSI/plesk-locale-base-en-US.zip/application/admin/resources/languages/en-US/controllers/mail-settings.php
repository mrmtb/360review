<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Server-wide mail settings',
    'index.preferencesTab' => 'Settings',
    'index.spamFilteringTab' => 'Spam Filtering',
    'index.antivirusTab' => 'Antivirus',
    'index.blockedDomainsTab' => 'Black List',
    'index.whiteListTab' => 'White List',
    'index.queueTab' => 'Mail Queue',
    'index.statisticsTab' => 'Statistics',
    'index.smarthostTab' => 'Smarthost',

    'mail-lists.title' => 'Configuring Mailing Lists Manager',
    'mail-lists.configured' => 'The Mailman mailing list manager was configured. The button Set Up Mailing Lists Server will no longer be displayed on the Tools & Settings screen.', // PFU
    'mail-lists.noLocalhostInServerWhiteList' => 'To use mailing lists, you need to have localhost (127.0.0.0/8, ::1/128) in the mail server\'s white list. However, to use outgoing mail control, you should not have localhost in the white list. As a compromise, if you activated outgoing mail control, you can use mail forwarding on the mailbox instead of mailing lists.',
    'mail-lists.noLocalhostInServerWhiteListIpv4' => 'To use mailing lists, you need to have localhost in the mail server\'s white list. However, to use outgoing mail control, you should not have localhost in the white list. As a compromise, if you activated outgoing mail control, you can use mail forwarding on the mailbox instead of mailing lists. Note that there are no IPv4 localhost addresses (127.0.0.0/8) in the white list now, so outgoing mail control will work for IPv4 addresses.',
    'mail-lists.noLocalhostInServerWhiteListIpv6' => 'To use mailing lists, you need to have localhost in the mail server\'s white list. However, to use outgoing mail control, you should not have localhost in the white list. As a compromise, if you activated outgoing mail control, you can use mail forwarding on the mailbox instead of mailing lists. Note that there are no IPv6 localhost addresses (::1/128) in the white list now, so outgoing mail control will work for IPv6 addresses.',
    'mail-lists.mailingListSoftwareNotInstalled' => 'Mailing list software is not installed.',
    'mail-lists.mailingListSoftwareAlreadyConfigured' => 'Mailing list software is already configured.',

    'customize-mailbox-quota-warning.title' => 'Mailbox quota warning customization',
    'customize-mailbox-quota-warning.successMessage' => 'The mailbox quota warning message was changed.',

    'customize-mailbox-quota-warning-form.subject' => 'Subject',
    'customize-mailbox-quota-warning-form.message' => 'Message',
    'customize-mailbox-quota-warning-form.tooLongMessage' => "Too long message. Maximum length is %max% characters",
];
