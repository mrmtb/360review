<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'clear-cache.apsCacheCleared' => 'Temporary files were removed.',

    'configure.title' => '%%name%%',
    'configure.applicationNotFound' => "The app with ID '%%id%%' was not found.",
    'configure.applicationHasNoSettings' => 'The app has no settings.',
    'configure.settingsUpdated' => 'App settings were updated.',
    'configure.settingsUpdateFailed' => 'Failed to update app settings: %%error%%',
    'configure.instancesNotReconfigured' => 'Some of the app instances were not reconfigured.',

    'index.title' => 'Application Vault',

    'info.title' => '%%name%%',
    'info.hint' => 'The list below contains the information about websites on which the app is installed. The None value in the Website column means that the app is external. Such an app cannot be installed on a certain customer\'s website; it only provides a link to an external service.',

    'remote-app-info.title' => 'Application Details',

    'update-settings.title' => 'Update Settings',
    'update-settings.settingsUpdated' => 'The settings were updated.',
    'update-settings.settingsUpdateFailed' => 'Unable to update the settings: %%error%%',

    'upload.title' => 'Add App',
    'upload.packageInstallationError' => 'The app could not be added: %%message%%.',
    'upload.appUploaded' => 'The app was successfully uploaded.',
    'upload.appDownloadStarted' => 'Downloading the selected apps.',

    'uploaded.title' => 'My Apps',
    'uploaded.hint' => 'Here you can add or remove apps from Application Vault as well as manage apps availability to customers. There are two reasons to add apps: Extend the list of available apps or configure server-wide settings of apps. Some apps cannot be installed without such configuration. All the added apps are listed below.',
    'uploaded.infoAppDeleted' => 'The selected apps were deleted.',
    'uploaded.infoAppNotDeleted' => 'Some of the selected apps were not deleted.',
    'uploaded.applicationsNowAvailable' => 'The selected apps are now available for installation by customers or for configuration.',
    'uploaded.applicationsNowNotAvailable' => 'The selected apps are no longer available for installation by customers or for configuration.',
    'uploaded.cantChangePackageProperties' => 'An error occurred on attempt to change the app availability settings.',
    'uploaded.appDownloaded' => 'The selected apps were successfully downloaded.',
    'uploaded.appNotDownloaded' => 'Some of the selected apps were not downloaded.',
    'uploaded.downloadInProgress' => 'Please wait...',

    'usage.title' => 'Installed Apps',
    'usage.hint' => 'The list below contains all apps either added by you or installed by your customers. Here you can manage app settings, check for updates, or remove temporary files that were added during apps installations.',
    'usage.hintReseller' => 'The list below shows information about all app installations on your sites and on the sites of your customers. Click an app name to see a list of websites on which the app is installed, and to check for updates for the app.',
];
