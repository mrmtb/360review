<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'index.title' => 'Server Health',
    'index.pageHint' => 'Here you can see detailed reports on the server health. To see how server health parameters have been changing, select the parameters, and Plesk will show you the appropriate charts. Note that you can change the period for which the reports are presented - from the past 3 hours to a week. Here you can also change the health monitor configuration that defines when red and yellow alarms should appear for each parameter, and which of the hard disk resources should be monitored. To do this, download a configuration file using the button below, edit the file, and upload your version. If server hardware was changed, you should propagate these changes to Health Monitor to get proper statistics.',
    'index.waitMessage' => 'Loading...',
    'index.buttonUpload' => 'Upload Configuration File',
    'index.buttonDownload' => 'Download Configuration File',
    'index.buttonRestoreDefaults' => 'Revert to Default Configuration',
    'index.buttonReconfigure' => 'Detect Hardware Changes',
    'index.buttonUploadHint' => 'Upload your file of health monitor configuration. The new configuration will be applied right when the upload is complete.',
    'index.buttonDownloadHint' => 'Save the current health monitor configuration to your computer.',
    'index.buttonRestoreDefaultsHint' => 'Restore the default settings of server health monitor.',
    'index.buttonReconfigureHint' => 'Propagate changes in hardware configuration to Health Monitor.',
    'index.confirmRestoreDefaultsTitle' => 'Restoring the Default Settings of Server Health Monitor',
    'index.confirmRestoreDefaultsDescription' => 'Are you sure you want to restore the default settings?',
    'index.confirmReconfigureTitle' => 'Detecting Hardware Changes',
    'index.confirmReconfigureDescription' => 'You are about to update hardware configuration in Health Monitor. This is relevant if the server hardware was changed and you want to reflect these changes in the Health Monitor statistics. Continue?',
    'index.settingsWereRestoredToDefault' => 'The default settings were restored.',
    'index.healthMonitorWasReconfigured' => 'Health Monitor information about hardware configuration was updated.',

    'parameters.loading' => 'Loading...',
    'parameters.selectPeriod' => 'Select period',
    'parameters.periodFromNowTo3h' => '3 hours',
    'parameters.periodFromNowTo6h' => '6 hours',
    'parameters.periodFromNowTo12h' => '12 hours',
    'parameters.periodFromNowTo1d' => '1 day',
    'parameters.periodFromNowTo3d' => '3 days',
    'parameters.periodFromNowTo7d' => '1 week',

    'thresholds-hint.waitMessage' => 'Loading...',

    'upload-config-file.title' => 'Upload Configuration File',
    'upload-config-file.configurationUploadedSuccessfully' => 'Configuration was uploaded and applied.',
];
