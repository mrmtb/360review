<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-domain-alias.noDomains' => 'Unable to create an alias: There are no domains available.',

    'add-domain.noDomains' => 'Unable to create an addon domain: There are no domains available.',

    'add-subdomain.noDomains' => 'Unable to create a subdomain: There are no domains available.',

    'change-owner.wrongOwnerId' => 'Unable to find the new owner of the customer account.',

    'change.title' => 'Changing Plan and Add-ons Associated with Subscriptions',

    'create.title' => 'Adding New Customer',

    'domains.title' => 'Domains',

    'list.title' => 'Customers',
    'list.infoNewCustomerCreated' => 'Customer %%name%% was created.',
    'list.infoCustomerActivated' => 'Selected customers were activated.',
    'list.infoCustomerNotActivated' => 'Some of the selected customers were not activated.',
    'list.infoCustomerSuspended' => 'Selected customers were suspended.',
    'list.infoCustomerNotSuspended' => 'Some of the selected customers were not suspended.',
    'list.infoCustomerDeleted' => 'Selected customers were deleted.',
    'list.infoCustomerNotDeleted' => 'Some of the selected customers were not deleted.',
    'list.upgrageCustomersHint' => 'You have upgraded to Plesk 11, which employs a new customer and business model. To complete switching to the new model, convert client accounts to customer or reseller accounts. Unless you do this, your customers will not be able to create websites even if they were granted such a permission before.',
    'list.upgrageCustomersLink' => 'Convert client accounts.',
    'list.infoCustomerToResellerConverted' => 'The selected customers were successfully converted to resellers.',
    'list.errorCustomerToResellerNotConverted' => 'Some of the selected customers were not converted to resellers.',
    'list.infoOwnerChanged' => 'The selected customers were moved to %%name%%.',
    'list.infoOwnerNotChanged' => 'Some of the selected customers were not moved to %%name%%.',

    'login-info.title' => 'Editing Login Info of %%name%%',

    'overview.title' => '%%name%%',

    'personal-info.title' => 'Editing Contact Info of %%name%%',

    'subscriptions.title' => 'Subscriptions',
];
