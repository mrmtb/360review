<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-customer-owner.title' => 'Moving Customers to Another Owner',
    'change-customer-owner.description' => 'The customer accounts will be moved to another owner. You can change service plans for customer subscriptions. To preserve the resources that are available to a customer, leave the Custom plan selected.',
    'change-customer-owner.ownerHint' => 'The customers will be moved to the selected owner:',
    'change-customer-owner.ipAddressHint' => 'A dedicated IP address cannot be preserved.',
    'change-customer-owner.loading' => 'Please wait...',
    'change-customer-owner.ipAddressNotSelected' => 'Select at least one IP address for each subscription.',
    'change-customer-owner.ownerNotSelected' => 'Select an owner.',

    'customer.title' => 'Converting Customers to Resellers',
    'customer.description' => 'The customer accounts will be converted to reseller accounts. You can choose reseller plans for converted accounts. To preserve the resources that were available to a customer, select the Custom plan: The reseller will have the sum of resource allotments, permissions and applications of all subscriptions.',
    'customer.loading' => 'Converting...',

    'reseller.title' => 'Converting Resellers to Customers',
    'reseller.description' => 'The resellers will be converted to customers.',
    'reseller.descriptionExtended' => 'Choose new service plans for resellers who have their own subscriptions. To preserve the resources available to a reseller, select the Custom service plan. To move the reseller\'s subscriptions to one of the existing service plans, select an existing service plan.',
    'reseller.loading' => 'Converting...',
];
