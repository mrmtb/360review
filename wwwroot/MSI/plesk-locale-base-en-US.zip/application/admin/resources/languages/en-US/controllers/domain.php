<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoDomainActivated' => 'Selected domains and aliases were activated.',
    'activate.errorDomainNotActivated' => 'Some of the selected domains or aliases were not activated.',
    'activate.domainStillSuspended' => 'Unable to activate the domain: %%reason%%',
    'activate.domainStatusOffByAdmin' => 'The domain is suspended by the administrator.',
    'activate.domainStatusOffWithParent' => 'Either the domain owner or their subscription is suspended.',
    'activate.domainStatusOffExpired' => 'The corresponding subscription is expired.',
    'activate.domainStatusOffBackupRestore' => 'The domain is temporarily suspended for backing up or restoring.',
    'activate.domainStatusOff' => 'The domain is suspended.',
    'activate.aliasStillSuspended' => 'Unable to activate the alias: The target domain is suspended.',

    'add-domain-alias.noDomains' => 'Unable to create an alias: There are no domains available.',

    'add-domain.noDomains' => 'Unable to create an addon domain: There are no domains available.',

    'add-subdomain.noDomains' => 'Unable to create a subdomain: There are no domains available.',

    'disable.infoDomainDisabled' => 'The selected domains were disabled.',
    'disable.errorDomainNotDisabled' => 'Some of the selected domains were not disabled.',

    'list.title' => 'Domains',
    'list.customerLinkTitle' => 'create a customer account',
    'list.subscriptionLinkTitle' => 'create your own subscription',

    'suspend.infoDomainSuspended' => 'Selected domains were suspended.',
    'suspend.errorDomainNotSuspended' => 'Some of the selected domains were not suspended.',
];
