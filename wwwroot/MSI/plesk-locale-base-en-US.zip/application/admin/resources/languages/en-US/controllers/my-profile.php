<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'change-password.title' => "Changing Administrator's Password",
    'change-password.passwordChanged' => 'The administrator\'s password was changed.',

    'index.personalInfoTitle' => "Editing Administrator Profile",
    'index.successMessage' => "Your profile was updated.",
    'index.aliasInfoTitle' => 'Additional Administrator Account Information',
    'index.aliasInfoUpdated' => 'Personal information of additional administrator account was updated.',
];
