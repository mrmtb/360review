<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'operation.startActionSuccess' => 'Service was started',
    'operation.stopActionSuccess' => 'Service was stopped',
    'operation.restartActionSuccess' => 'Service was restarted',
    'operation.changeStartupActionSuccess' => 'Startup type for service successfully changed',

    'list.title' => 'Services',

    'operation.startServiceMessage' => 'Please allow for some time for the service to start.',
    'operation.stopServiceMessage' => 'Please allow for some time for the service to stop.',
    'operation.restartServiceMessage' => 'Please allow for some time for the service to restart.',
    'operation.unableFetchFormData' => 'Unable to fetch form data: %%error%%',
    'operation.startActionError' => 'Unable to start service: %%error%%',
    'operation.stopActionError' => 'Unable to stop service: %%error%%',
    'operation.restartActionError' => 'Unable to restart service: %%error%%',
    'operation.changeStartupActionError' => 'Unable to change startup type for service: %%error%%',
];
