<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'settings.title' => 'Try and Buy Mode Settings',
    'settings.sitebuilderSettingsUpdated' => 'The settings were updated.',
];
