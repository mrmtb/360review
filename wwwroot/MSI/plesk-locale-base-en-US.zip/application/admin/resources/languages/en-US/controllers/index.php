<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'eula.title' => 'WebPros End-User License Agreement',
    'eula.popupTitle' => 'EULA',
    'eula.updatePopupTitle' => 'EULA Update',
    'eula.popupDescription' => 'You need to read and accept the EULA to continue using the product.',
    'eula.updatePopupDescription' => 'WebPros EULA has been updated. You need to read and accept the updated EULA to continue using the product.',
    'eula.buttonAccept' => 'Accept',
    'eula.buttonDecline' => 'Decline',
];
