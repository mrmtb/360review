<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'activate.infoAdminAliasActivated' => 'The selected administrator accounts were successfully activated.',
    'activate.infoAdminAliasNotActivated' => 'Some of the selected administrator accounts were not activated.',

    'create.title' => 'Adding Administrator Account',
    'create.infoNewAdminAliasCreated' => 'The additional administrator account %%contact%% was successfully created.',

    'deactivate.infoAdminAliasDeactivated' => 'The selected administrator accounts were successfully suspended.',
    'deactivate.infoAdminAliasNotDeactivated' => 'Some of the selected administrator accounts were not suspended.',

    'delete.infoAdminAliasDeleted' => 'The selected administrator accounts were successfully removed.',
    'delete.infoAdminAliasNotDeleted' => 'Some of the selected administrator accounts were not removed.',

    'edit.title' => "%%contact%%",
    'edit.infoNewAdminAliasUpdated' => 'The administrator account was successfully updated.',

    'list.title' => 'Additional Administrator Accounts',
    'list.hint' => 'Here you can create additional administrator accounts for your technical support engineers, enabling them to perform a variety of administrative tasks.',
];
