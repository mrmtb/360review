<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.
$messages = [
    'add-filter.title' => 'Add Jail Filter',
    'add-filter.filterAdded' => 'The jail filter was added.',
    'add-filter.errorFilterNotAdded' => 'Unable to add the jail filter: %%error%%.',

    'add-jail.title' => 'Add Jail',
    'add-jail.jailAdded' => 'The jail was added.',

    'add-trusted-ip.title' => 'Add a Trusted IP Address',
    'add-trusted-ip.trustedListTitle' => 'Trusted IP Addresses',
    'add-trusted-ip.ipAdded' => 'The IP address was added to the list of trusted addresses.',
    'add-trusted-ip.errorIpNotAdded' => 'Unable to add the IP address: %%error%%.',

    'edit-trusted-ip.title' => 'Edit description for %%ip%%',
    'edit-trusted-ip.ipEdited' => 'The IP address description was updated.',
    'edit-trusted-ip.ipAddressNotFound' => 'The IP address was not found on the trusted list.',
    'edit-trusted-ip.errorIpNotEdited' => 'Unable to edit the IP address: %%error%%.',

    'delete-banned-ips.infoBannedIpsDeleted' => 'The selected IP addresses were removed from the list of banned addresses.',
    'delete-banned-ips.infoBannedIpsNotDeleted' => 'Unable to remove some IP addresses from the list of banned addresses: %%error%%.',

    'delete-filters.infoFiltersDeleted' => 'The selected jail filters were removed.',
    'delete-filters.errorFiltersNotDeleted' => 'Unable to remove the selected filters: %%error%%.',
    'delete-filters.errorFiltersBuiltIn' => 'The built-in filters cannot be removed.',

    'delete-jail.infoJailDeleted' => 'The jail was removed.',
    'delete-jail.errorJailNotDeleted' => 'Unable to remove the jail: %%error%%.',
    'delete-jail.errorJailsBuiltIn' => 'The built-in jails cannot be removed.',

    'delete-jails.infoJailsDeleted' => 'The selected jails were removed.',
    'delete-jails.errorJailsNotDeleted' => 'Unable to remove the selected jails: %%error%%.',
    'delete-jails.errorJailsBuiltIn' => 'The built-in jails cannot be removed.',

    'delete-trusted-ips.infoTrustedIpsDeleted' => 'The selected IP addresses were removed from the list of trusted addresses.',
    'delete-trusted-ips.infoTrustedIpsNotDeleted' => 'Unable to remove some IP addresses from the list of trusted addresses: %%error%%.',
    'delete-trusted-ips.warningTrustedIpsPresentOnInterfaces' => 'Some of deleted trusted IPs are present on network interface(s): %%ips%%. They can be accidentally banned thus raising sites or services access issues.',

    'disable-jails.infoJailsDisabled' => 'The selected jails were switched off.',
    'disable-jails.errorJailsNotDisabled' => 'Unable to switch off the selected jails: %%error%%.',

    'edit-filter.title' => 'Edit Jail Filter',
    'edit-filter.filterSaved' => 'The jail filter was saved.',
    'edit-filter.errorFilterNotSaved' => 'Unable to save the jail filter: %%error%%.',
    'edit-filter.errorFilterNotEditable' => 'The filter cannot be changed.',

    'edit-jail.title' => '%%name%%',
    'edit-jail.jailSaved' => 'The jail settings were saved.',
    'edit-jail.errorJailNotEditable' => 'The jail cannot be changed.',

    'enable-jails.infoJailsEnabled' => 'The selected jails were switched on.',
    'enable-jails.errorJailsNotEnabled' => 'Unable to switch on the selected jails: %%error%%.',

    'filters-list.title' => 'Jail Filters',

    'index.title' => 'IP Address Banning',
    'index.banListTab' => 'Banned IP Addresses',
    'index.trustedListTab' => 'Trusted IP Addresses',
    'index.jailListTab' => 'Jails',
    'index.settingsTab' => 'Settings',
    'index.logListTab' => 'Logs',
    'index.jailNotFound' => 'The jail %%name%% was not found.',
    'index.filterNotFound' => 'The filter %%name%% was not found.',
    'index.logFileNotFound' => 'The log file was not found.',
    'index.tooManyDomains' => 'Fail2Ban might not operate properly if there are many domains and Fail2Ban has to monitor too many log files.',
    'index.errorServiceFailed' => 'The IP Address Banning (Fail2Ban) service failed and might not operate properly. %%link%%',
    'index.restartLink' => 'Try to restart',

    'jail-list.failed' => 'Unable to get the list of jails: %%error%%.',

    'log-view.fileIsEmpty' => 'The file is empty.',

    'move-to-trusted.infoTrustedIpsAdded' => 'The selected IP addresses were added to the list of trusted addresses.',
    'move-to-trusted.infoTrustedIpsNotAdded' => 'Unable to add some IP addresses to the list of trusted addresses: %%error%%.',

    'overview-jail.title' => '%%name%%',
    'overview-jail.pageHint' => 'Here you can see detailed information about the jail.',
    'overview-jail.buttonEditJail' => 'Change Settings',
    'overview-jail.hintEditJail' => 'Change the settings of this jail.',
    'overview-jail.buttonDisableJail' => 'Switch Off',
    'overview-jail.hintDisableJail' => 'Switch off this jail.',
    'overview-jail.buttonActivateJail' => 'Switch On',
    'overview-jail.hintActivateJail' => 'Switch on this jail.',
    'overview-jail.buttonRemoveJail' => 'Remove',
    'overview-jail.hintRemoveJail' => 'Remove this jail.',
    'overview-jail.fieldSatatus' => 'Status',
    'overview-jail.fieldParameters' => 'Settings',
    'overview-jail.enabled' => 'Active',
    'overview-jail.disabled' => 'Inactive',
    'overview-jail.banListHint' => 'IP addresses blocked by this jail:',

    'restart.success' => 'Restarting the service might take a few minutes.',
    'restart.failed' => 'Could not restart the service.',

    'settings.settingsSaved' => 'The settings were saved.',
    'settings.errorSettingsNotSaved' => 'Unable to save the settings: %%error%%.',
    'settings.errorServiceFailed' => 'The IP Address Banning (Fail2Ban) service failed: %%error%%',

    'toggle-jail.infoJailEnabled' => 'The jail was switched on.',
    'toggle-jail.infoJailDisabled' => 'The jail was switched off.',
    'toggle-jail.errorJailNotEnabled' => 'Unable to switch on the jail: %%error%%.',
    'toggle-jail.errorJailNotDisabled' => 'Unable to switch off the jail: %%error%%.',

    'add-banned-ip.title' => 'Ban IP Address',
    'add-banned-ip.bannedListTitle' => 'Banned IP Addresses',
    'add-banned-ip.ipAdded' => 'The IP address was added to the list of banned ones.',
    'add-banned-ip.errorIpNotAdded' => 'Unable to ban the IP address: %%error%%.',
];
