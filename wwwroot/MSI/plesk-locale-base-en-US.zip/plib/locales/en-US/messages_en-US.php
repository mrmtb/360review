<?php
// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

$code = 'en-US';

/**
 * For more info about time and date format see:
 * http://www.php.net/manual/en/function.date.php
 */
$GLOBALS['def_date_format'] = 'M j, Y';
$GLOBALS['def_time_format'] = 'h:i:s A';
$GLOBALS['def_short_time_format'] = 'h:i A';
$GLOBALS['def_datetime_format'] = 'M j, Y h:i A';
$GLOBALS['def_capitalize_options'] = [
    'enabled' => true,
    'exclude_words' => ['a', 'an', 'the', 'and', 'but', 'for', 'not', 'of', 'on', 'or', 'so', 'yet', 'at', 'for', 'with', 'into', 'to', 'from', 'in'],
    'first_word' => true,
    'last_word' => true,
];

// The + operator appends elements of remaining keys from
// the right handed array to the left handed, whereas
// duplicated keys are NOT overwritten.
// That's why this code MUST be executed after main array assignment
include(__DIR__ . '/common_messages_en-US.php');
include(__DIR__ . '/common_cli_messages_en-US.php');
include(__DIR__ . '/common_conhelp_en-US.php');
