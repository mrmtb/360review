<?php
$_prefs['time_format'] = array(
    'value' => '%X',
    'type' => 'enum',
    'enum' => array(
        '%X' => date('H:i:s') . ' (' . _('Default') . ')',
        '%H:%M:%S' => date('H:i:s') . ' (' . _('24-hour format') . ')',
        '%I:%M:%S %p' => date('h:m:s A'),
        '%H:%M' => date('H:i') . ' (' . _('24-hour format') . ')',
        '%I:%M %p' => date('h:m A'),
    ),
    'desc' => _('Choose how to display times:')
);
