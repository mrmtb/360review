<?php

$ServerName = preg_replace('/^webmail\./', '', preg_replace('/^www\./', '', $_SERVER['HTTP_HOST']));
if (false != ($pos = strpos($ServerName, ':'))) {
    $ServerName = substr($ServerName, 0, $pos);
}
$DomainName = ($ServerName != '') ? $ServerName : 'localhost';

$servers['imap'] = array(
    'disabled' => false,
    'name' => 'IMAP Server',
    'hostspec' => '127.0.0.1',
    'hordeauth' => false,
    'protocol' => 'imap',
    'port' => 143,
    'secure' => false,
    'maildomain' => '$DomainName',
    'smtp' => array(
        'auth' => true,
        'localhost' => 'localhost',
        'host' => '127.0.0.1',
        'password' => null,
        'port' => 25,
        'username' => null
    ),
    'cache' => false,
);

$servers['pop'] = array(
    'disabled' => false,
    'name' => 'POP3 Server',
    'hostspec' => '127.0.0.1',
    'hordeauth' => false,
    'protocol' => 'pop',
    'port' => 110,
    'secure' => false,
    'maildomain' => '$DomainName',
    'smtp' => array(
        'auth' => true,
        'localhost' => 'localhost',
        'host' => '127.0.0.1',
        'password' => null,
        'port' => 25,
        'username' => null
    ),
    'cache' => false,
);
