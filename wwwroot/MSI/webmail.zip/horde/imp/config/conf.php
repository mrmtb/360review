<?php
/* CONFIG START. DO NOT CHANGE ANYTHING IN OR AFTER THIS LINE. */
// $Id: 83b45ef5b7d38e12be4e65351c4c6e504a931ecf $
$conf['user']['autocreate_special'] = false;
$conf['user']['allow_folders'] = true;
$conf['user']['allow_view_source'] = true;
$conf['server']['server_list'] = 'shown';
$conf['server']['fixed_folders'] = array();
$conf['msgsettings']['filtering']['words'] = './config/filter.txt';
$conf['msgsettings']['filtering']['replacement'] = '****';
$conf['spam']['reporting'] = false;
$conf['notspam']['reporting'] = false;
$conf['compose']['use_vfs'] = true;
$conf['compose']['link_all_attachments'] = false;
$conf['compose']['link_attachments_notify'] = true;
$conf['compose']['link_attach_size_limit'] = 0;
$conf['compose']['link_attachments'] = false;
$conf['compose']['attach_size_limit'] = 0;
$conf['compose']['attach_count_limit'] = 0;
$conf['compose']['convert_to_related'] = true;
$conf['compose']['reply_limit'] = 200000;
$conf['compose']['ac_browser'] = 50;
$conf['compose']['ac_threshold'] = 3;
$conf['maillog']['use_maillog'] = true;
$conf['sentmail']['driver'] = 'Null';
$conf['tasklist']['use_tasklist'] = true;
$conf['notepad']['use_notepad'] = true;
/* CONFIG END. DO NOT CHANGE ANYTHING IN OR BEFORE THIS LINE. */