<?php
$_prefs['subscribe']['value'] = 0;
