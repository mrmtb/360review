"use strict";(self.webpackChunkPlesk=self.webpackChunkPlesk||[]).push([["views/admin/ip-address/list"],{2106:(e,t,s)=>{s.r(t),s.d(t,{default:()=>C});var n=s(270),i=s(272),r=s.n(i),a=s(271),d=s(902),l=s(89),o=s(2107),c=s(592),p=s(548),u=s(511),m=s(637),x=s(1035);const g=l.Locale.getTranslate("admin.components.forms.ip-address"),j=l.Locale.getSection("admin.components.forms.ip-address"),f=l.Locale.getTranslate("admin.components.forms.security-policy"),h=u.gql`
    fragment generalFields on Query {
        certificates(fromServerRepository: true) {
            id
            name
            repositoryName
        }
        server {
            settings {
                ftpOverSSL
            }
            ipAddresses {
                interfaces
            }
        }
        os {
            isIPv6Supported
            isWindows
        }
        capability {
            panel {
                accessDriver {
                    isHttpsProxyEnabled
                    isDefaultAccessDomain
                }
            }
            ftp {
                isExplicitSSL
            }
        }
    }
`,b=u.gql`
    ${h}
    query UpdateIpAddressValues($id: ID!) {
        ...generalFields
        ipAddress: node(id: $id) {
            ... on IpAddress {
                id
                type
                onRepairMode
                ipAddress
                publicIpAddress
                ftpOverSSL
                isIPv6
                interface
                certificate {
                    id
                    name
                    repositoryName
                }
                defaultDomain {
                    id
                }
                domains {
                    id
                    name(idn: false)
                    owner {
                        name
                    }
                }
            }
        }
    }
`,v=u.gql`
    ${h}
    query CreateIpAddressValues{
        ...generalFields
    }
`,S=u.gql`
    mutation UpdateIpAddress($input: UpdateIpAddressInput!){
        updateIpAddress(input: $input) {
            ipAddress {
                id
                ipAddress
            }
            task {
                id
            }
        }
    }
`,y=({children:e})=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("hr",{}),(0,n.jsx)(a.Text,{bold:!0,style:{fontSize:"1.2rem"},children:(0,n.jsx)(f,{content:"secureFtpSection"})}),e]}),A="/cp/ip-address",I=({onSuccess:e=()=>{}})=>{const t=(0,c.useNavigate)(),s=(0,c.useMatch)(`${A}/add`),i=(0,c.useMatch)(`${A}/:id/edit`),r=!(!s&&!i),[u,h]=(0,n.useState)(null),[I,C]=(0,n.useState)(null),P=(e,t)=>{const{ipAddress:s={},server:n={}}=e;h((()=>{const i={ftpOverSSL:"CUSTOM"===n.settings.ftpOverSSL?s.ftpOverSSL:n.settings.ftpOverSSL,ipAddress:s.ipAddress,publicIpAddress:s.publicIpAddress??"",type:s.type??"EXCLUSIVE",certificateId:s.certificate?.id??e.certificates?.[0]?.id,interface:s.interface};return t?i.interface=s.interface??e.server.ipAddresses.interfaces?.[0]:i.defaultDomainId=s.defaultDomain?.id??0,i})),C(e)},k=({message:e})=>{(0,p.addToast)({intent:"danger",message:e}),F()},[w,{loading:T}]=(0,m.useMutation)(S),[D]=(0,x.useLazyQuery)(v,{onCompleted:e=>P(e,!0),onError:k}),[L]=(0,x.useLazyQuery)(b,{onCompleted:e=>P(e,!1),onError:k});(0,n.useEffect)((()=>{h(null),C(null),s?D():i&&L({variables:{id:i.params.id}})}),[D,L,s,i,r]);const F=()=>{t(A)},O=(0,n.useMemo)((()=>{if(!I||!I?.os.isWindows)return null;const e=I?.capability.ftp.isExplicitSSL;if(!e||i&&!I.os.isIPv6Supported&&I.ipAddress.isIPv6)return(0,n.jsx)(y,{children:(0,n.jsx)(a.FormField,{label:(0,n.jsx)(f,{content:"ftpOverSsl"}),children:(0,n.jsx)(g,{content:e?"ftpOverSslIpv6NotSupportedByServer":"ftpOverSslNotSupportedByServer"})})});const t="CUSTOM"===I?.server.settings.ftpOverSSL,s=[t?null:{value:"REQUIRED",label:(0,n.jsx)(f,{content:"ftpOverSslOptionRequired"})},{value:"ENABLED",label:(0,n.jsx)(f,{content:"ftpOverSslOptionEnabled"})},{value:"DISABLED",label:(0,n.jsx)(f,{content:"ftpOverSslOptionDisabled"})}].filter((e=>e));return(0,n.jsx)(y,{children:(0,n.jsx)(a.FormFieldRadioButtons,{label:(0,n.jsx)(f,{content:"ftpOverSsl"}),name:"ftpOverSSL",disabled:!t,options:s,description:(0,n.jsx)(f,{content:t?"ftpOverSslCustomHint":"ftpOverSslCustomDisabledHint"})})})}),[I,i]),E=i&&I?.os.isWindows&&I?.capability.panel.accessDriver.isHttpsProxyEnabled&&I?.capability.panel.accessDriver.isDefaultAccessDomain,R=(0,n.useMemo)((()=>{if(I){const e=[...I.certificates||[]],t=I.ipAddress?.certificate;return i&&t&&!e.find((e=>e.id===t.id))&&e.push(t),e}return[]}),[I,i]);return(0,n.jsx)(a.Drawer,{"data-type":"ip-address-drawer",isOpen:r,onClose:F,title:i?(0,n.jsx)(g,{content:"editTitle",params:{address:(0,n.jsx)(a.Text,{bold:!0,children:I?.ipAddress.ipAddress||""}),interface:(0,n.jsx)(a.Text,{bold:!0,children:I?.ipAddress.interface||""})}}):(0,n.jsx)(g,{content:"addTitle"}),form:(0,n.jsx)(d.default,{"data-type":"ip-address-drawer-form",values:u,mutation:w,onSubmit:e=>(i&&(e.id=i.params.id),e),onSuccess:({updateIpAddress:{ipAddress:{id:s,ipAddress:n},task:i}={}})=>{i||(0,p.addToast)({intent:"success",message:l.Locale.getSection("admin.controllers.ip-address.add").lmsg("ipAddressAdded",{address:n})}),t(A),e({task:i,query:{query:b,variables:{id:s}}})},submitButton:{name:"send","data-action":"submit"},state:T?"loading":void 0,applyButton:!1,children:I?(0,n.jsxs)(n.Fragment,{children:[I.ipAddress?.onRepairMode?(0,n.jsx)(a.StatusMessage,{intent:"warning",children:(0,n.jsx)(g,{content:"ipAddressInterfaceNotAvailableWarning",params:{interface:I.ipAddress.interface}})}):null,s||I.ipAddress?.onRepairMode?(0,n.jsx)(a.FormFieldSelect,{name:"interface",label:(0,n.jsx)(g,{content:"interface"}),children:I.server.ipAddresses.interfaces.map((e=>(0,n.jsx)("option",{value:e,children:e},e)))}):null,s?(0,n.jsx)(a.FormFieldText,{name:"ipAddress",size:"lg",description:(0,n.jsx)(g,{content:I.isIPv6Supported?"addressHintIPv6":"addressHintIPv4"}),label:(0,n.jsx)(g,{content:"addressAndSubnetPrefixLength"}),inputProps:{maxLength:255}}):null,(0,n.jsx)(a.FormFieldText,{name:"publicIpAddress",label:(0,n.jsx)(g,{content:"publicIp"}),inputProps:{maxLength:255}}),(0,n.jsx)(a.FormFieldRadioButtons,{name:"type",label:(0,n.jsx)(g,{content:"distributionType"}),options:[{value:"SHARED",label:(0,n.jsx)(g,{content:"distributionTypeShared"})},{value:"EXCLUSIVE",label:(0,n.jsx)(g,{content:"distributionTypeExclusive"})}]}),(0,n.jsx)(a.FormFieldSelect,{name:"certificateId",label:(0,n.jsx)(g,{content:"certificate"}),children:R.map((({id:e,name:t})=>(0,n.jsx)("option",{value:e,children:t},e)))}),i?(0,n.jsxs)(a.FormFieldSelect,{name:"defaultDomainId","data-testid":"defaultSite",label:(0,n.jsx)(g,{content:"defaultSite"}),children:[(0,n.jsx)("option",{value:0,children:j.lmsg("none")}),I.ipAddress.domains?.map((({id:e,name:t,owner:{name:s}})=>(0,n.jsx)("option",{value:e,children:`${t} (${s})`},e)))]}):null,O,E?(0,n.jsx)("div",{style:{marginTop:"2rem"},children:(0,n.jsx)(a.Status,{intent:"warning",children:(0,n.jsx)(g,{content:"accessDomainOnAnyDomainWinWarning",params:{ip:I.ipAddress.ipAddress}})})}):null]}):(0,n.jsx)(o.default,{})})})};I.propTypes={onSuccess:r().func};const C=I},2107:(e,t,s)=>{s.r(t),s.d(t,{default:()=>r});var n=s(271),i=s(270);const r=()=>Array.from({length:6}).map(((e,t)=>(0,i.jsx)(n.FormField,{label:(0,i.jsx)(n.SkeletonText,{lines:1}),children:(0,i.jsx)(n.Skeleton,{maxWidth:300})},t)))},2104:(e,t,s)=>{s.r(t),s.d(t,{default:()=>S});var n=s(270),i=s(271),r=s(655),a=s(89),d=s(548),l=(s(2105),s(511)),o=s(637),c=s(598),p=s(880),u=s.n(p);const m=l.gql`
    mutation RereadIpAddresses {
        rereadIpAddresses {
            result
        }
    }
`,x=l.gql`
    mutation ReloadPublicIpAddresses {
        reloadPublicIpAddresses {
            task {
                id
            }
        }
    }
`,g=l.gql`
    mutation DeleteIpAddress($ids: [ID!]!) {
        deleteIpAddress(input: { ids: $ids} ) {
            ids
        }
    }
`,j=l.gql`
    mutation RepairIpAddress($id: ID!) {
        repairIpAddress(input: { id: $id }) {
            ipAddress {
                ipAddress
            }
        }
    }
`,f=a.Locale.getTranslate("admin.components.lists.ipaddresses"),h=a.Locale.getSection("admin.components.lists.ipaddresses"),b=a.Locale.getTranslate("components.buttons"),v={page:1,itemsPerPage:25},S=()=>{const[e,t]=(0,n.useState)({search:null,type:null}),[s,l]=(0,n.useState)({sortColumn:null,sortDirection:null}),[p,S]=(0,n.useState)(v),y=e=>e.sortColumn?{orderBy:{[e.sortColumn]:e.sortDirection}}:{},A={...p,...e,...y(s)},[I,{loading:C}]=(0,o.useMutation)(m,{refetchQueries:[{query:u(),variables:A}]}),[P,{loading:k}]=(0,o.useMutation)(x,{onCompleted({reloadPublicIpAddresses:{task:e}}){const t=({id:s,status:n})=>{e?.id===s&&"done"===n&&(_(),a.Observer.remove(t,"plesk:taskComplete"))};a.Observer.append(t,"plesk:taskComplete")}}),[w]=(0,o.useMutation)(g,{refetchQueries:[{query:u(),variables:A}],onCompleted(){(0,d.addToast)({intent:"success",message:h.lmsg("removeSuccess")})},onError({message:e}){(0,d.addToast)({intent:"danger",message:e}),_()}}),[T]=(0,o.useMutation)(j,{refetchQueries:[{query:u(),variables:A}],onCompleted({repairIpAddress:{ipAddress:{ipAddress:e}={}}={}}){(0,d.addToast)({intent:"success",message:h.lmsg("repairSuccess",{address:e})})},onError({message:e}){(0,d.addToast)({intent:"danger",message:e})}}),{data:D,previousData:L,loading:F,refetch:O}=(0,c.useQuery)(u(),{variables:v,notifyOnNetworkStatusChange:!0,onCompleted(e){const t=Math.ceil(e.server.ipAddresses.pageInfo.total/p.itemsPerPage);p.page>t&&S((e=>({...e,page:t}))),l(e.server.ipAddresses.sortInfo)}}),{mode:{isDemo:E,isPowerUserPanel:R,canManageResellers:M}={},serverInfo:{isVirtuozzo:B}={},server:{firewall:q,ipAddresses:{nodes:H,pageInfo:{total:$},canReloadPublic:N,hasPublicIp:U}={}}={}}=D||L,[Q,V]=(0,n.useState)([]),[W,z]=(0,n.useState)([]),[G,X]=(0,n.useState)(!1),K=!(E||B),J=!R&&M,Y=e.search||e.type,Z="all"===p.itemsPerPage?1:Math.ceil($/p.itemsPerPage),_=async t=>{await O({...p,...e,...y(s),...t})},ee=(0,n.jsx)(i.Panel,{children:(0,n.jsxs)(i.ToolbarGroup,{title:"",className:"ip-address-page-filter",children:[(0,n.jsxs)("div",{children:[(0,n.jsx)(i.Hint,{children:(0,n.jsx)(f,{content:"address"})}),(0,n.jsx)(i.Input,{value:e.search,onChange:({target:e})=>t((t=>({...t,search:e.value})))})]}),(0,n.jsxs)("div",{children:[(0,n.jsx)(i.Hint,{children:(0,n.jsx)(f,{content:"type"})}),(0,n.jsxs)(i.Select,{size:"sm",value:e.type??"",onChange:e=>t((t=>({...t,type:e||void 0}))),children:[(0,n.jsx)("option",{value:"",children:h.lmsg("typeAny")}),(0,n.jsx)("option",{value:"SHARED",children:h.lmsg("typeShared")}),(0,n.jsx)("option",{value:"EXCLUSIVE",children:h.lmsg("typeExclusive")})]})]}),(0,n.jsx)(i.Button,{onClick:()=>{S((e=>({...e,page:1}))),_({...e,page:1})},children:(0,n.jsx)(f,{content:"buttonSearch"})}),(0,n.jsx)(i.Button,{onClick:()=>{S((e=>({...e,page:1})));const e={search:null,type:null};t(e),_({...e,page:1})},children:(0,n.jsx)(f,{content:"buttonResetSearch"})})]})}),te=K?(0,n.jsx)(i.Button,{component:r.default,to:"/cp/ip-address/add","data-type":"ip-add-address",icon:"plus",intent:"primary",tooltip:(0,n.jsx)(f,{content:"buttonAddNewIpAddressDescription"}),children:(0,n.jsx)(f,{content:"buttonAddNewIpAddress"})}):null,se=(0,n.jsxs)(n.Fragment,{children:[(0,n.jsxs)(i.Toolbar,{children:[(0,n.jsxs)(i.ToolbarGroup,{title:"",children:[te,(0,n.jsx)(i.Button,{"data-type":"ip-reread-configuration",icon:"refresh",onClick:I,state:C?"loading":void 0,tooltip:(0,n.jsx)(f,{content:"buttonRereadConfigurationDescription"}),children:(0,n.jsx)(f,{content:"buttonRereadConfiguration"})}),N?(0,n.jsx)(i.Button,{"data-type":"ip-button-reload-public",onClick:P,state:k?"loading":void 0,tooltip:(0,n.jsx)(f,{content:"buttonReloadPublicDescription"}),children:(0,n.jsx)(f,{content:"buttonReloadPublic"})}):null,q?.isEnabled?(0,n.jsx)(i.Button,{to:"/cp/firewall/",component:r.default,"data-type":"ip-button-firewall",tooltip:(0,n.jsx)(f,{content:"buttonFirewallDescription"}),children:(0,n.jsx)(f,{content:"buttonFirewall"})}):null]}),(0,n.jsx)(i.ToolbarGroup,{title:"",children:(0,n.jsx)(i.ListOperation,{critical:!0,confirmationText:()=>h.formatMessage("removeConfirmation",{name:(0,n.jsx)("b",{children:H.find((({id:e})=>Q[0]===e)).ipAddress}),count:Q.length}),actionButtonText:(0,n.jsx)(b,{content:"yesRemove"}),cancelButtonText:(0,n.jsx)(b,{content:"cancel"}),children:(0,n.jsx)(i.Button,{"data-type":"ip-remove",disabled:!Q.length,onClick:async()=>{z(Q),await w({variables:{ids:Q}}),z([])},icon:"recycle",children:(0,n.jsx)(f,{content:"buttonRemove"})})})}),(0,n.jsx)(i.ToolbarExpander,{}),(0,n.jsx)(i.ToolbarGroup,{title:"",groupable:!1,children:(0,n.jsx)(i.Button,{icon:"chevron-"+(G?"up":"down"),state:G?"active":void 0,onClick:()=>X((e=>!e))})})]}),G&&ee]}),ne=(0,n.useMemo)((()=>[{key:"ipAddress",title:(0,n.jsx)(f,{content:"address"}),type:"title",sortable:!0,render:({isMain:e,ipAddress:t,id:s,mask:a,isBroken:d,isBlacklisted:l,isMissing:o})=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(i.Text,{bold:e,children:(0,n.jsx)(r.default,{"data-type":"ip-address-edit",to:`/cp/ip-address/${s}/edit`,children:t})}),(0,n.jsxs)(i.Hint,{children:[" ","/"," ",a]}),d?(0,n.jsx)("div",{style:{marginTop:"5px"},children:(0,n.jsxs)(i.Status,{intent:"warning",children:[(0,n.jsx)(f,{content:l?"ipAddressBlacklisted":"ipAddressBroken"})," ",o&&!l?(0,n.jsx)("a",{onClick:()=>T({variables:{id:s}}),children:(0,n.jsx)(f,{content:"repair"})}):null]})}):null]})},U?{key:"publicIpAddress",title:(0,n.jsx)(f,{content:"publicAddress"}),sortable:!0,render:({isMain:e,publicIpAddress:t})=>(0,n.jsx)(i.Text,{bold:e,children:t})}:null,{width:"160px",key:"interface",title:(0,n.jsx)(f,{content:"interface"}),sortable:!0,render:({interface:e})=>e},{width:"150px",key:"type",title:(0,n.jsx)(f,{content:"type"}),sortable:!0,render:({type:e})=>(0,n.jsx)(f,{content:"SHARED"===e?"typeSharedHint":"typeExclusiveHint"})},J?{width:"60px",key:"resellersCount",title:(0,n.jsx)(f,{content:"resellerCount"}),sortable:!0,render:({id:e,resellersCount:t})=>(0,n.jsx)(r.default,{to:`${e}/clients`,children:t})}:null,R?null:{width:"60px",key:"subscriptionsCount",title:(0,n.jsx)(f,{content:"subscriptionCount"}),sortable:!0,render:({id:e,subscriptionsCount:t})=>(0,n.jsx)(r.default,{to:`${e}/domains`,children:t})}].filter((e=>e))),[U,J,R,T]);return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(i.Paragraph,{children:(0,n.jsx)(f,{content:J?"hintWithResellers":"hint"})}),(0,n.jsx)(i.List,{loadingRows:W,"data-type":"ip-address-list",loading:F,rowKey:"id",sortColumn:s.sortColumn,sortDirection:s.sortDirection,onSortChange:e=>{l(e),_(y(e))},columns:ne,selection:Q,onSelectionChange:e=>V(e),data:H,toolbar:se,totalRows:$,pagination:(0,n.jsx)(i.Pagination,{current:p.page,total:Z,onSelect:e=>{S((t=>({...t,page:e}))),_({page:e})},itemsPerPage:p.itemsPerPage,onItemsPerPageChange:e=>{const t={page:1,itemsPerPage:"all"===e?1e4:e};S(t),_(t)},itemsPerPageOptions:[10,25,100,"all"]}),emptyView:(0,n.jsxs)(n.Fragment,{children:[Y&&se,(0,n.jsx)(i.ListEmptyView,{actions:!Y&&te})]})})]})}},2103:(e,t,s)=>{s.r(t),s.d(t,{default:()=>p});var n=s(270),i=s(611),r=s(323),a=s(89),d=s(600),l=s(2104),o=s(592),c=s(2106);const p=(0,i.withPageLayout)((()=>{const e=(0,d.useApolloClient)(),t=(0,n.useCallback)((({task:t,query:s})=>{const n=()=>e.refetchQueries({include:["IpAddressPage",s]});if(t){const e=({id:s,status:i})=>{t?.id===s&&"done"===i&&(n(),a.Observer.remove(e,"plesk:taskComplete"))};a.Observer.append(e,"plesk:taskComplete")}else n()}),[e]);return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(l.default,{}),(0,n.jsx)(c.default,{onSuccess:t}),(0,n.jsx)(o.Outlet,{})]})}),(e=>{const{showFrames:t,pageHeader:s,pageSidebar:n}=(0,r.default)(),i=a.Locale.getSection("admin.controllers.ip-address.list").lmsg("title");return{...e,showFrames:t,pageHeader:{...s,helpMenu:{...s.helpMenu,helpContext:"ip-address.list"}},pageSidebar:n,pageContentHeader:{pageTitle:i,breadcrumbs:[n.isPowerUserPanel?null:{title:a.Locale.getSection("admin.controllers.home.admin").lmsg("title"),href:"/admin/home/"},{title:a.Locale.getSection("admin.controllers.server.tools").lmsg("title"),href:"/admin/server/tools/"},{title:i,href:"/cp/ip-address/"}].filter(Boolean)},pageTitle:i}}))},2102:(e,t,s)=>{s.r(t),s.d(t,{default:()=>n.default});var n=s(2103)},2105:(e,t,s)=>{s.r(t)}}]);
//# sourceMappingURL=list.js.map?d2cb2580e88917897aec