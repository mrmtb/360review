// Copyright 1999-2025. WebPros International GmbH. All rights reserved.

document.addEventListener('DOMContentLoaded', function () {
    Jsw.UAT.init({
        instanceId: Jsw.Cookie.get('uat-iid') || 'HWID.ISNO.TSET.0000.0000.0000.0000.0000',
        sessionId: Jsw.Cookie.get('uat-sid') || '0000',
        firehose: JSON.parse(atob('ewogICAgInN0cmVhbSI6ICJwbGVzay0xOC4wLXV4IiwKICAgICJub1Nlc3Npb25TdHJlYW0iOiAicGxlc2stMTguMC11eC1ub19zZXNzaW9uIiwKICAgICJyZWdpb24iOiAidXMtd2VzdC0yIiwKICAgICJhY2Nlc3NLZXlJZCI6ICJBS0lBUjRZRVlSSkxYUFpQWUJGTCIsCiAgICAic2VjcmV0QWNjZXNzS2V5IjogIlFzNHJPZXN0c1pOWjlvYzVrY2NXWlVrUUNXU2JrWnRQSEJibHRraTMiLAogICAgImVuZHBvaW50IjogImZpcmVob3NlLnVzLXdlc3QtMi5hbWF6b25hd3MuY29tIiwKICAgICJodHRwT3B0aW9ucyI6IHsKICAgICAgICAiY29ubmVjdFRpbWVvdXQiOiA1MDAwLAogICAgICAgICJ0aW1lb3V0IjogNTAwMAogICAgfQp9Cg==')),
    });
});
