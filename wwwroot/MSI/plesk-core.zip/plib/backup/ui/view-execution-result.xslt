<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright 1999-2025. WebPros International GmbH. All rights reserved. -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
	<xsl:output method="text" indent="no"/>
	<xsl:strip-space elements="*"/>
	<xsl:variable name="newline">
		<xsl:text>
</xsl:text>
	</xsl:variable>
	<xsl:variable name="tab">
		<xsl:text>	</xsl:text>
	</xsl:variable>
	<xsl:template match="message">
		<xsl:param name="indent"/>
		<xsl:value-of select="$indent"/><xsl:value-of select="description"/><xsl:value-of select="$newline"/>
		<xsl:if test="resolution">
			<xsl:value-of select="$indent"/>Resolution: <xsl:value-of select="resolution"/><xsl:value-of select="$newline"/>
		</xsl:if>
		<xsl:apply-templates select="message">
			<xsl:with-param name="indent" select="concat($indent,$tab)"/>
		</xsl:apply-templates>
	</xsl:template>
</xsl:stylesheet>
